package com.nokia.oss.smu.mail;


public interface MailSender {
	void sendHTML(String recipient, String subject, String html);
}
