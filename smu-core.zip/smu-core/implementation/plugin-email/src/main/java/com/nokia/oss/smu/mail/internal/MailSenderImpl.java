package com.nokia.oss.smu.mail.internal;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.nokia.oss.smu.mail.MailSender;
import com.nokia.oss.smu.mail.MailSenderException;
import com.nokia.oss.smu.settings.PreferenceService;

@Component
public class MailSenderImpl implements MailSender {

	private static final Logger LOGGER = Logger.getLogger(MailSenderImpl.class.getName());
	
	private static final int DEFAULT_SMTP_PORT = 25;
	public static final String DEFAULT_SENDER_ADDRESS = "smu@nowhere";
    private static final String DEFAULT_HOST_NAME = "host";

    @Resource
	private PreferenceService preferenceService;

	@Override
	public void sendHTML(String recipient, String subject, String html) {
		String smtpServer = this.preferenceService.getVariable(PreferenceService.SMTP_SERVER);
		if (smtpServer == null || smtpServer.isEmpty()) {
			LOGGER.warning("Preference \"" + PreferenceService.SMTP_SERVER + "\" has no value, skip for mail " +
					"sending.");
			return;
		}

		LOGGER.fine("Prepare SMTP client and message for notification.");
		Date now = new Date();
		JavaMailSenderImpl javaMailSender = new JavaMailSenderImpl();
		javaMailSender.setHost(smtpServer);
		javaMailSender.setPort(this.getPort());

		InternetAddress from = getSenderAddress();

		try {
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "UTF-8");
			helper.setFrom(from);
			helper.setTo(recipient);
			helper.setSentDate(now);
			helper.setSubject(subject);
			helper.setText(html, true);
			javaMailSender.send(mimeMessage);
		} catch (MessagingException ex) {
			throw new MailSenderException(ex);
		} catch (MailException ex) {
			String msg = "Unable send mail to target address";
			throw new MailSenderException(msg, ex);
		}
	}

	public InternetAddress getSenderAddress() {
		String hostName = DEFAULT_HOST_NAME;
		try {
		    hostName = InetAddress.getLocalHost().getHostName();
        }
        catch (UnknownHostException ex) {
            LOGGER.log(Level.WARNING, "Unable to determine host name", ex);
        }

        String sender = this.preferenceService.getVariable(PreferenceService.MAIL_SENDER);
        if (sender == null || sender.isEmpty()) {
            sender = DEFAULT_SENDER_ADDRESS;
        }

        InternetAddress address = new InternetAddress();
        address.setAddress(sender);
        try {
             address.setPersonal(DEFAULT_HOST_NAME);
			 address.setPersonal(hostName);
		} catch (UnsupportedEncodingException ex) {
			LOGGER.log(Level.WARNING, "Unsupported chars in host name, set default host name for sender", ex);
		}

		return address;
	}

	private int getPort() {
		String portText = this.preferenceService.getVariable(PreferenceService.SMTP_SERVER_PORT);
		try {
            LOGGER.fine("Setting for SMTP server port in preference: " + portText);
		    return Integer.valueOf(portText);
        } catch (NullPointerException | NumberFormatException ignored) {
            LOGGER.fine("Invalid or no port in preference, default to: " + DEFAULT_SMTP_PORT);
		    return DEFAULT_SMTP_PORT;
        }
	}
}
