package com.nokia.oss.smu.mail;

public class MailSenderException extends RuntimeException {

    private static final long serialVersionUID = 1764922412028280850L;

    public MailSenderException() {
        super();
    }

    public MailSenderException(String message, Throwable cause) {
        super(message, cause);
    }

    public MailSenderException(String message) {
        super(message);
    }

    public MailSenderException(Throwable cause) {
        super(cause);
    }
}
