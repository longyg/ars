package com.nokia.oss.smu.phc.impl;

import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.phc.*;
import com.nokia.oss.smu.phc.internal.PHCConfParser;
import com.nokia.oss.smu.phc.internal.PHCReportStreamFactory;
import com.nokia.oss.smu.phc.internal.PHCResultListener;
import com.nokia.oss.smu.phc.internal.PHCResultParser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

import static org.junit.Assert.assertEquals;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = PHCServiceImplTest.SpringConf.class)
public class PHCServiceImplTest {

    public static final String LOCK_FILE = "/var/opt/nokia/oss/global/NSN-mhcf/lockfile";
    @Resource
    private FakeSSHRepository sshRepository;

    @Resource
    private FakePreferenceService preferenceService;

    @Resource
    private PHCService phcService;

    @Before
    public void setup() {
        preferenceService.clear();
        sshRepository.clear();
        sshRepository.markLockFileExist = false;
    }

    @Test(expected = ExecutionLimitException.class)
    public void exceptionThrownWhenPerformCheckIfCheckingIsOngoing() {
        preferenceService.setVariable("phc.checking.state", "Running");
        sshRepository.markLockFileExist = true;
        phcService.performCheck();
    }

    @Test
    public void stateShouldBeMarkedAsStarting_IfCheckPerformStarted() {
        phcService.performCheck();
        String state = preferenceService.getVariable("phc.checking.state");
        assertEquals("Starting", state);
    }

    @Test
    public void stateShouldChangeToRunningAfterLockFileCreated() {
        phcService.performCheck();
        sshRepository.markLockFileExist = true;
        RunningInfo info = phcService.updateRunningState();
        assertEquals(RunningInfo.State.Running, info.getState());
    }

    @Test
    public void testSuiteMapShouldReturnRawData() {
        assertEquals(
                "{I=one, II=two, III=three}", 
                this.phcService.getTestSuiteMap().toString()
        );
    }

    @Configuration
    public static class SpringConf {
        @Bean(name = "phcService")
        public PHCServiceImpl getServiceImpl() {
            return new PHCServiceImpl();
        }

        @Bean(name = "phcSFTPRepository")
        public FakeSFTPRepository getSFTPRepo() {
            return new FakeSFTPRepository();
        }

        @Bean(name = "phcSSHRepository")
        public FakeSSHRepository getSSHRepo() {
            return new FakeSSHRepository();
        }

        @Bean
        public PHCMailSender getMailSender() {
            return new PHCMailSender() {
                
                @Override
                public void sendWarningOfPHCResultDelay() {
                }

                @Override
                public void sendErrorHTML(Collection<PHCResult> results) {
                }
            };
        }

        @Bean
        public FakePreferenceService prefService() {
            return new FakePreferenceService();
        }
        
        @Bean
        public PHCConfParser confParser() {
            return new PHCConfParser() {
                @Override
                public Map<String, String> getTestSuiteMap() {
                    Map<String, String> map = new LinkedHashMap<>();
                    map.put("I", "one");
                    map.put("II", "two");
                    map.put("III", "three");
                    return map;
                }
            };
        }
        
        @Bean
        public PHCResultParser resultParser() {
            return new PHCResultParser() {
                @Override
                public Map<String, PHCResult> getPHCResults() {
                    return null;
                }

                @Override
                public PHCResult getLatestPHCResult() {
                    return null;
                }

                @Override
                public void addListener(PHCResultListener listener) {}

                @Override
                public void removeListener(PHCResultListener listener) {}

                @Override
                public void checkResultChanges() {

                }
            };
        }
        
        @Bean
        public PHCReportStreamFactory reportStreamFactory() {
            return new PHCReportStreamFactory() {
                @Override
                public InputStream createOTHtmlStream(String target) throws IOException {
                    return null;
                }

                @Override
                public InputStream createXmlStream(String storage) throws IOException {
                    return null;
                }
            };
        }
    }

    private static class FakeSFTPRepository implements SFTPRepository {
        public Map<String, List<String>> path2Contents = new HashMap<>();

        @Override
        public FilePart readFilePart(String hostName, String fileName, long offset, long maxLen) {
            return null;
        }

        @Override
        public FilePart readFilePart(String hostName, String fileName, long offset, String user, String password,
                                     long maxLen) {
            return null;
        }
		
		@Override
		public void verifyPassword(String password)
		{
			
		}

        @Override
        public long getFileSize(String packagePath, String user, String password) {
            return 0;
        }

        @Override
        public void downloadFile(String packageName, String user, String password, long offset, OutputStream outStream ) {
        }
    }

    private static class FakeSSHRepository implements SSHRepository {
        public List<String> executedCommands = new ArrayList<>();
        public List<AsyncCallback> callbacks = new ArrayList<>();
        public boolean markLockFileExist;

        @Override
        public Set<AsyncTask> getAsyncTasks(Predicate p) {
            return null;
        }

        @Override
        public AsyncTask executeCommand(String command, Object id, AsyncCallback callback) {
            executedCommands.add(command);
            callbacks.add(callback);
            if (command.contains(LOCK_FILE)) {
                if (markLockFileExist) {
                    callback.stdout(null, LOCK_FILE);
                }

                callback.finish(null, null);
            }

            return null;
        }

        @Override
        public int executeAndWait(String command) {
            return 0;
        }

        public void clear() {
            executedCommands.clear();
            callbacks.clear();
        }
    }
}
