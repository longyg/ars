package com.nokia.oss.smu.phc;

import com.nokia.oss.smu.core.lifecycle.State;
import com.nokia.oss.smu.settings.PreferenceService;

import java.util.Collection;
import java.util.HashMap;

public class FakePreferenceService implements PreferenceService {
    HashMap<String, String> values = new HashMap<>();

    @Override
    public String getVariable(String name) {
        return values.get(name);
    }

    @Override
    public boolean isTrue(String variable) {
        return false;
    }

    @Override
    public Collection<String> getMultiVariable(String variableName) {
        return null;
    }

    @Override
    public void setVariable(String name, String value) {
        this.values.put(name, value);
    }

    @Override
    public void setVariableWithoutLock(String name, String value) {
        this.values.put(name, value);
    }

    @Override
    public void setMultiVariable(String variableName, Collection<String> variableValues) {

    }

    @Override
    public void start() throws Exception {

    }

    @Override
    public void stop() throws Exception {

    }

    @Override
    public State getState() {
        return null;
    }

    public void clear() {
        this.values.clear();
    }
}
