package com.nokia.oss.smu.phc.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.junit.Test;
import org.springframework.core.io.Resource;

import com.nokia.oss.smu.phc.PHCResult;
import com.nokia.oss.smu.phc.PHCResultException;

public class PHCResultParserImplTest {
    
    @Test
    public void withResultPath_notExist() {
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource();
        assertTrue(parser.getPHCResults().isEmpty());
    }
    
    @Test
    public void withResultFile_WrongFormat() {
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource("<?xml version='1.0'?><wrongFormat></wrongFormat>");
        assertTrue(parser.getPHCResults().isEmpty());
    }
    
    @Test
    public void withResultFile_NoData(){
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource("<?xml version='1.0'?><PHCReports></PHCReports>");
        assertTrue(parser.getPHCResults().isEmpty());
    }
    
    @Test
    public void withResultFile_OneReportAvailable() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>");
        Map<String, PHCResult> results = parser.getPHCResults();
        assertEquals(1, results.size());
        
        PHCResult result = results.get("/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201");        
        assertEquals(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse("2016-06-11T23:22:01+0300"),result.getStart());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse("2016-06-11T23:25:35+0300"),result.getEnd());
        assertEquals(100,result.getTotalCase());
        assertEquals(97,result.getPassedCase());
        assertEquals(3,result.getFilters().size());
    }
    
    @Test(expected =PHCResultException.class )
    public void withResultFile_OneReportAvailable_storageMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>");
        parser.getPHCResults();
    }
    
    @Test(expected =PHCResultException.class )
    public void withResultFile_OneReportAvailable_startTimeMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>");
        parser.getPHCResults();
    }
    
    @Test(expected =PHCResultException.class )
    public void withResultFile_OneReportAvailable_endTimeMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>");
        parser.getPHCResults();
    }
    
    @Test(expected =PHCResultException.class )
    public void withResultFile_OneReportAvailable_totalCaseMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>"
        );
        parser.getPHCResults();
    }
    
    @Test
    public void withResultFile_OneReportAvailable_passcaseMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
       parser.resultResource = new MockedResource(
               "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "<filters>"
                + "  <filter value='was'/>"
                + "  <filter value='cm'/>"
                + "  <filter value='pm'/>"
                + "</filters>"
                + "</Report></PHCReports>"
        );
        Map<String, PHCResult> results = parser.getPHCResults();
        assertEquals(1, results.size());
    }
    
    
    @Test
    public void withResultFile_OneReportAvailable_filtersMissing() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'"
                + ">"
                + "</Report></PHCReports>"
        );
        Map<String, PHCResult> results = parser.getPHCResults();
        PHCResult result = results.get("/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/20160611_232201");      
        
        assertEquals(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse("2016-06-11T23:22:01+0300"),result.getStart());
        assertEquals(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").parse("2016-06-11T23:25:35+0300"),result.getEnd());
        assertEquals(100,result.getTotalCase());
        assertEquals(97,result.getPassedCase());
        
        assertTrue(result.getFilters().isEmpty());
    }
    
    @Test
    public void withResultFile_2ReportAvailable() throws ParseException{
        PHCResultParserImpl parser = new PHCResultParserImpl();
        parser.resultResource = new MockedResource(
                "<?xml version='1.0'?><PHCReports>"
                + "<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/1'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'>"
                + "</Report>"
                +"<Report "
                + " ReportDir='/var/opt/nokia/oss/global/NSN-mhcf/mhcf/netact/2'"
                + " Begin='2016-06-11T23:22:01+0300'"
                + " End='2016-06-11T23:25:35+0300'"
                + " TestsCount='100'"
                + " TestsPassed='97'>"
                + "</Report></PHCReports>");
        Map<String, PHCResult> results = parser.getPHCResults();
        assertEquals(2, results.size());
    }
    
    @Test
    public void watchResultFile() {
        PHCResultParserImpl parser = new PHCResultParserImpl();
        MockedResource mockedResource = new MockedResource("<?xml version='1.0'?><PHCReports/>");
        parser.resultResource = mockedResource;
        parser.checkResultChanges();

        final int[] changedCountRef = new int[1];
        parser.addListener(new PHCResultListener() {
            @Override
            public void changed() {
                changedCountRef[0]++;
            }
        });

        parser.checkResultChanges();
        parser.checkResultChanges();
        assertEquals(0, changedCountRef[0]);
        
        mockedResource.lastModified++;
        parser.checkResultChanges();
        parser.checkResultChanges();

        assertEquals(1, changedCountRef[0]);  
    }
    
    private static class MockedResource implements Resource {
        
        long lastModified;
        
        byte[] xml;
        
        MockedResource() {}
        
        MockedResource(String xml) {
            this.xml = xml.getBytes();
        }
        
        @Override
        public boolean exists() {
            return this.xml != null;
        }

        @Override
        public InputStream getInputStream() throws IOException {
            if (this.xml == null) {
                throw new FileNotFoundException("xml is null");
            }
            return new ByteArrayInputStream(this.xml);
        }

        @Override
        public long contentLength() throws IOException {
            return this.xml.length;
        }

        @Override
        public Resource createRelative(String path) throws IOException {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getDescription() {
            return null;
        }

        @Override
        public File getFile() throws IOException {
            return null;
        }

        @Override
        public String getFilename() {
            return null;
        }

        @Override
        public URI getURI() throws IOException {
            return null;
        }

        @Override
        public URL getURL() throws IOException {
            return null;
        }

        @Override
        public boolean isOpen() {
            return false;
        }

        @Override
        public boolean isReadable() {
            return true;
        }

        @Override
        public long lastModified() throws IOException {
            return this.lastModified;
        }
    }
}
