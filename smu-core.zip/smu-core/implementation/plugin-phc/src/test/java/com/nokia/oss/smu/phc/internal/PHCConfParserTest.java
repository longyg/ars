package com.nokia.oss.smu.phc.internal;

import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.nokia.oss.smu.phc.PHCConfException;

public class PHCConfParserTest {
    
    private static final Charset UTF8 = Charset.forName("utf-8");

    @Test
    public void parseNonExisting() {
        try (AbstractApplicationContext ctx = createApplicationContext(null)) {
            ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.fail(PHCConfException.class + " is expected");
        } catch (PHCConfException ex) {
            Assert.assertTrue(ex.getCause() instanceof FileNotFoundException);
        }
    }
    
    @Test
    public void parseIllegalFormat() {
        try (AbstractApplicationContext ctx = createApplicationContext("<?xml version='1.0'?>\nIllegalFormat")) {
            ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.fail(PHCConfException.class + " is expected");
        } catch (PHCConfException ex) {
            Assert.assertTrue(ex.getCause() instanceof SAXParseException);
            SAXParseException saxParseException = (SAXParseException)ex.getCause();
            Assert.assertEquals(2, saxParseException.getLineNumber());
        }
    }
    
    @Test
    public void parseNoId() {
        try (AbstractApplicationContext ctx = createApplicationContext("<module name='rhel'/>")) {
            ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.fail(PHCConfException.class + " is expected");
        } catch (PHCConfException ex) {
            Assert.assertTrue(ex.getCause() instanceof SAXException);
            Assert.assertEquals("<module/> requires the attribute 'id'", ex.getCause().getMessage());
        }
    }
    
    @Test
    public void parseNoName() {
        try (AbstractApplicationContext ctx = createApplicationContext("<module id='1.1'/>")) {
            ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.fail(PHCConfException.class + " is expected");
        } catch (PHCConfException ex) {
            Assert.assertTrue(ex.getCause() instanceof SAXException);
            Assert.assertEquals("<module/> requires the attribute 'name'", ex.getCause().getMessage());
        }
    }
    
    @Test
    public void parseDuplicatedId() {
        String phcConfXml = 
                "<conf>"
                + "<module id='1' name='a'/>"
                + "<module id='1' name='b'/>"
                + "</conf>";
        try (AbstractApplicationContext ctx = createApplicationContext(phcConfXml)) {
            ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.fail(PHCConfException.class + " is expected");
        } catch (PHCConfException ex) {
            Assert.assertTrue(ex.getCause() instanceof SAXException);
            Assert.assertEquals("Several '<module/>' elements have the same id: 1", ex.getCause().getMessage());
        }
    }
    
    @Test
    public void parseCorrectConf() {
        String phcConfXml = 
                "<conf>"
                + "<module id='I' name='Alpha'/>"
                + "<module id='II' name='Belta'/>"
                + "<module id='III' name='Gamma'/>"
                + "</conf>";
        try (AbstractApplicationContext ctx = createApplicationContext(phcConfXml)) {
            Map<String, String> map = ctx.getBean(PHCConfParser.class).getTestSuiteMap();
            Assert.assertEquals("{I=Alpha, II=Belta, III=Gamma}", map.toString());
        }
    }
    
    private static AbstractApplicationContext createApplicationContext(String phcConfXml) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext() ;
        ctx.setResourceLoader(new MockResourceLoader(phcConfXml));
        ctx.register(SpringConfiguration.class);
        ctx.refresh();
        return ctx;
    }
    
    @Configuration
    static class SpringConfiguration {
        
        @Bean
        public PHCConfParser parser() {
            return new PHCConfParserImpl();
        }
        
        @Bean
        public PropertyPlaceholderConfigurer propertyConfigurer() {
            Properties properties = new Properties();
            properties.put("phc.checker.conf", "mock:phc-conf.xml");
            PropertyPlaceholderConfigurer configurer = new PropertyPlaceholderConfigurer();
            configurer.setProperties(properties);
            return configurer;
        }
    }
    
    private static class MockResourceLoader extends DefaultResourceLoader {

        private String phcConfXml;
        
        public MockResourceLoader(String phcConfXml) {
            this.phcConfXml = phcConfXml;
        }
        
        @Override
        public Resource getResource(String resourceName) {
            if (resourceName.equals("mock:phc-conf.xml") && this.phcConfXml != null) {
                return new ByteArrayResource(phcConfXml.getBytes(UTF8), resourceName);
            }
            return super.getResource(resourceName);
        }
    }
}
