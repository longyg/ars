package com.nokia.oss.smu.phc;

import java.util.Date;
import java.util.Set;

public class PHCResult {

    private String storage;
    
    private Date start;
    
    private Date end;
    
    private int totalCase;
    
    private int passedCase;
    
    private Set<String> filters;

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public int getTotalCase() {
        return totalCase;
    }

    public void setTotalCase(int totalCase) {
        this.totalCase = totalCase;
    }

    public int getPassedCase() {
        return passedCase;
    }

    public void setPassedCase(int passedCase) {
        this.passedCase = passedCase;
    }

    public Set<String> getFilters() {
        return filters;
    }

    public void setFilters(Set<String> filters) {
        this.filters = filters;
    }
}
