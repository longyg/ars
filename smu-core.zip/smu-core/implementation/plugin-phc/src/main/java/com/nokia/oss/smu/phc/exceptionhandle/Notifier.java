package com.nokia.oss.smu.phc.exceptionhandle;

public interface Notifier {
	void warnUserReportIsDelayed();
	void resetNotifyState();
}
