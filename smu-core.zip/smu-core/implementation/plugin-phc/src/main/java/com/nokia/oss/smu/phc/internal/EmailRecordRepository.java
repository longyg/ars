package com.nokia.oss.smu.phc.internal;

import java.util.Collection;
import java.util.List;

public interface EmailRecordRepository {

    List<String> getStorages();
    
    void add(String storage);
    
    void cleanupByAliveStorages(Collection<String> aliveStorages);
}
