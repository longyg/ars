package com.nokia.oss.smu.phc;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public interface PHCService {

    RunningInfo performCheck(String... ids);

    RunningInfo updateRunningState();

    Map<String, String> getTestSuiteMap();

    Map<String, PHCResult> getPHCResults();

    PHCResult getLatestResult();

    InputStream createReportStream(String target) throws IOException;
}
