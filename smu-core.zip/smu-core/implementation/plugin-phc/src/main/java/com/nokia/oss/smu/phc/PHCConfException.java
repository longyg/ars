package com.nokia.oss.smu.phc;

public class PHCConfException extends RuntimeException {

    private static final long serialVersionUID = 6070726737255296876L;

    public PHCConfException(String message, Throwable cause) {
        super(message, cause);
    }

    public PHCConfException(String message) {
        super(message);
    }
}
