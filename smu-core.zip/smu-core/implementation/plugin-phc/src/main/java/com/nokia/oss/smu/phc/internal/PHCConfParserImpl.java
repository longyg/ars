package com.nokia.oss.smu.phc.internal;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.nokia.oss.smu.phc.PHCConfException;

@Component
public class PHCConfParserImpl implements PHCConfParser {

    private static final Logger LOGGER = Logger.getLogger(PHCConfParser.class.getName());
    
    private static final String ELEMENT_MODULE = "module";
    
    private static final String ATTR_ID = "id";
    
    private static final String ATTR_NAME = "name";
    
    @Value("${phc.checker.conf}")
    private Resource confResource;
    
    public Map<String, String> getTestSuiteMap() {
        try (InputStream inputStream = this.confResource.getInputStream()) {
            SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            saxParserFactory.setNamespaceAware(true);
            SAXParser saxParser = saxParserFactory.newSAXParser();
            TestSuiteCollector collector = new TestSuiteCollector();
            saxParser.parse(inputStream, collector);
            return collector.map;
        } catch (IOException ex) {
            String message = "Cannot read the configuration file: " + this.confResource;
            LOGGER.log(Level.SEVERE, message, ex);
            throw new PHCConfException(message, ex);
        } catch (ParserConfigurationException ex) {
            String message = "Cannot create the XML SAX parser when parse the configuration file: " + this.confResource;
            LOGGER.log(Level.SEVERE, message, ex);
            throw new PHCConfException(message, ex);
        } catch (SAXException ex) {
            String message = "Illegal foramt of configuration file: " + this.confResource;
            LOGGER.log(Level.SEVERE, message, ex);
            throw new PHCConfException(message, ex);
        }
    }
    
    private static class TestSuiteCollector extends DefaultHandler {

        Map<String, String> map = new LinkedHashMap<>();
        
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if (ELEMENT_MODULE.equals(localName)) {
                String id = attributes.getValue(XMLConstants.NULL_NS_URI, ATTR_ID);
                if (id == null || id.isEmpty()) {
                    throw new SAXException("<module/> requires the attribute 'id'");
                }
                String name = attributes.getValue(XMLConstants.NULL_NS_URI, ATTR_NAME);
                if (name == null || name.isEmpty()) {
                    throw new SAXException("<module/> requires the attribute 'name'");
                }
                if (this.map.put(id, name) != null) {
                    throw new SAXException("Several '<module/>' elements have the same id: " + id);
                }
             }
        }
    }
}
