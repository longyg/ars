package com.nokia.oss.smu.phc;

public class ExecutionLimitException extends RuntimeException {

    private static final long serialVersionUID = 1665779930953998283L;

    public ExecutionLimitException(String message) {
		super(message);
	}

}
