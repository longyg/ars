package com.nokia.oss.smu.phc;

import java.util.Date;

public class RunningInfo {
    public enum State {
        NotRunning,
        Starting,
        Running,
        Failed,
        Completed
    }

    private State state;

    private Date lastCheckTime;

    private Date now;

    private String error;

    public RunningInfo() {
        now = new Date();
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public Date getLastCheckTime() {
        return lastCheckTime;
    }

    public void setLastCheckTime(Date lastCheckTime) {
        this.lastCheckTime = lastCheckTime;
    }

    public Date getNow() {
        return now;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
