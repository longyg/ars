package com.nokia.oss.smu.phc.internal;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.nokia.oss.smu.phc.HTMLGenerator;
import com.nokia.oss.smu.phc.PHCResultException;

@Component
public class HTMLGeneratorImpl implements HTMLGenerator {

    private static final String REPORT_TEMPLATES_IE = "phc_html_report.xsl";

    private Templates errorReportTemplates;

    @Override
    public void translateErrorToHTML(InputStream xmlStream, OutputStream output) {
        Document xmlDocument = createDOM(xmlStream);

        filterSuccessCases(xmlDocument);

        Document htmlDocument = translateToHtmlDocument(xmlDocument, getNoIndexReportTemplatesIE());

        removeHyperLinks(htmlDocument);

        try {
            TransformerFactory.newInstance().newTransformer().transform(
                    new DOMSource(htmlDocument),
                    new StreamResult(output)
            );
        } catch (TransformerException ex) {
            throw new PHCResultException("Cannot translate the xml to error html", ex);
        }
    }

    private void filterSuccessCases(Document xmlDocument) {
        try {
            removeNodes(xmlDocument.getDocumentElement(),
                    "/report/modules/module[not(tests/test/result[@failed != '0'])]");
            removeNodes(xmlDocument.getDocumentElement(),
                    "/report/modules/module/tests/test[not(result[@failed != '0'])]");
            removeNodes(xmlDocument.getDocumentElement(),
                    "/report/modules/module/tests/test/result/node[@result != 'failed']");
        } catch (XPathExpressionException ex) {
            throw new PHCResultException(ex);
        }
    }

    private void removeHyperLinks(Document htmlDocument) {
        try {
            Element element = htmlDocument.getDocumentElement();
            XPathExpression xpathExpression = XPathFactory.newInstance().newXPath().compile("//a");
            NodeList nodeList = (NodeList) xpathExpression.evaluate(element, XPathConstants.NODESET);
            for (int i = nodeList.getLength() - 1; i >= 0; i--) {
                Node node = nodeList.item(i);
                Node parentNode = node.getParentNode();
                Node childNode = node.getFirstChild();
                while (childNode != null) {
                    Node nextChildNode = childNode.getNextSibling();
                    parentNode.appendChild(childNode);
                    childNode = nextChildNode;
                }
                parentNode.removeChild(node);
            }

        } catch (XPathExpressionException ex) {
            throw new PHCResultException(ex);
        }
    }
    
    private Templates getNoIndexReportTemplatesIE() {
        if (errorReportTemplates == null) {
            errorReportTemplates = createTemplates(REPORT_TEMPLATES_IE, new XslFilter() {
                @Override
                public void filter(Document document) throws XPathExpressionException {
                    NodeList nodeList =
                            (NodeList)
                            XPathFactory
                            .newInstance()
                            .newXPath()
                            .compile("//div[@class='contents']")
                            .evaluate(document, XPathConstants.NODESET);
                    for (int i = nodeList.getLength() - 1; i >=0 ;i--) {
                        Node node = nodeList.item(i);
                        node.getParentNode().removeChild(node);
                    }
                }
            });
        }

        return errorReportTemplates;
    }

    private Document translateToHtmlDocument(Document xmlDocument, Templates templates) {
        try {
            Document htmlDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            templates.newTransformer().transform(
                    new DOMSource(xmlDocument),
                    new DOMResult(htmlDocument)
            );

            return htmlDocument;
        } catch (ParserConfigurationException ex) {
            throw new PHCResultException(ex);
        }
        catch (TransformerException ex) {
            throw new PHCResultException(ex);
        }
    }

    private Templates createTemplates(String templateResource, XslFilter xslFilter) {
        Templates reportTemplates;
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            InputStream xslStream = null;
            try {
                xslStream = getClass().getClassLoader().getResourceAsStream(templateResource);
                if (xslFilter == null) {
                    reportTemplates = tf.newTemplates(new StreamSource(xslStream));
                } else {
                    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                    dbf.setNamespaceAware(true);
                    Document doc = dbf.newDocumentBuilder().parse(xslStream);
                    xslFilter.filter(doc);
                    reportTemplates = tf.newTemplates(new DOMSource(doc));
                }
            }
            finally {
                if (xslStream != null) {
                    xslStream.close();
                }
            }
        } catch (Exception ex) {
            throw new PHCResultException("Can not load the original XSL DOM", ex);
        }

        return reportTemplates;
    }

    private static Document createDOM(InputStream xmlStream) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();
            return db.parse(xmlStream);
        } catch (ParserConfigurationException ex) {
            throw new PHCResultException(ex);
        }
        catch (SAXException ex) {
            throw new PHCResultException(ex);
        }
        catch (IOException ex) {
            throw new PHCResultException(ex);
        }
    }

    private static void removeNodes(Element element, String xpath) throws XPathExpressionException {
        XPathExpression xpathExpression = XPathFactory.newInstance().newXPath().compile(xpath);
        NodeList nodeList = (NodeList) xpathExpression.evaluate(element, XPathConstants.NODESET);
        for (int i = nodeList.getLength() - 1; i >= 0; i--) {
            Node node = nodeList.item(i);
            node.getParentNode().removeChild(node);
        }
    }

    private interface XslFilter {
        void filter(Document document) throws Exception;
    }
}
