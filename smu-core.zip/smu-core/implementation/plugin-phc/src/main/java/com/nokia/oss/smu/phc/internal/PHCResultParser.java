package com.nokia.oss.smu.phc.internal;

import java.util.Map;

import com.nokia.oss.smu.phc.PHCResult;

public interface PHCResultParser {

    Map<String, PHCResult> getPHCResults();
    
    PHCResult getLatestPHCResult();
    
    void addListener(PHCResultListener listener);
    
    void removeListener(PHCResultListener listener);

    void checkResultChanges();
}
