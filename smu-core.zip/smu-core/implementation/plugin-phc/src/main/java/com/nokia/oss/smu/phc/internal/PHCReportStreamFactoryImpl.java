package com.nokia.oss.smu.phc.internal;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.stereotype.Component;

@Component
public class PHCReportStreamFactoryImpl implements PHCReportStreamFactory {

    private static final String CLASS_PATH_PREFIX = "classpath:";
    
    @Override
    public InputStream createXmlStream(String storage) throws IOException {
        if (storage.charAt(storage.length() - 1) != '/') {
            storage = storage + '/';
        }
        if (storage.startsWith(CLASS_PATH_PREFIX)) {
            String resoruceName = storage.substring(CLASS_PATH_PREFIX.length()) + "report.xml";
            return PHCReportStreamFactoryImpl.class.getClassLoader().getResourceAsStream(resoruceName);
        }
        
        File file = new File(storage);
        if (!file.exists()) {
            throw new IllegalArgumentException("The storage \"" + storage + "\" is does not exists");
        }
        
        for (String fileName : file.list()) {
            if (fileName.endsWith("Check.xml")) {
                return new FileInputStream(storage + fileName);
            }
        }
        throw new IllegalArgumentException(
                "No file whose name ends with \"Check.xml\" under the directory \""
                + storage
                + "\""
        );
    }

    @Override
    public InputStream createOTHtmlStream(String storage) throws IOException {
        if (storage.charAt(storage.length() - 1) != '/') {
            storage = storage + '/';
        }
        if (storage.startsWith(CLASS_PATH_PREFIX)) {
            String resoruceName = storage.substring(CLASS_PATH_PREFIX.length()) + "report.html";
            return PHCReportStreamFactoryImpl.class.getClassLoader().getResourceAsStream(resoruceName);
        }
        
        File file = new File(storage);
        if (!file.exists()) {
            throw new IllegalArgumentException("The storage \"" + storage + "\" is does not exists");
        }
        
        final String suffix = "_Check_Report.html";
        for (String fileName : file.list()) {
            if (fileName.endsWith(suffix)) {
                return new FileInputStream(storage + fileName);
            }
        }
        throw new IllegalArgumentException(
                "No file whose name ends with \"" + suffix + "\" under the directory \""
                + storage
                + "\""
        );
    }
}
