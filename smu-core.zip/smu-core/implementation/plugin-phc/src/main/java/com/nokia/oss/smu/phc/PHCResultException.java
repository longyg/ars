package com.nokia.oss.smu.phc;

public class PHCResultException extends RuntimeException{

    private static final long serialVersionUID = -8349975487413896488L;

    public PHCResultException(String message) {
        super(message);
    }
    
    public PHCResultException(Throwable cause) {
        super(cause);
    }

    public PHCResultException(String message, Throwable cause) {
        super(message, cause);
    }
}
