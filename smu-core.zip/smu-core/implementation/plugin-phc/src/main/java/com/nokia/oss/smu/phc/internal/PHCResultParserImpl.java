package com.nokia.oss.smu.phc.internal;

import com.nokia.oss.smu.core.util.LogUtils;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.phc.PHCResult;
import com.nokia.oss.smu.phc.PHCResultException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class PHCResultParserImpl implements PHCResultParser {
    
    private static final Logger LOGGER = Logger.getLogger(PHCConfParser.class.getName());
    
    private static final String ELEMENT_PHC_RESULT = "Report";
    
    private static final String ELEMENT_FILTER = "filter";
    
    private static final String ATTR_STORAGE = "ReportDir";
    
    private static final String ATTR_START = "Begin";
    
    private static final String ATTR_END = "End";
    
    private static final String ATTR_TOTAL_CASE = "TestsCount";
    
    private static final String ATTR_PASSED_CASE = "TestsPassed";
    
    private static final String ATTR_VALUE = "value";
    
    private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
    
    @Value("${phc.checker.result}")
    Resource resultResource;
    
    private CopyOnWriteArrayList<PHCResultListener> listeners = new CopyOnWriteArrayList<>();
    
    private Cache cache;
    
    private AtomicBoolean changed = new AtomicBoolean();
    
    @Override
    public Map<String, PHCResult> getPHCResults() {
        return this.getNewestCache().cloneResults();
    }
    
    @Override
    public PHCResult getLatestPHCResult() {
        return this.getNewestCache().cloneLatestResult();
    }
    
    @Override
    public void addListener(PHCResultListener listener) {
        if (listener != null) {
            this.listeners.add(listener);
        }
    }

    @Override
    public void removeListener(PHCResultListener listener) {
        this.listeners.remove(listener);
    }

    @Override
    @Synchronized(lockName = "phc.checker.result.watcher", nowait = true)
    public void checkResultChanges() {
        LOGGER.fine("check phc result changes start");
        this.getNewestCache();
        if (this.changed.compareAndSet(true, false)) {
            for (PHCResultListener listener : this.listeners) {
                LOGGER.info("PHC result changed. ");
                listener.changed();
            }
        }
        LOGGER.fine("check phc result changes done");
    }

    private synchronized Cache getNewestCache() {
        if (this.cache == null || !this.cache.isValid()) {
            this.cache = this.new Cache();
            this.changed.set(true);
        }
        return this.cache;
    }
    
    private Map<String, PHCResult> parseResults() {
        try {
            InputStream inputStream = this.resultResource.getInputStream();
            
            SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            saxParserFactory.setNamespaceAware(true);
            PHCResultCollector collector = new PHCResultCollector();
            SAXParser parser = saxParserFactory.newSAXParser();
            
            parser.parse(inputStream, collector);
            return collector.map;
        } catch (IOException ex) {
            if (!this.resultResource.exists()) {
                return Collections.emptyMap();
            }
            LOGGER.log(Level.SEVERE, "phc result file is not exsits : " + resultResource.getFilename(), ex);
            throw new PHCResultException("cannot parse phc result files; due to "+ex.getMessage());
        } catch (ParserConfigurationException | SAXException ex) {
            LOGGER.severe("cannot parse phc result files; due to " + LogUtils.getChainedCauses(ex));
            throw new PHCResultException("cannot parse phc result files; due to "+ex.getMessage());
        }
    }
    
    private static class PHCResultCollector extends DefaultHandler {
        
        Map<String, PHCResult> map = new LinkedHashMap<>();
        
        PHCResult currentResult;

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if (ELEMENT_PHC_RESULT.equals(localName)) {
                if (this.currentResult != null) {
                    throw new SAXException("Nested <" + ELEMENT_PHC_RESULT + "/> is not allowed");
                }
                PHCResult phcResult = new PHCResult();
                phcResult.setStorage(getResultAttribute(attributes, ATTR_STORAGE, String.class));
                if (this.map.put(phcResult.getStorage(), phcResult) != null) {
                    throw new SAXException(
                            "Duplicated <" +
                            ELEMENT_PHC_RESULT +
                            "/> with the same " +
                            ATTR_STORAGE +
                            ": " +
                            phcResult.getStorage()
                    );
                }
                phcResult.setStart(getResultAttribute(attributes, ATTR_START, Date.class));
                phcResult.setEnd(getResultAttribute(attributes, ATTR_END, Date.class));
                phcResult.setTotalCase(getResultAttribute(attributes, ATTR_TOTAL_CASE, Integer.class));
                phcResult.setPassedCase(getResultAttribute(attributes, ATTR_PASSED_CASE, Integer.class));
                phcResult.setFilters(new LinkedHashSet<String>());
                this.currentResult = phcResult;
            } else if (ELEMENT_FILTER.equals(localName)) {
                if (this.currentResult == null) {
                    throw new SAXException("<" + ELEMENT_FILTER + "/> must be declared under <" + ELEMENT_PHC_RESULT + "/>");
                }
                String value = attributes.getValue(XMLConstants.NULL_NS_URI, ATTR_VALUE);
                if (value == null || value.isEmpty()) {
                    throw new SAXException("<" + ELEMENT_FILTER + "/> requires the attribute \"" + ATTR_VALUE + '"');
                }
                this.currentResult.getFilters().add(value);
            }
        }
        
        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (ELEMENT_PHC_RESULT.equals(localName)) {
                this.currentResult = null;
            }
        }

        @SuppressWarnings("unchecked")
        private static <T> T getResultAttribute(Attributes attributes, String localName, Class<T> type) throws SAXException {
            String value = attributes.getValue(XMLConstants.NULL_NS_URI, localName);
            if (value == null || value.isEmpty()) {
                
                throw new SAXException(
                        "<" + 
                        ELEMENT_PHC_RESULT +
                        storageAttribute(attributes) +
                        "\"/> requires attribute \"" + 
                        localName + 
                        "\""
                );
            }
            if (type == Date.class) {
                try {
                    return (T)new SimpleDateFormat(DATE_FORMAT).parse(value);
                } catch (IllegalArgumentException | ParseException ex) {
                    throw new SAXException(
                            "The attribute \"" +
                             localName +
                            "\" of <" + 
                            ELEMENT_PHC_RESULT +
                            storageAttribute(attributes) +
                            "\"/> cannot match the format \"" +
                            DATE_FORMAT +
                            '"'
                    );
                }
            }
            if (type == Integer.class) {
                try {
                    return (T)new Integer(Integer.parseInt(value));
                } catch (NumberFormatException ex) {
                    throw new SAXException(
                            "The attribute \"" +
                             localName +
                            "\" of <" + 
                            ELEMENT_PHC_RESULT +
                            storageAttribute(attributes) +
                            "\"/> must be an integer"
                    );
                }
            }
            
            if (type == String.class) {
                    return (T) new String(value);
            }

            return (T)type;
        }
        
        private static String storageAttribute(Attributes attributes) {
            String storage = attributes.getValue(XMLConstants.NULL_NS_URI, ATTR_STORAGE);
            if (storage != null && storage.isEmpty()) {
                return ' ' + ATTR_STORAGE + "=\"" + storage + '"';
            }
            return "";
        }
    }
    
    private class Cache {
        
        private Map<String, PHCResult> results;
        
        private PHCResult latestResult;
        
        private long lastModified;
        
        Cache() {
            this.results = PHCResultParserImpl.this.parseResults();
            this.lastModified = this.resourceModified();
            PHCResult latestResult = null;
            for (PHCResult result : this.results.values()) {
                if (latestResult == null || latestResult.getEnd().compareTo(result.getEnd()) < 0) {
                    latestResult = result;
                }
            }
            this.latestResult = latestResult;
        }
        
        boolean isValid() {
            return this.lastModified == this.resourceModified();
        }
        
        Map<String, PHCResult> cloneResults() {
            Map<String, PHCResult> clonedMap = new LinkedHashMap<>((this.results.size() * 4 + 2) / 3);
            for (Entry<String, PHCResult> entry : this.results.entrySet()) {
                clonedMap.put(entry.getKey(), this.clone(entry.getValue()));
            }
            return clonedMap;
        }
        
        PHCResult cloneLatestResult() {
            if (this.latestResult == null) {
                return this.latestResult;
            }
            return clone(this.latestResult);
        }
        
        private PHCResult clone(PHCResult result) {
            PHCResult cloned = new PHCResult();
            cloned.setStorage(result.getStorage());
            cloned.setStart(result.getStart());
            cloned.setEnd(result.getEnd());
            cloned.setPassedCase(result.getPassedCase());
            cloned.setTotalCase(result.getTotalCase());
            cloned.setFilters(Collections.unmodifiableSet(result.getFilters()));
            return cloned;
        }
        
        private long resourceModified() {
            Resource resource = PHCResultParserImpl.this.resultResource;
            try {
                return resource.lastModified();
            } catch (IOException ex) {
                return 0;
            }
        }
    }
}
