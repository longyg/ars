package com.nokia.oss.smu.phc.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SMU_EMAIL_RECORD")
public class EmailRecord {

    @Id
    @Column(name = "STORAGE", length = 512, nullable = false)
    private String storage;

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }
}