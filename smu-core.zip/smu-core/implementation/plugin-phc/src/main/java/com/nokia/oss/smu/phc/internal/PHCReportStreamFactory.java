package com.nokia.oss.smu.phc.internal;

import java.io.IOException;
import java.io.InputStream;

public interface PHCReportStreamFactory {
    
    InputStream createXmlStream(String storage) throws IOException;
    
    InputStream createOTHtmlStream(String storage) throws IOException;
}
