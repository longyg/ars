package com.nokia.oss.smu.phc.impl;

import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.phc.*;
import com.nokia.oss.smu.phc.internal.PHCConfParser;
import com.nokia.oss.smu.phc.internal.PHCReportStreamFactory;
import com.nokia.oss.smu.phc.internal.PHCResultListener;
import com.nokia.oss.smu.phc.internal.PHCResultParser;
import com.nokia.oss.smu.settings.PreferenceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import static java.util.logging.Logger.getLogger;

@Service
public class PHCServiceImpl implements PHCService, ApplicationListener<ContextRefreshedEvent> {
    private static final Logger LOG = getLogger(PHCServiceImpl.class.getName());

    private static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS Z";
    private static final String CHECKING_STATE = "phc.checking.state";
    private static final String LAST_CHECK_TIME = "phc.checking.lastCheckTime";
    private static final String LAST_CHECK_ERROR = "phc.checking.lastError";
    private static final String PHC_COMMAND = "/opt/oss/bin/mhcf.pl -c /opt/oss/NSN-mhcf/product/netact/cfg.netact.xml";
    private static final String LOCK_FILE = "/var/opt/nokia/oss/global/NSN-mhcf/lockfile";
    private static final long STARTING_TIMEOUT = 60 * 1000;
    private static final int FINISH_WITH_FAILED_TESTS_RC = 1;
    private static final int FINISH_WITH_ALL_TESTS_PASS_RC = 0;
    private static final int STATE_RESET_RETRIES = 5;

    @Resource
    private SSHRepository sshRepository;

    @Resource
    private PreferenceService preferenceService;

    @Resource
    private PHCConfParser confParser;
    
    @Resource
    private PHCResultParser resultParser;
    
    @Resource
    private PHCReportStreamFactory reportStreamFactory;
    
    @Resource
    private PHCMailSender phcMailSender;

    @Override
    @Synchronized(lockName = "phc.report.update.lock")
    public RunningInfo performCheck(String... ids) throws ExecutionLimitException {
        checkAndMarkStartingState();
        String command = PHC_COMMAND;
        if (ids != null && ids.length > 0) {
            command += " -f " + StringUtils.join(ids, ",");
        }

        sshRepository.executeCommand(command, null, new SSHRepository.AsyncCallback() {
            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                String cleanedLine = cleanColorCodes(line).trim();
                if (cleanedLine.startsWith("ERROR:")) {
                    stderr(asyncTask, cleanedLine.replaceFirst("ERROR:", "PHC report an error:"));
                    return;
                }

                LOG.fine("Read PHC output line: " + cleanedLine);
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) {
                LOG.severe("Error message found executing PHC: " + line);
                preferenceService.setVariableWithoutLock(LAST_CHECK_ERROR, line);
            }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                updateExecutionResult(asyncTask, ex);
            }

            private String cleanColorCodes(String line) {
                Pattern ansiCodes = Pattern.compile("\\x1B\\[([0-9]{1,2}(;[0-9]{1,2})?)?[mGK]");
                return ansiCodes.matcher(line).replaceAll("");
            }

        });

        return updateRunningState();
    }

    @Transactional
    public void checkAndMarkStartingState() {
        RunningInfo.State currentState = updateRunningState().getState();
        if (currentState.equals(RunningInfo.State.Starting) || currentState.equals(RunningInfo.State.Running)) {
            throw new ExecutionLimitException("Checking is ongoing");
        }

        preferenceService.setVariableWithoutLock(LAST_CHECK_ERROR, null);
        preferenceService.setVariableWithoutLock(CHECKING_STATE, RunningInfo.State.Starting.name());
        preferenceService.setVariableWithoutLock(LAST_CHECK_TIME, new SimpleDateFormat(TIME_FORMAT).format(new Date()));
    }

    @Transactional
    public void updateExecutionResult(SSHRepository.AsyncTask task, Throwable ex) {
        RunningInfo.State state = RunningInfo.State.Completed;
        Integer returnCode = task.getReturnCode();
        if (ex != null) {
            LOG.severe("Failed to perform a check due to an error: " + ex.getMessage());
            state = RunningInfo.State.Failed;
            preferenceService.setVariableWithoutLock(LAST_CHECK_ERROR, ex.getMessage());
        } else if (returnCode == null) {
            LOG.severe("Exit code of PHC execution not caught, unable to determine execution result, mark it failed.");
            state = RunningInfo.State.Failed;
        } else if (returnCode != FINISH_WITH_ALL_TESTS_PASS_RC
                && returnCode != FINISH_WITH_FAILED_TESTS_RC) {
            LOG.severe("PHC invocation exit with code " + returnCode + ", mark this check as a failure");
            state = RunningInfo.State.Failed;
        }

        preferenceService.setVariableWithoutLock(CHECKING_STATE, state.name());
        LOG.info("SSH execute finished, ex=" + ex  + ", rc=" + returnCode);
    }

    /**
     * Handling application initialization for check and reset PHC executing state
     * This is an action preventing unexpected shutting down of application during
     * Executing PHC check.
     * A better way to handle synchronization problem is needed still.
     * @param event
     */
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        new Thread() {
            @Override
            public void run() {
                int retries = STATE_RESET_RETRIES;
                try {
                    while (retries-- > 0) {
                        LOG.info("Check and reset PHC state after a while.");
                        Thread.sleep(5000);
                        try {
                            checkAndResetExecutingState();
                            return;
                        } catch (IllegalStateException ex){
                            LOG.severe("Unable to check and reset PHC executing state.");
                        }
                    }
                } catch (InterruptedException e) {
                    LOG.severe("PHC execution state resetting is interrupted");
                }
            }
        }.start();
    }

    @Transactional
    public void checkAndResetExecutingState() {
        RunningInfo.State state = getStateFromPreference();
        // Starting phase still missed from check, no way to guarantee
        if (RunningInfo.State.Running.equals(state) && !lockFileExist()) {
            LOG.info("PHC Running state mismatch, mark as not running");
            preferenceService.setVariableWithoutLock(CHECKING_STATE, RunningInfo.State.NotRunning.name());
        }
    }

    @Override
    @Transactional
    public RunningInfo updateRunningState() {
        RunningInfo info = new RunningInfo();
        RunningInfo.State state = getStateFromPreference();
        String lastCheckTime = preferenceService.getVariable(LAST_CHECK_TIME);
        Date startTime = parseDate(lastCheckTime);
        if (RunningInfo.State.Starting.equals(state)) {
            if (lockFileExist()) {
                state = RunningInfo.State.Running;
            }
            else if (timeout(startTime, STARTING_TIMEOUT)){
                state = RunningInfo.State.Failed;
            }
        }
        else if(RunningInfo.State.Running.equals(state)) {
            if (!lockFileExist()) {
                state = RunningInfo.State.Failed;
            }
        }

        info.setLastCheckTime(startTime);
        info.setError(preferenceService.getVariable(LAST_CHECK_ERROR));
        info.setState(state);
        return info;
    }

    private boolean timeout(Date from, long timeout) {
        return (new Date().getTime() - from.getTime() > timeout);
    }

    @Override
    public Map<String, String> getTestSuiteMap() {
        return this.confParser.getTestSuiteMap();
    }

    @Override
    public Map<String, PHCResult> getPHCResults() {
        return this.resultParser.getPHCResults();
    }
    
    @Override
    public PHCResult getLatestResult() {
        return this.resultParser.getLatestPHCResult();
    }

    @Override
    public InputStream createReportStream(String target) throws IOException {
        return this.reportStreamFactory.createOTHtmlStream(target);
    }

    @PostConstruct
    public void onServiceStart() {
        this.resultParser.addListener(new PHCResultListener() {
            @Override
            public void changed() {
                PHCServiceImpl.this.onResultChanged();
            }
        });
    }

    @PreDestroy
    public void onServiceStop() {
    }

    private RunningInfo.State getStateFromPreference() {
        try {
            return RunningInfo.State.valueOf(preferenceService.getVariable(CHECKING_STATE));
        } catch (IllegalArgumentException | NullPointerException ignored) {
            LOG.fine("No value set for phc checking state in preference.");
            return RunningInfo.State.NotRunning;
        }
    }

    private boolean lockFileExist() {
        final Semaphore waitLockCheck = new Semaphore(0);
        final boolean[] lockFileExist = new boolean[1];
        sshRepository.executeCommand("ls " + LOCK_FILE + " 2>/dev/null", null, new SSHRepository.AsyncCallback() {

            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                lockFileExist[0] = line.contains(LOCK_FILE);
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) { }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                waitLockCheck.release();
            }
        });

        try {
            waitLockCheck.acquire(1);
        } catch (InterruptedException e) {
            LOG.warning("Checking PHC lock file has been interrupted.");
        }

        LOG.info("Lock file " + (lockFileExist[0] ? "found" : " not found"));

        return lockFileExist[0];
    }

    private Date parseDate(String input) {
        if (input == null || input.isEmpty()) {
            return null;
        }

        SimpleDateFormat formatter = new SimpleDateFormat(TIME_FORMAT);
        try {
            return formatter.parse(input);
        } catch (ParseException e) {
            return null;
        }
    }
    
    private void onResultChanged() {
        Map<String, PHCResult> results = this.resultParser.getPHCResults();
        this.phcMailSender.sendErrorHTML(results.values());
    }

}

