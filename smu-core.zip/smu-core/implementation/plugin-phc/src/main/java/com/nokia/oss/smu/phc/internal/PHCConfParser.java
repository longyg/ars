package com.nokia.oss.smu.phc.internal;

import java.util.Map;

public interface PHCConfParser {

    Map<String, String> getTestSuiteMap();
}
