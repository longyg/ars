package com.nokia.oss.smu.phc.internal;

public interface PHCResultListener {

    void changed();
}
