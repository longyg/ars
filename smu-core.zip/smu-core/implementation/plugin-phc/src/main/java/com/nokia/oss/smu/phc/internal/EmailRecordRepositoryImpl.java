package com.nokia.oss.smu.phc.internal;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.phc.entities.EmailRecord;
import com.nokia.oss.smu.phc.entities.EmailRecord_;

@Repository
public class EmailRecordRepositoryImpl implements EmailRecordRepository {

    @PersistenceContext
    private EntityManager em;
    
    @Override
    public List<String> getStorages() {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaQuery<String> cq = cb.createQuery(String.class);
        Root<EmailRecord> emailRecord = cq.from(EmailRecord.class);
        cq.select(emailRecord.get(EmailRecord_.storage));
        return this.em.createQuery(cq).getResultList();
    }

    @Override
    public void add(String storage) {
        EmailRecord emailRecord = new EmailRecord();
        emailRecord.setStorage(storage);
        this.em.persist(emailRecord);
    }

    @Override
    public void cleanupByAliveStorages(Collection<String> aliveStorages) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        if (aliveStorages.isEmpty()) {
            CriteriaDelete<EmailRecord> cd = cb.createCriteriaDelete(EmailRecord.class);
            cd.from(EmailRecord.class);
            this.em.createQuery(cd).executeUpdate();
        } else {
            Iterator<String> itr = aliveStorages.iterator();
            while (itr.hasNext()) {
                CriteriaDelete<EmailRecord> cd = cb.createCriteriaDelete(EmailRecord.class);
                Root<EmailRecord> emailRecord = cd.from(EmailRecord.class);
                In<String> in = cb.in(emailRecord.get(EmailRecord_.storage));
                for (int i = 1000; i > 0 && itr.hasNext(); --i) {
                    in.value(itr.next());
                }
                cd.where(cb.not(in));
                this.em.createQuery(cd).executeUpdate();
            }
        }
    }
}
