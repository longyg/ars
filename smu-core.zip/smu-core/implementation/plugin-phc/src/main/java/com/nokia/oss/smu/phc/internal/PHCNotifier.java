package com.nokia.oss.smu.phc.internal;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.phc.PHCMailSender;
import com.nokia.oss.smu.phc.exceptionhandle.Notifier;
import com.nokia.oss.smu.settings.PreferenceService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.logging.Logger;

@Component
public class PHCNotifier implements Notifier {

    private static Logger LOG = Logger.getLogger(PHCNotifier.class.getName());

    @Resource
    private PHCMailSender mailSender;

    @Resource
    private PreferenceService preferenceService;

    @Override
    public void warnUserReportIsDelayed() {
        if (this.preferenceService.isTrue(PreferenceService.PHC_DELAY_NOTIFIED)) {
            LOG.finest("The mail about report delay has been sent already earlier, do nothing");
            return;
        }
        LOG.info("Sending warning mail to user about report delay.");
        mailSender.sendWarningOfPHCResultDelay();
        this.preferenceService.setVariableWithoutLock(PreferenceService.PHC_DELAY_NOTIFIED, "true");
        LOG.info("Warning mail sent to user about report delay.");
    }

    @Override
    public void resetNotifyState() {
        if (this.preferenceService.isTrue(PreferenceService.PHC_DELAY_NOTIFIED)) {
            this.preferenceService.setVariableWithoutLock(PreferenceService.PHC_DELAY_NOTIFIED, "false");
            LOG.info("Reset the PHC report delay notify state to false.");
        }
    }
}
