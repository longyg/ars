package com.nokia.oss.smu.phc;

import java.io.InputStream;
import java.io.OutputStream;

public interface HTMLGenerator {

    void translateErrorToHTML(InputStream xmlStream, OutputStream output);
}
