package com.nokia.oss.smu.phc.internal;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.phc.PHCResult;
import com.nokia.oss.smu.phc.exceptionhandle.Notifier;
import com.nokia.oss.smu.settings.PreferenceService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

@Component
public class PHCReportDelayChecker {

	private static final int REPORT_DELAY_THRESHOLD = 72 * 60 * 60 * 1000;
	
	@Resource
	private Notifier notifier;
	
	@Resource
	private PHCResultParser resultParser;

    private Date latestReportTime;
	
	private static final Logger LOG = getLogger(PHCReportDelayChecker.class.getName());

    @Synchronized(lockName = "phcdelay.email.sending.lock", nowait = true)
    @Transactional
    public void checkAndSendMail() {
        Date latestReportTime = getLatestReportTime();

        if (isReportDelayed(latestReportTime)) {
            LOG.finest("Report is not updated for " + REPORT_DELAY_THRESHOLD/1000 + " seconds, warn the user ");
            notifier.warnUserReportIsDelayed();
        } else {
            LOG.finest("latest report time is " + latestReportTime);
            notifier.resetNotifyState();
        }
    }

    private boolean isReportDelayed(Date latestReportTime) {
        Date now = new Date();
        return now.after(new Date(latestReportTime.getTime() + REPORT_DELAY_THRESHOLD));
    }

    private Date getLatestReportTime() {
	    PHCResult latestResult = this.resultParser.getLatestPHCResult();
	    if (latestResult != null && latestResult.getEnd() != null) {
            this.latestReportTime = latestResult.getEnd();
        } else if (this.latestReportTime == null) {
            //init the report time as the application start time if there are no report yet only once.
            LOG.info("No PHC report time available, use current time as the latest report time");
            this.latestReportTime = new Date();
        }
        return this.latestReportTime;
	}
}
