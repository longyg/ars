package com.nokia.oss.smu.phc;

import java.util.Collection;

public interface PHCMailSender {

    void sendErrorHTML(Collection<PHCResult> results);

    void sendWarningOfPHCResultDelay();
}
