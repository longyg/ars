package com.nokia.oss.smu.phc.internal;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;

import com.nokia.oss.smu.mail.MailSenderException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.mail.MailSender;
import com.nokia.oss.smu.phc.HTMLGenerator;
import com.nokia.oss.smu.phc.PHCMailSender;
import com.nokia.oss.smu.phc.PHCResult;
import com.nokia.oss.smu.settings.PreferenceService;

@Component
public class PHCMailSenderImpl implements PHCMailSender {

    private static final Logger LOGGER = Logger.getLogger(PHCMailSenderImpl.class.getName());
    
    private static final Charset UTF_8 = Charset.forName("utf-8");

    @Resource
    private PreferenceService preferenceService;

    @Resource
    private MailSender mailSender;
    
    @Resource
    private PHCResultParser resultParser;

    @Resource
    private HTMLGenerator htmlGenerator;
    
    @Resource
    private PHCReportStreamFactory reportStreamFactory;
    
    @Resource
    private EmailRecordRepository emailRecordRepository;

    @Override
    @Synchronized(lockName = "phc.email.sending.lock")
    @Transactional
    public void sendErrorHTML(Collection<PHCResult> results) {
        
        Set<String> aliveStorages = new HashSet<String>((results.size() * 4 + 2) / 3);
        for (PHCResult result : results) {
            aliveStorages.add(result.getStorage());
        }
        
        /*
         * In order to optimize, these two SQL statements are batch.
         */
        this.emailRecordRepository.cleanupByAliveStorages(aliveStorages);
        List<String> sentStorages = this.emailRecordRepository.getStorages();
        
        for (PHCResult result : results) {
            if (!sentStorages.contains(result.getStorage())) {
                this.emailRecordRepository.add(result.getStorage());
                try {
                    this.sendErrorHTML(result);
                } catch (RuntimeException | Error ex) {
                    String message = 
                            "Unexpected exception whens send the phc result whose storage is \""
                            + result.getStorage()
                            + "\"";
                    LOGGER.log(Level.SEVERE, message, ex);
                }
            }
        }
    }
    
    private void sendErrorHTML(PHCResult result) {
        if (!this.preferenceService.isTrue(PreferenceService.ENABLED_FOR_PHC_CHECKER)) {
            LOGGER.info("The email notification for phc checker is disabled, so it's unnecessary to send the email");
            return;
        }

        Collection<String> recipients = getRecipients();
        if (recipients.isEmpty()) {
            LOGGER.info("Mail notification skipped due to no recipient set");
            return;
        }

        int failedCount = result.getTotalCase() - result.getPassedCase();
        if (failedCount > 0) {
            byte[] htmlBytes;
            LOGGER.info(
                    "Prepare to send mail for the error PHC result whose storage is \""
                    + result.getStorage()
                    + "\"");
            try (InputStream xmlStream = this.reportStreamFactory.createXmlStream(result.getStorage())) {
                try (ByteArrayOutputStream htmlStream = new ByteArrayOutputStream()) {
                    this.htmlGenerator.translateErrorToHTML(xmlStream, htmlStream);
                    htmlBytes = htmlStream.toByteArray();
                }
            } catch (RuntimeException | Error | IOException ex) {
                String message = 
                        "Cannot prepare mail content for the phc result whose storage is \""
                        + result.getStorage()
                        + "\"";
                LOGGER.log(Level.SEVERE, message, ex);
                return;
            }
            
            String subject = "PHC tests failed: " + failedCount + " failures / " + result.getTotalCase() + " total tests";
            String html = new String(htmlBytes, UTF_8);
            for (String address : recipients) {
                try {
                    mailSender.sendHTML(address, subject, html);
                } catch (MailSenderException ex) {
                    LOGGER.log(Level.SEVERE, "Cannot send mail for the phc result", ex);
                }
            }
        }
    }

    @Override
    public void sendWarningOfPHCResultDelay() {
        if (!this.preferenceService.isTrue(PreferenceService.ENABLED_FOR_PHC_CHECKER)) {
            LOGGER.info("The email notification for phc checker is disabled, so it's unnecessary to send the email");
            return;
        }

        Collection<String> recipients = getRecipients();
        if (recipients.isEmpty()) {
            LOGGER.info("Unable to inform user about PHC report not updating due to no recipient set");
            return;
        }

        PHCResult lastestPHCResult = this.resultParser.getLatestPHCResult();
        String reportTimeString = null;
        if (lastestPHCResult != null) {
            reportTimeString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(lastestPHCResult);
        }
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>");
        html.append("<html lang=\"en\">");
        html.append("<head>");
        html.append("<meta charset=\"utf-8\">");
        html.append("</head>");
        html.append("<body>");
        html.append("<h3>");
        html.append("Preventive Health Check report has not updated for 3 days");
        html.append("</h3>");

        html.append("<span>Latest report time: ");
        if (reportTimeString != null) {
            Date date = new Date(Long.parseLong(reportTimeString));
            html.append(date);
        } else {
            html.append("Not available");
        }
        html.append("</span>");

        html.append("<h3>You may check:</h3>");
        html.append("<ul>");
        html.append("<li>Is report pushing cron job running on SELFMON node?</li>");
        html.append("<li>Is phc executable working alone? Try to execute it manually.</li>");
        html.append("<li>Is there any error of processing report in log? </li>");
        html.append("</ul>");
        html.append("</body>");

        for (String address : recipients) {
            try {
                mailSender.sendHTML(address, "PHC report has not updated for 3 days", html.toString());
            } catch (MailSenderException ex) {
                LOGGER.log(Level.SEVERE, "Cannot send mail for the phc report not updating", ex);
            }
        }
    }

    private Collection<String> getRecipients() {
        return preferenceService.getMultiVariable(PreferenceService.TARGET_ADDRESSES);
    }
}
