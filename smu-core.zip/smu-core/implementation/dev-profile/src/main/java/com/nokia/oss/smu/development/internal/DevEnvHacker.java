package com.nokia.oss.smu.development.internal;

import com.nokia.oss.smu.alarm.AlarmComponentMapper;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.netact.alarm.bll.internal.InternalAlarmTrigger;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

@Service
public class DevEnvHacker implements ApplicationListener<ContextRefreshedEvent> {

    @Resource
    private AlarmComponentMapper alarmComponentMapper;

    @Resource
    private InternalAlarmRepository internalAlarmRepository;

    @Resource
    private InternalAlarmTrigger internalAlarmTrigger;
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
    }

    //@Scheduled(fixedDelay = 5000)
    public void synchronizeAlarmsByFile() throws IOException {
        if (!useAlarmsFile())
            return;

        File alarmFile = new File(getAlarmsFilePath());

        Collection<InternalAlarm> alarmsInFile = Arrays.asList(mapper.readValue(alarmFile, InternalAlarm[].class));
        for (InternalAlarm alarm : alarmsInFile) {
            Component mappedComponent = this.alarmComponentMapper.mapComponent(alarm);
            if (mappedComponent != null)
                alarm.setMappedComponentId(mappedComponent.getId());
            alarm.setSynchronizingState(InternalAlarmSynchronizingState.INSERTED);
            internalAlarmRepository.persistInternalAlarm(alarm);
        }

        this.internalAlarmTrigger.triggerEvents();
        this.internalAlarmRepository.deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState.ORIGINAL);
        this.internalAlarmRepository.changeSynchronizingState(InternalAlarmSynchronizingState.ORIGINAL);
    }

    private boolean useAlarmsFile() {
        if (getAlarmsFilePath() == null)
            return false;

        if (!new File(getAlarmsFilePath()).exists())
            return false;

        return true;
    }

    private String getAlarmsFilePath() {
        String file = System.getenv("SMU_ALARM_FILE");
        if (file != null)
            return file;

        return System.getProperty("alarmFile");
    }
}
