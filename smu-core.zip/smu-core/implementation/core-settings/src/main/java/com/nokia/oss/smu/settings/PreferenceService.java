package com.nokia.oss.smu.settings;

import java.util.Collection;

import com.nokia.oss.smu.core.platform.MonitorService;

public interface PreferenceService extends MonitorService {
	
	String SMTP_SERVER = "email_setting.smtp_server";
	
	String SMTP_SERVER_PORT = "email_setting.smtp_server_port";
	
	String TARGET_ADDRESSES = "email_setting.target_addresses";

	String MAIL_SENDER = "email_setting.mail_sender";

	String ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED = "email_setting.enable_alarm_critical_enabled";
	
	String ENABLE_ALARM_SEVERITY_MAJOR_ENABLED = "email_setting.enable_alarm_major_enabled";
	
	String ENABLE_ALARM_SEVERITY_MINOR_ENABLED = "email_setting.enable_alarm_minor_enabled";
	
	String ENABLED_FOR_PHC_CHECKER = "email_setting.enabled_for_phc_checker";

	String MAIL_DELAY = "email_setting.mail.delay";
	
	String CRITICAL_RESEND_INTERVAL = "email_setting.critical.resend.interval";
	
	String EMAIL_MAX_ALARM_COUNT = "email_setting.max.alarm.count";

	String PHC_DELAY_NOTIFIED = "phc.delay_notified";

	String getVariable(String variableName);
	
	boolean isTrue(String variable);
	
	Collection<String> getMultiVariable(String variableName);
	
	void setVariable(String variableName, String variableValue);
	
	void setMultiVariable(String variableName, Collection<String> variableValues);

	void setVariableWithoutLock(String name, String value);
}
