package com.nokia.oss.smu.settings.entities;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "SMU_VARIABLES")
@SequenceGenerator(
		name = "variableSequence",
		sequenceName = "VARIABLE_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class Variable {
	public static final int VALUE_MAX_LENGTH = 300;

	@Id
	@Access(AccessType.PROPERTY)
	@Column(name = "VARIABLE_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "variableSequence")
	private Long id;
	
	@Column(name = "VARIABLE_NAME", length = 50, nullable = false)
	private String name;
	
	@Column(name = "VARIABLE_VALUE", length = VALUE_MAX_LENGTH, nullable = false)
	private String value;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
