package com.nokia.oss.smu.settings.impl;

import java.util.*;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nokia.oss.smu.core.lifecycle.AbstractLifecycle;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.settings.PreferenceChangeEvent;
import com.nokia.oss.smu.settings.PreferenceService;
import com.nokia.oss.smu.settings.entities.Variable;

import static java.util.logging.Logger.getLogger;

@Service
public class PreferenceServiceImpl extends AbstractLifecycle implements PreferenceService {

	private static final Logger LOG = getLogger(PreferenceServiceImpl.class.getName());

	private static final Map<String, Validator> VALIDATOR_MAP;

	@Resource
	private ApplicationContext applicationContext;

	@Resource
	private VariableRepository variableRepository;

	@Transactional(readOnly = true)
	@Override
	public String getVariable(String variableName) {
		LOG.fine("Retrieving preference value for: " + variableName);
		List<Variable> variables = this.variableRepository.getVariablesByName(variableName);
		if (variables.isEmpty()) {
			LOG.fine("Nothing found, null returned.");
			return null;
		}

		String value = variables.get(0).getValue();
		LOG.fine("Found value: " + value + " for preference: " + variableName);
		return value;
	}
	
	@Transactional(readOnly = true)
	public boolean isTrue(String variableName) {
		return "true".equals(this.getVariable(variableName));
	}

	@Transactional(readOnly = true)
	@Override
	public Collection<String> getMultiVariable(String variableName) {
		LOG.fine("Retrieving multiple values for preference: " + variableName);
		List<Variable> variables = this.variableRepository.getVariablesByName(variableName);
		String[] values = new String[variables.size()];
		int index = 0;
		for (Variable variable : variables) {
			values[index++] = variable.getValue();
		}

		LOG.fine(values.length + " values found for preference: " + variableName);
		return Arrays.asList(values);
	}

    @Transactional
    @Override
    public void setVariableWithoutLock(String name, String value) {
        if (value != null) {
            this.doSetMultiVariables(name, Collections.singleton(value));
        } else {
            this.doSetMultiVariables(name, null);
        }
    }

    @Synchronized(lockName = "preference.change.lock")
	@Transactional
	@Override
	public void setVariable(String name, String value) {
        if (value != null) {
            this.doSetMultiVariables(name, Collections.singleton(value));
        } else {
            this.doSetMultiVariables(name, null);
        }
	}

	@Synchronized(lockName = "preference.change.lock") //1. Use lock
	@Transactional
	@Override
	public void setMultiVariable(String name, Collection<String> values) {
        doSetMultiVariables(name, values);
	}

    private void doSetMultiVariables(String name, Collection<String> values) {
        LOG.fine("Setting values for preference: " + name);
        Collection<String> oldValues = this.getMultiVariable(name);
        if (!oldValues.isEmpty()) {
            LOG.fine("Old values for preference: " + name + " found, remove them");
            this.variableRepository.removeVariablesByName(name);
        }

        if (values == null) {
            LOG.fine("Nothing provide for setting preference: " + name);
            return;
        }

        Set<String> validValues = filterDuplicateValues(values);
        LOG.fine("Unify values from " + values.size() + " to " + validValues.size());
        for (String variableValue : validValues) {
            if (variableValue != null) {
                validateAndMerge(name, variableValue);
            }
        }

        oldValues = filterDuplicateValues(oldValues);
        if (!Objects.equals(oldValues, validValues)) { //2. Check whether it is necessary to trigger event
            LOG.fine("Preference values changed, publish event to context.");
            applicationContext.publishEvent(new PreferenceChangeEvent(applicationContext, name, validValues));
        }
    }

    private Set<String> filterDuplicateValues(Collection<String> values) {
		Set<String> valueSet;
		if (values instanceof Set<?>) {
			valueSet = (Set<String>)values;
		} else {
			valueSet = new LinkedHashSet<>(values);
		}

		return valueSet;
	}


	private void validateAndMerge(String name, String value) {
		validate(name, value);
        Variable variable = new Variable();
		variable.setName(name);
		variable.setValue(value);
		this.variableRepository.merge(variable);
	}

	private static void validate(String variableName, String variableValue) {
		Validator validator = VALIDATOR_MAP.get(variableName);
		if (validator != null) {
			validator.validate(variableName, variableValue);
		}
	}
	
	private interface Validator {
		void validate(String name, String value);
	}
	
	private static class BooleanValidator implements Validator {
		@Override
		public void validate(String name, String value) {
			if (!"true".equals(value) && !"false".equals(value)) {
				throw new IllegalArgumentException(
						"The variable \""
						+ name
						+ "\" whose value is \""
						+ value
						+ "\" is neither \"true\" nor \"false\"");
			}
		}
	}
	
	private static class LongValidator implements Validator {
		
		private long min;
		
		private long max;
		
		public LongValidator(long min, long max) {
			this.min = min;
			this.max = max;
		}

		@Override
		public void validate(String name, String value) {
			long longValue;
			try {
				longValue = Long.parseLong(value);
			} catch (NumberFormatException ex) {
				throw new IllegalArgumentException(
						"The variable \""
						+ name
						+ "\" whose value is \""
						+ value
						+ "\" must be integer");
			}
			if (longValue < this.min || longValue > this.max) {
				throw new IllegalArgumentException(
						"The variable \""
						+ name
						+ "\" whose value is \""
						+ value
						+ "\" must between \""
						+ this.min
						+ "\" and \""
						+ this.max
						+ "\"");
			}
		}
	}
	
	private static class MaxLengthValidator implements Validator {

		private int maxLength;
		
		public MaxLengthValidator(int maxLength) {
			this.maxLength = maxLength;
		}
		
		@Override
		public void validate(String name, String value) {
			if (value.length() > this.maxLength) {
				throw new IllegalArgumentException(
						"The variable \""
						+ name
						+ "\" whose value is \""
						+ value
						+ "\" can only have "
						+ this.maxLength
						+ "character at most");
			}
		}
		
	}

	static {
		Map<String, Validator> map = new HashMap<String, Validator>();
		map.put(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, new BooleanValidator());
		map.put(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED, new BooleanValidator());
		map.put(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED, new BooleanValidator());
		map.put(PreferenceService.ENABLED_FOR_PHC_CHECKER, new BooleanValidator());
		map.put(PreferenceService.PHC_DELAY_NOTIFIED, new BooleanValidator());
		map.put(PreferenceService.SMTP_SERVER, new MaxLengthValidator(255));
		map.put(PreferenceService.SMTP_SERVER_PORT, new LongValidator(0, 65535));
		map.put(PreferenceService.TARGET_ADDRESSES, new MaxLengthValidator(300));
		map.put(PreferenceService.MAIL_DELAY, new LongValidator(1, Long.MAX_VALUE));
		map.put(PreferenceService.CRITICAL_RESEND_INTERVAL, new LongValidator(1, Long.MAX_VALUE));
		map.put(PreferenceService.EMAIL_MAX_ALARM_COUNT, new LongValidator(1, Integer.MAX_VALUE));
		VALIDATOR_MAP = map;
	}
}
