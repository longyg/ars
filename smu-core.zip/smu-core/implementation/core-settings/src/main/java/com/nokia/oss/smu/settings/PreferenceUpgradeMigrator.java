package com.nokia.oss.smu.settings;

public interface PreferenceUpgradeMigrator {

    void migrateAlarmMailTriggers();

}