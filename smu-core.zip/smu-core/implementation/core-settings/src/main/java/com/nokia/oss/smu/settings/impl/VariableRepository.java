package com.nokia.oss.smu.settings.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.settings.entities.Variable;
import com.nokia.oss.smu.settings.entities.Variable_;

@Repository
public class VariableRepository {
	
	@PersistenceContext
	private EntityManager em;

	public List<Variable> getVariablesByName(String name) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		final CriteriaQuery<Variable> cq = cb.createQuery(Variable.class);
		Root<Variable> variable = cq.from(Variable.class);
		cq.where(cb.equal(variable.get(Variable_.name), name));
		return this.em.createQuery(cq).getResultList();
	}
	
	public void removeVariablesByName(String name) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		final CriteriaDelete<Variable> cd = cb.createCriteriaDelete(Variable.class);
		Root<Variable> variable = cd.from(Variable.class);
		cd.where(cb.equal(variable.get(Variable_.name), name));
		this.em.createQuery(cd).executeUpdate();
	}
	
	public void merge(final Variable variable) {
		this.em.merge(variable);
	}
}
