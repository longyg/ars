package com.nokia.oss.smu.settings;

import org.springframework.context.ApplicationEvent;

import java.util.Collection;
import java.util.Collections;

public class PreferenceChangeEvent extends ApplicationEvent {
   
    private static final long serialVersionUID = 1434032923212024817L;
    
    private String name;
    
    private Collection<String> newValues;

    public PreferenceChangeEvent(Object source, String name, Collection<String> newValues) {
        super(source);
        this.name = name;
        this.newValues = newValues;
    }

    public PreferenceChangeEvent(Object source, String name, String value) {
        super(source);
        this.name = name;
        this.newValues = Collections.singleton(value);
    }

    public String getName() {
        return name;
    }

    public Collection<String> getNewValues() {
        return newValues;
    }
}
