package com.nokia.oss.smu.settings.impl;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.settings.PreferenceChangeEvent;
import com.nokia.oss.smu.settings.PreferenceService;
import com.nokia.oss.smu.settings.PreferenceUpgradeMigrator;
import com.nokia.oss.smu.settings.entities.Variable;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

/* For upgrade compatibility since 16.5 to any later releases.
 * Remove these code when there is no upgrade path from 16.5 or earlier to the current release.
 */
@Component
public class PreferenceUpgradeMigratorImpl implements PreferenceUpgradeMigrator {

    public static final String OLD_ENABLED_FOR_ALL_ALARMS = "email_setting.enabled_for_alarm_monitor";

    private static final Logger LOG = getLogger(PreferenceUpgradeMigratorImpl.class.getName());

    @Resource
    private ApplicationContext applicationContext;

    @Resource
    private VariableRepository variableRepository;

    @Transactional
    @Override
    public void migrateAlarmMailTriggers() {
        if (this.isTrue(OLD_ENABLED_FOR_ALL_ALARMS)) {
            doMigrateTriggers();
        }
    }

    @Synchronized(lockName = "preference.change.lock", nowait = true)
    public void doMigrateTriggers() {
        if (this.isTrue(OLD_ENABLED_FOR_ALL_ALARMS)) {
            LOG.info("migrating old alarm mail triggers, setting all triggers to true");

            this.variableRepository.removeVariablesByName(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED);
            this.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");
            this.variableRepository.removeVariablesByName(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED);
            this.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED, "true");
            this.variableRepository.removeVariablesByName(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED);
            this.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED, "true");
            this.variableRepository.removeVariablesByName(OLD_ENABLED_FOR_ALL_ALARMS);

            applicationContext.publishEvent(new PreferenceChangeEvent(applicationContext,
                    PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true"));
            applicationContext.publishEvent(
                    new PreferenceChangeEvent(applicationContext, PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED,
                            "true"));
            applicationContext.publishEvent(
                    new PreferenceChangeEvent(applicationContext, PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED,
                            "true"));
        }
    }

    private void setVariable(String name, String value) {
        final Variable variable = new Variable();
        variable.setName(name);
        variable.setValue(value);
        this.variableRepository.merge(variable);
    }

    private String getVariable(String variableName) {
        List<Variable> variables = this.variableRepository.getVariablesByName(variableName);
        if (variables.isEmpty()) {
            return null;
        }
        String value = variables.get(0).getValue();
        return value;
    }

    private boolean isTrue(String variableName) {
        return "true".equals(this.getVariable(variableName));
    }
}
