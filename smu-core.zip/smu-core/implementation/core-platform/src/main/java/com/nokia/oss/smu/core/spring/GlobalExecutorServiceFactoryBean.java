package com.nokia.oss.smu.core.spring;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

@Component("globalExecutorService")
public class GlobalExecutorServiceFactoryBean implements FactoryBean<ExecutorService> {

    private static final Logger LOGGER = Logger.getLogger(GlobalExecutorServiceFactoryBean.class.getName());
    
	private ExecutorService executorService = Executors.newCachedThreadPool();
	
	@Override
	public ExecutorService getObject() throws Exception {
		return this.executorService;
	}

	@Override
	public Class<?> getObjectType() {
		return ExecutorService.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@PreDestroy
	public void dispose() {
		
	    this.executorService.shutdown(); // Reject new tasks
		this.executorService.shutdownNow(); // Stop old tasks
		
		try {
            if (this.executorService.awaitTermination(5, TimeUnit.MINUTES)) {
                LOGGER.info("The globalExecutorService has been terminated successfully");
                return;
            }
        } catch (InterruptedException ex) {
            LOGGER.log(Level.SEVERE, "Failed to await the termination of executor service because of the intrrupting", ex);
            return;
        }
		
		LOGGER.log(Level.SEVERE, "Failed to await the termination of executor service because of unknown reason");
	}
}
