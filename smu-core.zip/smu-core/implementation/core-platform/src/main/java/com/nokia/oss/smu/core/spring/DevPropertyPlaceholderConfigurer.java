package com.nokia.oss.smu.core.spring;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DevPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer {
	
	private static final Pattern VARIABLE_PATTERN = Pattern.compile("\\$\\{[^\\}]*\\}");
	
	private static final Pattern OR_PATTERN = Pattern.compile("\\|");
	
	private Resource[] locations;
	
	public DevPropertyPlaceholderConfigurer() {
		this.setIgnoreUnresolvablePlaceholders(true);
	}
	
	@Override
	public void setLocation(Resource location) {
		this.setLocations(new Resource[] { location });
	}

	@Override
	public void setLocations(Resource... locations) {
		this.locations = locations;
		super.setLocations(locations);
	}

	@Override
	protected void loadProperties(Properties props) throws IOException {
		super.loadProperties(props);
		this.overrideProperties(props);
	}
	
	private void overrideProperties(Properties props) throws IOException {
		for (Resource location : this.locations) {
			if (location instanceof ClassPathResource) {
				ClassPathResource classPathResource = (ClassPathResource)location;
				String path = classPathResource.getPath();
				int lastDot = path.lastIndexOf('.');
				if (lastDot == -1) {
					lastDot = path.length();
				}
				path = path.substring(0, lastDot) + ".dev" + path.substring(lastDot);
				InputStream devStream = classPathResource.getClassLoader().getResourceAsStream(path);
				if (devStream != null) {
					try {
						Properties overrideProps = new Properties();
						overrideProps.load(devStream);
						for (Entry<Object, Object> entry : overrideProps.entrySet()) {
							String value = process(entry.getValue().toString());
							if (value != null) {
								entry.setValue(value);
							}
						}
						props.putAll(overrideProps);
					} finally {
						devStream.close();
					}
				}
			}
		}
	}


	private static String process(String value) {
		Matcher matcher = VARIABLE_PATTERN.matcher(value);
		StringBuilder builder = new StringBuilder();
		int end = 0;
		boolean find = false;
		while (matcher.find()) {
			find = true;
			builder.append(value.substring(end, matcher.start()));
			builder.append(processPattern(value.substring(matcher.start() + 2, matcher.end() - 1)));
			end = matcher.end();
		}
		if (!find) {
			return null;
		}
		builder.append(value.substring(end));
		return builder.toString();
	}
	
	private static String processPattern(String value) {
		for (String expression : OR_PATTERN.split(value)) {
			expression = processExpression(expression);
			if (expression != null && !expression.isEmpty()) {
				return expression;
			}
		}
		return "";
	}
	
	private static String processExpression(String value) {
		int indexStart = value.indexOf('[');
		int indexEnd = value.lastIndexOf(']');
		if (indexStart != -1 && indexEnd == -1) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", it contains '[', but does not contain ']'");
		}
		if (indexEnd != -1 && indexStart == -1) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", it contains ']', but does not contain '['");
		}
		if (indexStart > indexEnd) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", the ']' must be after '['.");
		}
		if (indexStart == -1) {
			return value.trim();
		}
		String obj = value.substring(0, indexStart).trim();
		if (!obj.equals("props") && !obj.equals("env")) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", the object before '[' must be 'props' or 'env'.");
		}
		String postfix = value.substring(indexEnd + 1).trim();
		if (!postfix.isEmpty()) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", nothing should appear after ']'");
		}
		String key = value.substring(indexStart + 1, indexEnd).trim();
		if (key.isEmpty()) {
			throw new IllegalArgumentException(
					"Illegal argument \""
					+ value
					+ "\", the key between '[' and ']' should not be empty");
		}
		return obj.equals("props") ? System.getProperty(key) : System.getenv(key);
	}
}
