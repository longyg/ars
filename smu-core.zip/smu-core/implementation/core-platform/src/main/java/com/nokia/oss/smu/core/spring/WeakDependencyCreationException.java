package com.nokia.oss.smu.core.spring;

public class WeakDependencyCreationException extends RuntimeException {

	private static final long serialVersionUID = 8477127235955136352L;

	public WeakDependencyCreationException() {
		super();
	}

	public WeakDependencyCreationException(String message) {
		super(message);
	}

	public WeakDependencyCreationException(Throwable cause) {
		super(cause);
	}

	public WeakDependencyCreationException(String message, Throwable cause) {
		super(message, cause);
	}
}
