package com.nokia.oss.smu.core.view;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.platform.MonitoredSystemManager;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.component.XmlObjectParser;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class XmlComponentViewLoader extends XmlObjectParser {

    public ComponentView parseComponentsView(InputStream componentXmlStream, Component rootComponent)
            throws XmlParseException {

        ClassLoader coreClassLoader = MonitoredSystemManager.class.getClassLoader();
        InputStream xsdStream = coreClassLoader.getResourceAsStream("component-view.xsd");

        HandlerImpl handler = new HandlerImpl();
        handler.buildComponentIdsMap(rootComponent);
        parse(xsdStream, handler, componentXmlStream);

        return handler.getComponentView();
    }

    private static class HandlerImpl extends DefaultHandler {
        private static final String TNS = "http://www.nsn.com/smu/componentViews";

        private static final String COMPONENT_VIEW_TAG = "component-view";
        private static final String LAYER_TAG = "layer";
        private static final String COMPONENT_REF_TAG = "component-ref";

        private static final String DISPLAY_NAME_ATTRIBUTE = "displayName";
        private static final String COMPONENT_ID_ATTRIBUTE = "component-id";

        private Stack<Object> stack = new Stack<Object>();

        private ComponentView componentView;
        private Map<String, Component> componentsIdMap;

        @Override
        public void error(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void fatalError(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes)
                throws SAXException {

            if (COMPONENT_VIEW_TAG.equals(localName) && TNS.equals(uri)) {
                if (componentView != null) {
                    throw new SAXException("Duplicate componentView tag found");
                }

                componentView = new ComponentView();
                stack.push(componentView);
            } else if (LAYER_TAG.equals(localName) && TNS.equals(uri)) {
                if (componentView == null) {
                    throw new SAXException("No componentView tag found before layer");
                }

                String displayName = attributes.getValue(XMLConstants.NULL_NS_URI, DISPLAY_NAME_ATTRIBUTE);
                ComponentLayer cl = new ComponentLayer();
                cl.setDisplayName(displayName);
                componentView.getLayers().add(cl);
                stack.push(cl);
            } else if (COMPONENT_REF_TAG.equals(localName) && TNS.equals(uri)) {
                ComponentLayer cl = (ComponentLayer) stack.peek();

                String displayName = attributes.getValue(XMLConstants.NULL_NS_URI, DISPLAY_NAME_ATTRIBUTE);
                String componentId = attributes.getValue(XMLConstants.NULL_NS_URI, COMPONENT_ID_ATTRIBUTE);

                Component component = componentsIdMap.get(componentId);
                if (component == null) {
                    throw new SAXException("There is no component with id " + componentId);
                }

                ComponentRef ref = new ComponentRef(component);
                ref.setDisplayName(displayName);
                cl.getComponentRefs().add(ref);
                stack.push(cl);
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (isValidTag(uri, localName)) {
                stack.pop();
            }
        }

        private boolean isValidTag(String uri, String localName) {
            return COMPONENT_VIEW_TAG.equals(localName) && TNS.equals(uri)
                    || LAYER_TAG.equals(localName) && TNS.equals(uri)
                    || COMPONENT_REF_TAG.equals(localName) && TNS.equals(uri);
        }

        public ComponentView getComponentView() {
            return this.componentView;
        }

        private void buildComponentIdsMap(Component rootComponent) {
            componentsIdMap = new HashMap<String, Component>();
            ComponentVisitor cv = new ComponentVisitor() {
                @Override
                public void visit(Component component) {
                    componentsIdMap.put(component.getId(), component);
                }
            };

            rootComponent.accept(cv);
        }
    }
}
