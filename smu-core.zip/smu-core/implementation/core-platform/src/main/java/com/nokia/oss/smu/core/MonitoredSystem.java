package com.nokia.oss.smu.core;

import com.nokia.oss.smu.core.view.ComponentView;

import java.util.Collection;

public interface MonitoredSystem extends Bindable {

    Deployment getDeployment();

    String getIdentifier();

    String getSystemName();

    void installAspect(MonitoringAspect aspect);

    void uninstallAspect(MonitoringAspect aspect);

    <P extends MonitoringAspect> P getAspect(Class<P> pluginType);

    <P extends MonitoringAspect> Collection<P> getAspects(Class<P> pluginType);

    ComponentView getComponentView();

    Component getRootComponent();

    Component getComponentById(String id);

    String getTypeIdentifier();
}
