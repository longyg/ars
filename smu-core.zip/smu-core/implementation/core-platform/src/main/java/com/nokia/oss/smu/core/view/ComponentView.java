package com.nokia.oss.smu.core.view;

import java.util.ArrayList;
import java.util.List;

public class ComponentView {
    private List<ComponentLayer> layers = new ArrayList<ComponentLayer>();

    public List<ComponentLayer> getLayers() {
        return layers;
    }
}
