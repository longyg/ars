package com.nokia.oss.smu.core.base;

import java.util.Collection;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoringAspect;
import com.nokia.oss.smu.core.component.ComponentFinder;
import com.nokia.oss.smu.core.util.DefaultRegistry;
import com.nokia.oss.smu.core.util.Registry;

/**
 * @author liu.jeffry@nsn.com
 * @author frank.1.chen@nsn.com
 */
public abstract class BaseSystem extends BaseBindable implements MonitoredSystem {

    private Registry<MonitoringAspect> aspectsRegistry = new DefaultRegistry<MonitoringAspect>();

    private ComponentFinder componentFinder;

    private String systemName;

    private String identifier;

    private String typeIdentifier;
    private String agentHostName;

    public BaseSystem(String name) {
        this.systemName = name;
    }

    @Override
    public String getSystemName() {
        return systemName;
    }

    @Override
    public synchronized void installAspect(MonitoringAspect aspect) {
        if (!(aspect instanceof BaseAspect)) {
            throw new IllegalArgumentException("aspect must be \"" + BaseAspect.class + "\"");
        }
        if (aspectsRegistry.register(aspect)) {
            ((BaseAspect) aspect).internalSetMonitoredSystem(this);
        }
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String systemId) {
        this.identifier = systemId;
    }

    @Override
    public String getTypeIdentifier() {
        return typeIdentifier;
    }

    public void setTypeIdentifier(String typeIdentifier) {
        this.typeIdentifier = typeIdentifier;
    }

    @Override
    public synchronized void uninstallAspect(MonitoringAspect aspect) {
        if (aspectsRegistry.unregister(aspect)) {
            ((BaseAspect) aspect).internalSetMonitoredSystem(null);
        }
    }

    @Override
    public synchronized <P extends MonitoringAspect> P getAspect(Class<P> aspect) {
        return aspectsRegistry.getOne(aspect);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public <P extends MonitoringAspect> Collection<P> getAspects(Class<P> aspect) {
        if (aspect == MonitoringAspect.class) {
            return (Collection) aspectsRegistry.getRegisteredObjects();
        }

        return aspectsRegistry.get(aspect);
    }

    @Override
    public Component getComponentById(String id) {
        if (componentFinder == null) {
            componentFinder = new ComponentFinder(getRootComponent());
        }
        return componentFinder.findById(id);
    }

    public void setAgentHostName(String agentHostName) {
        this.agentHostName = agentHostName;
    }

    public String getAgentHostName() {
        return agentHostName;
    }
}
