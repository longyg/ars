package com.nokia.oss.smu.core;

public interface Architecture {
    Component getRootComponent();

    Component getComponentById(String id);
}
