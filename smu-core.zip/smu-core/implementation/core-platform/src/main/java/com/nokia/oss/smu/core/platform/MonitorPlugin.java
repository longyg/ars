package com.nokia.oss.smu.core.platform;

public interface MonitorPlugin {
}
