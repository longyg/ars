package com.nokia.oss.smu.core.util;

public class AsyncException extends RuntimeException {

    private static final long serialVersionUID = 387418566578983178L;

    public AsyncException() {
        super();
    }

    public AsyncException(Throwable cause) {
        super(cause);
    }

    public AsyncException(String message) {
        super(message);
    }

    public AsyncException(String message, Throwable cause) {
        super(message, cause);
    }
}
