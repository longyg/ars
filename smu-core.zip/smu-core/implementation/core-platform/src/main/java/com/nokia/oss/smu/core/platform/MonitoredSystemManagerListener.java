package com.nokia.oss.smu.core.platform;

import com.nokia.oss.smu.core.MonitoredSystem;

public interface MonitoredSystemManagerListener {
    void onMonitoredSystemAdded(MonitoredSystem system);

    void onMonitoredSystemRemoved(MonitoredSystem system);

    void onMonitoredSystemRegistered(MonitoredSystem system);

    void onMonitoredSystemUnregistered(MonitoredSystem system);

    void onMonitoredSystemLoaded(MonitoredSystem system);

    void onMonitoredSystemUnloaded(MonitoredSystem system);
}
