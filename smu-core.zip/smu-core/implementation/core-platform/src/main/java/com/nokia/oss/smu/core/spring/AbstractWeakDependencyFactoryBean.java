package com.nokia.oss.smu.core.spring;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;

import java.io.Closeable;
import java.lang.reflect.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class AbstractWeakDependencyFactoryBean implements FactoryBean<Object> {

    private static final Logger LOGGER =
            Logger.getLogger(AbstractWeakDependencyFactoryBean.class.getName());

    private WeakDependencyTargetProxy targetProxy;

    private boolean createdWhenInitialized;

    @Override
    public Class<?> getObjectType() {
        return null;
    }

    @Override
    public final boolean isSingleton() {
        return true;
    }

    @Override
    public final Object getObject() throws Exception {
        if (this.targetProxy != null) {
            throw new IllegalStateException("getObject can only be invoked once");
        }
        Class<?>[] interfaceTypes = this.safeDeterminInterfaceTypes();
        Class<?>[] proxyInterfaceTypes = new Class[interfaceTypes.length + 1];
        System.arraycopy(interfaceTypes, 0, proxyInterfaceTypes, 0, interfaceTypes.length);
        proxyInterfaceTypes[interfaceTypes.length] = WeakDependencyTargetProxy.class;
        this.targetProxy = (WeakDependencyTargetProxy) Proxy.newProxyInstance(
                interfaceTypes[0].getClassLoader(),
                proxyInterfaceTypes,
                this.new WeakInvocationHandler(interfaceTypes)
        );
        return this.targetProxy;
    }

    private Class<?>[] safeDeterminInterfaceTypes() {
        Class<?>[] interfaceTypes = this.determineInterfaceTypes();
        if (interfaceTypes == null || interfaceTypes.length == 0) {
            throw new IllegalStateException("determineInterfaceTypes() must not be null or empty");
        }
        for (Class<?> interfaceType : interfaceTypes) {
            if (interfaceType == null) {
                throw new IllegalArgumentException(
                        "each interfaceType returned by "
                                + this.getClass().getName()
                                + ".determineInterfaceTypes() must not be null"
                );
            }
            if (!interfaceType.isInterface()) {
                throw new IllegalArgumentException(
                        "each interfaceType returned by "
                                + this.getClass().getName()
                                + ".determineInterfaceTypes() must not be interface"
                );
            }
            if (!Modifier.isPublic(interfaceType.getModifiers())) {
                throw new IllegalArgumentException(
                        "each interfaceType returned by "
                                + this.getClass().getName()
                                + "determineInterfaceTypes() must not be interface"
                );
            }
        }
        return interfaceTypes;
    }

    private Object safeCreateTarget(Class<?>[] interfaceTypes) {
        Object target;
        try {
            target = this.createTarget();
        } catch (WeakDependencyCreationException ex) {
            throw ex;
        } catch (Throwable ex) {
            throw new WeakDependencyCreationException(ex);
        }
        if (target == null) {
            throw new IllegalArgumentException(
                    "The raw target created by "
                            + this.getClass().getName()
                            + ".createTarget() must not be null "
            );
        }
        for (Class<?> interfaceType : interfaceTypes) {
            Class<? extends Object> rawTargetClass = target.getClass();
            if (!interfaceType.isAssignableFrom(rawTargetClass)) {
                throw new IllegalArgumentException(
                        "The raw target created by "
                                + this.getClass().getName()
                                + ".createTarget() must be " +
                                interfaceType
                );
            }
        }
        return target;
    }

    protected abstract Class<?>[] determineInterfaceTypes();

    protected abstract Object createTarget() throws Throwable;

    protected void destroyTarget(Object target) throws Exception {
        if (target instanceof DisposableBean) {
            ((DisposableBean) target).destroy();
        } else if (target instanceof Closeable) {
            ((Closeable) target).close();
        }
    }

    protected ThrowableHandleType handleThrowable(Throwable ex) {
        return ThrowableHandleType.RESET_AND_RETHROW;
    }

    protected final void requestCreate() {
        WeakDependencyTargetProxy targetProxy = this.targetProxy;
        if (targetProxy != null) {
            targetProxy.create();
        } else {
            this.createdWhenInitialized = true;
        }
    }

    protected final void requestDestory() {
        WeakDependencyTargetProxy targetProxy = this.targetProxy;
        if (targetProxy != null) {
            targetProxy.destroy();
        } else {
            this.createdWhenInitialized = false;
        }
    }

    public static enum ThrowableHandleType {
        RETHROW_ONLY,
        RESET_AND_RETHROW,
        RESET_AND_RETRY,
    }

    private class WeakInvocationHandler implements InvocationHandler {

        private Class<?>[] interfaceTypes;

        private volatile Object target;

        public WeakInvocationHandler(Class<?>... interfaceTypes) {
            this.interfaceTypes = interfaceTypes.clone();
            if (AbstractWeakDependencyFactoryBean.this.createdWhenInitialized) {
                try {
                    this.getRawTarget();
                } catch (RuntimeException | Error ex) {
                    LOGGER.log(
                            Level.SEVERE,
                            "Create not create the target when the weak dependency is initialized",
                            ex
                    );
                }
            }
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (method.getDeclaringClass().isAssignableFrom(WeakDependencyTargetProxy.class)) {
                String methodName = method.getName();
                if ("isAvailable".equals(methodName)) {
                    return this.target != null;
                } else if ("create".equals(methodName)) {
                    this.getRawTarget();
                } else if ("destroy".equals(methodName)) {
                    this.destroyTarget();
                }
                return null;
            }
            try {
                return method.invoke(this.getRawTarget(), args);
            } catch (IllegalAccessException | InvocationTargetException | RuntimeException | Error e) {
                Throwable ex = e;
                if (ex instanceof InvocationTargetException) {
                    ex = ((InvocationTargetException) ex).getTargetException();
                }
                switch (AbstractWeakDependencyFactoryBean.this.handleThrowable(ex)) {
                    case RESET_AND_RETRY:
                        this.destroyTarget();
                        try {
                            return method.invoke(this.getRawTarget(), args);
                        } catch (IllegalAccessException | InvocationTargetException | RuntimeException | Error nestedException) {
                            if (nestedException instanceof InvocationTargetException) {
                                ex = ((InvocationTargetException) nestedException).getTargetException();
                            } else {
                                ex = nestedException;
                            }
                        }
                        break;
                    case RESET_AND_RETHROW:
                        this.destroyTarget();
                        break;
                    default:    
                        break;
                }
                throw ex;
            }
        }

        private Object getRawTarget() {
            Object rawTarget = this.target;
            if (rawTarget == null) {
                synchronized (this) {
                    rawTarget = this.target;
                    if (rawTarget == null) {
                        rawTarget = AbstractWeakDependencyFactoryBean.this.safeCreateTarget(this.interfaceTypes);
                        this.target = rawTarget;
                    }
                }
            }
            return rawTarget;
        }

        private void destroyTarget() {
            synchronized (this) {
                Object tgt = this.target;
                if (tgt != null) {
                    this.target = null;
                    try {
                        AbstractWeakDependencyFactoryBean.this.destroyTarget(tgt);
                    } catch (Exception | Error ex) {
                        LOGGER.log(Level.SEVERE, "Can't destroy the target", ex);
                    }
                }
            }
        }
    }
}
