package com.nokia.oss.smu.core.view;

import java.util.ArrayList;
import java.util.List;

public class ComponentLayer {

    private String displayName;
    private List<ComponentRef> componentRefs = new ArrayList<ComponentRef>();

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public List<ComponentRef> getComponentRefs() {
        return componentRefs;
    }
}
