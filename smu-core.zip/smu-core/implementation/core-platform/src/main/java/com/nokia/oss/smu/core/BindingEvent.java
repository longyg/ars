package com.nokia.oss.smu.core;

import java.util.EventObject;

public class BindingEvent extends EventObject {

    private static final long serialVersionUID = -4586959451332102924L;

    private Object value;

    public BindingEvent(Bindable source, Object object) {
        super(source);
        this.value = object;
    }

    @Override
    public Bindable getSource() {
        return (Bindable) super.getSource();
    }

    public Object getObject() {
        return this.value;
    }
}
