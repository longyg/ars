package com.nokia.oss.smu.core.platform;

import java.util.Collection;

public abstract class MonitorPlatform implements MonitoredSystemManager {
    protected static volatile MonitorPlatform instance;

    public static MonitorPlatform getPlatform() {
        return instance;
    }

    public abstract Collection<MonitorPlugin> getPlugins();

    public abstract void installService(MonitorService service);

    public abstract void uninstallService(MonitorService service);

    public abstract <S extends MonitorService> S findService(Class<S> serviceClass);

    public abstract <S extends MonitorService> Collection<S> findServices(Class<S> serviceClass);

    public abstract void startup();

    public abstract void shutdown();

    public abstract boolean isStarted();

    protected static void setPlatformInstance(MonitorPlatform ms) {
        instance = ms;
    }
}
