package com.nokia.oss.smu.core;

/**
 * @author frank.1.chen@nsn.com
 * @MonitoringAspect A {@code MonitoringAspect} as it named, provides an aspect of monitored systems.
 * <p/>
 * <p>Aspect of monitored system is base of feature of monitored system, for example, a typical system may has
 * the feature of configuration, therefore there should be <em>configuration aspect</em> binding with the
 * {@code MonitoredSystem} object.
 * </p>
 * <p/>
 * Subclasses of MonitoringAspect or interfaces extends from it could be used for querying needed aspect from
 * monitored system. e.g.
 * <p/>
 * <code>
 * MonitoredSystem ms = ...;
 * ConfigurationAspect ca = ms.getAspect(ConfigurationAspect.class);
 * ca.readConfiguration(...);
 * </code>
 * <p/>
 * There are two ways of using aspects, when binding with specified monitored system, methods provided
 * by aspect implementation could be directly used as shown above, otherwise, when getting access those methods,
 * monitored system instance is needed, in this way, aspect instances are shared among multiple monitored systems.
 */
public interface MonitoringAspect {

    <S extends MonitoredSystem> S getMonitoredSystem();
}
