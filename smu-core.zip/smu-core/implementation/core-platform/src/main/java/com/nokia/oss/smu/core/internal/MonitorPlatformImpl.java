package com.nokia.oss.smu.core.internal;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoredSystemSpec;
import com.nokia.oss.smu.core.platform.*;
import com.nokia.oss.smu.core.util.AsyncUtil;
import com.nokia.oss.smu.core.util.DefaultRegistry;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author jeffery.liu@nsn.com
 * @author frchen.1.chen@nsn.com
 */
public final class MonitorPlatformImpl extends MonitorPlatform implements ApplicationListener<ApplicationEvent> {

    private static final Logger LOGGER = Logger.getLogger(MonitorPlatformImpl.class.getName());

    private Map<String, MonitoredSystem> monitoredSystems = new HashMap<String, MonitoredSystem>();

    private DefaultRegistry<MonitorService> servicesRegistry = new DefaultRegistry<MonitorService>();
    private List<MonitorPlugin> monitorPlugins = new LinkedList<MonitorPlugin>();
    private List<MonitoredSystemManagerListener> monitoredSystemManagerListener = new ArrayList<MonitoredSystemManagerListener>();
    private boolean started = false;

    private MonitorPlatformImpl() {
        setPlatformInstance(this);
    }

    @Override
    public List<MonitorPlugin> getPlugins() {
        return Collections.unmodifiableList(this.monitorPlugins);
    }

    public void setPlugins(List<MonitorPlugin> plugins) {
        monitorPlugins = plugins;
    }

    @Override
    public void installService(MonitorService service) {
        servicesRegistry.register(service);
    }

    @Override
    public void uninstallService(MonitorService service) {
        servicesRegistry.unregister(service);
    }

    @Override
    public <S extends MonitorService> S findService(Class<S> serviceClass) {
        return servicesRegistry.getOne(serviceClass);
    }

    @Override
    public <S extends MonitorService> Collection<S> findServices(Class<S> serviceClass) {
        return servicesRegistry.get(serviceClass);
    }

    @Override
    public void addMonitoredSystemManagerListener(MonitoredSystemManagerListener listener) {
        LOGGER.finest("Listener added: " + listener);
        monitoredSystemManagerListener.add(listener);
    }

    @Override
    public void removeMonitoredSystemManagerListener(MonitoredSystemManagerListener listener) {
        monitoredSystemManagerListener.remove(listener);
        LOGGER.finest("Listener removed: " + listener);
    }

    @Override
    public void addMonitoredSystem(String systemIdentifier, MonitoredSystem system) {
        if (system == null) {
            LOGGER.severe("Add monitored system null with identifier: " + systemIdentifier);
            return;
        }

        if (systemIdentifier == null || systemIdentifier.isEmpty()) {
            systemIdentifier = system.getClass().getName();
        }

        MonitoredSystem monitoredSystem = monitoredSystems.get(systemIdentifier);
        if (monitoredSystem != null) {
            LOGGER.warning("System[" + monitoredSystem.getSystemName() + "] with identifier '" + systemIdentifier
                    + "' already registered.");
            return;
        }

        monitoredSystems.put(systemIdentifier, system);
        fireMonitoredSystemAdded(system);
    }

    @Override
    public void removeMonitoredSystem(String systemIdentifier) {
        MonitoredSystem system = monitoredSystems.get(systemIdentifier);
        if (system == null) {
            return;
        }

        monitoredSystems.remove(systemIdentifier);
        fireMonitoredSystemRemoved(system);
    }

    @Override
    public Collection<MonitoredSystem> getMonitoredSystems() {
        return Collections.unmodifiableCollection(monitoredSystems.values());
    }

    @Override
    public MonitoredSystem getMonitoredSystem(String systemIdentifier) {
        return monitoredSystems.get(systemIdentifier);
    }

    @Override
    public MonitoredSystem getFirstMonitoredSystem() {
        Iterator<MonitoredSystem> iterator = monitoredSystems.values().iterator();
        if (iterator.hasNext()) {
            return iterator.next();
        }

        throw new RuntimeException("No monitored system is registered.");
    }

    @Override
    public void registerMonitoredSystem(MonitoredSystemSpec systemSpec) {
        if (!isStarted()) {
            LOGGER.severe("Cannot register system before platform started.");
            return;
        }

        Collection<MonitoredSystemCreationService> creationServices
                = findServices(MonitoredSystemCreationService.class);

        if (creationServices.isEmpty()) {
            LOGGER.warning("No MonitoredSystemCreationService installed, cannot create system for spec: " + systemSpec);
            return;
        }

        MonitoredSystemPersistService persistService = findService(MonitoredSystemPersistService.class);
        if (persistService == null) {
            LOGGER.severe("No monitored system persist service installed, cannot persist monitored systems.");
        }

        for (MonitoredSystemCreationService creationService : creationServices) {
            if (creationService.canCreate(systemSpec)) {
                MonitoredSystem ms = creationService.create(systemSpec);
                if (ms != null) {
                    LOGGER.info("Monitored system created for spec: " + systemSpec);
                    if (persistService != null) {
                        persistService.persist(ms);
                    }

                    addMonitoredSystem(ms.getIdentifier(), ms);
                    fireMonitoredSystemRegistered(ms);

                    return;
                }
            }
        }

        LOGGER.warning("No proper creation service found for system spec: " + systemSpec);
    }

    @Override
    public void unregisterMonitoredSystem(MonitoredSystemSpec systemSpec) {
        if (!isStarted()) {
            LOGGER.severe("Cannot register system before platform started.");
            return;
        }

        MonitoredSystemPersistService systemPersistService = findService(MonitoredSystemPersistService.class);
        String systemIdentifier = systemSpec.getSystemIdentifier();
        MonitoredSystem monitoredSystem = getMonitoredSystem(systemIdentifier);
        if (monitoredSystem == null) {
            LOGGER.warning("Monitored system specified by spec: " + systemSpec + " is not registered.");
            return;
        }

        systemPersistService.remove(monitoredSystem);
        removeMonitoredSystem(systemIdentifier);
        fireMonitoredSystemUnregistered(monitoredSystem);
        LOGGER.info("Monitored system removed: " + systemSpec);
    }

    @Override
    public boolean isMonitoredSystemExist(String systemIdentifier) {
        return getMonitoredSystem(systemIdentifier) != null;
    }

    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if (event instanceof ContextRefreshedEvent) {
            startup();
        }
    }

    public void startup() {
        startServices();
        loadMonitoredSystems();
        notifyServicesPlatformStarted();
        started = true;
    }

    public void shutdown() {
        LOGGER.info("Monitoring platform is shutting down.");
        notifyServicesPlatformShuttingDown();
        stopServices();
        AsyncUtil.terminate();
        started = false;
    }

    @Override
    public boolean isStarted() {
        return started;
    }

    private void startServices() {
        for (MonitorService service : servicesRegistry.get(MonitorService.class)) {
            try {
                service.start();
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Service start failed", ex);
            }
        }
    }

    private void loadMonitoredSystems() {
        MonitoredSystemPersistService persistService = findService(MonitoredSystemPersistService.class);
        if (persistService == null) {
            LOGGER.severe("No persist service available, cannot monitor any system.");
            return;
        }

        Collection<MonitoredSystem> systems = persistService.load();

        if (systems.isEmpty()) {
            LOGGER.warning("No monitored system loaded.");
        }

        for (MonitoredSystem system : systems) {
            addMonitoredSystem(system.getIdentifier(), system);
        }
    }

    private void stopServices() {

        for (MonitorService service : servicesRegistry.get(MonitorService.class)) {
            try {
                service.stop();
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, "Service stop failed.", ex);
            }
        }
    }

    private void notifyServicesPlatformStarted() {
        for (MonitorService service : servicesRegistry.get(MonitorService.class)) {
            if (service instanceof PlatformStateAware) {
                PlatformStateAware psa = (PlatformStateAware) service;
                psa.platformStartedUp();
            }
        }
    }

    private void notifyServicesPlatformShuttingDown() {
        for (MonitorService service : servicesRegistry.get(MonitorService.class)) {
            if (service instanceof PlatformStateAware) {
                PlatformStateAware psa = (PlatformStateAware) service;
                psa.platformShuttingDown();
            }
        }
    }

    private void fireMonitoredSystemAdded(MonitoredSystem system) {
        for (MonitoredSystemManagerListener listener : monitoredSystemManagerListener) {
            listener.onMonitoredSystemAdded(system);
        }
    }

    private void fireMonitoredSystemRemoved(MonitoredSystem system) {
        for (MonitoredSystemManagerListener listener : monitoredSystemManagerListener) {
            listener.onMonitoredSystemRemoved(system);
        }
    }

    private void fireMonitoredSystemRegistered(MonitoredSystem system) {
        for (MonitoredSystemManagerListener listener : monitoredSystemManagerListener) {
            try {
                listener.onMonitoredSystemRegistered(system);
            } catch (Exception ex) {
                LOGGER.log(Level.WARNING, listener + "throw exception while handle monitored system register event.", ex);
            }
        }
    }

    private void fireMonitoredSystemUnregistered(MonitoredSystem system) {
        for (MonitoredSystemManagerListener listener : monitoredSystemManagerListener) {
            listener.onMonitoredSystemUnregistered(system);
        }
    }
}
