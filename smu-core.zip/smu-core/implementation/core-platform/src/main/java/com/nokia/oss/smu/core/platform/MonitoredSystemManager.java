package com.nokia.oss.smu.core.platform;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoredSystemSpec;

import java.util.Collection;

public interface MonitoredSystemManager {
    void addMonitoredSystemManagerListener(MonitoredSystemManagerListener listener);

    void removeMonitoredSystemManagerListener(MonitoredSystemManagerListener listener);

    void addMonitoredSystem(String systemIdentifier, MonitoredSystem system);

    void removeMonitoredSystem(String systemIdentifier);

    Collection<MonitoredSystem> getMonitoredSystems();

    MonitoredSystem getMonitoredSystem(String systemIdentifier);

    // TODO: Change this.
    MonitoredSystem getFirstMonitoredSystem();

    void registerMonitoredSystem(MonitoredSystemSpec systemSpec);

    void unregisterMonitoredSystem(MonitoredSystemSpec systemSpec);

    boolean isMonitoredSystemExist(String systemIdentifier);
}
