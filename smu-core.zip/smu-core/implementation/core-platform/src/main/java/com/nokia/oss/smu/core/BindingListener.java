package com.nokia.oss.smu.core;

import java.util.EventListener;

public interface BindingListener extends EventListener {
    void bind(BindingEvent e);

    void unbind(BindingEvent e);
}
