package com.nokia.oss.smu.core.lifecycle;

public interface Lifecycle {

    void start() throws Exception;

    void stop() throws Exception;

    State getState();
}
