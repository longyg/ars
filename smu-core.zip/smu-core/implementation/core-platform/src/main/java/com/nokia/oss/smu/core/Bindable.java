package com.nokia.oss.smu.core;

// TODO: Check concept of 'bindable' when we have strong type implementation of binding interfaces
public interface Bindable {
    <T> T getBoundObject(Class<T> clazz);

    void bind(Object object);

    void unbind(Object object);

    void addBindListener(BindingListener listener);

    void removeBindListener(BindingListener listener);
}
