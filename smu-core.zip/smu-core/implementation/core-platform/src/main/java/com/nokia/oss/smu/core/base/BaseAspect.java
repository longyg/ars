package com.nokia.oss.smu.core.base;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoringAspect;

public abstract class BaseAspect implements MonitoringAspect {

    private MonitoredSystem monitoredSystem;

    private ReadWriteLock readWriteLock = new ReentrantReadWriteLock();

    @SuppressWarnings("unchecked")
    @Override
    public final <S extends MonitoredSystem> S getMonitoredSystem() {
        Lock lock = this.readWriteLock.readLock();
        lock.lock();
        try {
            return (S) this.monitoredSystem;
        } finally {
            lock.unlock();
        }
    }

    final void internalSetMonitoredSystem(MonitoredSystem monitoredSystem) {
        Lock lock = this.readWriteLock.writeLock();
        lock.lock();
        try {
            if (monitoredSystem != null) {
                if (this.monitoredSystem != null) {
                    throw new IllegalStateException("This plugin is already used by system");
                }
                this.monitoredSystem = monitoredSystem;
                this.onPostInstall();
            } else {
                if (this.monitoredSystem == null) {
                    throw new IllegalStateException("This plugin is not used by any system");
                }
                try {
                    this.onPreUninstall();
                } finally {
                    this.monitoredSystem = null;
                }
            }
        } finally {
            lock.unlock();
        }
    }

    protected void onPostInstall() {
    }

    protected void onPreUninstall() {
    }
}
