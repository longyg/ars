package com.nokia.oss.smu.core.component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.CompositeComponent;
import com.nokia.oss.smu.core.base.BaseComponent;

public class XmlComponent extends BaseComponent implements CompositeComponent {

    private List<XmlComponent> childComponents = new ArrayList<>();

    public XmlComponent(String name, XmlComponent... childComponents) {
        this.setDisplayName(name);
        Collections.addAll(this.childComponents, childComponents);
    }

    @Override
    public List<XmlComponent> getChildren() {
        return childComponents;
    }

    @Override
    public boolean hasDescendant(Component descendant) {
        for (CompositeComponent c : childComponents) {
            if (c == descendant || c.hasDescendant(descendant)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void accept(ComponentVisitor visitor) {
        super.accept(visitor);
        for (XmlComponent childComponent : childComponents) {
            childComponent.accept(visitor);
        }
    }

    public String toString() {
        return "XmlComponent[ID: " + getId() + ", Name: " + getDisplayName() + "]";
    }
}
