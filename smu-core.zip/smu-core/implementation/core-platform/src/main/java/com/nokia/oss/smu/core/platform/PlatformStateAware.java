package com.nokia.oss.smu.core.platform;

public interface PlatformStateAware {
    void platformStartedUp();

    void platformShuttingDown();
}
