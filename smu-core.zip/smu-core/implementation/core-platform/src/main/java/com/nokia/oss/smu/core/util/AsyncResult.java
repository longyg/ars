package com.nokia.oss.smu.core.util;

public interface AsyncResult<T> {

    boolean isDone();

    boolean isCancelled();

    T tryGet();

    T get();
}
