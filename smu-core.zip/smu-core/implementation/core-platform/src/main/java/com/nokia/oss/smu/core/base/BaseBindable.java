package com.nokia.oss.smu.core.base;

import java.util.ArrayList;
import java.util.Collection;

import com.nokia.oss.smu.core.Bindable;
import com.nokia.oss.smu.core.BindingEvent;
import com.nokia.oss.smu.core.BindingListener;
import com.nokia.oss.smu.core.util.DefaultRegistry;
import com.nokia.oss.smu.core.util.Registry;

/**
 * @author jeffery.liu@nsn.com
 * @author frank.1.chen@nsn.com
 */
public abstract class BaseBindable implements Bindable {

    private Registry<Object> bindingRegistry;

    private Collection<BindingListener> bindListeners;

    public BaseBindable() {
        bindingRegistry = new DefaultRegistry<Object>();
        bindListeners = new ArrayList<BindingListener>();
    }

    @Override
    public <T> T getBoundObject(Class<T> clazz) {
        if (clazz == null) {
            throw new NullPointerException();
        }
        if (clazz == Object.class) {
            throw new IllegalArgumentException("clazz can not be java.lang.Object");
        }
        if (clazz.isInstance(this)) {
            throw new IllegalArgumentException();
        }
        return this.bindingRegistry.getOne(clazz);
    }

    @Override
    public void bind(Object object) {
        if (object != null) {
            if (this.bindingRegistry.register(object)) {
                fireObjectBound(object);
            }
        }
    }

    @Override
    public void unbind(Object object) {
        if (object != null) {
            if (this.bindingRegistry.unregister(object)) {
                fireObjectUnbound(object);
            }
        }
    }

    @Override
    public void addBindListener(BindingListener listener) {
        bindListeners.add(listener);
    }

    @Override
    public void removeBindListener(BindingListener listener) {
        bindListeners.remove(listener);
    }

    private void fireObjectBound(Object object) {
        BindingEvent e = new BindingEvent(this, object);
        for (BindingListener listener : bindListeners) {
            listener.bind(e);
        }
    }

    private void fireObjectUnbound(Object object) {
        BindingEvent e = new BindingEvent(this, object);
        for (BindingListener listener : bindListeners) {
            listener.unbind(e);
        }
    }
}
