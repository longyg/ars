package com.nokia.oss.smu.core.component;

import com.nokia.oss.smu.core.XmlParseException;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class XmlObjectParser {
    private static final Logger LOGGER = Logger.getLogger(XmlObjectParser.class.getName());

    protected Schema schema;

    protected void parse(InputStream xsdInputStream, DefaultHandler handler, InputStream componentXmlStream) throws
            XmlParseException {
        if (null == componentXmlStream) {
            throw new XmlParseException("Input cannot be null.");
        }

        Schema schema = getSchema(xsdInputStream);
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        saxParserFactory.setNamespaceAware(true);
        saxParserFactory.setSchema(schema);

        SAXParser saxParser;
        try {
            saxParser = saxParserFactory.newSAXParser();
        } catch (ParserConfigurationException | SAXException ex) {
            throw new XmlParseException("Can not create the sax parser", ex);
        }

        try {
            saxParser.parse(componentXmlStream, handler);
        } catch (IOException | SAXException ex) {
            LOGGER.log(Level.SEVERE, "Can not parse/validate the xml", ex);
            throw new XmlParseException("Can not parse/validate the xml", ex);
        } finally {
            try {
                componentXmlStream.close();
            } catch (Exception ignored) { }
        }
    }

    private Schema getSchema(InputStream xsdInputStream) {
        if (schema == null) {
            SchemaFactory schemeFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            try {
                if (xsdInputStream != null) {
                    schema = schemeFactory.newSchema(new StreamSource(xsdInputStream));
                }

            } catch (SAXException ex) {
                LOGGER.log(Level.SEVERE, "Parse failed, schema definition might not be read properly.", ex);
                ex.printStackTrace();
            }
        }

        return schema;
    }

}
