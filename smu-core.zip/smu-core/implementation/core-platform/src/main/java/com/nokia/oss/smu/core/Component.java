package com.nokia.oss.smu.core;

public interface Component extends Bindable {
    String getId();

    String getDisplayName();

    void accept(ComponentVisitor visitor);
}
