package com.nokia.oss.smu.core.util;

import java.util.Set;

/**
 * @param <T>
 * @author frank.1.chen@nsn.com
 */
public abstract class AbstractRegistry<T> implements Registry<T> {

    @Override
    public Registry<T> toReadonly() {
        return new ReadonlyImpl<T>(this);
    }

    private static class ReadonlyImpl<T> implements Registry<T> {

        private Registry<T> raw;

        public ReadonlyImpl(Registry<T> raw) {
            assert !(raw instanceof ReadonlyImpl);
            this.raw = raw;
        }

        @Override
        public boolean register(T value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean unregister(T value) {
            throw new UnsupportedOperationException();
        }

        @Override
        public <X extends T> Set<X> unregister(Class<X> type) {
            throw new UnsupportedOperationException();
        }

        @Override
        public <X extends T> Set<X> get(Class<X> type) {
            return raw.get(type);
        }

        @Override
        public <X extends T> X getOne(Class<X> type) {
            return raw.getOne(type);
        }

        @Override
        public Set<T> getRegisteredObjects() {
            return raw.getRegisteredObjects();
        }

        @Override
        public Registry<T> toReadonly() {
            return this;
        }
    }
}
