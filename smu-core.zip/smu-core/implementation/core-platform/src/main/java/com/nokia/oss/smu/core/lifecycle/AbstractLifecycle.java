package com.nokia.oss.smu.core.lifecycle;

import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.nokia.oss.smu.core.util.DefaultRegistry;
import com.nokia.oss.smu.core.util.Registry;

public abstract class AbstractLifecycle implements Lifecycle {
	
    private static final Logger LOGGER = Logger.getLogger(AbstractLifecycle.class.getName());

    private State state = State.INITIALIZED;

    private static final ReadWriteLock SHARED_RWL = new ReentrantReadWriteLock();

    private AbstractLifecycle parent;

    private Registry<AbstractLifecycle> childRegistry = new DefaultRegistry<AbstractLifecycle>();

    @Override //Can not be final, for AOP
    public void start() {
    	Lock lock = SHARED_RWL.writeLock();
    	lock.lock();
    	try {
    		this.startImpl();
    	} finally {
    		lock.unlock();
    	}
    }

    @Override //Can not be final, for AOP
    public void stop() {
    	Lock lock = SHARED_RWL.writeLock();
    	lock.lock();
    	try {
    		this.stopImpl();
    	} finally {
    		lock.unlock();
    	}
    }

    @Override //Can not be final, for AOP
    public State getState() {
        Lock lock = SHARED_RWL.readLock();
        lock.lock();
        try {
            return this.state;
        } finally {
            lock.unlock();
        }
    }

    protected void onStart() {
        // subclass should override this for doing start work
    }

    protected void onStop() {
        // subclass should override this for doing stop work
    }

    protected final void addChild(Lifecycle lifecycle) {
        if (lifecycle == null || this == lifecycle) {
            return;
        }
        if (!(lifecycle instanceof AbstractLifecycle)) {
            throw new IllegalArgumentException(
                    "lifecycle must be an instance of \""
                            + AbstractLifecycle.class.getName()
                            + "\"");
        }
        AbstractLifecycle child = (AbstractLifecycle) lifecycle;
        
        Lock lock = SHARED_RWL.writeLock();
    	lock.lock();
    	try {
	        if (child.parent == this) {
	            return;
	        }
	        if (child.parent != null) {
	            throw new IllegalArgumentException("The child is belong to another lifecycle");
	        }
	        if (this.childRegistry.register(child)) {
	            child.parent = this;
	            if (this.state.isStarted()) {
	                child.startImpl();
	            }
	        }
    	} finally {
    		lock.unlock();
    	}
    }

    protected final void removeChild(Lifecycle lifecycle) {
        if (lifecycle == null) {
            return;
        }
        if (!(lifecycle instanceof AbstractLifecycle)) {
            throw new IllegalArgumentException(
                    "lifecycle must be an instance of \""
                            + AbstractLifecycle.class.getName()
                            + "\"");
        }
        AbstractLifecycle child = (AbstractLifecycle) lifecycle;

        Lock lock = SHARED_RWL.writeLock();
        lock.lock();
        try {
        	if (child.parent != this) {
                return;
            }
            if (this.childRegistry.unregister(child)) {
                try {
                    child.stopImpl();
                } finally {
                    child.parent = null;
                }
            }
        } finally {
        	lock.unlock();
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    protected final <X extends Lifecycle> Set<X> getChildren(Class<X> type) {
        return ((Registry) this.childRegistry).get(type);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    protected final <X extends Lifecycle> X getChild(Class<X> type) {
        return (X) ((Registry) this.childRegistry).getOne(type);
    }

    private void startImpl() {
    	this.startSelf();
        this.startChildren();
    }

    private void startSelf() {
        if (!this.state.isStarted()) {
            this.state = State.STARTING;
            try {
                this.onStart();
            } catch (Exception ex) {
                this.state = State.STARTED_FAILED;
                LOGGER.log(Level.SEVERE, "Start failed", ex);
                return;
            } catch (Error err) {
                this.state = State.STARTED_FAILED;
                throw err;
            }
            this.state = State.STARTED_SUCCEEDED;
        }
    }

    private void startChildren() {
        Throwable childThrowable = null;
        for (AbstractLifecycle child : this.childRegistry.getRegisteredObjects()) {
            try {
                child.startImpl();
            } catch (RuntimeException ex) {
                if (childThrowable == null) {
                    childThrowable = ex;
                }
            } catch (Error err) {
                if (childThrowable == null) {
                    childThrowable = err;
                }
            }
        }
        if (childThrowable instanceof RuntimeException) {
            throw (RuntimeException) childThrowable;
        }
        if (childThrowable instanceof Error) {
            throw (Error) childThrowable;
        }
    }

    private void stopImpl() {
    	try {
    	this.stopChildren();
    	} finally {
    		this.stopSelf();
    	}
    }

    private void stopSelf() {
        if (this.state.isStarted()) {
            this.state = State.STOPPING;
            try {
                this.onStop();
            } catch (Exception ex) {
                this.state = State.STOPPED_FAILED;
                LOGGER.log(Level.SEVERE, "Stop failed", ex);
                return;
            } catch (Error err) {
                this.state = State.STOPPED_FAILED;
                throw err;
            }
            this.state = State.STOPPED_SUCCEEDED;
        }
    }

    private void stopChildren() {
        Throwable childThrowable = null;
        for (AbstractLifecycle child : this.childRegistry.getRegisteredObjects()) {
            try {
                child.stopImpl();
            } catch (RuntimeException ex) {
                if (childThrowable == null) {
                    childThrowable = ex;
                }
            } catch (Error err) {
                if (childThrowable == null) {
                    childThrowable = err;
                }
            }
        }
        if (childThrowable instanceof RuntimeException) {
            throw (RuntimeException) childThrowable;
        }
        if (childThrowable instanceof Error) {
            throw (Error) childThrowable;
        }
    }
}
