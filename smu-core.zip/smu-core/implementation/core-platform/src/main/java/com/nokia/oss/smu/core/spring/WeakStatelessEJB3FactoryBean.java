package com.nokia.oss.smu.core.spring;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

import javax.annotation.PostConstruct;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import org.springframework.beans.factory.annotation.Value;

public class WeakStatelessEJB3FactoryBean extends AbstractWeakDependencyFactoryBean {
	
	private Class<?> interfaceType;
	
	private String jndiName;
	
	private Object fakeObjForDisabled;
	
	private InvocationHandler fakeHandlerForDisabled;
	
	private boolean initialized;
	
	@Value("${ejb.disabled}")
	private String ejbDisabled;
	
	public WeakStatelessEJB3FactoryBean() {}
	
	public void setInterfaceType(Class<?> interfaceType) {
		if (interfaceType == null || !interfaceType.isInterface()) {
			throw new IllegalArgumentException("interfaceType must be interface");
		}
		this.interfaceType = interfaceType;
	}

	public void setJndiName(String jndiName) {
		if (jndiName == null || jndiName.isEmpty()) {
			throw new IllegalArgumentException("jndiName cannot be null or empty");
		}
		if (this.initialized) {
			throw new IllegalStateException("The current object is initialized and forzen, don't change it");
		}
		this.jndiName = jndiName;
	}

	public void setFakeObjForDisabled(Object fakeObjForDisabled) {
		this.fakeObjForDisabled = fakeObjForDisabled;
	}

	public void setFakeHandlerForDisabled(InvocationHandler fakeHandlerForDisabled) {
		this.fakeHandlerForDisabled = fakeHandlerForDisabled;
	}

	@PostConstruct
	public void initialize() {
		if (this.initialized) {
			throw new IllegalStateException("Can only be initialized once");
		}
		if (this.interfaceType == null) {
			throw new IllegalStateException("interfaceType must be configured");
		}
		if (this.jndiName == null) {
			throw new IllegalStateException("jndiName must be configured");
		}
		if (this.fakeObjForDisabled != null && !this.interfaceType.isAssignableFrom(this.fakeObjForDisabled.getClass())) {
			throw new IllegalStateException("fakeObjForDisabled must be instance of " + this.interfaceType);
		}
		this.initialized = true;
	}

	@Override
	protected Class<?>[] determineInterfaceTypes() {
		return new Class[] { this.interfaceType };
	}

	@Override
	protected Object createTarget() {
		if ("true".equals(ejbDisabled)) {
			if (this.fakeObjForDisabled != null) {
				return this.fakeObjForDisabled;
			}
			if (this.fakeHandlerForDisabled != null) {
				return Proxy.newProxyInstance(
						this.interfaceType.getClassLoader(), 
						new Class[] { this.interfaceType }, 
						this.fakeHandlerForDisabled
				);
			}
			throw new IllegalStateException("EJB is disabled but no fake object or handler");
		}
		try {
			InitialContext context = new InitialContext();
            Object obj = context.lookup(this.jndiName);
            return PortableRemoteObject.narrow(obj, this.interfaceType);
		} catch (Exception ex) {
			throw new WeakDependencyCreationException(
					"Can't crete the ejb whose jndi \""
					+ this.jndiName
					+ "\"",
					ex
			);
		}
	}
	
}
