package com.nokia.oss.smu.core.spring;

/*
 * After upgrade to Java8, delete this class and move the static method
 * into the interface UnstableReferfence
 */
public class UnstableReferences {

	public static boolean isAvailable(Object reference) {
		if (reference instanceof UnstableReference) {
			return ((UnstableReference)reference).isAvailable();
		}
		return true;
	}
	
	private UnstableReferences() {}
}
