package com.nokia.oss.smu.core.spring;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import javax.annotation.PostConstruct;
import javax.ejb.EJBHome;
import javax.ejb.EJBLocalHome;
import javax.ejb.EJBLocalObject;
import javax.ejb.EJBObject;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import org.springframework.beans.factory.annotation.Value;

public class WeakStatelessEJB2FactoryBean extends AbstractWeakDependencyFactoryBean {
	
	private Method creationMethod;
	
	private String jndiName;
	
	private Object fakeObjForDisabled;
	
	private InvocationHandler fakeHandlerForDisabled;
	
	private boolean initialized;
	
	@Value("${ejb.disabled}")
	private String ejbDisabled;
	
	public WeakStatelessEJB2FactoryBean() {}
	
	public void setHomeType(Class<? extends EJBHome> homeType) {
		if (this.initialized) {
			throw new IllegalStateException("The current object is initialized and forzen, don't change it");
		}
		if (homeType == null) {
			throw new IllegalArgumentException("homeType can not be null");
		}
		if (!EJBHome.class.isAssignableFrom(homeType) && !EJBLocalHome.class.isAssignableFrom(homeType)) {
			throw new IllegalArgumentException(
					"homeType must be derived type of " 
					+ EJBHome.class.getName() 
					+ " or " 
					+ EJBLocalHome.class.getName());
		}
		try {
			this.creationMethod = homeType.getMethod("create", new Class[0]);
		} catch (NoSuchMethodException ex) {
			throw new IllegalArgumentException(
					"homeType \""
					+ homeType.getName()
					+ "\" must support a \"create()\" method");
		} 
		if (!EJBObject.class.isAssignableFrom(this.creationMethod.getReturnType()) && 
				!EJBLocalObject.class.isAssignableFrom(this.creationMethod.getReturnType())) {
			throw new IllegalArgumentException(
					"the method \""
					+ this.creationMethod
					+ "\" of \""
					+ homeType.getName()
					+ "\" is neither \""
					+ EJBObject.class
					+ "\" nor \""
					+ EJBLocalObject.class
					+ "\"");
		}
	}

	public void setJndiName(String jndiName) {
		if (jndiName == null || jndiName.isEmpty()) {
			throw new IllegalArgumentException("jndiName cannot be null or empty");
		}
		if (this.initialized) {
			throw new IllegalStateException("The current object is initialized and forzen, don't change it");
		}
		this.jndiName = jndiName;
	}

	public void setFakeObjForDisabled(Object fakeObjForDisabled) {
		this.fakeObjForDisabled = fakeObjForDisabled;
	}

	public void setFakeHandlerForDisabled(InvocationHandler fakeHandlerForDisabled) {
		this.fakeHandlerForDisabled = fakeHandlerForDisabled;
	}

	@PostConstruct
	public void initialize() {
		if (this.creationMethod == null) {
			throw new IllegalStateException("homeType must be configured");
		}
		if (this.jndiName == null) {
			throw new IllegalStateException("jndiName must be configured");
		}
		if (this.fakeObjForDisabled != null && !this.creationMethod.getReturnType().isAssignableFrom(this.fakeObjForDisabled.getClass())) {
			throw new IllegalStateException("fakeObjForDisabled must be instance of " + this.creationMethod.getReturnType());
		}

		initialized = true;
	}

	@Override
	protected Class<?>[] determineInterfaceTypes() {
		return new Class[] { this.creationMethod.getReturnType() };
	}

	@Override
	protected Object createTarget() {
		if ("true".equals(this.ejbDisabled)) {
			if (this.fakeObjForDisabled != null) {
				return this.fakeObjForDisabled;
			}
			if (this.fakeHandlerForDisabled != null) {
				return Proxy.newProxyInstance(
						this.creationMethod.getReturnType().getClassLoader(), 
						new Class[] { this.creationMethod.getReturnType() }, 
						this.fakeHandlerForDisabled
				);
			}
			throw new IllegalStateException("EJB is disabled but no fake object or handler");
		}
		try {
			InitialContext context = new InitialContext();
            Object obj = context.lookup(this.jndiName);
            Object home = PortableRemoteObject.narrow(obj, this.creationMethod.getDeclaringClass());
            return this.creationMethod.invoke(home, new Object[0]);
		} catch (InvocationTargetException ex) {
			throw new WeakDependencyCreationException(
					"Can't crete the ejb whose jndi \""
					+ this.jndiName
					+ "\"",
					ex.getTargetException()
			);
		} catch (Exception ex) {
			throw new WeakDependencyCreationException(
					"Can't crete the ejb whose jndi \""
					+ this.jndiName
					+ "\"",
					ex
			);
		}
	}
}
