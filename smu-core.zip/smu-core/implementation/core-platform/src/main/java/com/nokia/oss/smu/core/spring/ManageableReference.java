package com.nokia.oss.smu.core.spring;

public interface ManageableReference {

	void sendCommand(String command, Object ... args);
}
