package com.nokia.oss.smu.core.view;

import com.nokia.oss.smu.core.Component;

import java.util.HashMap;
import java.util.Map;

public class ComponentRef {

	private final Component component;
	
    private String displayName;
    
    private Map<String, Object> dataMap = new HashMap<String, Object>();

    public ComponentRef(Component component) {
        this.component = component;
        setUIdisplayName();
    }

    public Component getComponent() {
        return component;
    }

    public void setDisplayName(String name) {
        displayName = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void putData(String key, Object data) {
        dataMap.put(key, data);
    }

    public Object getData(String key) {
        return dataMap.get(key);
    }

    private void setUIdisplayName() {
        displayName = component.getDisplayName();
        /**
         * code there is used for user select

         if (displayName == null) {
         return component.getDisplayName();
         }
         return displayName;

         */
    }
}
