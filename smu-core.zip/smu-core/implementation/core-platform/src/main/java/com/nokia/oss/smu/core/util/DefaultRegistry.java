package com.nokia.oss.smu.core.util;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * @param <T>
 * @author frank.1.chen@nsn.com
 */
public class DefaultRegistry<T> extends AbstractRegistry<T> {
	
    private IdentityHashSet<T> set = new IdentityHashSet<T>();

    private Map<Class<?>, IdentityHashSet<T>> typeIndex = new HashMap<Class<?>, IdentityHashSet<T>>();
    
    private ReadWriteLock readWriteLock = new ReentrantReadWriteLock();

    @Override
    public boolean register(T value) {

        if (value == null) {
            throw new IllegalArgumentException("value can not be null");
        }

        Lock lock = this.readWriteLock.writeLock();
        lock.lock();
        try {
	        if (!this.set.add(value)) {
	            return false;
	        }
	        this.addValueIntoTypeIndex(value);
        } finally {
        	lock.unlock();
        }
        return true;
    }

    @Override
    public boolean unregister(T value) {
        if (value == null) {
            throw new IllegalArgumentException("value can not be null");
        }
        
        Lock lock = this.readWriteLock.writeLock();
        lock.lock();
        try {
	        if (!this.set.remove(value)) {
	            return false;
	        }
	        this.removeValueFromTypeIndex(value);
        } finally {
        	lock.unlock();
        }
        return true;
    }

    @Override
    public <X extends T> Set<X> unregister(Class<X> type) {
    	Set<X> localset = this.get(type, true);
        for (X x : localset) {
            this.unregister(x);
        }
        return localset;
    }

    @Override
    public <X extends T> Set<X> get(Class<X> type) {
        return this.get(type, false);
    }

    @Override
    public <X extends T> X getOne(Class<X> type) {
        Set<X> values = this.get(type);
        if (values.isEmpty()) {
            return null;
        }
        if (values.size() == 1) {
            return values.iterator().next();
        }
        throw new IllegalArgumentException("Serval values can be mapped by the type: " + type.getName());
    }

    @Override
    public Set<T> getRegisteredObjects() {
        return Collections.unmodifiableSet(this.set);
    }

    private static Set<Class<?>> collectTypes(Class<?> type) {
        Set<Class<?>> types = new HashSet<Class<?>>();
        collectTypes(type, types);
        return types;
    }

    private static void collectTypes(Class<?> type, Set<Class<?>> types) {
        if (type != null && type != Object.class) {
            types.add(type);
            collectTypes(type.getSuperclass(), types);
            for (Class<?> interfaceType : type.getInterfaces()) {
                collectTypes(interfaceType, types);
            }
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private <X extends T> Set<X> get(Class<X> type, boolean includeSuperTypes) {
        if (type == null) {
            throw new IllegalArgumentException("type can not be null");
        }
        if ((Class) type == Object.class) {
            throw new IllegalArgumentException("type can not be Object");
        }

        Lock lock = this.readWriteLock.writeLock();
        lock.lock();
        try {
	        Set<X> localset = new IdentityHashSet<X>();
	        Map<Class<?>, IdentityHashSet<T>> localTypeIndex = this.typeIndex;
	        Collection<Class<?>> allTypes = includeSuperTypes ? collectTypes(type) : Collections.<Class<?>>singleton(type);
	        for (Class<?> eachType : allTypes) {
	            IdentityHashSet<X> typeIndexItem = (IdentityHashSet) localTypeIndex.get(eachType);
	            if (typeIndexItem != null) {
	                localset.addAll(typeIndexItem);
	            }
	        }
	        return localset;
        } finally {
        	lock.unlock();
        }
        
    }

    private void addValueIntoTypeIndex(T value) {
        Set<Class<?>> types = collectTypes(value.getClass());
        Map<Class<?>, IdentityHashSet<T>> localTypeIndex = this.typeIndex;
        for (Class<?> type : types) {
            IdentityHashSet<T> typeIndexItem = localTypeIndex.get(type);
            if (typeIndexItem == null) {
                typeIndexItem = new IdentityHashSet<T>();
                localTypeIndex.put(type, typeIndexItem);
            }
            typeIndexItem.add(value);
        }
    }

    private void removeValueFromTypeIndex(T value) {
        Set<Class<?>> types = collectTypes(value.getClass());
        Map<Class<?>, IdentityHashSet<T>> localTypeIndex = this.typeIndex;
        for (Class<?> type : types) {
            IdentityHashSet<T> typeIndexItem = localTypeIndex.get(type);
            if (typeIndexItem != null) {
                typeIndexItem.remove(value);
                if (typeIndexItem.isEmpty()) {
                    localTypeIndex.remove(type);
                }
            }
        }
    }
}
