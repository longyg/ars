package com.nokia.oss.smu.core.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
import org.springframework.context.ApplicationContextException;
import org.springframework.stereotype.Component;

import com.nokia.oss.smu.core.lifecycle.Lifecycle;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.platform.MonitorService;

@Component
public class LifecycleBeanProcessor implements DestructionAwareBeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		
		if (bean instanceof Lifecycle) {
			try {
				((Lifecycle)bean).start();
			} catch (Exception ex) {
				throw new BeanInitializationException("Can not start bean :" + beanName, ex);
			}
			if (bean instanceof MonitorService) {
				MonitorPlatform.getPlatform().installService((MonitorService)bean);
			}
		}
		
		return bean;
	}

	@Override
	public void postProcessBeforeDestruction(Object bean, String beanName) throws BeansException {
		
		if (bean instanceof Lifecycle) {
			if (bean instanceof MonitorService) {
				MonitorPlatform.getPlatform().uninstallService((MonitorService)bean);
			}
			try {
				((Lifecycle)bean).stop();
			} catch (Exception ex) {
				throw new ApplicationContextException("Can not stop the " + beanName, ex);
			}
		}
	}

    @Override
    public boolean requiresDestruction(Object instance) {
        return true;
    }
}
