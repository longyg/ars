package com.nokia.oss.smu.core;

import java.util.Collection;

public interface Deployment {
    Collection<Node> getNodes();
}
