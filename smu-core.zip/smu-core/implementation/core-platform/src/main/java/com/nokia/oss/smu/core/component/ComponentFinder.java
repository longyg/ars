package com.nokia.oss.smu.core.component;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;

public class ComponentFinder {

    private static final Logger LOG = Logger.getLogger(ComponentFinder.class.getName());

    private Map<String, Component> components;

    public ComponentFinder(Component rootComponent) {
        if (rootComponent == null) {
            throw new NullPointerException();
        }
        buildIdMap(rootComponent);
    }

    public Component findById(String id) {
        Component foundComponent = components.get(id);
        if (foundComponent == null) {
            LOG.warning("Cannot found object with given ID: " + id);
        }
        return foundComponent;
    }

    public Collection<? extends Component> getAllDescendants() {
        return components.values();
    }

    public boolean contains(Component c) {
        return components.containsKey(c.getId());
    }

    private void buildIdMap(Component root) {
        components = new HashMap<>();
        root.accept(new ComponentVisitor() {
            @Override
            public void visit(Component component) {
                components.put(component.getId(), component);
            }
        });
    }
}
