package com.nokia.oss.smu.core;

public interface Node {
}
