package com.nokia.oss.smu.core.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;

/**
 * @author frank.1.chen@nsn.com
 */
public class IdentityHashSet<E> implements Set<E>, Serializable {

    private static final long serialVersionUID = -1974080799614900743L;

    private static final Object PRESENT = new Object();

    private IdentityHashMap<E, Object> m;

    public IdentityHashSet() {
        m = new IdentityHashMap<E, Object>();
    }

    public IdentityHashSet(Collection<? extends E> c) {
        m = new IdentityHashMap<E, Object>((c.size() * 4 + 2) / 3);
        for (E e : c) {
            m.put(e, PRESENT);
        }
    }

    @Override
    public int size() {
        return m.size();
    }

    @Override
    public boolean isEmpty() {
        return m.isEmpty();
    }

    @Override
    public Object[] toArray() {
        return m.keySet().toArray();
    }

    @Override
    public <T> T[] toArray(T[] a) {
        return m.keySet().toArray(a);
    }

    @Override
    public boolean contains(Object o) {
        return m.containsKey(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return m.keySet().containsAll(c);
    }

    @Override
    public boolean add(E e) {
        return m.put(e, PRESENT) == null;
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        boolean modified = false;
        Map<E, Object> m2 = this.m;
        for (E e : c) {
            modified |= m2.put(e, PRESENT) == null;
        }
        return modified;
    }

    @Override
    public void clear() {
        m.clear();
    }

    @Override
    public boolean remove(Object o) {
        return m.remove(o) != null;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return m.keySet().removeAll(c);
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return m.keySet().retainAll(c);
    }

    @Override
    public Iterator<E> iterator() {
        return m.keySet().iterator();
    }

    // This private method is invokied by JVM automactially
    private void writeObject(ObjectOutputStream out) throws IOException {
        out.writeInt(m.size());
        for (E e : m.keySet()) {
            out.writeObject(e);
        }
    }

    // This private method is invokied by JVM automactially
    @SuppressWarnings("unchecked")
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        int size = in.readInt();

        // Constructor will not be inovked during deserialization,
        // so create the member data manually
        IdentityHashMap<E, Object> local_m = new IdentityHashMap<E, Object>((size * 4 + 2) / 3);

        for (int i = size - 1; i >= 0; i--) {
            E e = (E) in.readObject();
            local_m.put(e, PRESENT);
        }
        this.m = local_m;
    }
}
