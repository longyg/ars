package com.nokia.oss.smu.core.spring;

public interface UnstableReference {

	boolean isAvailable();
}
