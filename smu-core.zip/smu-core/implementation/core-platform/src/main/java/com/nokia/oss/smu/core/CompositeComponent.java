package com.nokia.oss.smu.core;

import java.util.Collection;

public interface CompositeComponent extends Component {

    Collection<? extends Component> getChildren();

    boolean hasDescendant(Component component);
}
