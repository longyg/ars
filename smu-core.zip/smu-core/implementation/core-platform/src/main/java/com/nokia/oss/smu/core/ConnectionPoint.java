package com.nokia.oss.smu.core;

import java.util.Collection;

public interface ConnectionPoint extends Bindable {
    Collection<Connection> getSourceConnections();

    Collection<Connection> getTargetConnections();
}
