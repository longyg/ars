package com.nokia.oss.smu.core;

public class XmlParseException extends Exception {

    private static final long serialVersionUID = 3879661193096364533L;

    public XmlParseException(String message) {
        super(message);
    }

    public XmlParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
