package com.nokia.oss.smu.core;

public interface ComponentVisitor {
    void visit(Component component);
}
