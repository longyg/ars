package com.nokia.oss.smu.core.platform;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoredSystemSpec;

public interface MonitoredSystemCreationService extends MonitorService {
    boolean canCreate(MonitoredSystemSpec systemSpec);

    MonitoredSystem create(MonitoredSystemSpec systemSpec);
}
