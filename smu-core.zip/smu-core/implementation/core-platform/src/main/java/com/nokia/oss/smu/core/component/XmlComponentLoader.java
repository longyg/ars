package com.nokia.oss.smu.core.component;

import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.platform.MonitorService;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import java.io.InputStream;
import java.util.Stack;

public class XmlComponentLoader extends XmlObjectParser implements ComponentLoader {

    public XmlComponent parseRootComponent(InputStream componentXmlStream) throws XmlParseException {
        HandlerImpl handler = new HandlerImpl();
        InputStream xsdInputStream = MonitorService.class.getClassLoader().getResourceAsStream("component.xsd");
        parse(xsdInputStream, handler, componentXmlStream);

        return handler.getRootComponent();
    }

    private static class HandlerImpl extends DefaultHandler {
        private static final String ATTRIBUTE_ID = "id";
        private static final String ATTRIBUTE_NAME = "name";
        private static final String COMPONENT_TAG = "component";
        private static final String TNS = "http://www.nsn.com/smu/components";

        private Stack<XmlComponent> stack = new Stack<XmlComponent>();

        private XmlComponent rootComponent;

        @Override
        public void error(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void fatalError(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes)
                throws SAXException {
            if (COMPONENT_TAG.equals(localName) && TNS.equals(uri)) {
                String id = attributes.getValue(XMLConstants.NULL_NS_URI, ATTRIBUTE_ID);
                String name = attributes.getValue(XMLConstants.NULL_NS_URI, ATTRIBUTE_NAME);
                XmlComponent component = new XmlComponent(name);
                component.setId(id);
                if (stack.isEmpty()) {
                    rootComponent = component;
                } else {
                    XmlComponent parentComponent = stack.peek();
                    parentComponent.getChildren().add(component);
                }
                stack.push(component);
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (COMPONENT_TAG.equals(localName) && TNS.equals(uri)) {
                stack.pop();
            }
        }

        public XmlComponent getRootComponent() {
            return rootComponent;
        }
    }

}
