package com.nokia.oss.smu.core.util;

import java.util.Set;

/**
 * @param <T>
 * @author frank.1.chen@nsn.com
 */
public interface Registry<T> {

    boolean register(T value);

    boolean unregister(T value);

    <X extends T> Set<X> unregister(Class<X> type);

    <X extends T> Set<X> get(Class<X> type);

    <X extends T> X getOne(Class<X> type);

    Set<T> getRegisteredObjects();

    Registry<T> toReadonly();
}
