package com.nokia.oss.smu.core.util;

public class LogUtils {
    public static String getChainedCauses(Throwable t) {
        if (t == null) {
            return "null";
        }

        String causes = "causes: ";
        Throwable throwable = t;
        while(true) {
            causes += throwable.getMessage();
            if (throwable == throwable.getCause())
                break;

            throwable = throwable.getCause();
            if (throwable == null)
                break;

            causes += "  <=  ";
        }

        return causes;
    }
}
