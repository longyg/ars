package com.nokia.oss.smu.core.lifecycle;

public enum State {
    INITIALIZED(false, true),

    STARTING(false, true),

    STARTED_SUCCEEDED(true, true),

    STARTED_FAILED(true, false),

    STOPPING(false, true),

    STOPPED_SUCCEEDED(false, true),

    STOPPED_FAILED(false, false),;

    private boolean started;

    private boolean succeeded;

    private State(boolean started, boolean succeeded) {
        this.started = started;
        this.succeeded = succeeded;
    }

    public boolean isStarted() {
        return this.started;
    }

    public boolean isSucceeded() {
        return this.succeeded;
    }
}
