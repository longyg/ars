package com.nokia.oss.smu.core.platform;

import com.nokia.oss.smu.core.lifecycle.Lifecycle;

public interface MonitorService extends Lifecycle {

}
