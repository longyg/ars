package com.nokia.oss.smu.core.platform;

import java.util.Collection;

import com.nokia.oss.smu.core.MonitoredSystem;

public interface MonitoredSystemPersistService extends MonitorService {
    void persist(MonitoredSystem system);

    void remove(MonitoredSystem system);

    Collection<MonitoredSystem> load();
}
