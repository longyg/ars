package com.nokia.oss.smu.core.component;

public interface ComponentLoader {
}
