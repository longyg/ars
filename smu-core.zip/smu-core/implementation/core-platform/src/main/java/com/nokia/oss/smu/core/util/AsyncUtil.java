package com.nokia.oss.smu.core.util;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Logger;

public class AsyncUtil {

    private static final Logger LOG = Logger.getLogger(AsyncUtil.class.getName());

    @Deprecated
    protected AsyncUtil() {
        throw new UnsupportedOperationException();
    }

    private static ExecutorService executorService;

    public static void execute(Runnable task) {
        getExecutorService().execute(task);
    }

    private static synchronized ExecutorService getExecutorService() {
        if (executorService == null ||
                executorService.isShutdown() ||
                executorService.isTerminated()) {
            executorService = Executors.newCachedThreadPool(
                    new ThreadFactory() {
                        @Override
                        public Thread newThread(Runnable r) {
                            Thread thread = new Thread(r);
                            thread.setDaemon(true);
                            return thread;
                        }
                    }
            );
        }
        return executorService;
    }

    public static synchronized void terminate() {
        if (executorService != null) {
            List<Runnable> remainTasks = executorService.shutdownNow();
            if (!remainTasks.isEmpty()) {
                LOG.warning("There are tasks after executor terminated, remains: " + remainTasks.size());
            }
            executorService = null;
        }
    }

    public static <T> AsyncResult<T> execute(Callable<T> task) {
        return new Result<T>(getExecutorService().submit(task));
    }

    private static class Result<T> implements AsyncResult<T> {

        private Future<T> future;

        public Result(Future<T> future) {
            this.future = future;
        }

        @Override
        public boolean isDone() {
            return this.future.isDone();
        }

        @Override
        public boolean isCancelled() {
            return this.future.isCancelled();
        }

        @Override
        public T tryGet() {
            return this.get(false);
        }

        @Override
        public T get() {
            return this.get(true);
        }

        private T get(boolean wait) {
            if (!wait && !this.future.isDone()) {
                return null;
            }
            try {
                return this.future.get();
            } catch (InterruptedException ex) {
                //The future is done! it is impossible to throw InterruptedException.
                throw new AssertionError(
                        "Internal bug, the InterruptedException can not be thrown"
                                + "because the get() has check the future is already done");
            } catch (ExecutionException ex) {
                throw new AsyncException(ex.getCause());
            }
        }
    }
}
