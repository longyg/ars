package com.nokia.oss.smu.core.spring;

public interface WeakDependencyTargetProxy extends UnstableReference {
	
	void create();
	
	void destroy();
}
