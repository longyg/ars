package com.nokia.oss.smu.core.base;

import java.util.ArrayList;
import java.util.List;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.Deployment;
import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoringAspect;
import com.nokia.oss.smu.core.view.ComponentView;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.core.IsCollectionContaining.hasItem;
import static org.junit.Assert.*;

public class BaseSystemTest {

    private BaseSystem system;

    @Before
    public void setUp() {
        system = new FakeSystem("fake system");
        system.setTypeIdentifier("");
    }

    @Test
    public void givenNameToConstructor_returnAsSystemName() {
        assertEquals("fake system", system.getSystemName());
    }

    @Test
    public void aspectInstalledToSystemShouldBeRetrievedByGetAspect() {
        MonitoringAspect aspect = new FakeAspect();

        system.installAspect(aspect);
        assertEquals(aspect, system.getAspect(MonitoringAspect.class));
    }

    @Test
    public void uninstalledAspectShouldNotBeRetrieved() {
        MonitoringAspect aspect = new FakeAspect();

        system.installAspect(aspect);
        system.uninstallAspect(aspect);

        assertEquals(null, system.getAspect(MonitoringAspect.class));
    }

    @Test
    public void installMultipleAspectsShouldBeRetrievedUsingTheirSupperClass() {
        BaseAspect aspect1 = new FakeAspect();
        system.installAspect(aspect1);
        BaseAspect aspect2 = new BaseAspect() {
        };
        system.installAspect(aspect2);

        assertThat(system.getAspects(BaseAspect.class), hasItem(aspect1));
        assertThat(system.getAspects(BaseAspect.class), hasItem(aspect2));
    }

    @Test(expected = IllegalArgumentException.class)
    public void canNotInstallApectWhenAspectNotBaseAspectType() {
        FakeAspect2 fa = new FakeAspect2();
        system.installAspect(fa);
    }

    @Test
    public void shouldFindComponentByComponentId() {
        assertNotNull(system.getComponentById("child1"));
    }

    class FakeSystem extends BaseSystem {
        public FakeSystem(String name) {
            super(name);
        }

        @Override
        public Deployment getDeployment() {
            return null;
        }

        @Override
        public ComponentView getComponentView() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Component getRootComponent() {
            FakeBaseComponent child1 = new FakeBaseComponent("child1");
            FakeBaseComponent child2 = new FakeBaseComponent("child2");
            FakeBaseComponent child3 = new FakeBaseComponent("child3");
            FakeBaseComponent testComponent = new FakeBaseComponent("rootComponent", child1, child2, child3);
            this.bind(testComponent);
            return testComponent;
        }

    }

    // TODO: remove coupling between client Aspect class and BaseAspect!
    class FakeAspect extends BaseAspect {
    }

    class FakeAspect2 implements MonitoringAspect {

        @Override
        public <S extends MonitoredSystem> S getMonitoredSystem() {
            // TODO Auto-generated method stub
            return null;
        }
    }

    class FakeBaseComponent extends BaseBindable implements Component {
        private List<FakeBaseComponent> childComponents = new ArrayList<FakeBaseComponent>();
        private String id;

        public FakeBaseComponent(String id, FakeBaseComponent... childComponents) {
            this.id = id;
            for (FakeBaseComponent childComponent : childComponents) {
                this.childComponents.add(childComponent);
            }
        }

        public List<FakeBaseComponent> getChildren() {
            return childComponents;
        }

        @Override
        public void accept(ComponentVisitor visitor) {
            visitor.visit(this);
            for (FakeBaseComponent childComponent : childComponents) {
                childComponent.accept(visitor);
            }
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public String getDisplayName() {
            return id;
        }
    }

}
