package com.nokia.oss.smu.core.util;

import static org.junit.Assert.*;

import java.util.concurrent.Callable;

import org.junit.Test;

import com.nokia.oss.smu.core.util.AsyncResult;
import com.nokia.oss.smu.core.util.AsyncUtil;

public class AsyncUtilTest {

    @Test(expected = UnsupportedOperationException.class)
    public void AsyncUtilChildCanNotCreateInstance() {
        @SuppressWarnings("deprecation")
        class AsyncUtilChild extends AsyncUtil {
        }
        @SuppressWarnings("unused")
        AsyncUtilChild asyncUtilChild = new AsyncUtilChild();
    }

    @Test
    public void shouldHaveExecuteMethodToRunRunableTask() {
        class Runtask implements Runnable {
            @Override
            public void run() {
            }
        }
        Runtask task = new Runtask();
        AsyncUtil.execute(task);
    }

    @Test
    public void shouldHaveTerminatMethodToStopAllThread() {
        class Runtask implements Runnable {
            @Override
            public void run() {
                try {
                    Thread.sleep(10);
                } catch (Exception e) {
                }
            }
        }
        Runtask task = new Runtask();
        class RuntaskTWO implements Runnable {
            @Override
            public void run() {
            }
        }
        RuntaskTWO task2 = new RuntaskTWO();
        AsyncUtil.execute(task);
        AsyncUtil.execute(task2);
        AsyncUtil.terminate();
    }

    @Test
    public void executeWithCallableShouldReturnAsyncResultInstance() {
        AsyncResult<String> callableInstance = AsyncUtil.execute(new Callable<String>() {
            @Override
            public String call() throws Exception {
                Thread.sleep(10);
                return "call";
            }
        });
        assertFalse(callableInstance.isCancelled());
        assertFalse(callableInstance.isDone());
        assertEquals(null, callableInstance.tryGet());
        assertEquals("call", callableInstance.get());
    }

    @Test(expected = Exception.class)
    public void executeWithCallableWhenOccuredException() {
        AsyncResult<String> callableInstance = AsyncUtil.execute(new Callable<String>() {
            @Override
            public String call() throws Exception {
                Thread.sleep(10);
                throw new InterruptedException();
            }
        });
        assertFalse(callableInstance.isCancelled());
        assertFalse(callableInstance.isDone());
        assertEquals(null, callableInstance.tryGet());
        callableInstance.get();
    }

}
