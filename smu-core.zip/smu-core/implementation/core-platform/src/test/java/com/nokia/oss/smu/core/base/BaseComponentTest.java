package com.nokia.oss.smu.core.base;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;

public class BaseComponentTest {

    @Test
    public void stupidGetterSetterTest() {
        BaseComponent bc = new BaseComponent() {
        };
        bc.setDisplayName("Display Name");
        bc.setId("myId");

        assertEquals("Display Name", bc.getDisplayName());
        assertEquals("myId", bc.getId());
    }

    @Test
    public void visitorPatternSupportTest() {
        BaseComponent bc = new BaseComponent() {
        };
        SimpleVisitor cv = new SimpleVisitor();

        bc.accept(cv);
        assertTrue(cv.hasVisited(bc));
    }

    class SimpleVisitor implements ComponentVisitor {
        private Set<Component> visitedComponents = new HashSet<Component>();

        public boolean hasVisited(Component c) {
            return visitedComponents.contains(c);
        }

        @Override
        public void visit(Component component) {
            visitedComponents.add(component);
        }
    }
}
