package com.nokia.oss.smu.core;

import com.nokia.oss.smu.core.component.XmlComponent;
import org.junit.Test;

import static org.junit.Assert.*;

public class XmlComponentTest {
    @Test
    public void displayNameShouldBeCorrect() {
        String name = "root-c";
        XmlComponent c = new XmlComponent(name);
        assertEquals(c.getDisplayName(), name);
    }

    @Test
    public void hasDescendantShouldReturnTrueWhenChildIsGiven() {
        String name = "root-c";
        XmlComponent child = new XmlComponent("child");
        XmlComponent[] childrenLevel1 = {
                new XmlComponent("sub1-c1"),
                new XmlComponent("sub1-c2"),
                child
        };
        XmlComponent rootC = new XmlComponent(name, childrenLevel1);
        assertTrue(rootC.hasDescendant(child));
    }

    @Test
    public void hasDescendantShouldReturnTrueWhenGrandchildIsGiven() {
        String name = "root-c";
        XmlComponent descendant = new XmlComponent("grandchild");
        XmlComponent[] childrenLevel2 = { descendant };
        XmlComponent[] childrenLevel1 = {
                new XmlComponent("sub1-c1"),
                new XmlComponent("sub1-c2", childrenLevel2)
        };
        XmlComponent rootC = new XmlComponent(name, childrenLevel1);
        assertTrue(rootC.hasDescendant(descendant));
    }

    @Test
    public void hasDescendantShouldReturnFalseWhenNoDescendantIsGiven() {
        String name = "root-c";
        XmlComponent notADescendant = new XmlComponent("not-descendant");
        XmlComponent[] childrenLevel2 = {
                new XmlComponent("sub2-c1"),
                new XmlComponent("sub2-c2"),
                new XmlComponent("sub2-c3")
        };
        XmlComponent[] childrenLevel1 = {
                new XmlComponent("sub1-c1"),
                new XmlComponent("sub1-c2", childrenLevel2)
        };
        XmlComponent rootC = new XmlComponent(name, childrenLevel1);
        assertFalse(rootC.hasDescendant(notADescendant));
    }
}
