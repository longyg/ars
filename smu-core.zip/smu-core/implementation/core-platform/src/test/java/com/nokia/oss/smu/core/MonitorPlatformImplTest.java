package com.nokia.oss.smu.core;

import com.nokia.oss.smu.core.base.BaseSystem;
import com.nokia.oss.smu.core.internal.MonitorPlatformImpl;
import com.nokia.oss.smu.core.lifecycle.AbstractLifecycle;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.platform.MonitorPlugin;
import com.nokia.oss.smu.core.platform.MonitorService;
import com.nokia.oss.smu.core.platform.MonitoredSystemCreationService;
import com.nokia.oss.smu.core.platform.MonitoredSystemManagerListener;
import com.nokia.oss.smu.core.platform.MonitoredSystemPersistService;
import com.nokia.oss.smu.core.view.ComponentView;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Constructor;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.IsCollectionContaining.hasItem;
import static org.junit.Assert.*;

public class MonitorPlatformImplTest {
    private MonitorPlatformImpl platform;

    @Before
    public void setUp() throws Exception {
        // Walk around for instantiate platform class
        Constructor<?>[] constructors = MonitorPlatformImpl.class.getDeclaredConstructors();
        Constructor<?> constructor = constructors[0];
        constructor.setAccessible(true);

        platform = (MonitorPlatformImpl) constructor.newInstance();
    }

    @After
    public void tearDown() {
        platform.shutdown();
    }

    @Test
    public void ShouldStartPlatForm() {
        assertFalse(platform.isStarted());
        platform.startup();
        assertTrue(platform.isStarted());
    }

    @Test
    public void getPlatformShouldBeSingletonFromStaticMethods() {
        assertEquals(platform, MonitorPlatform.getPlatform());
    }

    @Test
    public void setPluginShouldBeSuccessfully() {
        List<MonitorPlugin> plugins = new LinkedList<MonitorPlugin>();
        plugins.add(new MonitorPlugin() {
        });
        plugins.add(new MonitorPlugin() {
        });
        platform.setPlugins(plugins);
        assertEquals(2, platform.getPlugins().size());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void pluginsShouldNotBeChangeWhenUseGetMethod() {
        List<MonitorPlugin> plugins = new LinkedList<MonitorPlugin>();
        plugins.add(new MonitorPlugin() {
        });
        plugins.add(new MonitorPlugin() {
        });
        platform.setPlugins(plugins);
        //do some modify action here.
        List<MonitorPlugin> testplugins = platform.getPlugins();
        testplugins.remove(0);
    }

    @Test
    public void getNotInstalledServiceShouldGetNull() {
        assertNull(platform.findService(FakeService.class));
    }

    @Test
    public void retrieveBoundObjectByAdaptItsClass() {
        FakeService service = new FakeService();
        platform.installService(service);

        assertEquals(service, platform.findService(FakeService.class));
    }

    @Test
    public void findServiceByItsSuperClass() {
        ExtendedFakeServiceA service = new ExtendedFakeServiceA();
        platform.installService(service);
        MonitorService p3 = new AnotherFakeService();
        platform.installService(p3);

        assertEquals(p3, platform.findService(AnotherFakeService.class));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void findServicesByTheirSuperClass() {
        MonitorService p1 = new ExtendedFakeServiceA();
        MonitorService p2 = new ExtendedFakeServiceB();
        MonitorService p3 = new AnotherFakeService();

        platform.installService(p1);
        platform.installService(p2);
        platform.installService(p3);

        Collection<MonitorService> services =
                (Collection) platform.findServices(FakeService.class);

        assertEquals(2, services.size());

        assertThat(services, hasItem(p1));
        assertThat(services, hasItem(p2));
    }

    @Test
    public void uninstalledServiceShouldNotBeRetrieved() {
        MonitorService p = new FakeService();
        platform.installService(p);

        assertEquals(p, platform.findService(FakeService.class));

        platform.uninstallService(p);

        assertNull(platform.findService(FakeService.class));
    }

    @Test
    public void whenInstallAServiceAlreadyInstalledHasNoEffect() {
        MonitorService service = new FakeService();
        platform.installService(service);

        assertEquals(1, platform.findServices(FakeService.class).size());

        platform.installService(service);

        assertEquals(1, platform.findServices(FakeService.class).size());
    }

    @Test
    public void canNotRegistMonitoredSystemWhenPlatformNotStarted() {
        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("a");
        assertEquals(0, platform.getMonitoredSystems().size());
        platform.registerMonitoredSystem(systemSpec);
        assertEquals(0, platform.getMonitoredSystems().size());
    }

    @Test
    public void canNotRegistWhenCreationServiceNotExsited() {
        platform.startup();
        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("a");
        assertEquals(0, platform.getMonitoredSystems().size());
        platform.registerMonitoredSystem(systemSpec);
        assertEquals(0, platform.getMonitoredSystems().size());
    }

    @Test
    public void canRegistMonitoredSystemTemplyWhenPersistServiceIsNull() {
        FakeMonitoredSystemCreationService fmscs = new FakeMonitoredSystemCreationService();
        platform.installService(fmscs);

        platform.startup();

        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("a");
        systemSpec.setInstanceName("test");

        assertEquals(0, platform.getMonitoredSystems().size());
        platform.registerMonitoredSystem(systemSpec);
        assertEquals(1, platform.getMonitoredSystems().size());
    }

    @Test
    public void canRegistMonitoredSystemForeverWhenPersistServiceIsNotNull() {
        FakeMonitoredSystemCreationService fmscs = new FakeMonitoredSystemCreationService();
        platform.installService(fmscs);

        FakeMonitoredSystemPersistService fmsps = new FakeMonitoredSystemPersistService();
        platform.installService(fmsps);

        platform.startup();

        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("a");
        systemSpec.setInstanceName("test");

        assertEquals(0, platform.getMonitoredSystems().size());
        platform.registerMonitoredSystem(systemSpec);
        assertEquals(1, platform.getMonitoredSystems().size());
        assertEquals(1, fmsps.load().size());
    }

    @Test
    public void canNotUnregistWhenPlatformIsNotStartUp() {
        prepareRegistENV();

        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("forunregist");
        systemSpec.setInstanceName("forunregist");

        assertEquals(1, platform.getMonitoredSystems().size());
        platform.unregisterMonitoredSystem(systemSpec);
        assertEquals(1, platform.getMonitoredSystems().size());
    }

    @Test
    public void canNotUnregistWhenSystemSpecIsNotRight() {
        prepareRegistENV();
        platform.startup();

        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("wrongId");
        systemSpec.setInstanceName("wrongId");

        assertEquals(1, platform.getMonitoredSystems().size());
        platform.unregisterMonitoredSystem(systemSpec);
        assertEquals(1, platform.getMonitoredSystems().size());
    }

    @Test
    public void canUnregistWhenPlatformStartAndInputRightSystemSpec() {
        prepareRegistENV();
        platform.startup();

        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("forunregist");
        systemSpec.setInstanceName("forunregist");

        assertEquals(1, platform.getMonitoredSystems().size());
        platform.unregisterMonitoredSystem(systemSpec);
        assertEquals(0, platform.getMonitoredSystems().size());
    }

    @Test
    public void testExistenceOfRegisteredSystemShouldBeSuccessful() {
        FakeSystem system = new FakeSystem();
        platform.addMonitoredSystem("1123445", system);
        assertTrue(platform.isMonitoredSystemExist("1123445"));
    }

    @Test
    public void testExistenceOfNotRegisteredSystemShouldFail() {
        assertFalse(platform.isMonitoredSystemExist("not_exist"));
    }

    @Test
    public void registeredSystemsShouldBeRetrieved() {
        FakeSystem system = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system);

        assertEquals(1, platform.getMonitoredSystems().size());
        assertTrue(platform.getMonitoredSystems().contains(system));
    }

    @Test
    public void registeredSystemShouldBeRetriedByName() {
        FakeSystem system = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system);

        assertEquals(system, platform.getMonitoredSystem("test"));
    }

    @Test(expected = RuntimeException.class)
    public void exceptionOcurredWhenNoMonitoredSystemRegisted() {
        platform.getFirstMonitoredSystem();
    }

    @Test
    public void returnFirstMonitoredSystemWhenSystemRegisted() {
        FakeSystem system1 = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system1);
        FakeSystem system2 = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system2);
        assertEquals(system1, platform.getFirstMonitoredSystem());
    }

    @Test
    public void registeredTwoSystemsShouldBeRetrievedByTheirNames() {
        FakeSystem sys1 = new FakeSystem() {
        };
        FakeSystem sys2 = new FakeSystem() {
        };
        platform.addMonitoredSystem("sys1", sys1);
        platform.addMonitoredSystem("sys2", sys2);

        assertEquals(sys1, platform.getMonitoredSystem("sys1"));
        assertEquals(sys2, platform.getMonitoredSystem("sys2"));
    }

    @Test
    public void systemWithNameOfAlreadyRegisteredSystemCannotBeRegistered() {
        FakeSystem sys1 = new FakeSystem() {
        };
        FakeSystem sys2 = new FakeSystem() {
        };
        platform.addMonitoredSystem("sys", sys1);
        platform.addMonitoredSystem("sys", sys2);

        assertEquals(sys1, platform.getMonitoredSystem("sys"));
    }

    @Test
    public void unregisteredSystemShouldNotBeRetrieved() {
        FakeSystem system = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system);
        platform.removeMonitoredSystem("test");

        assertNull(platform.getMonitoredSystem("test"));
    }

    @Test
    public void unregisteredNotExsitedSystemShouldFailed() {
        FakeSystem system = new FakeSystem() {
        };
        platform.addMonitoredSystem("test", system);
        assertEquals(1, platform.getMonitoredSystems().size());
        platform.removeMonitoredSystem("wrongkey");
        assertEquals(1, platform.getMonitoredSystems().size());
    }

    @Test
    public void registerNullShouldResultInNothingRegistered() {
        platform.addMonitoredSystem("test", null);
        assertEquals(0, platform.getMonitoredSystems().size());
    }

    @Test
    public void registerSystemWithoutIdentifierShouldResultInItRegisteredWithItsQualifiedClassName() {
        FakeSystem system = new FakeSystem();
        platform.addMonitoredSystem(null, system);

        assertEquals(system, platform.getMonitoredSystem(FakeSystem.class.getName()));
        platform.removeMonitoredSystem(FakeSystem.class.getName());

        assertNull(platform.getMonitoredSystem(FakeSystem.class.getName()));

        platform.addMonitoredSystem("", system);
        assertEquals(system, platform.getMonitoredSystem(FakeSystem.class.getName()));
    }

    @Test
    public void serviceInstalledShouldBeStartedAfterPlatformStart() {
        FakeService service = new FakeService();
        platform.installService(service);

        assertFalse(service.getState().isStarted());
        platform.startup();

        assertTrue(service.getState().isStarted());
    }

    @Test
    public void shouldAddAndRemoveMonitoredSystemListener() {
        MonitoredSystemManagerListener listenerA = new FakeSystemListener();
        platform.addMonitoredSystemManagerListener(listenerA);
        platform.removeMonitoredSystemManagerListener(listenerA);
    }

    @Test
    public void listenerShouldWorkWhenAddOrRemoveMonitoredSystem() {
        MonitoredSystemManagerListener listenerA = new FakeSystemListener();
        platform.addMonitoredSystemManagerListener(listenerA);
        FakeSystem systema = new FakeSystem();
        assertEquals("default", systema.getTag());
        platform.addMonitoredSystem("a", systema);
        assertEquals("addA", systema.getTag());
        platform.removeMonitoredSystem("a");
        assertEquals("removeA", systema.getTag());
    }

    @Test
    public void listenerShouldWorkWhenRegistMonitoredSystem() {
        MonitoredSystemManagerListener listenerA = new FakeSystemListener();
        platform.addMonitoredSystemManagerListener(listenerA);
        prepareRegistENV();
        FakeSystem fakeSystem = (FakeSystem) platform.getMonitoredSystem("forunregist");
        assertEquals("registA", fakeSystem.getTag());
    }

    @Test
    public void listenerShouldWorkWhenUnregistMonitoredSystem() {
        MonitoredSystemManagerListener listenerA = new FakeSystemListener();
        platform.addMonitoredSystemManagerListener(listenerA);
        prepareRegistENV();
        FakeSystem fakeSystem = (FakeSystem) platform.getMonitoredSystem("forunregist");
        platform.startup();
        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("forunregist");
        systemSpec.setInstanceName("forunregist");
        platform.unregisterMonitoredSystem(systemSpec);
        assertEquals("unregistA", fakeSystem.getTag());
    }

    private void prepareRegistENV() {
        FakeMonitoredSystemCreationService fmscs = new FakeMonitoredSystemCreationService();
        platform.installService(fmscs);
        FakeMonitoredSystemPersistService fmsps = new FakeMonitoredSystemPersistService();
        platform.installService(fmsps);
        platform.startup();
        MonitoredSystemSpec systemSpec = new MonitoredSystemSpec();
        systemSpec.setSystemIdentifier("forunregist");
        systemSpec.setInstanceName("forunregist");
        systemSpec.setSequenceId(123L);
        systemSpec.setSystemType("test");
        platform.registerMonitoredSystem(systemSpec);
        platform.shutdown();
    }

    class FakeService extends AbstractLifecycle implements MonitorService {
    }

    class AnotherFakeService extends AbstractLifecycle implements MonitorService {
    }

    class ExtendedFakeServiceA extends FakeService {
    }

    class ExtendedFakeServiceB extends FakeService {
    }

    class FakeMonitoredSystemCreationService extends AbstractLifecycle implements MonitoredSystemCreationService {
        @Override
        public boolean canCreate(MonitoredSystemSpec systemSpec) {
            // TODO Auto-generated method stub
            if (systemSpec.getInstanceName() == null) return false;
            return true;
        }

        @Override
        public MonitoredSystem create(MonitoredSystemSpec systemSpec) {
            FakeSystem fs = new FakeSystem();
            fs.setIdentifier(systemSpec.getSystemIdentifier());
            fs.setTypeIdentifier(
                    systemSpec.getInstanceName() + systemSpec.getSystemType() + systemSpec.getSequenceId());
            systemSpec.setSystemType(fs.getTypeIdentifier());
            return fs;
        }
    }

    class FakeMonitoredSystemPersistService extends AbstractLifecycle implements MonitoredSystemPersistService {
        Collection<MonitoredSystem> monitoredSystems = new LinkedList<MonitoredSystem>();

        @Override
        public void persist(MonitoredSystem system) {
            // TODO Auto-generated method stub
            monitoredSystems.add(system);
        }

        @Override
        public void remove(MonitoredSystem system) {
            // TODO Auto-generated method stub
            monitoredSystems.remove(system);
        }

        @Override
        public Collection<MonitoredSystem> load() {
            // TODO Auto-generated method stub. may from other where else.
            return monitoredSystems;
        }

    }

    class FakeSystem extends BaseSystem {
        private String tag = "default";

        public FakeSystem() {
            super("fake system");
        }

        public String getTag() {
            return tag;
        }

        public void setTag(String tag) {
            this.tag = tag;
        }

        @Override
        public Deployment getDeployment() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public ComponentView getComponentView() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public Component getRootComponent() {
            // TODO Auto-generated method stub
            return null;
        }

    }

    class FakeSystemListener implements MonitoredSystemManagerListener {
        @Override
        public void onMonitoredSystemAdded(MonitoredSystem system) {
            setTag(system, "addA");
        }

        @Override
        public void onMonitoredSystemRemoved(MonitoredSystem system) {
            setTag(system, "removeA");
        }

        @Override
        public void onMonitoredSystemRegistered(MonitoredSystem system) {
            setTag(system, "registA");
        }

        @Override
        public void onMonitoredSystemUnregistered(MonitoredSystem system) {
            setTag(system, "unregistA");
        }

        @Override
        public void onMonitoredSystemLoaded(MonitoredSystem system) {
            setTag(system, "loadA");
        }

        @Override
        public void onMonitoredSystemUnloaded(MonitoredSystem system) {
            setTag(system, "unloadA");
        }

        private void setTag(MonitoredSystem system, String tagName) {
            FakeSystem fs = (FakeSystem) system;
            fs.setTag(tagName);
        }
    }

}
