package com.nokia.oss.smu.core.view;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.base.BaseComponent;
import com.nokia.oss.smu.core.component.XmlComponent;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

public class XmlComponentViewLoaderTest {

    private XmlComponentViewLoader loader;

    @Before
    public void setUp() {
        loader = new XmlComponentViewLoader();
    }

    @Test(expected = XmlParseException.class)
    public void parseEmptyTextShouldThrowXmlParseException() throws XmlParseException {
        String emptyString = "";
        InputStream is = new ByteArrayInputStream(emptyString.getBytes());
        XmlComponent component = new XmlComponent("hello");

        loader.parseComponentsView(is, component);
    }

    @Test
    public void whenCorrectXmlGivenLayersAndComponentViewShouldBeParsed() throws XmlParseException {
        String emptyString = "<?xml version=\"1.0\"?>\n"
                + "<component-view xmlns=\"http://www.nsn.com/smu/componentViews\"\n"
                + "        xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
                + "        xsi:schemaLocation=\"http://www.nsn.com/smu/componentViews component-view.xsd\">\n"
                + "\n"
                + "    <layer displayName=\"layer1\">\n"
                + "        <component-ref component-id=\"cpmId\" displayName=\"Disp\"/>\n"
                + "    </layer>"
                + " </component-view>";

        InputStream is = new ByteArrayInputStream(emptyString.getBytes());

        XmlComponent component = new XmlComponent("hello");
        component.setId("cpmId");

        ComponentView cv = loader.parseComponentsView(is, component);
        assertEquals(1, cv.getLayers().size());

        ComponentLayer layer = cv.getLayers().get(0);
        assertEquals(1, layer.getComponentRefs().size());

        ComponentRef ref = layer.getComponentRefs().get(0);
        assertEquals("Disp", ref.getDisplayName());

        assertEquals(component, ref.getComponent());
    }

    @Test(expected = XmlParseException.class)
    public void whenUnrecognizedComponentFoundExceptionShouldBeThrown() throws XmlParseException {
        String emptyString = "<?xml version=\"1.0\"?>\n"
                + "<component-view xmlns=\"http://www.nsn.com/smu/componentViews\"\n"
                + "        xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
                + "        xsi:schemaLocation=\"http://www.nsn.com/smu/componentViews component-view.xsd\">\n"
                + "\n"
                + "    <layer displayName=\"layer1\">\n"
                + "        <component-ref component-id=\"component-not-exist\" displayName=\"Disp\"/>\n"
                + "    </layer>"
                + " </component-view>";

        InputStream is = new ByteArrayInputStream(emptyString.getBytes());
        XmlComponent component = new XmlComponent("hello");
        component.setId("cpmId");

        ComponentView cv = loader.parseComponentsView(is, component);
    }

}
