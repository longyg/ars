package com.nokia.oss.smu.core.view;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.base.BaseBindable;

public class ComponentViewTest {

    private Component component;

    @Before
    public void setup() {
        component = new FakeComponent("testcomponent");
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void shouldCreateComponentRefWithComponentInstance() {
        ComponentRef cr = new ComponentRef(component);
        cr.setDisplayName("disk");
        assertEquals("disk", cr.getDisplayName());
        cr.putData("key", new Object());
        cr.putData("key1", "hello world");
        cr.putData("key2", new Integer(1));
        cr.putData("ker3", new ArrayList());
        cr.putData("ker3", new HashMap());
        cr.putData("key5", 2.0);
        assertEquals("hello world", cr.getData("key1"));
        assertEquals(2.0, cr.getData("key5"));

    }

    @Test
    public void shouldCreateComponentLayerInstance() {
        ComponentLayer cl = new ComponentLayer();
        cl.setDisplayName("hardware");
        assertEquals("hardware", cl.getDisplayName());
        assertEquals(0, cl.getComponentRefs().size());
        ComponentRef cr1 = new ComponentRef(component);
        ComponentRef cr2 = new ComponentRef(component);
        cl.getComponentRefs().add(cr1);
        cl.getComponentRefs().add(cr2);
        assertEquals(2, cl.getComponentRefs().size());
    }

    @Test
    public void shouldCreateComponentViewInstance() {
        ComponentView cv = new ComponentView();
        assertEquals(0, cv.getLayers().size());
        ComponentLayer cl = new ComponentLayer();
        ComponentLayer c2 = new ComponentLayer();
        cv.getLayers().add(cl);
        cv.getLayers().add(c2);
        assertEquals(2, cv.getLayers().size());
    }

    private class FakeComponent extends BaseBindable implements Component {
        private String id;

        public FakeComponent(String id) {
            this.id = id;
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public String getDisplayName() {
            return id;
        }

        @Override
        public void accept(ComponentVisitor visitor) {
        }

    }

}
