package com.nokia.oss.smu.core.util;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.HashSet;

import org.junit.Test;

public class IdentityHashSetTest {

    @Test
    public void shouldHasDefaultConstrutor() {
        @SuppressWarnings("unused")
        IdentityHashSet<Object> identityHashSet = new IdentityHashSet<Object>();
    }

    @Test
    public void shouldHaveAddMthod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        identityHashSet.add(testObject3);
        //for method:clear
        assertEquals(3, identityHashSet.size());
    }

    @Test
    public void shouldHaveClearMthod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        //for method:clear
        identityHashSet.clear();
        assertEquals(0, identityHashSet.size());
    }

    @Test
    public void shouldHaveRemoveAllMethod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        //for method:removeall
        Collection<TestObject> TestObjectsForRemove = new IdentityHashSet<TestObject>();
        TestObjectsForRemove.add(testObject2);
        TestObjectsForRemove.add(testObject3);
        identityHashSet.removeAll(TestObjectsForRemove);
        assertEquals(1, identityHashSet.toArray().length);
    }

    @Test
    public void ShouldHaveRemoveMethod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        //for method:remove
        identityHashSet.remove(testObject3);
        assertEquals(2, identityHashSet.toArray().length);
        assertFalse(identityHashSet.contains(testObject3));
    }

    @Test
    public void shouldHaveRetainMethod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        //for method:retainAll
        Collection<TestObject> TestObjectsForCompare = new IdentityHashSet<TestObject>();
        TestObjectsForCompare.add(testObject);
        TestObjectsForCompare.add(testObject2);
        assertFalse(!identityHashSet.retainAll(TestObjectsForCompare));
    }

    @Test
    public void shouldHaveBasicMethods() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        TestObject testObjectnotIncluded = new TestObject(4);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        //for method:isEmpty , size  , contains
        assertFalse(identityHashSet.isEmpty());
        assertEquals(3, identityHashSet.size());
        assertFalse(!identityHashSet.contains(testObject3));
        assertFalse(identityHashSet.contains(testObjectnotIncluded));
    }

    @Test
    public void shouldHaveContainAllMethod() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObject testObject2 = new TestObject(2);
        TestObject testObject3 = new TestObject(3);
        TestObject testObjectnotIncluded = new TestObject(4);
        identityHashSet.add(testObject);
        identityHashSet.add(testObject2);
        identityHashSet.add(testObject3);
        Collection<TestObject> TestObjectsForContainAll = new IdentityHashSet<TestObject>();
        TestObjectsForContainAll.add(testObject);
        assertFalse(!identityHashSet.containsAll(TestObjectsForContainAll));
        TestObjectsForContainAll.add(testObjectnotIncluded);
        assertFalse(identityHashSet.containsAll(TestObjectsForContainAll));
    }

    @Test
    public void shouldHaveToArrayMethod() {
        IdentityHashSet<String> identityHashSet = new IdentityHashSet<String>();
        identityHashSet.add("1");
        identityHashSet.add("2");
        assertEquals(2, identityHashSet.toArray().length);
    }

    @Test(expected = ClassCastException.class)
    public void shouldHaveToArrayMethodWithComponentType() {
        IdentityHashSet<String> identityHashSet = new IdentityHashSet<String>();
        identityHashSet.add("1");
        identityHashSet.add("2");
        String[] items = (String[]) identityHashSet.toArray(new String[2]);
        assertEquals(2, items.length);
        @SuppressWarnings("unused")
        //must throw exception there
                String[] wrongitems = (String[]) identityHashSet.toArray();
    }

    @Test
    public void shouldOverrideMethodsSetProvideForMultiObjectType() {
        IdentityHashSet<TestObject> identityHashSet = new IdentityHashSet<TestObject>();
        TestObject testObject = new TestObject(1);
        TestObjectSon testObjectSon = new TestObjectSon(1, 2);
        TestObjectSon testObjectSon2 = new TestObjectSon(3, 4);
        TestObjectGrandson testObjectGrandson = new TestObjectGrandson(1, 2, 3);
        identityHashSet.add(testObject);
        identityHashSet.add(testObjectSon);
        identityHashSet.add(testObjectSon2);
        identityHashSet.add(testObjectGrandson);
        //add same object action must failed
        identityHashSet.add(testObjectGrandson);
        assertEquals(4, identityHashSet.size());
    }

    @Test
    public void shouldHasConstrutorWithCollectionCopy() {
        Collection<String> sets = new HashSet<String>();
        IdentityHashSet<String> identityHashSet = new IdentityHashSet<String>();
        assertEquals(0, identityHashSet.size());
        sets.add("1");
        sets.add("2");
        IdentityHashSet<String> identityHashSetafter = new IdentityHashSet<String>(sets);
        assertEquals(2, identityHashSetafter.size());
    }

    class TestObject {
        private int x;

        TestObject(int x) {
            this.x = x;
        }

        public int getX() {
            return this.x;
        }
    }

    class TestObjectSon extends TestObject {
        private int y;

        TestObjectSon(int x, int y) {
            super(x);
            this.y = y;
        }

        public int getY() {
            return this.y;
        }
    }

    class TestObjectGrandson extends TestObjectSon {
        private int z;

        TestObjectGrandson(int x, int y, int z) {
            super(x, y);
            this.z = z;
        }

        public int getZ() {
            return this.z;
        }
    }

}
