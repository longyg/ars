package com.nokia.oss.smu.core.util;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

public class AbstractRegistryTest {

    @Test
    public void canCreateRegistryInstance() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>();
        assertNotNull(abstractRegistrys);
    }

    @Test
    public void canGetReadOnlyRegistryInstance() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>().toReadonly();
        assertNotNull(abstractRegistrys);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void registerWhenReadOnly() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>().toReadonly();
        abstractRegistrys.register(new TestPoint(1, 2));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void unregisterWhenReadOnly() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>().toReadonly();
        abstractRegistrys.unregister(new TestPoint(1, 2));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void unregisterChildTypeWhenReadOnly() {
        Registry<TestChildPoint> abstractRegistrys = new TestAbstractRegistry<TestChildPoint>().toReadonly();
        abstractRegistrys.unregister(TestChildPoint.class);
    }

    @Test
    public void getChildSetWhenReadOnly() {
        Registry<TestChildPoint> abstractRegistrys = new TestAbstractRegistry<TestChildPoint>().toReadonly();
        Set<TestChildPoint> k = abstractRegistrys.get(TestChildPoint.class);
        assertNull(k);
    }

    @Test
    public void getOneChildWhenReadOnly() {
        Registry<TestChildPoint> abstractRegistrys = new TestAbstractRegistry<TestChildPoint>().toReadonly();
        TestChildPoint k = abstractRegistrys.getOne(TestChildPoint.class);
        assertNull(k);
    }

    @Test
    public void getRegisteredObjects() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>().toReadonly();
        Set<TestPoint> RegisteredObjects = abstractRegistrys.getRegisteredObjects();
        assertEquals(0, RegisteredObjects.size());
    }

    @Test
    public void instanceShouldBeSameWhenCallReadOnly() {
        Registry<TestPoint> abstractRegistrys = new TestAbstractRegistry<TestPoint>().toReadonly();
        Registry<TestPoint> abstractRegistrys2 = abstractRegistrys.toReadonly();
        assertEquals(abstractRegistrys, abstractRegistrys2);
    }

    @SuppressWarnings("rawtypes")
    class TestAbstractRegistry<T> extends AbstractRegistry<T> {
        @Override
        public boolean register(T value) {
            return true;
        }

        @Override
        public boolean unregister(T value) {
            return false;
        }

        @Override
        public Set<T> unregister(Class type) {
            return null;
        }

        @Override
        public Set<T> get(Class type) {
            return null;
        }

        @Override
        public T getOne(Class type) {
            return null;
        }

        @Override
        public Set<T> getRegisteredObjects() {
            return new HashSet<T>();
        }
    }

    class TestPoint {
        public int x;
        public int y;

        public TestPoint(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    class TestChildPoint extends TestPoint {
        public int z;

        public TestChildPoint(int x, int y, int z) {
            super(x, y);
            this.z = z;
        }
    }

}
