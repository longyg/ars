package com.nokia.oss.smu.core.component;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.base.BaseBindable;

public class ComponentFinderTest {

    private FakeComponent testComponent;
    private FakeComponent grandsonchild121;
    private FakeComponent grandson12;
    private FakeComponent grandson11;
    private FakeComponent child1;
    private FakeComponent grandson21;
    private FakeComponent child2;
    private FakeComponent child3;

    /**
     * this method will initialize a component object tree like this.
     * -testComponent
     * --child1
     * ----grandson11
     * ----grandson12
     * ------grandsonchild121
     * --child2
     * ----grandson21
     * --child3
     */
    @Before
    public void setup() {
        grandsonchild121 = new FakeComponent("grandsonchild121");
        grandson12 = new FakeComponent("grandson12", grandsonchild121);
        grandson11 = new FakeComponent("grandson11");
        child1 = new FakeComponent("child1", grandson11, grandson12);
        grandson21 = new FakeComponent("grandson11");
        child2 = new FakeComponent("child2", grandson21);
        child3 = new FakeComponent("child3");
        testComponent = new FakeComponent("rootComponent", child1, child2, child3);
    }

    @Test(expected = NullPointerException.class)
    public void createWithNullComponent() {
        @SuppressWarnings("unused")
        ComponentFinder cv = new ComponentFinder(null);
    }

    @Test
    public void createWithComponentInstance() {
        @SuppressWarnings("unused")
        ComponentFinder cv = new ComponentFinder(testComponent);
    }

    @Test
    public void shouldGetAllChildComponents() {
        ComponentFinder cv = new ComponentFinder(testComponent);
        assertEquals(7, cv.getAllDescendants().size());
    }

    @Test
    public void containsWithComponentValue() {
        ComponentFinder cv = new ComponentFinder(testComponent);
        assertTrue(cv.contains(child1));
        assertTrue(cv.contains(grandson21));
        assertTrue(cv.contains(grandsonchild121));
        FakeComponent nullcomponent = new FakeComponent("nullcomponent");
        assertFalse(cv.contains(nullcomponent));
    }

    @Test
    public void findComponentByIdWithId() {
        ComponentFinder cv = new ComponentFinder(testComponent);
        assertEquals(child1, cv.findById("child1"));
        assertEquals(null, cv.findById("errorId"));
    }

    class FakeComponent extends BaseBindable implements Component {
        private List<FakeComponent> childComponents = new ArrayList<FakeComponent>();
        private String id;

        public FakeComponent(String id, FakeComponent... childComponents) {
            this.id = id;
            for (FakeComponent childComponent : childComponents) {
                this.childComponents.add(childComponent);
            }
        }

        public List<FakeComponent> getChildren() {
            return childComponents;
        }

        @Override
        public void accept(ComponentVisitor visitor) {
            visitor.visit(this);
            for (FakeComponent childComponent : childComponents) {
                childComponent.accept(visitor);
            }
        }

        @Override
        public String getId() {
            return id;
        }

        @Override
        public String getDisplayName() {
            return id;
        }
    }
}
