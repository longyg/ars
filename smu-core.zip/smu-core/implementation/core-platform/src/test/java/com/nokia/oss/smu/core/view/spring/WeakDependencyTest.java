package com.nokia.oss.smu.core.view.spring;

import org.junit.Assert;
import org.junit.Test;

import com.nokia.oss.smu.core.spring.AbstractWeakDependencyFactoryBean;
import com.nokia.oss.smu.core.spring.AbstractWeakDependencyFactoryBean.ThrowableHandleType;

public class WeakDependencyTest {

	@Test
	public void testRethrowOnly() throws Exception {
		WeakFactoryBean weakFactoryBean = new WeakFactoryBean(ThrowableHandleType.RETHROW_ONLY);
		Appendable appendable = (Appendable)weakFactoryBean.getObject();
		StringBuilder outBuilder = new StringBuilder();
		StringBuilder errBuilder = new StringBuilder();
		for (int i = 0; i < 8; i++) {
			try {
				appendable.appendTo(outBuilder);
			} catch (SpecialException ex) {
				errBuilder.append(ex.getMessage());
			}
		}
		Assert.assertEquals("V", outBuilder.toString());
		Assert.assertEquals("XXXXXXX", errBuilder.toString());
		Assert.assertEquals(1, weakFactoryBean.createdCount);
	}
	
	@Test
	public void testResetAndRethrow() throws Exception {
		WeakFactoryBean weakFactoryBean = new WeakFactoryBean(ThrowableHandleType.RESET_AND_RETHROW);
		Appendable appendable = (Appendable)weakFactoryBean.getObject();
		StringBuilder outBuilder = new StringBuilder();
		StringBuilder errBuilder = new StringBuilder();
		for (int i = 0; i < 8; i++) {
			try {
				appendable.appendTo(outBuilder);
			} catch (SpecialException ex) {
				errBuilder.append(ex.getMessage());
			}
		}
		Assert.assertEquals("VVVV", outBuilder.toString());
		Assert.assertEquals("XXXX", errBuilder.toString());
		Assert.assertEquals(4, weakFactoryBean.createdCount);
	}
	
	@Test
	public void testResetAndRetry() throws Exception {
		WeakFactoryBean weakFactoryBean = new WeakFactoryBean(ThrowableHandleType.RESET_AND_RETRY);
		Appendable appendable = (Appendable)weakFactoryBean.getObject();
		StringBuilder outBuilder = new StringBuilder();
		StringBuilder errBuilder = new StringBuilder();
		for (int i = 0; i < 8; i++) {
			try {
				appendable.appendTo(outBuilder);
			} catch (SpecialException ex) {
				errBuilder.append(ex.getMessage());
			}
		}
		Assert.assertEquals("VVVVVVVV", outBuilder.toString());
		Assert.assertEquals("", errBuilder.toString());
		Assert.assertEquals(8, weakFactoryBean.createdCount);
	}
	
	private static class WeakFactoryBean extends AbstractWeakDependencyFactoryBean {

		int createdCount = 0;
		
		ThrowableHandleType handleType;
		
		WeakFactoryBean(ThrowableHandleType handleType) {
			this.handleType = handleType;
		}
		
		@Override
		protected Class<?>[] determineInterfaceTypes() {
			return new Class[] { Appendable.class };
		}

		@Override
		protected ThrowableHandleType handleThrowable(Throwable ex) {
			return this.handleType;
		}

		@Override
		protected Object createTarget() {
			this.createdCount++;
			return new Target();
		}
	}
	
	private static class Target implements Appendable {

		private int invokeCount;
		@Override
		public void appendTo(StringBuilder builder) {
			if (invokeCount++ != 0) {
				throw new SpecialException("X");
			}
			builder.append("V");
		}
	}
	
	private static class SpecialException extends RuntimeException {

		private static final long serialVersionUID = -6428282187557322062L;

		public SpecialException(String message) {
			super(message);
		}
	}
}
