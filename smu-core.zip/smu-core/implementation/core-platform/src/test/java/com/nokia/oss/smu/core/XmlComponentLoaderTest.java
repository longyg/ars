package com.nokia.oss.smu.core;

import com.nokia.oss.smu.core.component.XmlComponent;
import com.nokia.oss.smu.core.component.XmlComponentLoader;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class XmlComponentLoaderTest {

    private XmlComponentLoader loader;
    private String xmlOneLevel = "<?xml version=\"1.0\"?>\n"
            + "<component id=\"netact15\"\n"
            + "        xmlns=\"http://www.nsn.com/smu/components\"\n"
            + "        name=\"NetAct\">\n"
            + "    <component id=\"core-fm\" name=\"Fault Management\"/>\n"
            + "    <component id=\"core-cm\" name=\"Configuration Management\"/>\n"
            + "    <component id=\"core-pm\" name=\"Performance Management\"/>\n"
            + "</component>\n";

    private String xmlTwoLevels = "<?xml version=\"1.0\"?>\n"
            + "<component id=\"netact15\"\n"
            + "        xmlns=\"http://www.nsn.com/smu/components\"\n"
            + "        name=\"NetAct\">\n"
            + "    <component id=\"core-fm\" name=\"Fault Management\">\n"
            + "    <component id=\"cpu\" name=\"CPU\"/>\n"
            + "    </component>\n"
            + "    <component id=\"core-cm\" name=\"Configuration Management\"/>\n"
            + "    <component id=\"core-pm\" name=\"Performance Management\"/>\n"
            + "</component>\n";

    @Before
    public void setUp() throws Exception {
        loader = new XmlComponentLoader();
    }

    @Test(expected = XmlParseException.class)
    public void whenGivenNullExceptionShouldRaise() throws XmlParseException {
        XmlComponent root = loader.parseRootComponent(null);
        root.getChildren();
    }

    @Test(expected = XmlParseException.class)
    public void whenGivenEmptyInputStreamExceptionShouldRaise() throws XmlParseException {
        String emptyString = "";
        InputStream is = new ByteArrayInputStream(emptyString.getBytes());

        XmlComponent root = loader.parseRootComponent(is);
        root.getChildren();
    }

    @Test
    public void typicalComponentXmlShouldBeParsedCorrectly() throws XmlParseException {
        InputStream is = new ByteArrayInputStream(xmlOneLevel.getBytes());
        XmlComponent root = loader.parseRootComponent(is);
        Collection<? extends Component> components = root.getChildren();
        assertNotNull(components);

        assertEquals(3, components.size());
    }

    @Test
    public void componentWithChildrenXmlShouldBeParsedCorrectly() throws XmlParseException {

        InputStream is = new ByteArrayInputStream(xmlTwoLevels.getBytes());
        XmlComponent root = loader.parseRootComponent(is);
        Collection<? extends Component> components = root.getChildren();
        assertNotNull(components);

        assertEquals(3, components.size());
        for (Component c : components) {
            if (c.getId().equals("core-fm")) {
                assertEquals(1, ((XmlComponent) c).getChildren().size());
            }
        }
    }
}
