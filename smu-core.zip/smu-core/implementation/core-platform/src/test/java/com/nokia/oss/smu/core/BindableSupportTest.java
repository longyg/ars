package com.nokia.oss.smu.core;

import com.nokia.oss.smu.core.base.BaseBindable;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class BindableSupportTest {
    private BaseBindable adaptableSupport;

    @Before
    public void setUp() throws Exception {
        adaptableSupport = new BaseBindable() {
        };
    }

    @Test
    public void bindObjectShouldBeSuccess() {
        Integer a = new Integer(1);
        adaptableSupport.bind(a);
        assertEquals(a, adaptableSupport.getBoundObject(Integer.class));
    }

    @Test(expected = NullPointerException.class)
    public void getBoundObjcetWhenInputNull() {
        adaptableSupport.getBoundObject(null);
    }

    @Test
    public void retrieveBoundObjectByAdaptItsClass() {
        Object customObject = "StringObject";
        adaptableSupport.bind(customObject);

        assertNotNull(adaptableSupport.getBoundObject(String.class));
    }

    @Test
    public void retrieveBoundObjectByAdaptItsSuperClass() {
        class Base {
        }
        class Extended extends Base {
        }

        Extended extendedObject = new Extended();
        adaptableSupport.bind(extendedObject);

        assertNotNull(adaptableSupport.getBoundObject(Base.class));
    }

    @Test
    public void unboundObjectShouldBeNotAdaptable() {
        Object customObject = "StringObject";
        adaptableSupport.bind(customObject);

        assertNotNull(adaptableSupport.getBoundObject(String.class));
    }

    @Test
    public void whenBindingHappenAfterListenerAddedToObjectListenerShouldBeNotified() {
        FakeBindListener fbl = new FakeBindListener();
        adaptableSupport.addBindListener(fbl);

        assertNull(fbl.getBoundEvent());
        assertNull(fbl.getUnboundEvent());

        String stringObject = "theStringObject";
        adaptableSupport.bind(stringObject);

        assertNotNull(fbl.getBoundEvent());
        assertEquals(adaptableSupport, fbl.getBoundEvent().getSource());
        assertEquals(stringObject, fbl.getBoundEvent().getObject());
    }

    @Test
    public void whenUnbindingHappenListenerShouldBeNotified() {
        FakeBindListener fbl = new FakeBindListener();
        adaptableSupport.addBindListener(fbl);

        String stringObject = "theStringObject";
        adaptableSupport.bind(stringObject);

        adaptableSupport.unbind(stringObject);
        assertNotNull(fbl.getBoundEvent());
        assertEquals(adaptableSupport, fbl.getUnboundEvent().getSource());
        assertEquals(stringObject, fbl.getUnboundEvent().getObject());
    }

    @Test
    public void whenBindingHappenedRemovedListenerCannotBeNotified() {
        FakeBindListener fbl = new FakeBindListener();
        adaptableSupport.addBindListener(fbl);
        adaptableSupport.removeBindListener(fbl);
        String stringObject = "theStringObject";
        adaptableSupport.bind(stringObject);

        assertNull(fbl.getBoundEvent());
        assertNull(fbl.getUnboundEvent());
    }

    @Test
    public void whenUnbindingHappenedRemovedListenerCannotBeNotified() {
        FakeBindListener fbl = new FakeBindListener();
        adaptableSupport.addBindListener(fbl);
        adaptableSupport.removeBindListener(fbl);
        String stringObject = "theStringObject";
        adaptableSupport.bind(stringObject);
        adaptableSupport.unbind(stringObject);

        assertNull(fbl.getUnboundEvent());
    }

    //TODO: Add multiple listener binding cases?

    class FakeBindListener implements BindingListener {
        private BindingEvent boundEvent;
        private BindingEvent unboundEvent;

        @Override
        public void bind(BindingEvent e) {
            boundEvent = e;
        }

        @Override
        public void unbind(BindingEvent e) {
            unboundEvent = e;
        }

        public BindingEvent getBoundEvent() {
            return boundEvent;
        }

        public BindingEvent getUnboundEvent() {
            return unboundEvent;
        }
    }

}
