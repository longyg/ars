package com.nokia.oss.smu.core.lifecycle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class AbstractLifecycleTest {

    private AbstractLifecycle lifecycle;

    @Before
    public void setUp() {
        lifecycle = new AbstractLifecycle() {
        };
    }

    @Test
    public void theStateShouldBeInitialedAfterCreation() {
        assertEquals(State.INITIALIZED, lifecycle.getState());
    }

    @Test
    public void stateShouldBeStartedSucceededWhenLifecycleStarted() throws Exception {
        lifecycle.start();
        assertEquals(State.STARTED_SUCCEEDED, lifecycle.getState());
    }

    @Test
    public void stateShouldBeStoppedSucceededWhenLifecycleStopped() throws Exception {
        lifecycle.start();
        lifecycle.stop();
        assertEquals(State.STOPPED_SUCCEEDED, lifecycle.getState());
    }

    @Test
    public void stateShouldBeStartedFailedWhenLifecycleStartFailed() {
        AbstractLifecycle lifecycle = new AbstractLifecycle() {
            @Override
            protected void onStart() {
                throw new Error("test error");
            }
        };

        try {
            lifecycle.start();
        } catch (Error ignored) {
        }

        assertEquals(State.STARTED_FAILED, lifecycle.getState());
        assertFalse(lifecycle.getState().isSucceeded());
    }

    @Test
    public void stateShouldBeStartedFailedWhenLifecycleStartOccurredExecption() {
        AbstractLifecycle lifecycle = new AbstractLifecycle() {
            @Override
            protected void onStart() {
                throw new IllegalArgumentException();
            }
        };
        try {
            lifecycle.start();
        } catch (Exception ignored) {
        }

        assertEquals(State.STARTED_FAILED, lifecycle.getState());
        assertFalse(lifecycle.getState().isSucceeded());
    }

    @Test
    public void childStateShouldBeStartSuccessWhenParentStartLifecycle() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        parentLifecycle.start();
        for (AbstractLifecycle child : parentLifecycle.getChildren(AbstractLifecycle.class)) {
            assertEquals(State.STARTED_SUCCEEDED, child.getState());
        }
    }

    @Test
    public void firstChildStateShouldBeStartedFailedWhenParentOccuredError() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
            @Override
            protected void onStart() {
                throw new Error();
            }
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        try {
            parentLifecycle.start();
            Assert.fail("Must throw exception, can not reach here");
        } catch (Throwable e) {

        }
        assertEquals(State.STARTED_FAILED, childLifecycle1.getState());
        assertEquals(State.STARTED_SUCCEEDED, childLifecycle2.getState());

    }

    @Test
    public void firstChildStateShouldBeStartedFailedWhenOccuredRuntimeException() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
            @Override
            protected void onStart() {
                throw new IllegalArgumentException();
            }
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        try {
            parentLifecycle.start();
            Assert.fail("Must throw exception, can not reach here");
        } catch (Throwable e) {

        }
        assertEquals(State.STARTED_FAILED, childLifecycle1.getState());
        assertEquals(State.STARTED_SUCCEEDED, childLifecycle2.getState());

    }

    @Test
    public void stateShouldBeStoppedFailedWhenLifecycleStopFailed() throws Exception {
        AbstractLifecycle lifecycle = new AbstractLifecycle() {
            @Override
            protected void onStop() {
                throw new Error("test error");
            }
        };

        try {
            lifecycle.start();
            lifecycle.stop();
        } catch (Error ignored) {
        }

        assertEquals(State.STOPPED_FAILED, lifecycle.getState());
        assertFalse(lifecycle.getState().isSucceeded());
    }

    @Test
    public void stateShouldBeStoppedFailedWhenLifecycleStopOccurredExecption() throws Exception {
        AbstractLifecycle lifecycle = new AbstractLifecycle() {
            @Override
            protected void onStop() {
                throw new IllegalArgumentException();
            }
        };

        try {
            lifecycle.start();
            lifecycle.stop();
        } catch (Error ignored) {
        }

        assertEquals(State.STOPPED_FAILED, lifecycle.getState());
        assertFalse(lifecycle.getState().isSucceeded());
    }

    @Test
    public void childStateShouldBeStoppedSuccessWhenParentStopLifecycle() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        parentLifecycle.start();
        parentLifecycle.stop();
        for (AbstractLifecycle child : parentLifecycle.getChildren(AbstractLifecycle.class)) {
            assertEquals(State.STOPPED_SUCCEEDED, child.getState());
        }
    }

    @Test
    public void firstChildStateShouldBeStoppedFailedWhenOccuredError() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
            @Override
            protected void onStop() {
                throw new Error();
            }
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        parentLifecycle.start();
        try {
            parentLifecycle.stop();
            Assert.fail("Must throw exception, can not reach here");
        } catch (Throwable e) {

        }
        assertEquals(State.STOPPED_FAILED, childLifecycle1.getState());
        assertEquals(State.STOPPED_SUCCEEDED, childLifecycle2.getState());
    }

    @Test
    public void firstChildStateShouldBeStoppedFailedWhenOccuredRuntimeException() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle1 = new AbstractLifecycle() {
            @Override
            protected void onStop() {
                throw new IllegalArgumentException();
            }
        };
        AbstractLifecycle childLifecycle2 = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle1);
        parentLifecycle.addChild(childLifecycle2);
        parentLifecycle.start();
        try {
            parentLifecycle.stop();
            Assert.fail("Must throw exception, can not reach here");
        } catch (Throwable e) {

        }
        assertEquals(State.STOPPED_FAILED, childLifecycle1.getState());
        assertEquals(State.STOPPED_SUCCEEDED, childLifecycle2.getState());
    }

    @Test
    public void GetChildShouldBeEmptyWhenArgumentWithNullValue() {
        AbstractLifecycle nullLifecycle = null;
        lifecycle.addChild(nullLifecycle);
        assertEquals(null, lifecycle.getChild(AbstractLifecycle.class));
    }

    @Test
    public void GetChildShouldBeEmptyWhenArgumentWithItself() {
        lifecycle.addChild(lifecycle);
        assertEquals(null, lifecycle.getChild(AbstractLifecycle.class));
    }

    @Test(expected = IllegalArgumentException.class)
    public void AddChildWhenArgumentNotAbstractLifecycleInstance() {
        LifecycleImplementForTest lifecycleImplementForTest = new LifecycleImplementForTest();
        lifecycle.addChild(lifecycleImplementForTest);
    }

    @Test
    public void AddChildShouldBeEscapedWhenArgumentWithChildExistd() {
        AbstractLifecycle parentlifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childlifecycle = new AbstractLifecycle() {
        };
        parentlifecycle.addChild(childlifecycle);
        parentlifecycle.addChild(childlifecycle);
        assertEquals(1, parentlifecycle.getChildren(AbstractLifecycle.class).size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void AddChildWhenChildParentIsNotNull() {
        AbstractLifecycle childlifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle parentlifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle formerparentlifecycle = new AbstractLifecycle() {
        };
        formerparentlifecycle.addChild(childlifecycle);
        parentlifecycle.addChild(childlifecycle);
    }

    @Test
    public void AddChildShouldCorrectWhenParentLifecycleStatusIsStarted() {
        AbstractLifecycle parentlifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childlifecycle = new AbstractLifecycle() {
        };
        parentlifecycle.start();
        parentlifecycle.addChild(childlifecycle);
        assertEquals(1, parentlifecycle.getChildren(AbstractLifecycle.class).size());
    }

    @Test
    public void removeChildShouldBeEscapedWhenArgumentWithNullValue() {
        AbstractLifecycle parentlifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childlifecycle = new AbstractLifecycle() {
        };
        parentlifecycle.addChild(childlifecycle);
        childlifecycle = null;
        parentlifecycle.removeChild(childlifecycle);
        assertEquals(1, parentlifecycle.getChildren(AbstractLifecycle.class).size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void removeChildWhenArgumentNotAbstractLifecycleInstance() {
        LifecycleImplementForTest lifecycleImplementForTest = new LifecycleImplementForTest();
        lifecycle.removeChild(lifecycleImplementForTest);
    }

    @Test
    public void removeChildShouldFailedWhenChildParentIsNotRight() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle thirdGuy = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle);
        thirdGuy.removeChild(childLifecycle);
        parentLifecycle.removeChild(thirdGuy);
        assertEquals(1, parentLifecycle.getChildren(AbstractLifecycle.class).size());
    }

    @Test
    public void removeChildShouldCorrect() {
        AbstractLifecycle parentLifecycle = new AbstractLifecycle() {
        };
        AbstractLifecycle childLifecycle = new AbstractLifecycle() {
        };
        parentLifecycle.addChild(childLifecycle);
        parentLifecycle.removeChild(childLifecycle);
        assertEquals(0, parentLifecycle.getChildren(AbstractLifecycle.class).size());
    }

    class LifecycleImplementForTest implements Lifecycle {

        @Override
        public void start() throws Exception {
            // TODO Auto-generated method stub

        }

        @Override
        public void stop() throws Exception {
            // TODO Auto-generated method stub

        }

        @Override
        public State getState() {
            // TODO Auto-generated method stub
            return null;
        }

    }

}
