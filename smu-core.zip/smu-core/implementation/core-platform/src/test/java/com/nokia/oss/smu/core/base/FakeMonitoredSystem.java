package com.nokia.oss.smu.core.base;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.Deployment;
import com.nokia.oss.smu.core.base.BaseSystem;
import com.nokia.oss.smu.core.view.ComponentView;

public class FakeMonitoredSystem extends BaseSystem {

    private Component root;

    public FakeMonitoredSystem() {
        super("Fake system");
    }

    @Override
    public Deployment getDeployment() {
        return null;
    }

    @Override
    public ComponentView getComponentView() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Component getRootComponent() {
        return root;
    }

    public void setRootComponent(Component c) {
        root = c;
    }
}
