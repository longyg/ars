package com.nokia.oss.smu.core.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class AsyncExceptionTest {

    @Test
    public void asyncExceptionShouldbeCreatedRightWay() {
        AsyncException ae1 = new AsyncException();
        ;
        AsyncException ae2 = new AsyncException(new Throwable());
        AsyncException ae3 = new AsyncException("system error");
        AsyncException ae4 = new AsyncException("system error", new Throwable());
        assertNotNull(ae1);
        assertNotNull(ae2);
        assertNotNull(ae3);
        assertNotNull(ae4);
    }

}
