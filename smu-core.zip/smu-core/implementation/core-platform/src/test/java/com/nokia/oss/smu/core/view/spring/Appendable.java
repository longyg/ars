package com.nokia.oss.smu.core.view.spring;

public interface Appendable {
	
	void appendTo(StringBuilder builder);
}