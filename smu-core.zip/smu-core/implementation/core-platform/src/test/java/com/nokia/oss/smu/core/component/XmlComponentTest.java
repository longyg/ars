package com.nokia.oss.smu.core.component;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class XmlComponentTest {

    private XmlComponent testComponent;
    private XmlComponent grandsonchild121;
    private XmlComponent grandson12;
    private XmlComponent grandson11;
    private XmlComponent child1;
    private XmlComponent grandson21;
    private XmlComponent child2;
    private XmlComponent child3;

    /**
     * this method will initialize a component object tree like this.
     * -testComponent
     * --child1
     * ----grandson11
     * ----grandson12
     * ------grandsonchild121
     * --child2
     * ----grandson21
     * --child3
     */
    @Before
    public void setup() {
        grandsonchild121 = new XmlComponent("grandsonchild121");
        grandson12 = new XmlComponent("grandson12", grandsonchild121);
        grandson11 = new XmlComponent("grandson11");
        child1 = new XmlComponent("child1", grandson11, grandson12);
        grandson21 = new XmlComponent("grandson11");
        child2 = new XmlComponent("child2", grandson21);
        child3 = new XmlComponent("child3");
        testComponent = new XmlComponent("rootComponent", child1, child2, child3);
    }

    @Test
    public void canSetIdAndDisplayName() {
        testComponent.setId("rootId");
        String answer = "XmlComponent[ID: rootId, Name: rootComponent]";
        assertEquals(answer, testComponent.toString());
    }

}
