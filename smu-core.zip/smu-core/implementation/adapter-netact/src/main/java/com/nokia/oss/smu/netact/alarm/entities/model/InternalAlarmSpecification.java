package com.nokia.oss.smu.netact.alarm.entities.model;

import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm.AckState;
import org.apache.commons.lang3.StringUtils;

public class InternalAlarmSpecification {

	private Set<AlarmSeverity> severities;
	
	private AckState ackState;
	
	private Collection<String> mappedComponentIds;

	private boolean unmapped;
	
	private List<Order> orders;
	
	public Collection<AlarmSeverity> getSeverities() {
		return this.severities;
	}
	
	public void setSeverities(Collection<AlarmSeverity> severities) {
		Set<AlarmSeverity> set = EnumSet.noneOf(AlarmSeverity.class);
		for (AlarmSeverity severity : severities) {
			if (severity != null) {
				set.add(severity);
			}
		}
		this.severities = set;
	}
	
	public AckState getAckState() {
		return ackState;
	}

	public void setAckState(AckState ackState) {
		this.ackState = ackState;
	}
	
	public Collection<String> getMappedComponentIds() {
		return mappedComponentIds;
	}

	public void setMappedComponentIds(Collection<String> mappedComponentIds) {
		this.mappedComponentIds = mappedComponentIds;
	}

	public boolean isUnmapped() {
		return unmapped;
	}

	public void setUnmapped(boolean unmapped) {
		this.unmapped = unmapped;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
        return "Severity limit:" + (severities == null ? "null" : StringUtils.join(severities, ",")) +
                " Ack state: " + ackState +
                " Component ids:" + (mappedComponentIds == null ? "null" : StringUtils.join(mappedComponentIds, ",")) +
                " Orders: " + (orders == null ? "null" : StringUtils.join(orders, ","));
	}
}
