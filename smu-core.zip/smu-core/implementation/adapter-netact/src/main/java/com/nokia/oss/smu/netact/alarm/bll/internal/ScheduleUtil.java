package com.nokia.oss.smu.netact.alarm.bll.internal;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ScheduleUtil {

    private static final long MAX_REMINDER_SENDING_INTERVAL = 24L * 3600L * 1000L;

    private static final Logger LOGGER = Logger.getLogger(ScheduleUtil.class.getName());

    public static long getAlignedMills(TimeZone zone, long millis, long interval) {
        if (interval <= 0) {
            return millis;
        }
        if (interval > MAX_REMINDER_SENDING_INTERVAL) {
            LOGGER.finest("reminder sending interval is bigger than 24 hours which is upper limit.");
            interval = MAX_REMINDER_SENDING_INTERVAL;
        }

        long offset = zone.getOffset(millis);
        return millis - (millis + offset) % interval;
    }

    public static long getAlignedMills(long millis, long interval) {
        return getAlignedMills(TimeZone.getDefault(), millis, interval);
    }
}
