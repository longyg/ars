package com.nokia.oss.smu.netact.alarm.entities.model;

import java.util.List;

public class LimitedResult<T> {

	private boolean overflow;
	private long totalAlarmNumber = 0;
	private long matchedAlarmNumber = 0;
	private List<T> entities;
	
	public LimitedResult() {
	}
	
	public LimitedResult(boolean overflow, List<T> entities) {
		this.overflow = overflow;
		this.entities = entities;
	}
		
	public LimitedResult(boolean overflow, List<T> entities,long totalAlarmNumber,long  matchedAlarmNumber) {
		this.overflow = overflow;
		this.entities = entities;
		this.totalAlarmNumber = totalAlarmNumber;
		this.matchedAlarmNumber = matchedAlarmNumber;
	}

	public long getTotalAlarmNumber() {
		return totalAlarmNumber;
	}

	public void setTotalAlarmNumber(long totalAlarmNumber) {
		this.totalAlarmNumber = totalAlarmNumber;
	}

	public long getMatchedAlarmNumber() {
		return matchedAlarmNumber;
	}

	public void setMatchedAlarmNumber(long matchedAlarmNumber) {
		this.matchedAlarmNumber = matchedAlarmNumber;
	}

	public boolean isOverflow() {
		return overflow;
	}

	public void setOverflow(boolean overflow) {
		this.overflow = overflow;
	}

	public List<T> getEntities() {
		return entities;
	}

	public void setEntities(List<T> entities) {
		this.entities = entities;
	}
}
