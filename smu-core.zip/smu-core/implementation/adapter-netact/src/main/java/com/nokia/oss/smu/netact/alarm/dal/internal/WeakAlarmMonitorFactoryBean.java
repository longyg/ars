package com.nokia.oss.smu.netact.alarm.dal.internal;

import java.net.URL;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nokia.oss.fmaccess.service.impl.AlarmMonitorService;
import com.nokia.oss.interfaces.fmaccess.service.AlarmMonitorSEI;

@Component
public class WeakAlarmMonitorFactoryBean extends AbstractWeakCXFDependencyFactoryBean {

	@Value("${fm.access.web.service.uri}")
	private String uri;

	@Override
	public Class<?> getObjectType() {
		return AlarmMonitorSEI.class;
	}

	@Override
	protected String getServiceUri() {
		return uri;
	}

	@Override
	protected Object createPortObject(String serviceUrl) throws Throwable {
		AlarmMonitorService monitorService = new AlarmMonitorService(new URL(serviceUrl));
		return monitorService.getAlarmMonitorPort();
	}
}
