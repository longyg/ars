package com.nokia.oss.smu.netact.alarm.dal.internal;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.netact.alarm.dal.AlarmMailTaskRepository;
import com.nokia.oss.smu.netact.alarm.entities.AlarmMailTask;
import com.nokia.oss.smu.netact.alarm.entities.AlarmMailTask_;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm_;

@Repository
public class AlarmMailTaskRepositoryImpl implements AlarmMailTaskRepository {
    
    private static final int DB_IN_LIMIT = 1000;
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<AlarmMailTask> getNewTasks() {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaQuery<AlarmMailTask> cq = cb.createQuery(AlarmMailTask.class);
        Root<AlarmMailTask> alarmMailTask = cq.from(AlarmMailTask.class);
        alarmMailTask.fetch(AlarmMailTask_.alarm);
        cq.where(cb.isNull(alarmMailTask.get(AlarmMailTask_.lastSentTime)));
        return this.em.createQuery(cq).getResultList();
    }

    @Override
    public void persistTask(AlarmMailTask task) {
        this.em.persist(task);
    }

    @Override
    public void deleteTasks(Iterable<AlarmMailTask> tasks) {
        Iterator<AlarmMailTask> i = tasks.iterator();
        while (i.hasNext()) {
            CriteriaBuilder cb = this.em.getCriteriaBuilder();
            CriteriaDelete<AlarmMailTask> cd = cb.createCriteriaDelete(AlarmMailTask.class);
            Root<AlarmMailTask> alarmMailTask = cd.from(AlarmMailTask.class);
            In<Long> in = cb.in(alarmMailTask.get(AlarmMailTask_.id));
            for (int count = 0; i.hasNext() && count++ < DB_IN_LIMIT; ) {
                in.value(i.next().getId());
            }

            cd.where(in);
            this.em.createQuery(cd).executeUpdate();
        }
    }

    @Override
    public void deleteTasksByAlarms(Iterable<InternalAlarm> alarms) {
        
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        Iterator<InternalAlarm> itr = alarms.iterator();
        
        while (itr.hasNext()) {
            CriteriaDelete<AlarmMailTask> cd = cb.createCriteriaDelete(AlarmMailTask.class);
            Root<AlarmMailTask> alarmMailTask = cd.from(AlarmMailTask.class);
            In<InternalAlarm> in = cb.in(alarmMailTask.get(AlarmMailTask_.alarm));
            for (int i = DB_IN_LIMIT; i > 0 && itr.hasNext(); i--) {
                in.value(itr.next());
            }
            cd.where(in);
            this.em.createQuery(cd).executeUpdate();
        }
    }

    @Override
    public void deleteTasksByAlarmSeverity(AlarmSeverity severity) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaDelete<AlarmMailTask> cd = cb.createCriteriaDelete(AlarmMailTask.class);
        Root<AlarmMailTask> alarmMailTask = cd.from(AlarmMailTask.class);
        Subquery<Long> sq;
        { // "delete" does not allows join, so use sub query.
            sq = cd.subquery(Long.class);
            Root<InternalAlarm> alarm = sq.from(InternalAlarm.class);
            sq
            .where(cb.equal(alarm.get(InternalAlarm_.severity), severity))
            .select(alarm.get(InternalAlarm_.id));
        }
        cd.where(cb.in(alarmMailTask.get(AlarmMailTask_.alarm).get(InternalAlarm_.id)).value(sq));
        this.em.createQuery(cd).executeUpdate();
    }

}
