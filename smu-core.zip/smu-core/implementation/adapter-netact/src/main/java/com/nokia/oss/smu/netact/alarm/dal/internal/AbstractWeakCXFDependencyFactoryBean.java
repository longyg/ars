package com.nokia.oss.smu.netact.alarm.dal.internal;

import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;

import com.nokia.oss.smu.core.util.LogUtils;

import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.service.factory.ServiceConstructionException;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.beans.factory.annotation.Value;

import com.nokia.oss.credserv.credentiallibrary.CredentialReader;
import com.nokia.oss.smu.core.spring.AbstractWeakDependencyFactoryBean;
import com.nsn.oss.libs.netact.http.RteHttpInfo;

public abstract class AbstractWeakCXFDependencyFactoryBean extends AbstractWeakDependencyFactoryBean {
    private static final Logger LOGGER = Logger.getLogger(AbstractWeakCXFDependencyFactoryBean.class.getName());

    private static final String ACCESS_TYPE = "appserv";
    private static final String ACCESS_INSTANCE = "appserv";

    @Value("${fm.access.web.service.username}")
    private String username;
    
    @Value("${fm.access.web.service.password}")
    private String password;

    @Value("${fm.access.web.service.timeout}")
    private int timeout;

    @Value("${fm.access.web.service.protocol}")
    private String serviceProtocol;
    
    @Value("${fm.access.web.service.port}")
    private short servicePort;

    @Override
    public abstract Class<?> getObjectType();

    @Override
    protected final Class<?>[] determineInterfaceTypes() {
        return new Class[]{this.getObjectType()};
    }

    @Override
    protected final Object createTarget() throws Throwable {
        String serviceUrl = this.getServiceUrl();
        Object portObject;
        try {
            portObject = this.createPortObject(serviceUrl);
        } catch (MalformedURLException ex) {
            LOGGER.warning("FM Access service URL is invalid" + serviceUrl + ". " + LogUtils.getChainedCauses(ex));
            LOGGER.log(Level.FINEST, "FM Access service URL is invalid" + serviceUrl, ex);
            throw ex;
        } catch (ServiceConstructionException ex) {
            LOGGER.warning("Cannot create service from " + serviceUrl + ". " + LogUtils.getChainedCauses(ex));
            LOGGER.log(Level.FINEST, "Cannot create service from " + serviceUrl, ex);
            throw ex;
        } catch (WebServiceException ex) {
            LOGGER.warning("Cannot get service port. "  + LogUtils.getChainedCauses(ex));
            LOGGER.log(Level.FINEST, "Cannot get service port", ex);
            throw ex;
        }

        this.configureInterface(portObject);
        return portObject;
    }

    protected abstract String getServiceUri();

    protected abstract Object createPortObject(String serviceUrl) throws Throwable;

    protected final String getHost() {
        return RteHttpInfo.getFactory().getHost();
    }

    private void configureInterface(Object interfaceObject) {
        String password = this.getPassword(this.username);

        org.apache.cxf.endpoint.Client client = ClientProxy.getClient(interfaceObject);
        HTTPConduit http = (HTTPConduit) client.getConduit();
        HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
        httpClientPolicy.setConnectionTimeout(this.timeout);
        httpClientPolicy.setReceiveTimeout(this.timeout);
        http.setClient(httpClientPolicy);

        ((BindingProvider) interfaceObject).getRequestContext().put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

        ((BindingProvider) interfaceObject).getRequestContext().put(
                BindingProvider.USERNAME_PROPERTY, username);
        ((BindingProvider) interfaceObject).getRequestContext().put(
                BindingProvider.PASSWORD_PROPERTY, password);
    }

    private String getServiceUrl() {
        StringBuilder sb = 
                new StringBuilder()
                .append(this.serviceProtocol)
                .append("://")
                .append(getHost());
        
        if (!this.isDefaultServicePort()) {
            sb.append(":").append(this.servicePort);
        }
        sb.append(getServiceUri());

        return sb.toString();
    }

    private boolean isDefaultServicePort() {
        switch (this.serviceProtocol) {
        case "https":
            return this.servicePort == 443;
        case "http":
            return this.servicePort == 80;
        }
        return false;
    }

    private String getPassword(String user) {
        String password = this.password;
        if (password == null || password.isEmpty()) {
            CredentialReader reader = new CredentialReader();
            try {
                password = reader.getPassword(user, ACCESS_TYPE, ACCESS_INSTANCE);
            } catch (RuntimeException ex) {
                LOGGER.severe("Cannot get authentication from credentiallibrary" + LogUtils.getChainedCauses(ex));
                LOGGER.log(Level.FINEST, "Cannot get authentication from credentiallibrary", ex);
                throw ex;
            }
        }
        return password;
    }
}
