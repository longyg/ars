package com.nokia.oss.smu.netact.alarm.bll;

import java.util.Collection;

import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;

public interface InternalAlarmListener {

	void alarmsAdded(Collection<InternalAlarm> alarms);

	void alarmsRemoved(Collection<InternalAlarm> alarms);

	void alarmsChanged(Collection<InternalAlarm> alarms);
}
