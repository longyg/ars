package com.nokia.oss.smu.netact.internal;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoredSystemSpec;
import com.nokia.oss.smu.core.lifecycle.AbstractLifecycle;
import com.nokia.oss.smu.core.platform.MonitoredSystemCreationService;
import com.nokia.oss.smu.netact.NetAct;

import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

public class NetActCreationService extends AbstractLifecycle implements MonitoredSystemCreationService {
    private static final Logger LOG = getLogger(NetActCreationService.class.getName());

    public static final String TYPE_IDENTIFIER = "netact";

    @Override
    public boolean canCreate(MonitoredSystemSpec systemSpec) {
        return TYPE_IDENTIFIER.equals(systemSpec.getSystemType());
    }

    @Override
    public MonitoredSystem create(MonitoredSystemSpec systemSpec) {
        String instanceName = systemSpec.getInstanceName();
        if (instanceName == null) {
            LOG.fine("No instance name specified, use system identifier as default.");
            instanceName = systemSpec.getSystemIdentifier();
        }

        NetAct instance = new NetAct(instanceName);
        instance.setIdentifier(systemSpec.getSystemIdentifier());
        instance.setTypeIdentifier(systemSpec.getSystemType());
        instance.bind(systemSpec);

        return instance;
    }
}
