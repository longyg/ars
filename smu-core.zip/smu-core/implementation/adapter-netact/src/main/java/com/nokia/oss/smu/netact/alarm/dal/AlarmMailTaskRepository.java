package com.nokia.oss.smu.netact.alarm.dal;

import java.util.Date;
import java.util.List;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.netact.alarm.entities.AlarmMailTask;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;

public interface AlarmMailTaskRepository {
    
    List<AlarmMailTask> getNewTasks();

    void persistTask(AlarmMailTask task);
    
    void deleteTasks(Iterable<AlarmMailTask> tasks);
    
    void deleteTasksByAlarms(Iterable<InternalAlarm> alarms);
    
    void deleteTasksByAlarmSeverity(AlarmSeverity severity);

}
