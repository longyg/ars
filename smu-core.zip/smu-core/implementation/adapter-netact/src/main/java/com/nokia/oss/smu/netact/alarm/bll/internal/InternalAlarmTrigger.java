package com.nokia.oss.smu.netact.alarm.bll.internal;

import static java.util.logging.Logger.getLogger;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Transactional;

import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmListener;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;

public class InternalAlarmTrigger {

    private static final Logger LOGGER = getLogger(InternalAlarmTrigger.class.getName());
    
    private static final int BATCH_TRIGGER_LIMIT = 1000;

    @Resource
    private InternalAlarmRepository internalAlarmRepository;

    private List<InternalAlarmListener> listeners;

    public void setListeners(List<InternalAlarmListener> listeners) {
        this.listeners = listeners;
    }

    @Transactional
    public void triggerEvents() {
    	this.triggerRemovingEvents();
    	this.triggerAddingEvents();
	    this.triggerChangingEvents();
    }

	private void triggerChangingEvents() {

		List<InternalAlarmListener> ls = this.listeners;
		if (ls == null || ls.isEmpty()) {
			return;
		}

		long minId = 0;
		while (true) {
			List<InternalAlarm> alarms = this.internalAlarmRepository.getSynchronizingInternalAlarmsByOrderById(
					InternalAlarmSynchronizingState.CHANGED, minId, BATCH_TRIGGER_LIMIT
			);
			if (alarms.isEmpty()) {
				break;
			}

			LOGGER.info("Trigger changing events for the alarms whose ids are: " + extractIdText(alarms));
			for (InternalAlarmListener listener : ls) {
				listener.alarmsChanged(alarms);
			}
			minId = alarms.get(alarms.size() - 1).getId();

			this.internalAlarmRepository.flushAndClear();
		}
	}
    
    private void triggerRemovingEvents() {

		List<InternalAlarmListener> ls = this.listeners;
		if (ls == null || ls.isEmpty()) {
			return;
		}

		long minId = 0;
		while (true) {
			List<InternalAlarm> alarms = this.internalAlarmRepository.getSynchronizingInternalAlarmsByOrderById(
					InternalAlarmSynchronizingState.ORIGINAL, minId, BATCH_TRIGGER_LIMIT
			);
			if (alarms.isEmpty()) {
				break;
			}
			if (LOGGER.isLoggable(Level.INFO)) {
				LOGGER.info("Trigger removing events for the alarms whose ids are: " + extractIdText(alarms));
			}
			for (InternalAlarmListener listener : ls) {
				listener.alarmsRemoved(alarms);
			}
			minId = alarms.get(alarms.size() - 1).getId();
			
			this.internalAlarmRepository.flushAndClear();
		}
	}

	private void triggerAddingEvents() {

    	List<InternalAlarmListener> ls = this.listeners;
    	if (ls == null || ls.isEmpty()) {
    		return;
    	}

    	long minId = 0;
    	while (true) {
    		List<InternalAlarm> alarms = this.internalAlarmRepository.getSynchronizingInternalAlarmsByOrderById(
    				 InternalAlarmSynchronizingState.INSERTED, minId, BATCH_TRIGGER_LIMIT
    		);
    		if (alarms.isEmpty()) {
    			break;
    		}
    		if (LOGGER.isLoggable(Level.INFO)) {
    			LOGGER.info("Trigger adding events for the alarms whose ids are: " + extractIdText(alarms));
    		}
    		for (InternalAlarmListener listener : ls) {
				listener.alarmsAdded(alarms);
			}
    		minId = alarms.get(alarms.size() - 1).getId();
    		
    		this.internalAlarmRepository.flushAndClear();
    	}
    }
    
    private static String extractIdText(Iterable<InternalAlarm> alarms) {
    	StringBuilder builder = new StringBuilder();
    	boolean addComma = false;
    	for (InternalAlarm alarm : alarms) {
    		if (addComma) {
    			builder.append(", ");
    		} else {
    			addComma = true;
    		}
    		builder.append(alarm.getId());
    	}
    	return builder.toString();
    }
}
