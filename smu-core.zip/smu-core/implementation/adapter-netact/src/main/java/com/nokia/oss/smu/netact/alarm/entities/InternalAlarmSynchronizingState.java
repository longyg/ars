package com.nokia.oss.smu.netact.alarm.entities;

public enum InternalAlarmSynchronizingState {

	ORIGINAL,
    REFRESHED,
	INSERTED,
	CHANGED
}
