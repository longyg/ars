package com.nokia.oss.smu.netact.alarm.entities.model;

public class InternalAlarmSummary {

	private long criticalCount;
	
	private long majorCount;
	
	private long minorCount;
	
	private long warningCount;
	
	private long indeterminateCount;

	public long getCriticalCount() {
		return criticalCount;
	}

	public void setCriticalCount(long criticalCount) {
		this.criticalCount = criticalCount;
	}

	public long getMajorCount() {
		return majorCount;
	}

	public void setMajorCount(long majorCount) {
		this.majorCount = majorCount;
	}

	public long getMinorCount() {
		return minorCount;
	}

	public void setMinorCount(long minorCount) {
		this.minorCount = minorCount;
	}

	public long getWarningCount() {
		return warningCount;
	}

	public void setWarningCount(long warningCount) {
		this.warningCount = warningCount;
	}

	public long getIndeterminateCount() {
		return indeterminateCount;
	}

	public void setIndeterminateCount(long indeterminateCount) {
		this.indeterminateCount = indeterminateCount;
	}
	
	public static InternalAlarmSummary combine(InternalAlarmSummary a, InternalAlarmSummary b) {
		if (a == null) {
			return b;
		}
		if (b == null) {
			return a;
		}
		InternalAlarmSummary combined = new InternalAlarmSummary();
		combined.criticalCount = a.criticalCount + b.criticalCount;
		combined.majorCount = a.majorCount + b.majorCount;
		combined.minorCount = a.minorCount + b.minorCount;
		combined.warningCount = a.warningCount + b.warningCount;
		combined.indeterminateCount = a.indeterminateCount + b.indeterminateCount;
		return combined;
	}
}
