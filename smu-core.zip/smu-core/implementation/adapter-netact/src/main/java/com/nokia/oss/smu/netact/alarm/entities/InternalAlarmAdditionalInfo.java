package com.nokia.oss.smu.netact.alarm.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class InternalAlarmAdditionalInfo {

	@Column(name = "ADDITIONAL_TEXT1", length = 1025)
	private String additionalText1;
	
	@Column(name = "ADDITIONAL_TEXT2", length = 1025)
	private String additionalText2;
	
	@Column(name = "ADDITIONAL_TEXT3", length = 1025)
	private String additionalText3;
	
	@Column(name = "ADDITIONAL_TEXT4", length = 1025)
	private String additionalText4;
	
	@Column(name = "ADDITIONAL_TEXT5", length = 1025)
	private String additionalText5;
	
	@Column(name = "ADDITIONAL_TEXT6", length = 1025)
	private String additionalText6;
	
	@Column(name = "ADDITIONAL_TEXT7", length = 1025)
	private String additionalText7;
	
	public String getAdditionalText1() {
		return additionalText1;
	}

	public void setAdditionalText1(String additionalText1) {
		this.additionalText1 = additionalText1;
	}

	public String getAdditionalText2() {
		return additionalText2;
	}

	public void setAdditionalText2(String additionalText2) {
		this.additionalText2 = additionalText2;
	}

	public String getAdditionalText3() {
		return additionalText3;
	}

	public void setAdditionalText3(String additionalText3) {
		this.additionalText3 = additionalText3;
	}

	public String getAdditionalText4() {
		return additionalText4;
	}

	public void setAdditionalText4(String additionalText4) {
		this.additionalText4 = additionalText4;
	}

	public String getAdditionalText5() {
		return additionalText5;
	}

	public void setAdditionalText5(String additionalText5) {
		this.additionalText5 = additionalText5;
	}

	public String getAdditionalText6() {
		return additionalText6;
	}

	public void setAdditionalText6(String additionalText6) {
		this.additionalText6 = additionalText6;
	}

	public String getAdditionalText7() {
		return additionalText7;
	}

	public void setAdditionalText7(String additionalText7) {
		this.additionalText7 = additionalText7;
	}
}
