package com.nokia.oss.smu.netact.internal;

import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.platform.MonitorPlugin;
import com.nokia.oss.smu.netact.MonitoredNetActInitializer;

public class Activator implements MonitorPlugin {

    private NetActCreationService instanceCreationService = new NetActCreationService();
    private MonitoredNetActInitializer initializer = new MonitoredNetActInitializer();
    private FixedSingleSystemPersistService persistService;

    public Activator() {
    }

    public void activate() {
        MonitorPlatform platform = MonitorPlatform.getPlatform();
        platform.installService(instanceCreationService);
        platform.addMonitoredSystemManagerListener(initializer);

        persistService = new FixedSingleSystemPersistService();
        platform.installService(persistService);
    }

    public void deactivate() {
        MonitorPlatform platform = MonitorPlatform.getPlatform();
        platform.uninstallService(instanceCreationService);
        platform.removeMonitoredSystemManagerListener(initializer);
        platform.uninstallService(persistService);
    }

}