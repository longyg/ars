package com.nokia.oss.smu.netact.alarm;

public class AlarmManualSpec {
    private String notificationId;
    private String dn;
    private int alarmNumber;
    private long time;

    public AlarmManualSpec(String notificationId, String dn, int alarmNumber, long time) {
        this.notificationId = notificationId;
        this.dn = dn;
        this.alarmNumber = alarmNumber;
        this.time = time;
    }

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getDn() {
        return dn;
    }

    public void setDn(String dn) {
        this.dn = dn;
    }

    public int getAlarmNumber() {
        return alarmNumber;
    }

    public void setAlarmNumber(int alarmNumber) {
        this.alarmNumber = alarmNumber;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "AlarmManualSpec{" +
                "notificationId='" + notificationId + '\'' +
                ", dn='" + dn + '\'' +
                ", alarmNumber=" + alarmNumber +
                ", time=" + time +
                '}';
    }
}
