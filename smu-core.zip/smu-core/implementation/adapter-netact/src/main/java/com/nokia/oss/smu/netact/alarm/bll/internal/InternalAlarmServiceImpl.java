package com.nokia.oss.smu.netact.alarm.bll.internal;

import com.nokia.oss.interfaces.fmaccess.service.*;
import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.OperationException;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.util.LogUtils;
import com.nokia.oss.smu.core.view.ComponentLayer;
import com.nokia.oss.smu.core.view.ComponentRef;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmException;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmService;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service("internalAlarmService")
public class InternalAlarmServiceImpl implements InternalAlarmService {

    private static final Logger LOGGER = Logger.getLogger(InternalAlarmServiceImpl.class.getName());

    @Resource
    private InternalAlarmRepository internalAlarmRepository;

    @Resource
    private AlarmMonitorSEI alarmMonitorSEI;

    @Resource
    private AlarmDelegateSEI alarmDelegateSEI;

    @Value("${fm.access.web.service.username}")
    private String userName;

    private static final InternalAlarmSpecification ALL_SEVERITIES = new InternalAlarmSpecification();

    static {
        ALL_SEVERITIES.setSeverities(EnumSet.of(AlarmSeverity.MINOR,
                AlarmSeverity.MAJOR,
                AlarmSeverity.WARNING,
                AlarmSeverity.CRITICAL));
    }

    @Transactional(readOnly = true, isolation = Isolation.SERIALIZABLE)
    @Override
    public LimitedResult<InternalAlarm> query(
            InternalAlarmSpecification specification,
            int maxRows) {
        LOGGER.fine("Querying internal alarm cache with specification: " + specification);
        LimitedResult<InternalAlarm> limitAlarms = new LimitedResult<>();

        try {
            long totalAlarmNumber = internalAlarmRepository.countAlarms(ALL_SEVERITIES);
            if (totalAlarmNumber > 0) {
                if (noSeveritySpecified(specification)) {
                    LOGGER.warning("No severities specified, no alarms will be fetched.");
                    limitAlarms.setTotalAlarmNumber(totalAlarmNumber);
                    limitAlarms.setMatchedAlarmNumber(0);
                    return limitAlarms;
                }

                long matchedAlarmNumber = internalAlarmRepository.countAlarms(specification);
                if (matchedAlarmNumber > 0) {
                    limitAlarms = this.internalAlarmRepository.getInternalAlarms(specification, maxRows);
                }
                limitAlarms.setMatchedAlarmNumber(matchedAlarmNumber);
            }

            limitAlarms.setTotalAlarmNumber(totalAlarmNumber);
        } catch (Exception ex) {
            LOGGER.severe("Unable to fetch alarms from cache, " + LogUtils.getChainedCauses(ex));
            throw ex;
        }

        return limitAlarms;
    }

    private boolean noSeveritySpecified(InternalAlarmSpecification specification) {
        return specification.getSeverities() != null && specification.getSeverities().size() == 0;
    }

    @Transactional(readOnly = true)
    @Override
    public Map<String, InternalAlarmSummary> getSummariesForComponents() {
        LOGGER.fine("Getting alarm summary for components");
        final Map<String, InternalAlarmSummary> summaryMap = this.internalAlarmRepository.getSummaryMap();
        MonitoredSystem monitoredSystem = MonitorPlatform.getPlatform().getFirstMonitoredSystem();
        for (ComponentLayer componentLayer : monitoredSystem.getComponentView().getLayers()) {
            for (ComponentRef componentRef : componentLayer.getComponentRefs()) {
                final Component component = componentRef.getComponent();
                final InternalAlarmSummary[] summaryRef = new InternalAlarmSummary[]{
                        summaryMap.get(component.getId())};
                component.accept(new ComponentVisitor() {
                    @Override
                    public void visit(Component c) {
                        if (component != c) {
                            summaryRef[0] = InternalAlarmSummary.combine(summaryRef[0], summaryMap.get(c.getId()));
                        }
                    }
                });
                if (summaryRef[0] != null) {
                    summaryMap.put(component.getId(), summaryRef[0]);
                }
            }
        }
        return summaryMap;
    }

    @Transactional(readOnly = true)
    @Override
    public long count(InternalAlarmSpecification specification) {
        LOGGER.fine("Counting alarms by given specification: " + specification);
        return internalAlarmRepository.countAlarms(specification);
    }

    @Override
    public void acknowledge(long[] ids, String user) throws OperationException {
        LOGGER.info("Acknowledging alarms by ids: " + Arrays.toString(ids));
        List<NsnAlarmKey> alarmKeys = convertToAlarmKeys(ids);
        XMLGregorianCalendar date = createXmlGregorianCalendar();
        try {
            List<AlarmKeyResult> results = alarmDelegateSEI.acknowledgeAlarmsByKeys(alarmKeys, user, date);
            checkAlarmOperationResults(results);
            LOGGER.info("Acknowledgement request sent for alarms initiated by " + user);
        } catch (AckAlarmsByKeysFault fault) {
            LOGGER.severe("Cannot acknowledge the alarms, " + LogUtils.getChainedCauses(fault));
            throw new OperationException(fault.getMessage(), fault);
        }
    }

    @Override
    public long countUnmapped() {
        return internalAlarmRepository.countUnmappedAlarms();
    }

    @Override
    public void unacknowledge(long[] ids, String user) throws OperationException {
        LOGGER.info("Unacknowledging alarms by ids: " + Arrays.toString(ids));
        List<NsnAlarmKey> alarmKeys = convertToAlarmKeys(ids);
        XMLGregorianCalendar date = createXmlGregorianCalendar();
        try {
            List<AlarmKeyResult> results = alarmDelegateSEI.unAcknowledgeAlarmsByKeys(alarmKeys, user, date);
            checkAlarmOperationResults(results);
            LOGGER.info("Unacknowledgement request sent for alarms initiated by " + user);
        } catch (UnAckAlarmsByKeysFault fault) {
            LOGGER.severe("Cannot unacknowledge the alarms, " + LogUtils.getChainedCauses(fault));
            throw new OperationException(fault.getMessage(), fault);
        }
    }

    @Override
    public void cancel(long[] ids, String user) throws OperationException {
        LOGGER.info("Canceling alarms by ids: " + Arrays.toString(ids));
        List<NsnAlarmKey> alarmKeys = convertToAlarmKeys(ids);
        XMLGregorianCalendar date = createXmlGregorianCalendar();
        try {
            List<AlarmKeyResult> results = alarmDelegateSEI.clearAlarmsByKeys(alarmKeys, user, date);
            checkAlarmOperationResults(results);
            LOGGER.info("Alarms " + alarmKeys + " are cancelled by " + user);
        } catch (ClearAlarmsByKeysFault fault) {
            LOGGER.severe("Cannot clear the alarms " + alarmKeys + ", " + LogUtils.getChainedCauses(fault));
            throw new OperationException(fault.getMessage(), fault);
        }
    }

    @Override
    public ManPageInfo getManPageInfo(long alarmId){
        try {
            LOGGER.fine("Will get man page from the alarm id "+ alarmId);
            long[] alarmIds = {alarmId};
            List<NsnAlarmKey> alarmKeys = convertToAlarmKeys(alarmIds);
            return alarmMonitorSEI.getAlarmDescriptionByKeys(alarmKeys, null)
				            		.getEntry().get(0)
				            		.getValue()
				            		.getManPageInfo();
        }catch (GetAlarmDescriptionByKeysFault ex) {
        	LOGGER.log(Level.SEVERE,"Failed on get man page",ex);
        	throw new InternalAlarmException(ex);
        }catch (RuntimeException | Error ex) {
        	LOGGER.log(Level.SEVERE,"Failed on get man page by unknown error",ex);
            throw new InternalAlarmException(ex);
        } 
    }

    private List<NsnAlarmKey> convertToAlarmKeys(long[] ids) {
        List<NsnAlarmKey> alarmKeys = new ArrayList<>();
        for (long id : ids) {
            NsnAlarmKey alarmKey = new NsnAlarmKey();
            alarmKey.setAlarmId(id);
            alarmKeys.add(alarmKey);
        }
        return alarmKeys;
    }

    private XMLGregorianCalendar createXmlGregorianCalendar() throws OperationException {
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar());
        } catch (DatatypeConfigurationException ex) {
            LOGGER.severe("Cannot create XMLGregorianCalendar, " + LogUtils.getChainedCauses(ex));
            throw new OperationException("Cannot determine server time.", ex);
        }
    }

    private void checkAlarmOperationResults(List<AlarmKeyResult> results) throws OperationException {
        if (results.isEmpty()) {
            LOGGER.finest("Alarm operation done without error.");
            return;
        }

        Map<String, List<Long>> errors = new HashMap<>();
        for (AlarmKeyResult result : results) {
            if (!result.isSuccess() || result.getException() != null) {
                String exception = result.getException();
                LOGGER.severe("FM Access report an error for alarm ID=" + result.getAlarmKey().getAlarmId()
                        + ", error: " + exception);

                List<Long> ids = errors.get(exception);
                if (ids != null) {
                    ids.add(result.getAlarmKey().getAlarmId());
                } else {
                    List<Long> newIds = new ArrayList<>();
                    newIds.add(result.getAlarmKey().getAlarmId());
                    errors.put(exception, newIds);
                }
            }
        }

        StringBuilder builder = new StringBuilder();
        for (String exception : errors.keySet()) {
            List<Long> ids = errors.get(exception);
            builder.append(" '" + exception + "': consecutive numbers ").append(ids.toString()).append(". ");
        }

        throw new OperationException("Errors occurred during operation. " + builder.toString());
    }
}
