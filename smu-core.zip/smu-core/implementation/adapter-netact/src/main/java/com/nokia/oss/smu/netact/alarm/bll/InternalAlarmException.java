package com.nokia.oss.smu.netact.alarm.bll;

public class InternalAlarmException extends RuntimeException {

	private static final long serialVersionUID = 724856753888839853L;

	public InternalAlarmException(String message) {
		super(message);
	}

	public InternalAlarmException(Throwable cause) {
		super(cause);
	}
}
