package com.nokia.oss.smu.netact;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.platform.MonitoredSystemManagerListener;

public class MonitoredNetActInitializer implements MonitoredSystemManagerListener {

    @Override
    public void onMonitoredSystemAdded(MonitoredSystem system) {
    }

    @Override
    public void onMonitoredSystemRemoved(MonitoredSystem system) {
    }

    @Override
    public void onMonitoredSystemRegistered(MonitoredSystem system) {
    }

    @Override
    public void onMonitoredSystemUnregistered(MonitoredSystem system) {
    }

    @Override
    public void onMonitoredSystemLoaded(MonitoredSystem system) {
    }

    @Override
    public void onMonitoredSystemUnloaded(MonitoredSystem system) {
    }
}
