package com.nokia.oss.smu.netact.alarm.dal.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.From;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm_;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import com.nokia.oss.smu.netact.alarm.entities.model.Order;

@Repository("internalAlarmRepository")
public class InternalAlarmRepositoryImpl implements InternalAlarmRepository {
	
	private static final int MAX_IN_LIST = 1000;
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public Map<Long, InternalAlarm> getInternalAlarmByIds(Iterable<Long> ids) {
		
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		Map<Long, InternalAlarm> map = new HashMap<>();
		
		Iterator<Long> itr = ids.iterator();
		while (itr.hasNext()) {
			CriteriaQuery<InternalAlarm> cq = cb.createQuery(InternalAlarm.class);
			Root<InternalAlarm> internalAlarm = cq.from(InternalAlarm.class);
			In<Long> in = cb.in(internalAlarm.get(InternalAlarm_.id));
			for (int i = MAX_IN_LIST; i > 0 && itr.hasNext(); --i) {
				in.value(itr.next());
			}
			cq.where(in);
			List<InternalAlarm> list = this.em.createQuery(cq).getResultList();
			for (InternalAlarm alarm : list) {
				map.put(alarm.getId(), alarm);
			}
		}
		return map;
	}

	@Override
	public List<InternalAlarm> getSynchronizingInternalAlarmsByOrderById(InternalAlarmSynchronizingState synchronizingState, long minExclusiveId, int limit) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<InternalAlarmSynchronizingState> pSS = cb.parameter(InternalAlarmSynchronizingState.class, "synchronizingState");
		ParameterExpression<Long> pMinExclusiveId = cb.parameter(Long.class, "minExclusiveId");
		
		CriteriaQuery<InternalAlarm> cq = cb.createQuery(InternalAlarm.class);
		Root<InternalAlarm> internalAlarm = cq.from(InternalAlarm.class);
		cq
		.where(
				cb.equal(internalAlarm.get(InternalAlarm_.synchronizingState), pSS),
				cb.gt(internalAlarm.get(InternalAlarm_.id), pMinExclusiveId)
		)
		.orderBy(cb.asc(internalAlarm.get(InternalAlarm_.id)));
		return this
				.em
				.createQuery(cq)
				.setParameter(pSS, synchronizingState)
				.setParameter(pMinExclusiveId, minExclusiveId)
				.setMaxResults(limit)
				.getResultList();
	}

	@Override
	public LimitedResult<InternalAlarm> getInternalAlarms(
			InternalAlarmSpecification specification, 
			int maxRows) {
	    if (maxRows <= 0 || maxRows >= Integer.MAX_VALUE) {
	        throw new IllegalStateException("The maxRows must between [1, " + (Integer.MAX_VALUE - 1)+ "]");
	    }
		if (specification.getSeverities() != null && specification.getSeverities().isEmpty()) {
			return new LimitedResult<InternalAlarm>(false, Collections.<InternalAlarm>emptyList());
		}
		if (specification.getMappedComponentIds() != null && specification.getMappedComponentIds().isEmpty()) {
			return new LimitedResult<InternalAlarm>(false, Collections.<InternalAlarm>emptyList());
		}
		
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<InternalAlarm> cq = cb.createQuery(InternalAlarm.class);
		Root<InternalAlarm> internalAlarm = cq.from(InternalAlarm.class);
		cq.where(this.createPredicates(cb, internalAlarm, specification));
		if (specification.getOrders() != null && !specification.getOrders().isEmpty()) {
			List<javax.persistence.criteria.Order> jpaOrders = 
					new ArrayList<javax.persistence.criteria.Order>(specification.getOrders().size());
			for (Order order : specification.getOrders()) {
				if (order.getMode() == Order.OrderMode.ASCENDING) {
					jpaOrders.add(cb.asc(internalAlarm.get(order.getPropertyName())));
				} else {
					jpaOrders.add(cb.desc(internalAlarm.get(order.getPropertyName())));
				}
			}
			cq.orderBy(jpaOrders);
		}
		
		List<InternalAlarm> internalAlarms = 
				this
				.em
				.createQuery(cq)
				.setMaxResults(maxRows + 1)
				.getResultList();
		long alarmSize = internalAlarms.size();
		if (alarmSize <= maxRows) {
			return new LimitedResult<>(false, internalAlarms);
		}
		return new LimitedResult<>(true, internalAlarms.subList(0, maxRows));
	}

	@Override
	public Map<String, InternalAlarmSummary> getSummaryMap() {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaQuery<Object[]> cq = cb.createQuery(Object[].class);
        Root<InternalAlarm> internalAlarm = cq.from(InternalAlarm.class);
        cq
        .groupBy(
        		internalAlarm.get(InternalAlarm_.mappedComponentId),
        		internalAlarm.get(InternalAlarm_.severity)
        )
        .multiselect(
        		internalAlarm.get(InternalAlarm_.mappedComponentId),
        		internalAlarm.get(InternalAlarm_.severity),
        		cb.count(internalAlarm)
        );
        List<Object[]> tupleList = this.em.createQuery(cq).getResultList();
        Map<String, InternalAlarmSummary> map = new HashMap<String, InternalAlarmSummary>();
		for (Object[] tuple : tupleList) {
			String mappedComponent = (String)tuple[0];
			AlarmSeverity severity = (AlarmSeverity)tuple[1];
			long count = (Long)tuple[2];
			InternalAlarmSummary summary = map.get(mappedComponent);
			if (summary == null) {
				summary = new InternalAlarmSummary();
				map.put(mappedComponent, summary);
			}
			if (severity == AlarmSeverity.CRITICAL) {
				summary.setCriticalCount(summary.getCriticalCount() + count);
			} else if (severity == AlarmSeverity.MAJOR) {
				summary.setMajorCount(summary.getMajorCount() + count);
			} else if (severity == AlarmSeverity.MINOR) {
				summary.setMinorCount(summary.getMinorCount() + count);
			} else if (severity == AlarmSeverity.WARNING) {
				summary.setWarningCount(summary.getWarningCount() + count);
			} else if (severity == AlarmSeverity.INDETERMINATE) {
				summary.setIndeterminateCount(summary.getIndeterminateCount() + count);
			}
        }
		return map;
	}

	@Override
    public long countAlarms(InternalAlarmSpecification specification) {
    		CriteriaBuilder cb = this.em.getCriteriaBuilder();
            CriteriaQuery<Long> cq = cb.createQuery(Long.class);
            Root<InternalAlarm> internalAlarm = cq.from(InternalAlarm.class);
            cq
            .where(this.createPredicates(cb, internalAlarm, specification))
            .select(cb.count(internalAlarm));
            return em.createQuery(cq).getSingleResult();
    }

	@Override
	public long countUnmappedAlarms() {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		Root<InternalAlarm> unmapped = cq.from(InternalAlarm.class);
		cq.where(cb.isNull(unmapped.get(InternalAlarm_.mappedComponentId)))
				.select(cb.count(unmapped));

		return em.createQuery(cq).getSingleResult();
	}

	@Override
	public void persistInternalAlarm(InternalAlarm internalAlarm) {
		this.em.persist(internalAlarm);
	}

    @Override
	public void changeSynchronizingState(InternalAlarmSynchronizingState synchronizingState) {
    	
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<InternalAlarmSynchronizingState> pState = cb.parameter(InternalAlarmSynchronizingState.class, "state");
		
		CriteriaUpdate<InternalAlarm> cu = cb.createCriteriaUpdate(InternalAlarm.class);
		cu.from(InternalAlarm.class);
		cu.set(InternalAlarm_.synchronizingState, pState);
		this.em.createQuery(cu).setParameter(pState, synchronizingState).executeUpdate();
	}

	@Override
	public void deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState synchronizingState) {
		
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<InternalAlarmSynchronizingState> pState = cb.parameter(InternalAlarmSynchronizingState.class, "state");
		
		CriteriaDelete<InternalAlarm> cd = cb.createCriteriaDelete(InternalAlarm.class);
		Root<InternalAlarm> internalAlarm = cd.from(InternalAlarm.class);
		cd.where(cb.equal(internalAlarm.get(InternalAlarm_.synchronizingState), pState));
		this.em.createQuery(cd).setParameter(pState, synchronizingState).executeUpdate();
	}

	@Override
    public void mergeInternalAlarm(InternalAlarm alarm) {
        this.em.merge(alarm);
    }

    @Override
	public void flushAndClear() {
		this.em.flush();
	    this.em.clear();
	}

	private Predicate[] createPredicates(
			CriteriaBuilder cb, 
			From<?, InternalAlarm> internalAlarm, 
			InternalAlarmSpecification specification) {
		List<Predicate> list = new ArrayList<Predicate>();
		if (specification != null) {
			Collection<AlarmSeverity> severities = specification.getSeverities();
			if (severities != null && severities.size() < AlarmSeverity.values().length) {
				In<AlarmSeverity> in = cb.in(internalAlarm.get(InternalAlarm_.severity));
				for (AlarmSeverity severity : severities) {
					in.value(severity);
				}
				list.add(in);
			}
			if (specification.getAckState() != null) {
				list.add(cb.equal(internalAlarm.get(InternalAlarm_.ackState), specification.getAckState()));
			}
			if (specification.isUnmapped()) {
				list.add(cb.isNull(internalAlarm.get(InternalAlarm_.mappedComponentId)));
			}
			else if (specification.getMappedComponentIds() != null) {
				In<String> in = cb.in(internalAlarm.get(InternalAlarm_.mappedComponentId));
				for (String mappedComponentId : specification.getMappedComponentIds()) {
					in.value(mappedComponentId);
				}
				list.add(in);
			}
		}
		
		list.add(cb.notEqual(internalAlarm.get(InternalAlarm_.synchronizingState), InternalAlarmSynchronizingState.INSERTED));

		return list.toArray(new Predicate[list.size()]);
	}
}
