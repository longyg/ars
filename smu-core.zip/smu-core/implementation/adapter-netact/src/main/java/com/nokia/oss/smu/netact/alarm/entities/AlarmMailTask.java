package com.nokia.oss.smu.netact.alarm.entities;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SMU_ALARM_MAIL_TASK")
@SequenceGenerator(
		name = "alarmMailTaskSequence",
		sequenceName = "SMU_ALARM_MAIL_TASK_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class AlarmMailTask {

	@Id
	@Access(AccessType.PROPERTY)
	@Column(name = "ALARM_MAIL_TASK_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "alarmMailTaskSequence")
	private Long id;

	@Column(name = "LAST_SENT_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastSentTime;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ALARM_ID", nullable = false, unique = true)
    private InternalAlarm alarm;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "TYPE_ORDINAL")
    private EventType type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Date getLastSentTime() {
        return lastSentTime;
    }

    public void setLastSentTime(Date lastSentTime) {
        this.lastSentTime = lastSentTime;
    }

    public EventType getType() {
        return type;
    }

    public void setType(EventType type) {
        this.type = type;
    }

    public InternalAlarm getAlarm() {
        return alarm;
    }

    public void setAlarm(InternalAlarm alarm) {
        this.alarm = alarm;
    }

    public enum EventType {
        NEW_ALARM,
        CHANGE_EVENT
    }
}
