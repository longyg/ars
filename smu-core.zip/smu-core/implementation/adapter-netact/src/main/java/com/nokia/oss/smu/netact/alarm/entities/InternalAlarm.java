package com.nokia.oss.smu.netact.alarm.entities;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.Alarmable;

@Entity
@Table(name = "SMU_INTERNAL_ALARM")
public class InternalAlarm implements Alarmable {
	
	@Access(AccessType.PROPERTY)
	@Id
	@Column(name = "INTERNAL_ALARM_ID", nullable = false)
	private Long id;

	@Column(name = "ALARM_NUMBER", nullable = false)
	private long number;
	
	@Column(name = "NOTIFICATION_ID", nullable = false, length = 129)
	private String notificationId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ALARM_TIME")
	private Calendar alarmTime;

	@Enumerated(EnumType.ORDINAL)
	@Column(name = "SEVERITY_ORDINAL")
	private AlarmSeverity severity;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "ACK_STATE_TEXT")
	private AckState ackState;
	
	@Column(name = "DISTINGUISH_NAME", length = 401)
	private String distinguishName;
	
	@Column(name = "ALARM_TITLE", length = 1025)
	private String title;
	
	@Column(name = "EVENT_TYPE", length = 30)
	private String eventType;
	
	@Column(name = "ACK_USER", length = 64)
	private String acknowledgedBy;
	
	@Column(name = "ACK_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar ackTime;
	
	@Column(name = "CLEAR_USER", length = 64)
	private String clearedBy;
	
	@Column(name = "CLEAR_TIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar clearTime;
	
	@Embedded
	private InternalAlarmAdditionalInfo additionalInfo;
	
	@Column(name = "MAPPED_COMPONENT_ID", length = 30)
	private String mappedComponentId;
	
	@Column(name = "SYNCHRONIZING_STATE_ORDINAL", nullable = false)
	@Enumerated(EnumType.ORDINAL)
	private InternalAlarmSynchronizingState synchronizingState;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public Calendar getAlarmTime() {
		return alarmTime;
	}

	public void setAlarmTime(Calendar alarmTime) {
		this.alarmTime = alarmTime;
	}

	public AlarmSeverity getSeverity() {
		return severity;
	}

	public void setSeverity(AlarmSeverity severity) {
		this.severity = severity;
	}

	public AckState getAckState() {
		return ackState;
	}

	public void setAckState(AckState ackState) {
		this.ackState = ackState;
	}

	public String getDistinguishName() {
		return distinguishName;
	}

	public void setDistinguishName(String distinguishName) {
		this.distinguishName = distinguishName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEventType() {
		if (eventType != null) {
			if (eventType.equals("PROCESSINGERROR")) {
				eventType = "PROCESSING ERROR";
			} else if (eventType.equals("QUALITYOFSERVICE")) {
				eventType = "QUALITY OF SERVICE";
			} else if (eventType.equals("INTEGRITYVIOLATION")) {
				eventType = "INTEGRITY VIOLATION";
			} else if (eventType.equals("OPERATIONALVIOLATION")) {
				eventType = "OPERATIONAL VIOLATION";
			} else if (eventType.equals("PHYSICALVIOLATION")) {
				eventType = "PHYSICAL VIOLATION";
			} else if (eventType.equals("SECURITYVIOLATION")) {
				eventType = "SECURITY VIOLATION";
			} else if (eventType.equals("TIMEDOMAINVIOLATION")) {
				eventType = "TIMEDOMAIN VIOLATION";
			}
		}
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getAcknowledgedBy() {
		return acknowledgedBy;
	}

	public void setAcknowledgedBy(String acknowledgedBy) {
		this.acknowledgedBy = acknowledgedBy;
	}

	public Calendar getAckTime() {
		return ackTime;
	}

	public void setAckTime(Calendar ackTime) {
		this.ackTime = ackTime;
	}

	public String getClearedBy() {
		return clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	public Calendar getClearTime() {
		return clearTime;
	}

	public void setClearTime(Calendar clearTime) {
		this.clearTime = clearTime;
	}

	public InternalAlarmAdditionalInfo getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(InternalAlarmAdditionalInfo additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	@Override
	public Map<String, String> getAdditionalAttributes() {
		Map<String, String> map = new LinkedHashMap<String, String>();
		InternalAlarmAdditionalInfo info = this.additionalInfo;
		if (info != null) {
			map.put("additionalText1", info.getAdditionalText1());
			map.put("additionalText2", info.getAdditionalText2());
			map.put("additionalText3", info.getAdditionalText3());
			map.put("additionalText4", info.getAdditionalText4());
			map.put("additionalText5", info.getAdditionalText5());
			map.put("additionalText6", info.getAdditionalText6());
			map.put("additionalText7", info.getAdditionalText7());
		}
		return map;
	}

	public String getMappedComponentId() {
		return mappedComponentId;
	}

	public void setMappedComponentId(String mappedComponentId) {
		this.mappedComponentId = mappedComponentId;
	}

	public InternalAlarmSynchronizingState getSynchronizingState() {
		return synchronizingState;
	}

	public void setSynchronizingState(InternalAlarmSynchronizingState synchronizingState) {
		this.synchronizingState = synchronizingState;
	}

	public enum AckState {
		UNACKED, //UNACKED is initialized value, so it's first variable(ordinal = zero)
		ACKED,
	}

	@Override
	public int hashCode() {
		int hash = (int)this.number;
		hash = hash * 31 + hash(this.alarmTime);
		hash = hash * 31 + hash(this.id);
		hash = hash * 31 + hash(this.title);
		hash = hash * 31 + hash(this.ackState);
		hash = hash * 31 + hash(this.severity);
		hash = hash * 31 + hash(this.acknowledgedBy);
		hash = hash * 31 + hash(this.ackTime);
		hash = hash * 31 + hash(this.clearedBy);
		hash = hash * 31 + hash(this.clearTime);
		return hash;
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) {
        	return true;
        }
		if (!(o instanceof InternalAlarm)) {
            return false;
        }

        InternalAlarm other = (InternalAlarm) o;
        return  number == other.getNumber()
                && eq(alarmTime, other.getAlarmTime())
                && eq(id, other.getId())
                && eq(title, other.getTitle())
                && eq(ackState, other.getAckState())
                && eq(severity, other.getSeverity())
                && eq(acknowledgedBy, other.getAcknowledgedBy())
                && eq(ackTime, other.getAckTime())
                && eq(clearedBy, other.getClearedBy())
                && eq(clearTime, other.getClearTime());
    }
    
    private static int hash(Object o) {
    	return o == null ? 0 : o.hashCode();
    }

    private static <T> boolean eq(T a, T b) {
        return a == null ? b == null : a.equals(b);
    }
}
