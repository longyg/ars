package com.nokia.oss.smu.netact;

import com.nokia.oss.smu.core.Deployment;
import com.nokia.oss.smu.core.Node;

import java.util.Collection;

public class NetActDeployment implements Deployment {

    @Override
    public Collection<Node> getNodes() {
        return null;
    }
}
