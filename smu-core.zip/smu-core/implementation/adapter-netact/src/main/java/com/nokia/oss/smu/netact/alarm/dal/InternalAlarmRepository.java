package com.nokia.oss.smu.netact.alarm.dal;

import java.util.List;
import java.util.Map;

import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;

public interface InternalAlarmRepository {
	
	Map<Long, InternalAlarm> getInternalAlarmByIds(Iterable<Long> ids);

	List<InternalAlarm> getSynchronizingInternalAlarmsByOrderById(InternalAlarmSynchronizingState synchronizingState, long minExclusiveId, int limit);
	
	LimitedResult<InternalAlarm> getInternalAlarms(
			InternalAlarmSpecification specification,
			int maxRows);
	
    long countAlarms(InternalAlarmSpecification specification);
    
    Map<String, InternalAlarmSummary> getSummaryMap();
	
	void persistInternalAlarm(InternalAlarm internalAlarm);
	
	void mergeInternalAlarm(InternalAlarm alarm);
	
	void changeSynchronizingState(InternalAlarmSynchronizingState synchronizingState);
	
	void deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState synchronizingState);
	
	long countUnmappedAlarms();
	
	/*
	 * Internal alarm synchronizer and internal alarm trigger
	 * don't process all the alarm one time, but split the alarms
	 * to some partitions and process them one by one to avoid
	 * the memory cost when there are too much alarms.
	 * 
	 * It's very important to clear the JPA level-1 cache after
	 * each partition is processed to free the memory of processed
	 * alarm object; otherwise, that solution is a joke.
	 * 
	 * Before clear, it's important to invoke flush, that's why the name
	 * of this method is "flushAndClear"
	 */
	void flushAndClear();

}
