package com.nokia.oss.smu.netact.alarm.bll.internal;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import com.nokia.oss.smu.alarm.AlarmComponentMapper;
import com.nokia.oss.smu.alarm.AlarmMapping;
import com.nokia.oss.smu.alarm.Alarmable;
import com.nokia.oss.smu.alarm.internal.AlarmMappingConfigParser;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.platform.MonitorPlatform;

@org.springframework.stereotype.Component("alarmComponentMapper")
public class AlarmComponentMapperImpl implements AlarmComponentMapper {
	
	private static final Logger LOGGER = Logger.getLogger(AlarmComponentMapperImpl.class.getName());

    private List<AlarmMapping> alarmMappings;

    @Override
    public Component mapComponent(Alarmable alarmable) {
		LOGGER.fine("Mapping alarm (alarm ID=" + alarmable.getId() + ") to component.");
        for (AlarmMapping alarmMapping : this.getAlarmMappings()) {
        	com.nokia.oss.smu.core.Component component = alarmMapping.mapComponent(alarmable);
            if (component != null) {
				LOGGER.finest("Alarm (alarm ID=" + alarmable.getId() + ") mapped to component (name = " + component
						.getDisplayName() + ")");
				return component;
            }
        }

		LOGGER.warning("Unable to map (alarm ID=" + alarmable.getId() + ") to any component.");
        return null;
    }

    synchronized private List<AlarmMapping> getAlarmMappings() {
    	if (alarmMappings == null) {
			LOGGER.info("Loading alarm to component mapping definitions");
			alarmMappings = createAlarmMappings();
			LOGGER.info("Mapping definitions loaded, " + alarmMappings.size() + " mappings in total" );
    	}
    	
        return alarmMappings;
    }
    
    private List<AlarmMapping> createAlarmMappings() {
		try {
			Component rootComponent = MonitorPlatform.getPlatform().getFirstMonitoredSystem().getRootComponent();
			InputStream mappingStream = getClass().getClassLoader().getResourceAsStream("smu-netact-alarm-mappings.xml");
			return new AlarmMappingConfigParser().loadAlarmMappingRules(
					Collections.singletonList(rootComponent),
					mappingStream
			);
		} catch (XmlParseException ex) {
			LOGGER.warning("Unable to load mapping configuration, exception caught: " + ex.getMessage());
			return Collections.emptyList();
		}
    }
}
