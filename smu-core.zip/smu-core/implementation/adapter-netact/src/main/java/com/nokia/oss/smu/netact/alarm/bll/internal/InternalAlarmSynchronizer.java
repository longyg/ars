package com.nokia.oss.smu.netact.alarm.bll.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nokia.oss.interfaces.fmaccess.service.AckStatus;
import com.nokia.oss.interfaces.fmaccess.service.AlarmCounts;
import com.nokia.oss.interfaces.fmaccess.service.AlarmMonitorSEI;
import com.nokia.oss.interfaces.fmaccess.service.Filter;
import com.nokia.oss.interfaces.fmaccess.service.GetActiveAlarmsFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmsCountsFault;
import com.nokia.oss.interfaces.fmaccess.service.IterationFault;
import com.nokia.oss.interfaces.fmaccess.service.NsnAlarm;
import com.nokia.oss.interfaces.fmaccess.service.Operator;
import com.nokia.oss.interfaces.fmaccess.service.PerceivedSeverity;
import com.nokia.oss.interfaces.fmaccess.service.RelationalCriterion;
import com.nokia.oss.interfaces.fmaccess.service.UserInfo;
import com.nokia.oss.smu.alarm.AlarmComponentMapper;
import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmException;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm.AckState;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmAdditionalInfo;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import com.nokia.oss.smu.settings.PreferenceService;
import org.springframework.transaction.annotation.Transactional;

@Component
public class InternalAlarmSynchronizer {

    private static final Logger LOGGER = Logger.getLogger(InternalAlarmSynchronizer.class.getName());

    private static final String LAST_SYNC_MILLIS = "private.alarm.last.sync.millis";

    private static final int ALARM_FETCH_AMOUNT_EACH_ROUND = 100;

    private static final String NSNALARM_SPECIFIC_PROBLEM = "specificProblem";

    private static final String NSNALARM_DN = "dn";

    private static final String LIKE_NETACT = "*NETACT*";
    private static final long SYNC_TOLERANCE = 60000;

    @Resource
    private DelayedEntityManagerFactory delayedEMF;

    @Resource
    private InternalAlarmRepository internalAlarmRepository;

    @Resource
    private AlarmMonitorSEI alarmMonitorSEI;

    @Resource
    private InternalAlarmTrigger internalAlarmTrigger;

    @Resource
    private AlarmComponentMapper mapper;

    @Resource
    private PreferenceService preferenceService;

    @Value("${internal.alarm.synchronizer.interval}")
    private long interval;

    @Value("${selfmon.alarm.number.ranges}")
    private String selfmonAlarmNumberRangeText;

    @Value("${internal.alarm.number.ranges}")
    private String internalAlarmNumberRangeText;

    private long[][] selfmonAlarmNumberRanges;

    private long[][] internalAlarmNumberRanges;

    public InternalAlarmSynchronizer() {
    }

    @PostConstruct
    public void initialize() {

        if (this.selfmonAlarmNumberRangeText == null || this.selfmonAlarmNumberRangeText.isEmpty()) {
            throw new IllegalStateException("selfmonAlarmNumberRangeText must be configured");
        }

        if (this.internalAlarmNumberRangeText == null || this.internalAlarmNumberRangeText.isEmpty()) {
            throw new IllegalStateException("internalAlarmNumberRanges must be configured");
        }

        this.selfmonAlarmNumberRanges = parseRanges(this.selfmonAlarmNumberRangeText);
        this.internalAlarmNumberRanges = parseRanges(this.internalAlarmNumberRangeText);

        logSyncSpecs();
    }

    private long[][] parseRanges(String rangesText) {
        String[] rangeTextArr = rangesText.split("\\s*,\\s*");
        long[][] numberArr = new long[rangeTextArr.length][];
        for (int i = numberArr.length - 1; i >= 0; i--) {
            String text = rangeTextArr[i];
            int index = text.indexOf('-');
            if (index == -1) {
                long value = Long.parseLong(text);
                numberArr[i] = new long[] { value, value };
            } else {
                long min = Long.parseLong(text.substring(0, index).trim());
                long max = Long.parseLong(text.substring(index + 1).trim());
                numberArr[i] = new long[] { min, max };
            }
        }
        return numberArr;
    }

    private void logSyncSpecs() {
        LOGGER.info("Interval to sync alarms: " + this.interval);
        StringBuilder builder = new StringBuilder();
        for (long[] range : this.selfmonAlarmNumberRanges) {
            if (builder.length() != 0) {
                builder.append(", ");
            }
            builder.append(range[0]).append('-').append(range[1]);
        }
        LOGGER.info("Selfmon alarm number ranges: " + builder.toString());

        builder = new StringBuilder();
        for (long[] range : this.internalAlarmNumberRanges) {
            if (builder.length() != 0) {
                builder.append(", ");
            }
            builder.append(range[0]).append('-').append(range[1]);
        }
        LOGGER.info("Internal alarm number ranges: " + builder.toString());
    }

    @Synchronized(lockName = "internal.alarm.synchronization.lock", nowait = true)
    @Transactional
    public void synchronize() {
        if (!this.delayedEMF.isAvailable()) {
            return;
        }
        try {
            if (shouldExecute(this.preferenceService.getVariable(LAST_SYNC_MILLIS), this.interval)) {
                LOGGER.fine("sync alarm start");
                this.doSynchronize();
                this.preferenceService.setVariableWithoutLock(LAST_SYNC_MILLIS, Long.toString(System.currentTimeMillis()));
                LOGGER.fine("sync alarm done");
            }
        } catch (GetAlarmsCountsFault | GetActiveAlarmsFault | IterationFault ex) {
            throw new AlarmSyncException("Unable to fetch alarms via FM Access. ", ex);
        }
    }

    public boolean isSynchronizing() {
        String lastSync = preferenceService.getVariable(LAST_SYNC_MILLIS);
        return lastSync != null && System.currentTimeMillis() - Long.valueOf(lastSync) < SYNC_TOLERANCE;

    }

    private boolean shouldExecute(String lastSyncMillis, long interval) {
        boolean shouldExecute;
        try {
            shouldExecute = lastSyncMillis == null || System.currentTimeMillis() - Long.parseLong(lastSyncMillis) >= interval;
        } catch (NumberFormatException ex) {
            shouldExecute = true;
        }
        LOGGER.finest("should execute = " + shouldExecute + ", lastSync = " + lastSyncMillis);
        return shouldExecute;
    }

    private void doSynchronize() throws GetAlarmsCountsFault, GetActiveAlarmsFault, IterationFault {
        LOGGER.fine("do syncing alarms ");
        long expectedNewCount = this.queryActiveInternalAlarmCountFromFM();
        int actualNewCount = this.acceptActiveInternalAlarmsFromFM();
        if (expectedNewCount != actualNewCount) {
            throw new AlarmSyncException("GetActiveAlarmCounts got " + expectedNewCount +
                    ", but getActiveAlarms got " + actualNewCount);
        }
        this.internalAlarmTrigger.triggerEvents();
        this.internalAlarmRepository.deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState.ORIGINAL);
        this.internalAlarmRepository.changeSynchronizingState(InternalAlarmSynchronizingState.ORIGINAL);
    }

    private long queryActiveInternalAlarmCountFromFM() throws GetAlarmsCountsFault {
        ArrayList<Filter> filters = this.createInternalAlarmFilters();
        UserInfo userInfo = new UserInfo();
        userInfo.setFilterId(new Short("0"));
        AlarmCounts counts = this.alarmMonitorSEI.getActiveAlarmCounts(filters, userInfo);
        long count = 0;
        if (counts.getCriticalCount() != null) {
            count += counts.getCriticalCount();
        }
        if (counts.getMajorCount() != null) {
            count += counts.getMajorCount();
        }
        if (counts.getMinorCount() != null) {
            count += counts.getMinorCount();
        }
        if (counts.getWarningCount() != null) {
            count += counts.getWarningCount();
        }
        if (counts.getIndeterminateCount() != null) {
            count += counts.getIndeterminateCount();
        }
        if (counts.getClearedCount() != null) {
            count += counts.getClearedCount();
        }
        return count;
    }

    private int acceptActiveInternalAlarmsFromFM() throws GetActiveAlarmsFault, IterationFault {
        ArrayList<Filter> filters = this.createInternalAlarmFilters();
        UserInfo userInfo = new UserInfo();
        userInfo.setFilterId(new Short("0"));
        int alarmCount = 0;

        LOGGER.fine("Requesting get active alarms.");
        this.alarmMonitorSEI.getActiveAlarms(0, null, filters, userInfo);
        while (true) {
            List<NsnAlarm> alarms = alarmMonitorSEI.getNext(ALARM_FETCH_AMOUNT_EACH_ROUND);
            if (alarms.isEmpty()) {
                break;
            }
            LOGGER.fine(alarms.size() + " alarms fetched from AlarmMonitorService");
            InternalAlarm[] arr = new InternalAlarm[alarms.size()];
            int index = 0;
            for (NsnAlarm nsnAlarm : alarms) {
                LOGGER.finest("NsnAlarm: " + getNsnAlarmString(nsnAlarm));
                arr[index++] = convert(nsnAlarm);
            }
            this.acceptInternalAlarms(arr);
            alarmCount += arr.length;
        }
        return alarmCount;
    }

    private static String getNsnAlarmString(NsnAlarm nsnAlarm) {
        return "number " + nsnAlarm.getSpecificProblem() + ", id " + nsnAlarm.getAlarmKey() + ", dn: " +
                nsnAlarm.getDn() + ", severity " + nsnAlarm.getPerceivedSeverity();
    }

    private static String getInternalAlarmString(InternalAlarm alarm) {
        return "number " + alarm.getNumber() + ", id " + alarm.getId() + ", dn " +
                alarm.getDistinguishName() + ", severity " + alarm.getSeverity();
    }

    private void acceptInternalAlarms(InternalAlarm[] alarms) {
        Long[] ids = new Long[alarms.length];
        for (int i = alarms.length - 1; i >= 0; --i) {
            ids[i] = alarms[i].getId();
        }
        Map<Long, InternalAlarm> originalAlarms = this.internalAlarmRepository.getInternalAlarmByIds(Arrays.asList(ids));
        LOGGER.fine("Determine the mapped components for inserted internal alarms");
        for (InternalAlarm alarm : alarms) {
            InternalAlarm existAlarm = originalAlarms.get(alarm.getId());
            if (existAlarm != null) {
                if (existAlarm.getSeverity() != alarm.getSeverity()) {
                    alarm.setSynchronizingState(InternalAlarmSynchronizingState.CHANGED);
                    LOGGER.info("Alarm is changed: " + getInternalAlarmString(alarm) + ", original severity: " + existAlarm.getSeverity());
                } else {
                    alarm.setSynchronizingState(InternalAlarmSynchronizingState.REFRESHED);
                    if (LOGGER.isLoggable(Level.FINEST)) {
                        LOGGER.finest("Alarm is refreshed: " + getInternalAlarmString(alarm));
                    }
                }
                alarm.setMappedComponentId(existAlarm.getMappedComponentId());
                this.internalAlarmRepository.mergeInternalAlarm(alarm);
            } else {
                com.nokia.oss.smu.core.Component mappedComponent = this.mapper.mapComponent(alarm);
                if (mappedComponent == null) {
                    LOGGER.warning("Alarm " + alarm + " cannot be mapped to component.");
                } else {
                    alarm.setMappedComponentId(mappedComponent.getId());
                }
                alarm.setSynchronizingState(InternalAlarmSynchronizingState.INSERTED);
                this.internalAlarmRepository.persistInternalAlarm(alarm);
            }
        }

        this.internalAlarmRepository.flushAndClear();
    }

    private ArrayList<Filter> createInternalAlarmFilters() {
        ArrayList<Filter> filters = new ArrayList<Filter>();

        for (long[] range : this.selfmonAlarmNumberRanges) {
            Filter filter = createFilter(range[0], range[1], true);
            filters.add(filter);
        }

        for (long[] range : this.internalAlarmNumberRanges) {
            Filter filter = createFilter(range[0], range[1], false);
            filters.add(filter);
        }
        return filters;
    }

    private static Filter createFilter(long minAlarmNumber, long maxAlarmNumber, boolean dnLikeNetAct) {
        Filter filter = new Filter();
        List<RelationalCriterion> relations = filter.getRelationalCriteria();
        RelationalCriterion relation;

        relation = new RelationalCriterion();
        relation.setOperator(Operator.GREATERTHANEQUALS);
        relation.setAttributeName(NSNALARM_SPECIFIC_PROBLEM);
        relation.setAttributeValue(minAlarmNumber);
        relations.add(relation);

        relation = new RelationalCriterion();
        relation.setOperator(Operator.LESSTHANEQUALS);
        relation.setAttributeName(NSNALARM_SPECIFIC_PROBLEM);
        relation.setAttributeValue(maxAlarmNumber);
        relations.add(relation);

        if (dnLikeNetAct) {
            relation = new RelationalCriterion();
            relation.setOperator(Operator.LIKE_IGNORECASE);
            relation.setAttributeName(NSNALARM_DN);
            relation.setAttributeValue(LIKE_NETACT);
            relations.add(relation);
        }

        return filter;
    }

    private static InternalAlarm convert(NsnAlarm nsnAlarm) {
        InternalAlarm internalAlarm = new InternalAlarm();
        internalAlarm.setId(nsnAlarm.getAlarmKey().getAlarmId());
        internalAlarm.setNumber(nsnAlarm.getSpecificProblem());
        if (nsnAlarm.getAlarmTime() == null) {
            throw new InternalAlarmException("Invalid internal alarm: " + getNsnAlarmString(nsnAlarm) + ", alarmTime is null");
        }

        internalAlarm.setAlarmTime(nsnAlarm.getAlarmTime().toGregorianCalendar());
        internalAlarm.setSeverity(convert(nsnAlarm.getPerceivedSeverity()));
        internalAlarm.setAckState(convert(nsnAlarm.getAckStatus()));
        internalAlarm.setDistinguishName(nsnAlarm.getDn());
        internalAlarm.setTitle(nsnAlarm.getAlarmText());
        internalAlarm.setAcknowledgedBy(nsnAlarm.getAckUser());
        if (nsnAlarm.getAckTime() != null) {
            internalAlarm.setAckTime(nsnAlarm.getAckTime().toGregorianCalendar());
        }
        internalAlarm.setClearedBy(nsnAlarm.getClearUser());
        if (nsnAlarm.getClearTime() != null) {
            internalAlarm.setClearTime(nsnAlarm.getClearTime().toGregorianCalendar());
        }
        if (nsnAlarm.getEventType() != null) {
            internalAlarm.setEventType(nsnAlarm.getEventType().name());
        }
        if (nsnAlarm.getAdditionalAttributes() != null) {
            for (NsnAlarm.AdditionalAttributes.Entry entry : nsnAlarm.getAdditionalAttributes().getEntry()) {
                if ("originalAlarmId".equals(entry.getKey())) {
                    internalAlarm.setNotificationId(entry.getValue());
                }
            }
        }
        InternalAlarmAdditionalInfo additionalInfo = new InternalAlarmAdditionalInfo();
        additionalInfo.setAdditionalText1(nsnAlarm.getAdditionalText1());
        additionalInfo.setAdditionalText2(nsnAlarm.getAdditionalText2());
        additionalInfo.setAdditionalText3(nsnAlarm.getAdditionalText3());
        additionalInfo.setAdditionalText4(nsnAlarm.getAdditionalText4());
        additionalInfo.setAdditionalText5(nsnAlarm.getAdditionalText5());
        additionalInfo.setAdditionalText6(nsnAlarm.getAdditionalText6());
        additionalInfo.setAdditionalText7(nsnAlarm.getAdditionalText7());
        internalAlarm.setAdditionalInfo(additionalInfo);
        return internalAlarm;
    }

    private static AlarmSeverity convert(PerceivedSeverity perceivedSeverity) {
        if (perceivedSeverity == PerceivedSeverity.INDETERMINATE) {
            return AlarmSeverity.INDETERMINATE;
        }
        if (perceivedSeverity == PerceivedSeverity.WARNING) {
            return AlarmSeverity.WARNING;
        }
        if (perceivedSeverity == PerceivedSeverity.MINOR) {
            return AlarmSeverity.MINOR;
        }
        if (perceivedSeverity == PerceivedSeverity.MAJOR) {
            return AlarmSeverity.MAJOR;
        }
        if (perceivedSeverity == PerceivedSeverity.CRITICAL) {
            return AlarmSeverity.CRITICAL;
        }
        throw new IllegalArgumentException(
                "Invalid " + PerceivedSeverity.class.getName() + " \"" + perceivedSeverity + "\"");
    }

    private static AckState convert(AckStatus ackStatus) {
        if (ackStatus == AckStatus.UNACKED) {
            return AckState.UNACKED;
        }
        if (ackStatus == AckStatus.ACKED) {
            return AckState.ACKED;
        }
        throw new IllegalArgumentException(
                "Invalid " + AckStatus.class.getName() + " \"" + ackStatus + "\"");
    }
}
