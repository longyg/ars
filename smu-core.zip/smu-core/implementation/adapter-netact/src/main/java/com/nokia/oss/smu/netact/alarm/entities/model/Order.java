package com.nokia.oss.smu.netact.alarm.entities.model;

import javax.persistence.metamodel.SingularAttribute;

public class Order {

	private String propertyName;
	
	private OrderMode mode;
	
	public static Order asc(String propertyName) {
		return new Order(propertyName, OrderMode.ASCENDING);
	}
	
	public static Order desc(String propertyName) {
		return new Order(propertyName, OrderMode.DESCENDING);
	}
	
	public static Order asc(SingularAttribute<?, ?> attribute) {
		return new Order(attribute.getName(), OrderMode.ASCENDING);
	}
	
	public static Order desc(SingularAttribute<?, ?> attribute) {
		return new Order(attribute.getName(), OrderMode.DESCENDING);
	}
	
	public Order(String propertyName, OrderMode mode) {
		if (propertyName == null || propertyName.isEmpty()) {
			throw new IllegalArgumentException("propertyName can not be null or empty");
		}
		if (mode == null) {
			throw new IllegalArgumentException("mode can not be null");
		}
		this.propertyName = propertyName;
		this.mode = mode;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public OrderMode getMode() {
		return mode;
	}

	/*
	 * Private member for JSON deserialization
	 */
	@SuppressWarnings("unused")
	private Order() {}
	
	@SuppressWarnings("unused")
	private void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	@SuppressWarnings("unused")
	private void setMode(OrderMode mode) {
		this.mode = mode;
	}
	
	public static enum OrderMode {
		ASCENDING,
		DESCENDING
	}
}
