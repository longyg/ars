package com.nokia.oss.smu.netact.internal;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.MonitoredSystemSpec;
import com.nokia.oss.smu.core.lifecycle.AbstractLifecycle;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.platform.MonitoredSystemCreationService;
import com.nokia.oss.smu.core.platform.MonitoredSystemPersistService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

public class FixedSingleSystemPersistService extends AbstractLifecycle implements MonitoredSystemPersistService {
    private static final Logger LOG = getLogger(FixedSingleSystemPersistService.class.getName());


    @Override
    public void persist(MonitoredSystem system) {
        LOG.info("Current system no need to be persisted.");
    }

    @Override
    public void remove(MonitoredSystem system) {
        LOG.info("Current system no cannot be removed.");
    }

    @Override
    public Collection<MonitoredSystem> load() {
        MonitorPlatform platform = MonitorPlatform.getPlatform();
        Collection<MonitoredSystemCreationService> ss = platform.findServices(MonitoredSystemCreationService.class);

        List<MonitoredSystem> monitoredSystems = new ArrayList<MonitoredSystem>();

        MonitoredSystemSpec spec = new MonitoredSystemSpec();
        spec.setInstanceName("Current Monitored System");
        spec.setSystemIdentifier("built-in system");
        spec.setSystemType("netact");
        MonitoredSystem ms = createMonitoredSystem(spec, ss);
        if (ms == null) {
            LOG.severe("Cannot create monitored system for spec: " + spec);
            return monitoredSystems;
        }

        monitoredSystems.add(ms);

        return monitoredSystems;
    }

    private MonitoredSystem createMonitoredSystem(MonitoredSystemSpec spec,
            Collection<MonitoredSystemCreationService> ss) {
        for (MonitoredSystemCreationService creationService : ss) {
            if (creationService.canCreate(spec)) {
                MonitoredSystem ms = creationService.create(spec);
                if (ms != null) {
                    return ms;
                }
            }
        }

        return null;
    }
}
