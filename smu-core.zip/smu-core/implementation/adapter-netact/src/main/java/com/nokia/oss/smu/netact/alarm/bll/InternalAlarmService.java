package com.nokia.oss.smu.netact.alarm.bll;

import com.nokia.oss.smu.alarm.OperationException;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import com.nokia.oss.interfaces.fmaccess.service.ManPageInfo;

import java.util.Map;

public interface InternalAlarmService {

	LimitedResult<InternalAlarm> query(
			InternalAlarmSpecification specification,
			int maxRows);
	
	Map<String, InternalAlarmSummary> getSummariesForComponents();

	long count(InternalAlarmSpecification specification);

	void acknowledge(long[] ids, String user) throws OperationException;
	
	void unacknowledge(long[] ids, String user) throws OperationException;
	
	void cancel(long[] ids, String user) throws OperationException;
    
    ManPageInfo getManPageInfo(long alarmId);

	long countUnmapped();
}
