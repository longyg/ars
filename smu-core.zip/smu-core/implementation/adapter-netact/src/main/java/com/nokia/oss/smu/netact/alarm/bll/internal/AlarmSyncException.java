package com.nokia.oss.smu.netact.alarm.bll.internal;

public class AlarmSyncException extends RuntimeException {

    private static final long serialVersionUID = 5283545005246042944L;

    public AlarmSyncException(String message) {
        super(message);
    }

    public AlarmSyncException(String message, Throwable cause) {
        super(message, cause);
    }
}
