package com.nokia.oss.smu.netact.alarm.dal.internal;

import com.nokia.oss.fmaccess.service.impl.AlarmDelegateService;
import com.nokia.oss.interfaces.fmaccess.service.AlarmDelegateSEI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URL;

@Component
public class WeakAlarmDelegateFactoryBean extends AbstractWeakCXFDependencyFactoryBean {

    @Value("${fm.access.web.service.delegate.uri}")
    private String delegateUri;

    @Override
    public Class<?> getObjectType() {
        return AlarmDelegateSEI.class;
    }

    @Override
    protected String getServiceUri() {
        return delegateUri;
    }

    @Override
    protected Object createPortObject(String serviceUrl) throws Throwable {
        AlarmDelegateService delegateService = new AlarmDelegateService(new URL(serviceUrl));
        return delegateService.getAlarmDelegatePort();
    }
}
