package com.nokia.oss.smu.netact.alarm.bll.internal;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.Alarmable;
import com.nokia.oss.smu.alarm.mail.AlarmMailContentGenerator;
import com.nokia.oss.smu.core.util.LogUtils;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.mail.MailSender;
import com.nokia.oss.smu.mail.MailSenderException;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmListener;
import com.nokia.oss.smu.netact.alarm.dal.AlarmMailTaskRepository;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.AlarmMailTask;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import com.nokia.oss.smu.settings.PreferenceChangeEvent;
import com.nokia.oss.smu.settings.PreferenceService;
import com.nokia.oss.smu.settings.PreferenceUpgradeMigrator;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

@Component("alarmMailTaskManager")
public class AlarmMailTaskManager implements InternalAlarmListener, ApplicationListener<PreferenceChangeEvent> {

    private static final Logger LOGGER = getLogger(AlarmMailTaskManager.class.getName());

    public static final String VARIABLE_LAST_NEW_MAIL_SENT_TIME = "private.last.new.mail.sent.time";

    public static final String VARIABLE_LAST_REMINDER_MAIL_SENT_TIME = "private.last.reminder.mail.sent.aligned.time";

    @Resource
    private AlarmMailTaskRepository taskRepository;

    @Resource
    private InternalAlarmRepository internalAlarmRepository;

    @Resource
    private MailSender mailSender;

    @Resource
    private AlarmMailContentGenerator contentGenerator;

    @Resource
    private PreferenceService preferenceService;

    @Resource
    private PreferenceUpgradeMigrator preferenceUpgradeMigrator;

    @Value("${internal.alarm.mail.delay.default}")
    private long defaultMailDelay;

    @Value("${internal.alarm.mail.resend.interval.default}")
    private long defaultResendInterval;

    @Value("${internal.alarm.mail.max.default}")
    private int defaultMaxCount;

    private static AlarmSeverity preferenceNameToSeverity(String preferenceName) {
        switch (preferenceName) {
        case PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED:
            return AlarmSeverity.CRITICAL;
        case PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED:
            return AlarmSeverity.MAJOR;
        case PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED:
            return AlarmSeverity.MINOR;
        default:
            return null;
        }
    }

    private static List<InternalAlarm> extractAlarms(Collection<AlarmMailTask> tasks) {
        InternalAlarm[] arr = new InternalAlarm[tasks.size()];
        int index = 0;
        for (AlarmMailTask task : tasks) {
            InternalAlarm alarm = task.getAlarm();
            /*
             * "Persistence.getPersistenceUtil().isLoaded(alarm)" cannot be used in WAS because the
             * vendor of "javax.persistence.Persistence" isn't Hibernate,
             * so we have to use Hibernate.isInitialized(alarm)
             */
            if (!Hibernate.isInitialized(alarm)) {
                throw new AssertionError("The alarm of task must be fetch to avoid N + 1 query");
            }
            arr[index++] = task.getAlarm();
        }
        return Arrays.asList(arr);
    }

    private static String alarmIdListString(Iterable<InternalAlarm> alarms) {
        StringBuilder builder = new StringBuilder();
        for (Alarmable alarmable : alarms) {
            if (builder.length() != 0) {
                builder.append(", ");
            }
            builder.append(alarmable.getId());
        }
        return builder.toString();
    }

    @Transactional
    @Override
    public void alarmsAdded(Collection<InternalAlarm> alarms) {
        this.createTasksByAlarms(alarms, AlarmMailTask.EventType.NEW_ALARM);
    }

    @Transactional
    @Override
    public void alarmsRemoved(Collection<InternalAlarm> alarms) {
        if (!alarms.isEmpty()) {
            LOGGER.info("Delete mail tasks of the removed alarms: " + alarmIdListString(alarms));
            this.taskRepository.deleteTasksByAlarms(alarms);
        }
    }

    @Override
    public void alarmsChanged(Collection<InternalAlarm> alarms) {
        this.createTasksByAlarms(alarms, AlarmMailTask.EventType.CHANGE_EVENT);
    }

    @Synchronized(lockName = "com.nokia.oss.smu.netact.sendAlarmMail", nowait = true)
    @Transactional
    public void executeTasks() {
        LOGGER.fine("execute send alarm mail task start");
        String lastNewMailSentTime = this.preferenceService.getVariable(VARIABLE_LAST_NEW_MAIL_SENT_TIME);
        long now = System.currentTimeMillis();
        if (lastNewMailSentTime == null) {
            preferenceService.setVariableWithoutLock(VARIABLE_LAST_NEW_MAIL_SENT_TIME, Long.toString(now));
            LOGGER.finest("First time of checking mail sending for alarms");
            return;
        }
        if (now < Long.parseLong(lastNewMailSentTime) + this.getMailDelay()) {
            LOGGER.finest("Not due to send mails yet, sent at " + lastNewMailSentTime + " and now is " + now);
            return;
        }

        preferenceService.setVariableWithoutLock(VARIABLE_LAST_NEW_MAIL_SENT_TIME, Long.toString(now));
        Collection<String> recipients = preferenceService.getMultiVariable(PreferenceService.TARGET_ADDRESSES);
        if (recipients.isEmpty()) {
            LOGGER.fine("Mail notification skipped due to no recipient set.");
            return;
        }

        this.sendForNewOrChangedAlarms(recipients);
        this.resendCriticalAlarms(recipients);
        LOGGER.fine("execute send alarm mail task done");
    }

    @Transactional
    @Override
    public void onApplicationEvent(PreferenceChangeEvent event) {
        LOGGER.fine("Handling preference changed: " + event.getName());
        AlarmSeverity severity = preferenceNameToSeverity(event.getName());
        if (severity == null) {
            LOGGER.fine("Preference change event is not about severity, ignored.");
            return;
        }

        boolean enabled = !event.getNewValues().isEmpty() && event.getNewValues().iterator().next().equals("true");

        if (!enabled) {
            LOGGER.info("The preference configuration is changed, the mail notification for \" " + severity
                    + "\" is disabled, some the mail tasks of some alarms will be removed.");
            this.taskRepository.deleteTasksByAlarmSeverity(severity);
        }
    }

    private boolean reminderSendingEnabled() {
        return this.preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED);
    }

    private boolean reminderSendingDue() {
        final String lastSentTime = this.preferenceService.getVariable(VARIABLE_LAST_REMINDER_MAIL_SENT_TIME);
        if (null == lastSentTime) {
            LOGGER.info("Init " + VARIABLE_LAST_REMINDER_MAIL_SENT_TIME);
            setAlignedReminderSentTime();
            return false;
        }
        try {
            return getAlignedMillsForNow() > getAlignedMills(Long.parseLong(lastSentTime));
        } catch (NumberFormatException ex) {
            LOGGER.warning("Wrong format for " + VARIABLE_LAST_REMINDER_MAIL_SENT_TIME + ", reset it");
            setAlignedReminderSentTime();
            return false;
        }
    }

    private void setAlignedReminderSentTime() {
        this.preferenceService
                .setVariableWithoutLock(VARIABLE_LAST_REMINDER_MAIL_SENT_TIME, Long.toString(getAlignedMillsForNow()));
    }

    private long getAlignedMillsForNow() {
        return ScheduleUtil.getAlignedMills(System.currentTimeMillis(), this.getResendInterval());
    }

    private long getAlignedMills(long millis) {
        return ScheduleUtil.getAlignedMills(millis, this.getResendInterval());
    }

    private void createTasksByAlarms(Collection<InternalAlarm> alarms, AlarmMailTask.EventType type) {
        if (alarms.isEmpty()) {
            return;
        }
        Set<AlarmSeverity> enabledSeverities = this.getEnabledSeverities();
        for (InternalAlarm alarm : alarms) {
            if (enabledSeverities.contains(alarm.getSeverity())) {
                LOGGER.info("Schedule to send mail for the " +
                        "alarm(id=" + alarm.getId() + ", number=" + alarm.getNumber() + ")");
                AlarmMailTask task = new AlarmMailTask();
                task.setLastSentTime(null);
                task.setAlarm(alarm);
                task.setType(type);
                this.taskRepository.persistTask(task);
            } else {
                LOGGER.info("The email notification for severity '" + alarm.getSeverity()
                        + "' is disabled, so the alarm(id = " + alarm.getId() + ", number=" + alarm.getNumber()
                        + ") is ignored");
            }
        }
    }

    private void resendCriticalAlarms(Collection<String> recipients) {
        if (!reminderSendingEnabled()) {
            LOGGER.fine("Sending reminder mail for critical alarms disabled.");
            return;
        }

        if (!reminderSendingDue()) {
            LOGGER.fine("Sending reminder mail for critical alarms not due yet.");
            return;
        }

        setAlignedReminderSentTime();

        InternalAlarmSpecification specForCriticalAlarms = new InternalAlarmSpecification();
        specForCriticalAlarms.setSeverities(EnumSet.of(AlarmSeverity.CRITICAL));
        long count = internalAlarmRepository.countAlarms(specForCriticalAlarms);
        if (count == 0) {
            LOGGER.info("No critical alarms to send reminder");
            return;
        }

        LimitedResult<InternalAlarm> alarms = this.internalAlarmRepository
                .getInternalAlarms(specForCriticalAlarms, getMaxEmailCount() + 1);
        sendOldAlarmMail(alarms.getEntities(), count, recipients);
    }

    private void sendForNewOrChangedAlarms(Collection<String> recipients) {
        LOGGER.fine("Merge and send tasks of new events");
        List<AlarmMailTask> tasks = taskRepository.getNewTasks();
        if (tasks.isEmpty()) {
            return;
        }

        this.taskRepository.deleteTasks(tasks);
        List<AlarmMailTask> newAlarmTasks = new ArrayList<>();
        List<AlarmMailTask> changeEventTasks = new ArrayList<>();
        for (AlarmMailTask task : tasks) {
            if (task.getType() == AlarmMailTask.EventType.CHANGE_EVENT) {
                changeEventTasks.add(task);
            } else {
                newAlarmTasks.add(task);
            }
        }

        if (!newAlarmTasks.isEmpty()) {
            this.sendNewAlarmMail(extractAlarms(newAlarmTasks), recipients);
        }
        if (!changeEventTasks.isEmpty()) {
            this.sendChangeEventsMail(extractAlarms(changeEventTasks), recipients);
        }
    }

    private void sendOldAlarmMail(List<InternalAlarm> alarms, long total, Collection<String> recipients) {
        LOGGER.info("Sending email for " + alarms.size() + " still active critical internal alarm(s): " +
                alarmIdListString(alarms));
        String subject = total + " critical internal alarm(s) still active";
        String html = contentGenerator.generateContent(this.getMaxEmailCount(), alarms);
        for (String address : recipients) {
            try {
                mailSender.sendHTML(address, subject, html);
            } catch (MailSenderException ex) {
                LOGGER.severe("Failed to send mail for still active critical alarms: " + LogUtils.getChainedCauses
                        (ex));
            }
        }

        LOGGER.info("Mail sent for still active alarms complete");
    }

    private void sendChangeEventsMail(List<InternalAlarm> alarms, Collection<String> recipients) {
        LOGGER.info("Sending mail for alarm change events: " + alarmIdListString(alarms));
        String html = contentGenerator.generateContent(getMaxEmailCount(), alarms);
        String subject = alarms.size() + " internal alarm(s) severity changed";
        for (String address : recipients) {
            try {
                this.mailSender.sendHTML(address, subject, html);
            } catch (MailSenderException ex) {
                LOGGER.severe("Failed to send mail for change events: " + LogUtils.getChainedCauses(ex));
            }
        }

        LOGGER.info("Mail sent for change events");
    }

    private void sendNewAlarmMail(List<InternalAlarm> alarms, Collection<String> recipients) {
        int counts[] = new int[AlarmSeverity.values().length];
        for (InternalAlarm alarm : alarms) {
            counts[alarm.getSeverity().ordinal()]++;
        }

        String what = "";
        if (counts[AlarmSeverity.CRITICAL.ordinal()] > 0) {
            what += counts[AlarmSeverity.CRITICAL.ordinal()] + " critical ";
        }
        if (counts[AlarmSeverity.MAJOR.ordinal()] != 0) {
            what += counts[AlarmSeverity.MAJOR.ordinal()] + " major ";
        }
        if (counts[AlarmSeverity.MINOR.ordinal()] != 0) {
            what += counts[AlarmSeverity.MINOR.ordinal()] + " minor ";
        }

        LOGGER.info("Sending email for " + what + "alarms: " + alarmIdListString(alarms));
        String html = contentGenerator.generateContent(getMaxEmailCount(), alarms);
        String subject = what + "internal alarm(s) raised";
        for (String address : recipients) {
            try {
                this.mailSender.sendHTML(address, subject, html);
            } catch (MailSenderException ex) {
                LOGGER.severe("Failed to send mail for new alarms: " + LogUtils.getChainedCauses(ex));
            }
        }

        LOGGER.info("Mail sent for new alarms");
    }

    private long getMailDelay() {
        try {
            String delayString = this.preferenceService.getVariable(PreferenceService.MAIL_DELAY);
            return Long.parseLong(delayString);
        } catch (NullPointerException | NumberFormatException ex) {
            return this.defaultMailDelay;
        }
    }

    private long getResendInterval() {
        try {
            String intervalString = this.preferenceService.getVariable(PreferenceService.CRITICAL_RESEND_INTERVAL);
            return Long.parseLong(intervalString);
        } catch (NullPointerException | NumberFormatException ex) {
            return defaultResendInterval;
        }
    }

    private int getMaxEmailCount() {
        try {
            String countString = this.preferenceService.getVariable(PreferenceService.EMAIL_MAX_ALARM_COUNT);
            return Integer.parseInt(countString);
        } catch (NullPointerException | NumberFormatException ex) {
            return this.defaultMaxCount;
        }
    }

    private Set<AlarmSeverity> getEnabledSeverities() {
        preferenceUpgradeMigrator.migrateAlarmMailTriggers();
        Set<AlarmSeverity> severities = EnumSet.noneOf(AlarmSeverity.class);
        if (this.preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED)) {
            severities.add(AlarmSeverity.CRITICAL);
        }
        if (this.preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED)) {
            severities.add(AlarmSeverity.MAJOR);
        }
        if (this.preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED)) {
            severities.add(AlarmSeverity.MINOR);
        }
        return severities;
    }
}
