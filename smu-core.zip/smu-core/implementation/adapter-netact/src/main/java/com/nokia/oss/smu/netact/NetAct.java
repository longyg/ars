package com.nokia.oss.smu.netact;

import static java.util.logging.Logger.getLogger;

import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.Deployment;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.base.BaseSystem;
import com.nokia.oss.smu.core.component.XmlComponentLoader;
import com.nokia.oss.smu.core.view.ComponentView;
import com.nokia.oss.smu.core.view.XmlComponentViewLoader;

public class NetAct extends BaseSystem {
    private static final Logger LOG = getLogger(NetAct.class.getName());

    private Component rootComponent;

    private ComponentView componentView;

    private Deployment deployment = new NetActDeployment();

    public NetAct(String name) {
        super(name);

        loadStaticComponents();
        loadComponentsView();
    }

    @Override
    public Deployment getDeployment() {
        return deployment;
    }

    public String toString() {
        return "NetAct instance '" + getSystemName() + "'\n";
    }

    private void loadStaticComponents() {
        XmlComponentLoader componentLoader = new XmlComponentLoader();
        InputStream componentsXml = getClass().getClassLoader().getResourceAsStream("smu-netact-components.xml");
        try {
            rootComponent = componentLoader.parseRootComponent(componentsXml);
        } catch (XmlParseException ex) {
            LOG.log(Level.SEVERE, "Cannot parse components definition from xml", ex);
        }
    }

    private void loadComponentsView() {
        XmlComponentViewLoader vl = new XmlComponentViewLoader();
        InputStream componentsXml = getClass().getClassLoader().getResourceAsStream("smu-netact-components-view.xml");
        try {
            componentView = vl.parseComponentsView(componentsXml, rootComponent);
        } catch (XmlParseException ex) {
            LOG.log(Level.SEVERE, "Cannot parse component view.", ex);
        }
    }

    @Override
    public ComponentView getComponentView() {
        return componentView;
    }

    @Override
    public Component getRootComponent() {
        return rootComponent;
    }
}
