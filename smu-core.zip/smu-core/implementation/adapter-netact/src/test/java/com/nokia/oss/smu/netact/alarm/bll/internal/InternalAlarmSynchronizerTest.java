package com.nokia.oss.smu.netact.alarm.bll.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.persistence.Cache;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceUnitUtil;
import javax.persistence.Query;
import javax.persistence.SynchronizationType;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.metamodel.Metamodel;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.TransactionStatus;

import com.nokia.oss.interfaces.fmaccess.service.AckStatus;
import com.nokia.oss.interfaces.fmaccess.service.AlarmCounts;
import com.nokia.oss.interfaces.fmaccess.service.AlarmMonitorSEI;
import com.nokia.oss.interfaces.fmaccess.service.Filter;
import com.nokia.oss.interfaces.fmaccess.service.GetActiveAlarmsFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmDescriptionByKeysFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmDescriptionByKeysResponse.Return;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmsByKeysFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmsByTemplateFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAlarmsCountsFault;
import com.nokia.oss.interfaces.fmaccess.service.GetAllAlarmsFault;
import com.nokia.oss.interfaces.fmaccess.service.IterationFault;
import com.nokia.oss.interfaces.fmaccess.service.NsnAlarm;
import com.nokia.oss.interfaces.fmaccess.service.NsnAlarmKey;
import com.nokia.oss.interfaces.fmaccess.service.PerceivedSeverity;
import com.nokia.oss.interfaces.fmaccess.service.UserInfo;
import com.nokia.oss.smu.alarm.AlarmComponentMapper;
import com.nokia.oss.smu.alarm.Alarmable;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.lifecycle.State;
import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;
import com.nokia.oss.smu.netact.alarm.FakeInternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmListener;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.settings.PreferenceService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = InternalAlarmSynchronizerTest.SpringConfiguration.class)
public class InternalAlarmSynchronizerTest {
	
	@Resource
	private InternalAlarmSynchronizer internalAlarmSynchronizer;
	
	@Resource
    private DelayedEntityManagerFactory delayedEMF;
	
	@Resource
	private FakeAlarmMonitorSEI fakeAlarmMonitorSEI;
	
	@Resource
	private FakeInternalAlarmRepository fakeInternalAlarmRepository;
	
	@Resource
	private ListenerImpl listenerImpl;
	
	@Before
	public void init() {
		this.fakeAlarmMonitorSEI.nsnAlarms = Collections.emptyList();
		this.fakeAlarmMonitorSEI.fakeActiveAlarmCount = null;
		this.fakeInternalAlarmRepository.reset();
		this.listenerImpl.getStringAndClear();
	}

	@Test
	public void test() throws Exception {
		
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("", listenerImpl.getStringAndClear());
		
		this.fakeAlarmMonitorSEI.nsnAlarms = Collections.singletonList(this.createNsnAlarm(1L));
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("insert(1);", listenerImpl.getStringAndClear());
		
		Assert.assertEquals("", listenerImpl.getStringAndClear());
		
		this.fakeAlarmMonitorSEI.nsnAlarms = Arrays.asList(this.createNsnAlarm(1L), this.createNsnAlarm(2L));
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("insert(2);", listenerImpl.getStringAndClear());
		
		Assert.assertEquals("", listenerImpl.getStringAndClear());
		
		this.fakeAlarmMonitorSEI.nsnAlarms = Arrays.asList(this.createNsnAlarm(2L), this.createNsnAlarm(3L));
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("delete(1);insert(3);", listenerImpl.getStringAndClear());
		
		Assert.assertEquals("", listenerImpl.getStringAndClear());
	}
	
	@Test
	public void testRetry() throws Exception {
		
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("", listenerImpl.getStringAndClear());
		
		this.fakeAlarmMonitorSEI.nsnAlarms = Collections.singletonList(this.createNsnAlarm(1L));
		
		// First time, fail
		this.fakeAlarmMonitorSEI.fakeActiveAlarmCount = 2L;
		try {
            this.internalAlarmSynchronizer.synchronize();
        } catch (AlarmSyncException ex) {
            //ignore
        }
		Assert.assertEquals("", listenerImpl.getStringAndClear());
		
		// Second time, success
		this.fakeAlarmMonitorSEI.fakeActiveAlarmCount = null;
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("insert(1);", listenerImpl.getStringAndClear());
	}

	@Test
	public void severityChanged_ChangeEventsShouldBeTriggered() throws Exception {
		this.fakeAlarmMonitorSEI.nsnAlarms = Collections.singletonList(this.createNsnAlarm(1L));
		this.fakeAlarmMonitorSEI.nsnAlarms.get(0).setPerceivedSeverity(PerceivedSeverity.MAJOR);
		this.internalAlarmSynchronizer.synchronize();
		Assert.assertEquals("insert(1);", listenerImpl.getStringAndClear());

		this.fakeAlarmMonitorSEI.nsnAlarms = Collections.singletonList(this.createNsnAlarm(1L));
		this.fakeAlarmMonitorSEI.nsnAlarms.get(0).setPerceivedSeverity(PerceivedSeverity.CRITICAL);
		this.internalAlarmSynchronizer.synchronize();
        Assert.assertEquals("change(1);", listenerImpl.getStringAndClear());
	}
	
	private NsnAlarm createNsnAlarm(long id) throws Exception {
		NsnAlarm nsnAlarm = new NsnAlarm();
		NsnAlarmKey key = new NsnAlarmKey();
		key.setAlarmId(id);
		nsnAlarm.setAlarmKey(key);
		nsnAlarm.setAlarmTime(DatatypeFactory.newInstance().newXMLGregorianCalendar());
		nsnAlarm.setSpecificProblem(0L);
		nsnAlarm.setAckStatus(AckStatus.UNACKED);	
		nsnAlarm.setPerceivedSeverity(PerceivedSeverity.MAJOR);
		return nsnAlarm;
	}
	
	@Configuration
	public static class SpringConfiguration {
		
		@Bean
		public DelayedEntityManagerFactory delayedEntityManagerFactory() {
			return new FakeDelayedEntityManagerFactory();
		}
		
		@Bean
		public InternalAlarmSynchronizer internalAlarmSynchronizer() {
			return new InternalAlarmSynchronizer();
		}
		
		@Bean
		public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() {
			PropertyPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertyPlaceholderConfigurer();
			Properties properties = new Properties();
			properties.put("internal.alarm.synchronizer.interval", "0");
			properties.put("internal.alarm.number.ranges", "0");
			properties.put("selfmon.alarm.number.ranges", "0");
			propertyPlaceholderConfigurer.setProperties(properties);
			return propertyPlaceholderConfigurer;
		}
		
		@Bean
		public InternalAlarmRepository internalAlarmRepository() {
			return new FakeInternalAlarmRepository();
		}
		
		@Bean
		public AlarmMonitorSEI alarmMonitorSEI() {
			return new FakeAlarmMonitorSEI();
		}
		
		@Bean
		public InternalAlarmTrigger internalAlarmTrigger(InternalAlarmListener listener) {
			InternalAlarmTrigger trigger = new InternalAlarmTrigger();
			trigger.setListeners(Collections.singletonList(listener));
			return trigger;
		}
		
		@Bean
		public AlarmComponentMapper mapper() {
			return new FakeMapper();
		}
		
		@Bean
		public PreferenceService preferenceService() {
		    return new FakePreferenceServiceImpl();
		}
		
		@Bean
		public InternalAlarmListener listener() {
			return new ListenerImpl();
		}

        @Bean
        public PlatformTransactionManager transactionManager() {
            return new FakePlatformTransactionManager();
        }
	}
	
	private static class FakeDelayedEntityManagerFactory implements DelayedEntityManagerFactory{

		@Override
		public EntityManager createEntityManager() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public EntityManager createEntityManager(Map map) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public EntityManager createEntityManager(
				SynchronizationType synchronizationType) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public EntityManager createEntityManager(
				SynchronizationType synchronizationType, Map map) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public CriteriaBuilder getCriteriaBuilder() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Metamodel getMetamodel() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean isOpen() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void close() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Map<String, Object> getProperties() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Cache getCache() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public PersistenceUnitUtil getPersistenceUnitUtil() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void addNamedQuery(String name, Query query) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public <T> T unwrap(Class<T> cls) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public <T> void addNamedEntityGraph(String graphName,
				EntityGraph<T> entityGraph) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean isAvailable() {
			// TODO Auto-generated method stub
			return true;
		}

		@Override
		public void sendCommand(String command, Object... args) {
			// TODO Auto-generated method stub
			
		}
		
	}

	private static class FakePlatformTransactionManager implements PlatformTransactionManager {
		@Override
		public TransactionStatus getTransaction(TransactionDefinition definition) throws TransactionException {
			return null;
		}

		@Override
		public void commit(TransactionStatus status) throws TransactionException {

		}

		@Override
		public void rollback(TransactionStatus status) throws TransactionException {

		}
	}
	
	private static class FakeAlarmMonitorSEI implements AlarmMonitorSEI {
		
		List<NsnAlarm> nsnAlarms = new ArrayList<>();
		
		Long fakeActiveAlarmCount;
		
		@Override
		public void getActiveAlarms(Integer maxAlarms,
				XMLGregorianCalendar updateTimestamp,
				List<Filter> filters, UserInfo userInfo)
				throws GetActiveAlarmsFault {
			
		}
		
		@Override
		public List<NsnAlarm> getNext(Integer howMany) throws IterationFault {
			if (nsnAlarms == null || nsnAlarms.isEmpty()) {
				return Collections.emptyList();
			}
			howMany = Math.min(howMany, nsnAlarms.size());
			List<NsnAlarm> returnedList = nsnAlarms.subList(0, howMany);
			nsnAlarms = nsnAlarms.subList(howMany, nsnAlarms.size());
			return returnedList;
		}

		@Override
		public void getAllAlarms(Integer maxAlarms,
				XMLGregorianCalendar updateTimestamp,
				List<Filter> filters, UserInfo userInfo)
				throws GetAllAlarmsFault {
			throw new UnsupportedOperationException();
		}

		@Override
		public AlarmCounts getActiveAlarmCounts(List<Filter> filters, UserInfo userInfo) throws GetAlarmsCountsFault {
			AlarmCounts counts = new AlarmCounts();
			counts.setMajorCount(
					this.fakeActiveAlarmCount != null ?
					this.fakeActiveAlarmCount.longValue() :
					(long)this.nsnAlarms.size()
			);
			return counts;
		}

		@Override
		public AlarmCounts getAllAlarmCounts(List<Filter> filters, UserInfo userInfo) throws GetAlarmsCountsFault {
			throw new UnsupportedOperationException();
		}

		@Override
		public void getAlarmsByTemplate(NsnAlarm alarmTemplate,
				List<Filter> filters, Integer maxAlarms,
				UserInfo userInfo) throws GetAlarmsByTemplateFault {
			throw new UnsupportedOperationException();
		}

		@Override
		public void getAlarmsByKeys(List<NsnAlarmKey> alarmKeyList)
				throws GetAlarmsByKeysFault {
			throw new UnsupportedOperationException();
		}

		@Override
		public Return getAlarmDescriptionByKeys(List<NsnAlarmKey> alarmKey,
				String localeInfo) throws GetAlarmDescriptionByKeysFault {
			return null;
		}
	}

	private static class FakeMapper implements AlarmComponentMapper {

		@Override
		public Component mapComponent(Alarmable alarm) {
			return null;
		}
	}
	
	private static class FakePreferenceServiceImpl implements PreferenceService {

	    Map<String, String> map = new HashMap<>();
	    
        @Override
        public String getVariable(String variableName) {
            return this.map.get(variableName);
        }

        @Override
        public void setVariable(String variableName, String variableValue) {
            this.map.put(variableName, variableValue);
        }

        @Override
        public void start() throws Exception {
            throw new UnsupportedOperationException();
        }

        @Override
        public void stop() throws Exception {
            throw new UnsupportedOperationException();
        }

		@Override
		public void setVariableWithoutLock(String name, String value) {

		}

		@Override
        public State getState() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean isTrue(String variable) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Collection<String> getMultiVariable(String variableName) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setMultiVariable(String variableName, Collection<String> variableValues) {
            throw new UnsupportedOperationException();
        }
	}
	
	private static class ListenerImpl implements InternalAlarmListener {

		private StringBuilder builder = new StringBuilder();
		
		public String getStringAndClear() {
			String retval = this.builder.toString();
			this.builder = new StringBuilder();
			return retval;
		}

		@Override
		public void alarmsRemoved(Collection<InternalAlarm> alarms) {
			if (!alarms.isEmpty()) {
				builder.append("delete(");
				appendIdToBuilder(alarms);
				builder.append(");");
			}
		}

		@Override
		public void alarmsChanged(Collection<InternalAlarm> alarms) {
			if (!alarms.isEmpty()) {
				builder.append("change(");
				appendIdToBuilder(alarms);
				builder.append(");");
			}
		}

		@Override
		public void alarmsAdded(Collection<InternalAlarm> alarms) {
			if (!alarms.isEmpty()) {
				builder.append("insert(");
				appendIdToBuilder(alarms);
				builder.append(");");
			}
		}

		private void appendIdToBuilder(Collection<InternalAlarm> alarms) {
			boolean addComma = false;
			for (InternalAlarm alarm : alarms) {
				if (addComma) {
					builder.append(", ");
				} else {
					addComma = true;
				}
				builder.append(alarm.getId());
			}
		}
	}
}
