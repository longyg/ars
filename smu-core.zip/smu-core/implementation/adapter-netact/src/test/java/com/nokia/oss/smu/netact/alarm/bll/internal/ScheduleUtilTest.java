package com.nokia.oss.smu.netact.alarm.bll.internal;

import org.junit.Before;
import org.junit.Test;
import sun.reflect.generics.repository.GenericDeclRepository;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import static org.junit.Assert.*;

public class ScheduleUtilTest {

    private GregorianCalendar calendar = new GregorianCalendar(2017, 03, 06, 23, 44); //2017-04-07 23:44:00

    @Test
    public void testGetAlignedMillis() throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        GregorianCalendar aligned = (GregorianCalendar)calendar.clone();
        aligned.set(Calendar.HOUR_OF_DAY, 23);
        aligned.set(Calendar.MINUTE, 30);
        assertEquals(ScheduleUtil.getAlignedMills(calendar.getTimeInMillis(), 1800000L), aligned.getTimeInMillis());

        assertAlignEquals(1, 23);
        assertAlignEquals(3, 21);
        assertAlignEquals(6, 18);
        assertAlignEquals(12, 12);
    }

    @Test
    public void testTimeZoneChanged() {
        GregorianCalendar timeInDifferentZone = (GregorianCalendar)calendar.clone();
        timeInDifferentZone.setTimeZone(TimeZone.getTimeZone("GMT +6:00"));
        GregorianCalendar aligned = (GregorianCalendar)calendar.clone();
        aligned.set(Calendar.HOUR_OF_DAY, 23);
        aligned.set(Calendar.MINUTE, 30);
        assertEquals(ScheduleUtil.getAlignedMills(calendar.getTimeInMillis(), 1800000L), aligned.getTimeInMillis());
    }

    private void assertAlignEquals(int interval, int alignedHour) {
        GregorianCalendar aligned = (GregorianCalendar)calendar.clone();
        aligned.set(Calendar.HOUR_OF_DAY, alignedHour);
        aligned.set(Calendar.MINUTE, 0);
        assertEquals(ScheduleUtil.getAlignedMills(calendar.getTimeInMillis(), interval *3600000L), aligned.getTimeInMillis());
    }
}