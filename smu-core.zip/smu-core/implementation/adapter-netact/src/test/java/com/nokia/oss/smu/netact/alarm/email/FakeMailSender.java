package com.nokia.oss.smu.netact.alarm.email;

import com.nokia.oss.smu.mail.MailSender;

import java.util.ArrayList;
import java.util.List;

class FakeMailSender implements MailSender {
    public List<String> sentSubjects = new ArrayList<>();
    public List<String> sentHTMLs = new ArrayList<>();

    @Override
    public String toString() {
        return this.sentHTMLs.toString();
    }

    public void reset() {
        this.sentHTMLs.clear();
    }

    @Override
    public void sendHTML(String recipient, String subject, String html) {
        sentSubjects.add(subject);
        sentHTMLs.add(html);
    }
}
