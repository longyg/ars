package com.nokia.oss.smu.netact.alarm.dal.internal;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.dbunit.dataset.datatype.IDataTypeFactory;
import org.dbunit.ext.hsqldb.HsqldbDataTypeFactory;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Transactional;

import com.github.springtestdbunit.annotation.DatabaseSetup;
import com.github.springtestdbunit.annotation.DbUnitConfiguration;
import com.github.springtestdbunit.annotation.ExpectedDatabase;
import com.github.springtestdbunit.assertion.DatabaseAssertionMode;
import com.github.springtestdbunit.bean.DatabaseConfigBean;
import com.github.springtestdbunit.bean.DatabaseDataSourceConnectionFactoryBean;
import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm.AckState;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm_;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import com.nokia.oss.smu.netact.alarm.entities.model.Order;

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({ 
	DependencyInjectionTestExecutionListener.class,
	TransactionalTestExecutionListener.class,
	DelayedDbUnitTestExecutionListener.class
})
@ContextConfiguration(classes = InternalAlarmRepositoryImplTest.SpringConfiguration.class)
@DbUnitConfiguration(databaseConnection = "dbUnitConnection")
public class InternalAlarmRepositoryImplTest {
	
	@Resource
	private InternalAlarmRepository internalAlarmRepository;
	
	@Resource
	private DelayedEntityManagerFactory emf;
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectAllByOneOrder() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.desc(InternalAlarm_.alarmTime)));
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 7, number: 10007, alarmTime: 2015-09-10 23:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-333, title: This is an error }, "
				+   "{ id: 1, number: 10001, alarmTime: 2015-09-10 17:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-123, title: This is an error }, "
				+   "{ id: 2, number: 10002, alarmTime: 2015-09-10 13:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-456, title: This is an error }, "
				+   "{ id: 8, number: 10008, alarmTime: 2015-09-10 11:00:00, severity: WARNING, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-666, title: This is an error }, "
				+   "{ id: 3, number: 10003, alarmTime: 2015-09-10 07:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-789, title: This is an error }, "
				+   "{ id: 5, number: 10005, alarmTime: 2015-09-10 05:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-654, title: This is an error }, "
				+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error }, "
				+   "{ id: 6, number: 10006, alarmTime: 2015-09-10 00:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-987, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectAllByTwoOrders() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(
				Arrays.asList(
						Order.desc(InternalAlarm_.severity),
						Order.desc(InternalAlarm_.alarmTime)
				)
		);
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 1, number: 10001, alarmTime: 2015-09-10 17:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-123, title: This is an error }, "
				+   "{ id: 5, number: 10005, alarmTime: 2015-09-10 05:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-654, title: This is an error }, "
				+   "{ id: 2, number: 10002, alarmTime: 2015-09-10 13:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-456, title: This is an error }, "
				+   "{ id: 6, number: 10006, alarmTime: 2015-09-10 00:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-987, title: This is an error }, "
				+   "{ id: 7, number: 10007, alarmTime: 2015-09-10 23:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-333, title: This is an error }, "
				+   "{ id: 3, number: 10003, alarmTime: 2015-09-10 07:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-789, title: This is an error }, "
				+   "{ id: 8, number: 10008, alarmTime: 2015-09-10 11:00:00, severity: WARNING, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-666, title: This is an error }, "
				+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectMajorAlarms() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		spec.setSeverities(Arrays.asList(AlarmSeverity.MAJOR));
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 6, number: 10006, alarmTime: 2015-09-10 00:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-987, title: This is an error }, "
				+   "{ id: 2, number: 10002, alarmTime: 2015-09-10 13:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-456, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectNonMajorAlarms() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		spec.setSeverities(Arrays.asList(AlarmSeverity.WARNING, AlarmSeverity.MINOR, AlarmSeverity.CRITICAL, AlarmSeverity.INDETERMINATE));
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error }, "
				+   "{ id: 5, number: 10005, alarmTime: 2015-09-10 05:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-654, title: This is an error }, "
				+   "{ id: 3, number: 10003, alarmTime: 2015-09-10 07:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-789, title: This is an error }, "
				+   "{ id: 8, number: 10008, alarmTime: 2015-09-10 11:00:00, severity: WARNING, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-666, title: This is an error }, "
				+   "{ id: 1, number: 10001, alarmTime: 2015-09-10 17:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-123, title: This is an error }, "
				+   "{ id: 7, number: 10007, alarmTime: 2015-09-10 23:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-333, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectPlatformAlarms() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		spec.setMappedComponentIds(Collections.singleton("Platform"));
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 8, number: 10008, alarmTime: 2015-09-10 11:00:00, severity: WARNING, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-666, title: This is an error }, "
				+   "{ id: 7, number: 10007, alarmTime: 2015-09-10 23:00:00, severity: MINOR, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-333, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectAckedAlarms() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		spec.setAckState(AckState.ACKED);
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 6, number: 10006, alarmTime: 2015-09-10 00:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-987, title: This is an error }, "
				+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error }, "
				+   "{ id: 2, number: 10002, alarmTime: 2015-09-10 13:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-456, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testSelectAlarmsByBothServityAndAckState() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		spec.setSeverities(Arrays.asList(AlarmSeverity.WARNING, AlarmSeverity.CRITICAL));
		spec.setAckState(AckState.ACKED);
		LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(
				spec, 
				100
		);
		Assert.assertFalse(limitedResult.isOverflow());
		Assert.assertEquals(
				"[ "
				+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error } "
				+ "]", 
				toString(limitedResult.getEntities())
		);
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	public void testOverflowQuery() {
		InternalAlarmSpecification spec = new InternalAlarmSpecification();
		spec.setOrders(Arrays.asList(Order.asc(InternalAlarm_.alarmTime)));
		
		{
			LimitedResult<InternalAlarm> limitedResult = this.internalAlarmRepository.getInternalAlarms(spec, 3);
			Assert.assertTrue(limitedResult.isOverflow());
			Assert.assertEquals(
					"[ "
					+   "{ id: 6, number: 10006, alarmTime: 2015-09-10 00:00:00, severity: MAJOR, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-987, title: This is an error }, "
					+   "{ id: 4, number: 10004, alarmTime: 2015-09-10 04:00:00, severity: WARNING, ackState: ACKED, distinguishName: PLMN-PLMN/BSC-321, title: This is an error }, "
					+   "{ id: 5, number: 10005, alarmTime: 2015-09-10 05:00:00, severity: CRITICAL, ackState: UNACKED, distinguishName: PLMN-PLMN/BSC-654, title: This is an error } "
					+ "]", 
					toString(limitedResult.getEntities())
			);
		}
	}
	
	@Test
	@DatabaseSetup("initialized-dataset.xml")
	@ExpectedDatabase(
			value = "deleted-dataset.xml", 
			table = "SMU_INTERNAL_ALARM",
			assertionMode = DatabaseAssertionMode.NON_STRICT
	)
	@Transactional
	public void testBatchDelete() {
		this.internalAlarmRepository.deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState.REFRESHED);
	}
	
	private static String toString(Collection<InternalAlarm> internalAlarms) {
		if (internalAlarms.isEmpty()) {
			return "[]";
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		StringBuilder builder = new StringBuilder();
		builder.append("[ ");
		boolean addComma = false;
		for (InternalAlarm internalAlarm : internalAlarms) {
			if (addComma) {
				builder.append(", ");
			} else {
				addComma = true;
			}
			builder
			.append("{ id: ").append(internalAlarm.getId())
			.append(", number: ").append(internalAlarm.getNumber())
			.append(", alarmTime: ").append(dateFormat.format(internalAlarm.getAlarmTime().getTime()))
			.append(", severity: ").append(internalAlarm.getSeverity())
			.append(", ackState: ").append(internalAlarm.getAckState())
			.append(", distinguishName: ").append(internalAlarm.getDistinguishName())
			.append(", title: ").append(internalAlarm.getTitle())
			.append(" }");
		}
		builder.append(" ]");
		return builder.toString();
	}
	
	@Configuration
	@ImportResource("classpath:plugin-data.spring.xml")
	public static class SpringConfiguration {
		
		@Bean
		public InternalAlarmRepository internalAlarmRepository() {
			return new InternalAlarmRepositoryImpl();
		}
		
		@Bean
		public Properties jpaProperties() {
			Properties properties = new Properties();
			properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
			properties.put("hibernate.hbm2ddl.auto", "create-drop");
			return properties;
		}
		
		@Bean
		public DataSource dataSource() {
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
			dataSource.setUrl("jdbc:hsqldb:mem:internal_alarm_repository_test");
			dataSource.setUsername("sa");
			return dataSource;
		}
		
		@Bean(name = "dbUnitConnection")
		public DatabaseDataSourceConnectionFactoryBean databaseDataSourceConnectionFactoryBean(DataSource dataSource, IDataTypeFactory dataTypeFactory) {
			DatabaseDataSourceConnectionFactoryBean factoryBean = new DatabaseDataSourceConnectionFactoryBean();
			factoryBean.setDataSource(dataSource);
			DatabaseConfigBean databaseConfig = new DatabaseConfigBean();
			databaseConfig.setDatatypeFactory(dataTypeFactory);
			factoryBean.setDatabaseConfig(databaseConfig);
			return factoryBean;
		}
		
		@Bean
		public IDataTypeFactory dataTypeFactory() {
			return new HsqldbDataTypeFactory();
		}
	}
}
