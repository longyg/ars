package com.nokia.oss.smu.netact.alarm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarmSynchronizingState;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;

public class FakeInternalAlarmRepository implements InternalAlarmRepository {

    List<InternalAlarm> internalAlarms = new ArrayList<InternalAlarm>();

    @Override
    public LimitedResult<InternalAlarm> getInternalAlarms(
            InternalAlarmSpecification specification, int maxRows) {
        List<InternalAlarm> list = new ArrayList<>(this.internalAlarms.size());
        for (InternalAlarm alarm : this.internalAlarms) {
            if (specification.getSeverities() == null || 
                    specification.getSeverities().contains(alarm.getSeverity())) {
                list.add(alarm);
            }
        }
        return new LimitedResult<>(list.size() < maxRows, list);
    }

    @Override
    public long countAlarms(InternalAlarmSpecification specification) {
        return internalAlarms.size();
    }

    @Override
    public Map<String, InternalAlarmSummary> getSummaryMap() {
        return null;
    }

    @Override
    public void flushAndClear() {

    }

    @Override
	public Map<Long, InternalAlarm> getInternalAlarmByIds(Iterable<Long> ids) {
		Set<Long> idSet;
		if (ids instanceof Set<?>) {
			idSet = (Set<Long>)ids;
		} else {
			idSet = new LinkedHashSet<>();
			for (Long id : ids) {
				idSet.add(id);
			}
		}
		Map<Long, InternalAlarm> map = new LinkedHashMap<>();
    	for (InternalAlarm alarm : this.internalAlarms) {
			if (idSet.contains(alarm.getId())) {
				map.put(alarm.getId(), alarm);
			}
		}
    	return map;
	}

	@Override
	public List<InternalAlarm> getSynchronizingInternalAlarmsByOrderById(
			InternalAlarmSynchronizingState synchronizingState, long minExclusiveId, int limit) {
		List<InternalAlarm> list = new ArrayList<>();
		for (InternalAlarm alarm : this.internalAlarms) {
			if (alarm.getSynchronizingState() == synchronizingState && alarm.getId() > minExclusiveId) {
				list.add(alarm);
				if (list.size() == limit) {
					break;
				}
			}
		}
		return list;
	}

	@Override
	public void persistInternalAlarm(InternalAlarm internalAlarm) {
	    this.internalAlarms.add(internalAlarm);
	}

	@Override
	public void mergeInternalAlarm(InternalAlarm alarm) {
		List<InternalAlarm> list = this.internalAlarms;
		for (int i = list.size() - 1; i >= 0; --i) {
			if (list.get(i).getId() == alarm.getId()) {
				list.set(i, alarm);
				return;
			}
		}
		throw new IllegalArgumentException("No alarm whose id is " + alarm.getId());
	}

	@Override
	public void changeSynchronizingState(InternalAlarmSynchronizingState synchronizingState) {
		for (InternalAlarm alarm : this.internalAlarms) {
			alarm.setSynchronizingState(synchronizingState);
		}
	}

	@Override
	public void deleteInternalAlarmsBySynchronizingState(InternalAlarmSynchronizingState synchronizingState) {
		Iterator<InternalAlarm> itr = this.internalAlarms.iterator();
		while (itr.hasNext()) {
			if (itr.next().getSynchronizingState() == synchronizingState) {
				itr.remove();
			}
		}
	}

	@Override
    public long countUnmappedAlarms() {
        //TODO.
        return 0;
    }

    public void reset() {
        internalAlarms.clear();
    }
}
