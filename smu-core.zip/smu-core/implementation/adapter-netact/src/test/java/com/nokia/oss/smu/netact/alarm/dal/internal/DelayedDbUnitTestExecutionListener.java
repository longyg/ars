package com.nokia.oss.smu.netact.alarm.dal.internal;

import javax.persistence.EntityManager;

import org.springframework.test.context.TestContext;

import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;

public class DelayedDbUnitTestExecutionListener extends DbUnitTestExecutionListener {

	@Override
	public void prepareTestInstance(TestContext testContext) throws Exception {
		DelayedEntityManagerFactory delayedEMF = testContext.getApplicationContext().getBean(DelayedEntityManagerFactory.class);
		delayedEMF.sendCommand("contextReady");
		EntityManager em = delayedEMF.createEntityManager();
		try {
			// Do nothing, just let Hibernate initialize database immediately before DbUnit test data prepare.
		} finally {
			em.close();
		}
		super.prepareTestInstance(testContext);
	}
}
