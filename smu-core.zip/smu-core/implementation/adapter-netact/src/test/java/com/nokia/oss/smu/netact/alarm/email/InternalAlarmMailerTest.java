/*
 * After code review, this file will be deleted
 * and another file "AlarmMailTaskManagerImplTest.java"
 * will be renamed to be this name
 */