package com.nokia.oss.smu.netact.alarm.email;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.Alarmable;
import com.nokia.oss.smu.alarm.mail.AlarmMailContentGenerator;
import com.nokia.oss.smu.core.lifecycle.State;
import com.nokia.oss.smu.mail.MailSender;
import com.nokia.oss.smu.netact.alarm.FakeInternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.bll.internal.AlarmMailTaskManager;
import com.nokia.oss.smu.netact.alarm.dal.AlarmMailTaskRepository;
import com.nokia.oss.smu.netact.alarm.dal.InternalAlarmRepository;
import com.nokia.oss.smu.netact.alarm.entities.AlarmMailTask;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.settings.PreferenceChangeEvent;
import com.nokia.oss.smu.settings.PreferenceService;
import com.nokia.oss.smu.settings.PreferenceUpgradeMigrator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AlarmMailTaskManagerTest.SpringConfiguration.class)
public class AlarmMailTaskManagerTest {
    private static final AtomicLong ALARM_ID_SEQUENCE = new AtomicLong();
    @Autowired
    ApplicationContext context;
    @Resource
    private AlarmMailTaskManager alarmMailTaskManager;

    @Resource
    private FakeAlarmMailTaskRepository fakeAlarmMailTaskRepository;

    @Resource
    private FakeInternalAlarmRepository fakeInternalAlarmRepository;

    @Resource
    private FakeMailSender fakeMailSender;

    @Resource
    private FakePreferenceService fakePreferenceService;

    @Before
    public void setUp() {
        this.fakePreferenceService.reset();
        this.fakeAlarmMailTaskRepository.reset();
        this.fakeMailSender.reset();
        this.fakeInternalAlarmRepository.reset();
    }

    @Test
    public void when_MailTaskShouldBeCreated() {
        this.fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");
        this.alarmMailTaskManager.alarmsAdded(createAlarms(AlarmSeverity.CRITICAL, "Critical Alarm"));
        AlarmMailTask mailTask = fakeAlarmMailTaskRepository.getTaskMap().values().iterator().next();
        assertEquals(AlarmSeverity.CRITICAL, mailTask.getAlarm().getSeverity());
    }

    @Test
    public void mailShouldNotBeSentExecutedWhenReceivedMajorAlarm() throws InterruptedException {
        this.alarmMailTaskManager.alarmsAdded(this.createAlarms(AlarmSeverity.MAJOR, "Major Alarm"));

        Thread.sleep(2);
        this.alarmMailTaskManager.executeTasks();

        assertEquals("[]", this.fakeMailSender.toString());
    }

    @Test
    public void alarmsShouldBeConsolidated_IfReceivedInShortTime() throws InterruptedException {
        this.fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED, "true");
        this.fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");
        this.alarmMailTaskManager.alarmsAdded(this.createAlarms(AlarmSeverity.MAJOR, "First Alarm"));
        this.alarmMailTaskManager.alarmsAdded(this.createAlarms(AlarmSeverity.CRITICAL, "Second Alarm"));

        setLastReminderSentTimeAsTomorrow();
        this.fakePreferenceService.setReminderSendingInterval(60000);

        fakePreferenceService.setMultiVariable(PreferenceService.TARGET_ADDRESSES, Collections.singleton
                ("me@localhost"));

        this.alarmMailTaskManager.executeTasks();
        this.alarmMailTaskManager.executeTasks();
        assertEquals(0, this.fakeAlarmMailTaskRepository.getTaskMap().size());
        assertEquals("[{ FakeContent: First Alarm }{ FakeContent: Second Alarm }]", this.fakeMailSender.toString());
    }

    @Test
    public void lastSentTimeOfNewTaskShouldBeNull() {
        this.fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");
        this.alarmMailTaskManager.alarmsAdded(this.createAlarms(AlarmSeverity.CRITICAL, "Critical Alarm"));

        AlarmMailTask task = fakeAlarmMailTaskRepository.getTaskMap().firstEntry().getValue();
        Assert.assertNull(task.getLastSentTime());
    }

    @Test
    public void reminderMailShouldBeSent_IfTimeScheduleIsExceeded() throws InterruptedException {
        setLastReminderSentTimeAsSixHoursAgo();
        //set interval as 3 hour. When it's aligned, it should be bigger than the last sent time.
        fakePreferenceService.setReminderSendingInterval(3L * 3600L * 1000L);
        fakeInternalAlarmRepository.persistInternalAlarm(createAlarm(AlarmSeverity.CRITICAL, "Critical Alarm"));
        fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");

        fakePreferenceService.setMultiVariable(PreferenceService.TARGET_ADDRESSES, Collections.singleton
                ("me@localhost"));
        this.alarmMailTaskManager.executeTasks();
        assertEquals("[{ FakeContent: Critical Alarm }]", this.fakeMailSender.toString());
        assertEquals(0, this.fakeAlarmMailTaskRepository.getTaskMap().size());
        this.alarmMailTaskManager.executeTasks();
        assertEquals("[{ FakeContent: Critical Alarm }]", this.fakeMailSender.toString());
    }

    @Test
    public void mailShouldBeSent_whenChangeEventsArrive() throws InterruptedException {
        this.fakePreferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, "true");
        final List<InternalAlarm> alarms = this.createAlarms(AlarmSeverity.CRITICAL, "changed to critical");
        this.alarmMailTaskManager.alarmsChanged(alarms);
        fakeInternalAlarmRepository.persistInternalAlarm(alarms.get(0));

        setLastReminderSentTimeAsTomorrow();
        this.fakePreferenceService.setReminderSendingInterval(60000);
        fakePreferenceService.setMultiVariable(PreferenceService.TARGET_ADDRESSES, Collections.singleton
                ("me@localhost"));
        this.alarmMailTaskManager.executeTasks();
        assertEquals("[{ FakeContent: changed to critical }]", this.fakeMailSender.toString());
        assertTrue(this.fakeMailSender.sentSubjects.contains("1 internal alarm(s) severity changed"));

        setLastReminderSentTimeAsSixHoursAgo();

        this.fakeMailSender.reset();
        this.fakePreferenceService.setReminderSendingInterval(0);
        this.alarmMailTaskManager.executeTasks();
        assertTrue(this.fakeMailSender.sentSubjects.contains("1 critical internal alarm(s) still active"));
        assertTrue(this.fakeMailSender.sentHTMLs.contains("{ FakeContent: changed to critical }"));

        this.fakeAlarmMailTaskRepository.reset();
        this.fakeMailSender.reset();
        this.alarmMailTaskManager.alarmsChanged(this.createAlarms(AlarmSeverity.CRITICAL, "alarm1"));
        this.alarmMailTaskManager.alarmsChanged(this.createAlarms(AlarmSeverity.CRITICAL, "alarm2"));

        this.alarmMailTaskManager.executeTasks();
        assertTrue(this.fakeMailSender.sentSubjects.contains("2 internal alarm(s) severity changed"));
        assertTrue(this.fakeMailSender.sentHTMLs.contains("{ FakeContent: alarm1 }{ FakeContent: alarm2 }"));
    }

    @Test
    public void mailShouldNotBeSent_IfTimeNotExceedInterval() {
        setLastReminderSentTimeAsTomorrow();
        fakePreferenceService.setReminderSendingInterval(1000);
        fakeInternalAlarmRepository.persistInternalAlarm(createAlarm(AlarmSeverity.CRITICAL, "Critical Alarm"));
        alarmMailTaskManager.executeTasks();

        assertEquals(0, fakeMailSender.sentHTMLs.size());
    }

    private void setLastReminderSentTimeAsTomorrow() {
        fakePreferenceService.setVariableWithoutLock(AlarmMailTaskManager.VARIABLE_LAST_REMINDER_MAIL_SENT_TIME,
                Long.toString(System.currentTimeMillis() + 24L * 3600L * 1000L));
    }

    private void setLastReminderSentTimeAsSixHoursAgo() {
        fakePreferenceService.setVariableWithoutLock(AlarmMailTaskManager.VARIABLE_LAST_REMINDER_MAIL_SENT_TIME,
                Long.toString(System.currentTimeMillis() - 6L * 3600L * 1000L));
    }

    @Test
    public void alarmTaskShouldNotBeCleaned_WhenOtherSeverityUnchecked() {
        String criticalPref = PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED;
        String majorPref = PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED;
        fakePreferenceService.setVariable(criticalPref, "true");
        fakePreferenceService.setVariable(majorPref, "true");

        alarmMailTaskManager.alarmsAdded(createAlarms(AlarmSeverity.CRITICAL));

        alarmMailTaskManager.onApplicationEvent(new PreferenceChangeEvent(context, majorPref, "false"));

        assertEquals(1, this.fakeAlarmMailTaskRepository.getTaskMap().size());
    }

    @Test
    public void alarmTaskShouldNotBeCreated_WhenCriticalAlarmDisabled() {
        String prefName = PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED;
        fakePreferenceService.setVariable(prefName, "false");

        InternalAlarm alarm = createAlarm(AlarmSeverity.CRITICAL, "Critical Alarm");
        fakeInternalAlarmRepository.persistInternalAlarm(alarm);

        alarmMailTaskManager.alarmsAdded(Collections.singletonList(alarm));

        assertEquals(0, this.fakeAlarmMailTaskRepository.getTaskMap().size());
    }

    @Test
    public void ExistingTasksShouldBeRemoved_WhenMailTriggerDisabled() {
        String majorEnabled = PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED;
        String criticalEnabled = PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED;
        fakePreferenceService.setVariable(majorEnabled, "true");
        fakePreferenceService.setVariable(criticalEnabled, "true");

        InternalAlarm alarm = createAlarm(AlarmSeverity.CRITICAL, "Critical Alarm");
        fakeInternalAlarmRepository.persistInternalAlarm(alarm);
        InternalAlarm alarmMajor = createAlarm(AlarmSeverity.MAJOR, "Major Alarm");

        alarmMailTaskManager.alarmsAdded(Arrays.asList(alarm, alarmMajor));
        assertEquals(2, this.fakeAlarmMailTaskRepository.getTaskMap().size());

        fakePreferenceService.setVariable(criticalEnabled, "false");
        fakePreferenceService.setVariable(majorEnabled, "false");
        alarmMailTaskManager.onApplicationEvent(new PreferenceChangeEvent(context, criticalEnabled, "false"));
        alarmMailTaskManager.onApplicationEvent(new PreferenceChangeEvent(context, majorEnabled, "false"));

        assertEquals(0, this.fakeAlarmMailTaskRepository.getTaskMap().size());
    }

    @Test
    public void NoNewTasksShouldBeCreated_WhenMailTriggerEnabled() {
        String criticalEnabled = PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED;
        fakePreferenceService.setVariable(criticalEnabled, "false");

        InternalAlarm alarm = createAlarm(AlarmSeverity.CRITICAL, "Critical Alarm");
        alarmMailTaskManager.alarmsAdded(Collections.singletonList(alarm));
        fakeInternalAlarmRepository.persistInternalAlarm(alarm);

        fakePreferenceService.setVariable(criticalEnabled, "true");
        alarmMailTaskManager.onApplicationEvent(new PreferenceChangeEvent(context, criticalEnabled, "true"));

        assertEquals(0, this.fakeAlarmMailTaskRepository.getTaskMap().size());
    }

    private List<InternalAlarm> createAlarms(AlarmSeverity... severities) {
        List<InternalAlarm> alarms = new ArrayList<>(severities.length);
        for (AlarmSeverity severity : severities) {
            InternalAlarm alarm = new InternalAlarm();
            int number = 123456;
            alarm.setId(ALARM_ID_SEQUENCE.incrementAndGet());
            alarm.setNumber(number);
            alarm.setTitle("Fake internal alarm");
            alarm.setSeverity(severity);
            alarms.add(alarm);
        }

        return alarms;
    }

    private List<InternalAlarm> createAlarms(AlarmSeverity severity, String title) {
        return Collections.singletonList(createAlarm(severity, title));
    }

    private InternalAlarm createAlarm(AlarmSeverity severity, String title) {
        InternalAlarm alarm = new InternalAlarm();
        int number = 123456;
        alarm.setId(ALARM_ID_SEQUENCE.incrementAndGet());
        alarm.setNumber(number);
        alarm.setTitle(title);
        alarm.setSeverity(severity);
        return alarm;
    }

    @Configuration
    public static class SpringConfiguration {

        @Bean
        PreferenceUpgradeMigrator preferenceUpgradeMigrator() {
            return new FakePreferenceUpgradeMigrator();
        }

        @Bean
        public AlarmMailTaskManager alarmMailTaskManager() {
            return new AlarmMailTaskManager();
        }

        @Bean
        public FakeAlarmMailTaskRepository alarmMailTaskRepository() {
            return new FakeAlarmMailTaskRepository();
        }

        @Bean
        public InternalAlarmRepository internalAlarmRepository() {
            return new FakeInternalAlarmRepository();
        }

        @Bean
        public MailSender mailSender() {
            return new FakeMailSender();
        }

        @Bean
        public AlarmMailContentGenerator alarmMailContentGenerator() {
            return new FakeAlarmMailContentGenerator();
        }

        @Bean
        public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() {
            Properties properties = new Properties();
            properties.put("internal.alarm.mail.delay.default", "0");
            properties.put("internal.alarm.mail.resend.interval.default", "0");
            properties.put("internal.alarm.mail.max.default", "2");
            PropertyPlaceholderConfigurer configurer = new PropertyPlaceholderConfigurer();
            configurer.setProperties(properties);
            return configurer;
        }

        @Bean
        public PreferenceService preferenceService() {
            return new FakePreferenceService();
        }

        @Bean
        FakeExecutorService executorService() {
            return new FakeExecutorService();
        }
    }

    private static class FakePreferenceUpgradeMigrator implements PreferenceUpgradeMigrator {
        @Override
        public void migrateAlarmMailTriggers() {

        }
    }

    private static class FakeAlarmMailTaskRepository implements AlarmMailTaskRepository {

        private AtomicLong idSequence = new AtomicLong();

        private NavigableMap<Long, AlarmMailTask> tasks = new TreeMap<>();

        @Override
        public List<AlarmMailTask> getNewTasks() {
            List<AlarmMailTask> result = new ArrayList<>(this.tasks.size());
            for (AlarmMailTask task : this.tasks.values()) {
                if (task.getLastSentTime() == null) {
                    result.add(task);
                }
            }
            return result;
        }

        @Override
        public void persistTask(AlarmMailTask task) {
            if (task.getId() == null) {
                task.setId(this.idSequence.incrementAndGet());
            }
            this.tasks.put(task.getId(), task);
        }

        @Override
        public void deleteTasks(Iterable<AlarmMailTask> tasks) {
            for (AlarmMailTask task : tasks) {
                this.tasks.remove(task.getId());
            }
        }

        @Override
        public void deleteTasksByAlarms(Iterable<InternalAlarm> alarms) {
            Iterator<AlarmMailTask> itr = this.tasks.values().iterator();
            while (itr.hasNext()) {
                long alarmId = itr.next().getAlarm().getId();
                for (InternalAlarm alarm : alarms) {
                    if (alarm.getId() == alarmId) {
                        itr.remove();
                        break;
                    }
                }
            }
        }

        @Override
        public void deleteTasksByAlarmSeverity(AlarmSeverity severity) {
            Iterator<AlarmMailTask> itr = this.tasks.values().iterator();
            while (itr.hasNext()) {
                if (itr.next().getAlarm().getSeverity() == severity) {
                    itr.remove();
                }
            }
        }

        public NavigableMap<Long, AlarmMailTask> getTaskMap() {
            return this.tasks;
        }

        public void reset() {
            this.idSequence = new AtomicLong();
            this.tasks.clear();
        }
    }

    private static class FakeAlarmMailContentGenerator extends AlarmMailContentGenerator {
        @Override
        public String generateContent(int maxCount, List<? extends Alarmable> alarmables) {
            StringBuilder builder = new StringBuilder();
            for (Alarmable alarmable : alarmables) {
                builder.append("{ FakeContent: " + alarmable.getTitle() + " }");
            }
            return builder.toString();
        }
    }

    private static class FakePreferenceService implements PreferenceService {

        private Map<String, String> values = new HashMap<>();
        private HashMap<String, Collection<String>> multipleValues = new HashMap<>();

        @Override
        public void start() throws Exception {
            throw new UnsupportedOperationException();
        }

        @Override
        public void stop() throws Exception {
            throw new UnsupportedOperationException();
        }

        @Override
        public State getState() {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getVariable(String name) {
            return values.get(name);
        }

        @Override
        public boolean isTrue(String variable) {
            return values.get(variable) != null && values.get(variable).equals("true");
        }

        @Override
        public Collection<String> getMultiVariable(String variableName) {
            Collection<String> strings = multipleValues.get(variableName);
            if (strings == null) {
                return Collections.emptyList();
            }

            return strings;
        }

        @Override
        public void setVariable(String name, String value) {
            values.put(name, value);
        }

        @Override
        public void setVariableWithoutLock(String name, String value) {
            setVariable(name, value);
        }

        @Override
        public void setMultiVariable(String variableName, Collection<String> variableValues) {
            multipleValues.put(variableName, variableValues);
        }

        public void setReminderSendingInterval(long interval) {
            this.setVariable(PreferenceService.CRITICAL_RESEND_INTERVAL, Long.toString(interval));
        }

        public void reset() {
            this.values.clear();
            this.values.put(AlarmMailTaskManager.VARIABLE_LAST_NEW_MAIL_SENT_TIME,
                    Long.toString(System.currentTimeMillis()));
            this.values.put(AlarmMailTaskManager.VARIABLE_LAST_REMINDER_MAIL_SENT_TIME,
                    Long.toString(System.currentTimeMillis()));
        }
    }
}
