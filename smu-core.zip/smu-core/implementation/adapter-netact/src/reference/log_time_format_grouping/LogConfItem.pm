############################################
# class LogConfItem {
#    bool acceptLmcPath(String filePath);
#    String[] getFormats();
#};

use strict;
use Text::Glob qw( match_glob glob_to_regex );
use Data::Dumper qw(Dumper);
package LogConfItem;

sub new {
# lmcpath path components nodes timeformat example
    my ($class, $lmcPath, $path, $components, $nodes, $timeFormat, $example) = (@_);
    my $self = {
        lmcPath => $lmcPath,
        path =>  $path,
        components => {},
        nodes => {},
        timeFormats => {}
    };
    if ($components) {
        my @arr = split(",", $components);
        foreach (@arr) {
            ${$self->{components}}{$_} = 1;
        }
    }
    if ($nodes) {
        my @arr = split(",", $nodes);
        foreach (@arr) {
            ${$self->{nodes}}{$_} = 1;
        }
    }
    if ($timeFormat) {
        $self->{timeFormats} = {$timeFormat => $example};
    }
    bless $self, $class;
    return $self;
}

sub hashKeysToString {
    my ($refHash) = (@_);
    my $res = "";
    if ($refHash) {
        foreach (sort keys %$refHash) {
            if (length($res) > 0) {
                $res .= ",";
            }
            $res .= $_;
        }
    }
    return $res;
}

sub toRows {
    my $self = shift;
    my @baseCols; 
    push @baseCols, $self->{path};
    push @baseCols, $self->{lmcPath};
    push @baseCols, join(",", sort keys $self->{components});
    push @baseCols, join(",", sort keys $self->{nodes});

    my $rows = [];
    if (scalar keys %{$self->{timeFormats}} > 0) {
        foreach my $timeFormat (sort keys %{$self->{timeFormats}}) {
            my $row = [@baseCols];
            push @$row, $timeFormat;
            push @$row, ${$self->{timeFormats}}{$timeFormat};
            push @$rows, $row;
        }
    } else {
        my $row = [@baseCols, undef, undef];
        push @$rows, $row;
    }
    return $rows;
}
    
sub acceptLmcPath {
    my ($self, $lmcPath, $timeFormat) = (@_);
    $lmcPath =~ /.*\/logc\/([^\/]*)\/(.*)/;
    my $partPath = $2;
    if (match_glob_pattern($self->{lmcPath}, $partPath)) {
        $self->addTimeFormat($timeFormat, $lmcPath);
        return 1;
    }
    return 0;
}

sub match_glob_pattern {
    my $fmt = shift;
    my $fpath = shift;
    my @words_left = split("\/", $fmt);
    my @words_right = split("\/", $fpath);
    if (trim(\$words_left[0]) ne trim(\$words_right[0])) {
        return 0;
    } 
    if ($words_left[0] ne "onepm_commonlog" and  $words_left[0] ne "onepm_trace" 
            and  $words_left[0] ne "httpserver" and  $words_left[0] ne "deployment")  {
        if ($words_left[1] ne $words_right[1]) {
            return 0;
        } 
    }

    trim(\$fmt);
    trim(\$fpath);
    return Text::Glob::match_glob($fmt, $fpath);
}

sub trim
{
    my $refstr = shift;
    $$refstr =~ s/^\s*\(.*\)\s*$/\1/;
    return $$refstr;
}

sub getFormats {
    my ($self) = @_;
    return [keys %{$self->{timeFormats}}];
}

sub addTimeFormat {
    my ($self, $timeFormat, $path) = @_;
    ${$self->{timeFormats}}{$timeFormat} = $path;
}

sub addNode {
    my ($self, $node) = @_;
    if ($node) {
        my @arr = split(",", $node);
        foreach (@arr) {
            ${$self->{nodes}}{$_} = 1;
        }
    }
}

sub addComponent {
    my ($self, $component) = @_;
    if ($component) {
        my @arr = split(",", $component);
        foreach (@arr) {
            ${$self->{components}}{$_} = 1;
        }
    }
}
1;
