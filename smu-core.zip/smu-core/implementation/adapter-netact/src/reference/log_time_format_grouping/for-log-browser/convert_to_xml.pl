#!/usr/bin/perl
use strict;
use Getopt::Long;
use Data::Dumper qw(Dumper);

my $file;
my $nguess = 0;
my $fpath_file = "patternguess";
main();

sub usage
{
    print "$0 -f <filename>";
    exit;
}

sub parseOptions
{
    GetOptions("file|f=s" => \$file);
    if (!$file){
        usage();
    }
}


sub convert_to_xml
{
    my $file = shift;
    my $fh;
    my %pathMap;
    open ($fh, "<", $file) or die "cannot open file $file";
    while (my $line = <$fh>) {
        chomp ($line);
        my ($fpath, $lmcPath, $comp, $haservice) = split("\t", $line);
        trim(\$fpath);
        trim(\$comp);
        trim(\$haservice);
        remove_file_part(\$fpath);
        add_comp_and_haservice(\%pathMap, $fpath, $comp, $haservice);
    }

#print Dumper \%pathMap;
    for my $fpath (keys %pathMap) {
        my @ss = keys $pathMap{$fpath}{'services'};
        my $comp = join(",", keys $pathMap{$fpath}{'services'});
        my $haservice = join(",", keys $pathMap{$fpath}{'haservice'});
        print "<path name='$fpath' scenario-services='$comp' native-service='$haservice'/>\n";
    }
}

sub add_comp_and_haservice {
    my $refmap = shift;
    my $path = shift;
    my $comp = shift;
    my $haservice = shift;
    $$refmap{$path}{'services'}{$comp} = 1;
    $$refmap{$path}{'haservice'}{$haservice} = 1;
}

sub remove_file_part {
    my $refstr = shift;
    $$refstr =~ s/\/[^\/]*$/\//g;
}

sub trim
{
        my $refstr = shift;
        $$refstr =~ s/^\s+|\s+$//g;
}



sub main
{
    parseOptions();
    convert_to_xml($file);
}


