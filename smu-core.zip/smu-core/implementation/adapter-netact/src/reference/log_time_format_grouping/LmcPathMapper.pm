use strict;
use strict;
use Getopt::Long;
use LmcMapRule;
use Data::Dumper qw(Dumper);
package LmcPathMapper;

sub new {
    my $class = shift;
    my $self = {
        config => shift,
    };
    bless $self, $class;
    $self->{rules} = $self->readMapsFromFile($self->{config});
    return $self;
}

sub readMapsFromFile {
    my $self = shift;
    my $file = shift;
    my @result;
    open(my $fh, "<", $file) or die "cannot open file $file";
    while (my $line = <$fh>) {
        chomp $line;
        my $map = LmcMapRule->new(split("\t", $line));
        push(@result, $map);
    }
    close($fh);
    return \@result;
}

sub getLmcPath {
    my ($self, $path) = (@_);
    my $lmcPath;
    foreach my $rule (@{$self->{rules}}) {
        if ($rule->matchPath($path)) {
            $lmcPath = $rule->getMappedPath($path);
            last;
        } 
    }
    return $lmcPath;
}

sub getOriginalPath {
    my ($self, $lmcPath) = (@_);
    my $path;
    foreach my $rule (@{$self->{rules}}) {
        if ($rule->matchLmcPath($lmcPath)) {
            $path = $rule->getPath($lmcPath);
            last;
        }
    }
    return $path;
}

1;
