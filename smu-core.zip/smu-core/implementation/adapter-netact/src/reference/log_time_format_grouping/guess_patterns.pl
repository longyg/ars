#!/usr/bin/perl
use strict;
use Getopt::Long;

my $file;
my $nguess = 0;
my $fpath_file = "patternguess";
main();

sub usage
{
    print "$0 -f <filename>";
    exit;
}

sub parseOptions
{
    GetOptions("file|f=s" => \$file);
    if (!$file){
        usage();
    }
}

sub guess
{
    $nguess++;
    my $file = shift;
    my $pattern = shift;
    my $out = qx(sed \'$pattern\' $file | sort | uniq -c);
    qx (echo "$out" > patternguess$nguess);
}

sub extract_fpath
{
    my $file = shift;
    my $out = qx(awk -F\'%%\' \'{print \$3;}\' $file);
    print $out;
    qx (echo "$out" > $fpath_file);
}

sub guess_patterns
{
    my $f = shift;
    guess($f, 's/\(\/[^\/]*\/\).*/\1/'); #/d1/
    guess($f, 's/\([^\/]*\/[^\/]*\).*/\1/'); #/d1/d2
    guess($f, 's/\([^\/]*\/[^\/]*\).*\.\([^\.]*\)/\1.*\\\.\2/'); #d1/d2/.txt
    guess($f, 's/\(.*\/.*\/[^_\.]*\).*/\1/'); #d1/d2/d3
    guess($f, 's/\(.*\/.*\/[^_\.]*\)\(.*\.\)*\(.*\)/\1\3/'); #d1/d2/d3.txt
    guess($f, 's/.*\.\(.*\)/\1/');
    guess($f, 's/\([^\/]*\).*\/\([^\.\/_]*\).*/\1\/\2/');
    guess($f, 's/\([^\/]*\).*/\1/');
    guess($f, 's/\([^\/]*\).*\/\([^\.\/_]*\).*/\2/');
}

sub main
{
    parseOptions();
    extract_fpath($file);
    guess_patterns($fpath_file);
}


