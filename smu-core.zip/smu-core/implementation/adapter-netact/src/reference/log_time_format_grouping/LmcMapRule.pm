use strict;
package LmcMapRule;

sub new {
    my $class = shift;
    my $self = {
        path =>  shift,
        linkPath => shift,
        lmcPath => shift,
    };
    bless $self, $class;
    return $self;
}

sub matchPath {
    my $self = shift;
    my $path = shift;
    return (beginWith($path, $self->{path}) or beginWith($path, $self->{linkPath}));
}

sub matchLmcPath {
    my ($self, $lmcPath) = (@_);
    return beginWith($lmcPath, $self->{lmcPath});
}

sub getMappedPath {
    my $self = shift;
    my $path = shift;
    my $result = "";
    if (beginWith($path, $self->{path})) { 
        $result = $self->{lmcPath}.substr($path, length($self->{path}));
    } elsif (beginWith($path, $self->{linkPath})) { 
        $result = $self->{lmcPath}.substr($path, length($self->{linkPath}));
    }
    return $result;
}

sub getPath {
    my ($self, $lmcPath) = (@_);
    my $result = "";
    if (beginWith($lmcPath, $self->{lmcPath})) {
        $result = $self->{path}.substr($lmcPath, length($self->{lmcPath}));
    }
    return $result;
}

sub beginWith
{
    my ($string, $pattern) = @_;
    my $length = length($pattern);
    my $prefix = substr($string, 0, $length);
    return $prefix eq $pattern;
}

1;
