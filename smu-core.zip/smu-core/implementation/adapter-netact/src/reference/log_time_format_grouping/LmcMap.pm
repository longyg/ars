use strict;
package LmcMap;

sub new {
    my $class = shift;
    my $self = {
        path =>  shift,
        linkPath => shift,
        lmcPath => shift,
    };
    bless $self, $class;
    return $self;
}

sub matchPath
{
    my $self = shift;
    my $path = shift;
    return (beginWith($path, $self->{path}) or beginWith($path, $self->{linkPath}));
}

sub getMappedPath
{
    my $self = shift;
    my $path = shift;
    my $result = $path;
    if (beginWith($path, $self->{path})) { 
        $result =~ s/$self->{path}/$self->{lmcPath}/;
    } elsif (beginWith($path, $self->{linkPath})) { 
        $result =~ s/$self->{linkPath}/$self->{lmcPath}/;
    }
    return $result;
}

sub beginWith
{
    my ($string, $pattern) = @_;
    return $string =~ /^$pattern/;
}

1;
