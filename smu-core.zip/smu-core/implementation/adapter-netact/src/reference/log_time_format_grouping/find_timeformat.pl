#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use Data::Dumper qw(Dumper);

my $debug = 0;
my %g_format_map;
my $defaultMapfile = "smu_time_formatmap.txt";
my $g_max_lines = 500;
my $g_status_matched = 'Y';
my $g_status_try = 'T';
my $g_status_never_match = 'N';
my $g_accept_ratio = '0.1';
my $myFS = ' %% ';
my @g_weak_time_regex;
my %g_time_regex;
my @g_weak_patterns = ('yyyy', 'hh:mi:ss');
my %g_predefined_patterns = (
        '/oss_activity.*' => 'yyyy-mm-dd-Thh:mi:ss.mis',
        '/oss_trace.*' => 'yyyy-mm-dd-Thh:mi:ss.mis',
        );

my @g_patterns=(
            'yyyy-mon-ddThh:mi:ss', #4 2014-Oct-14T17:53:13, /var/opt/oss/logc/clab604node07/osslogdir/install/NSN-jbi_cpf/saucnt_install_debug.txt
            'dd-mm-yyyy hh.mi.ss', #7 15-10-2014 03.20.07, "/var/opt/oss/logc/clab604node02/osslogdir/db/pcolib.analyze.log"
            'mm/dd/yy hh:mi:ss', #6 10/14/14 10:45:16:792 EEST, "/var/opt/oss/logc/clab604node14/applicationserver/nodeagent/native_stdout.log"
            'mon dd, yyyy hh:mi:ss',
            'mon dd hh:mi:ss', #Oct 14 14:04:40
            'mon-dd-yyyy hh:mi:ss', #Oct-23-2014 17:48:00
            'yyyy-mon-dd@hh:mi:ss', #5 2014-Oct-14@13:55:31, /var/opt/oss/logc/clab604node07/osslogdir/mf-cpf-config/mf-cpf-config-2014-Oct-14_13..log
            'yyyy-mm-dd hh:mi:ss', #8 2014-09-09 01:10:35
            'yyyy-mm-dd Thh:mi:ss', #9 2014-09-09T08:52:34
            'yyyy-mm-dd @hh:mi:ss', #10 2014-09-09@08:52:34
            'yyyy-mm-dd::hh:mi:ss',
            'dd-mm-yyyy hh:mi:ss', #10 2014-09-09@08:52:34
            'dd-mm-yyyy hh-mi-ss',
            'dd-mon-yyyy hh:mi', #11-OCT-2014 03:57
            'dd mon yyyy hh:mi:ss', #14 Oct 2014 12:21:56
            'dd-mm-yyyyThh:mi:ss', #10-10-2014T14:03:51
            'dd.mm.yyyy hh:mi:ss', #17.10.2014 23:59:59
            'yyyy/mm/dd at hh:mi:ss', #2014/10/14 at 07:39:31
            'yyyy/mm/dd hh:mi:ss', #2014/10/10 14:32:50
            'yyyy/mm/dd hh:mi.ss', #2014/10/10 14:04.12
            'dd/mm/yyyy hh:mi:ss', #13/10/2014 00:10:07
            'wod mon dd hh:mi:ss yyyy', #Sat Oct 14 13:55:19 2014
            'wod mon dd hh:mi:ss EEST yyyy', #3 Sat Oct 18 00:05:06 EEST 2014
            'yyyy-mm-dd-Thh:mi:ss.mis', #2014-10-14-T20:10:01.261
            'yyyy-mm-ddThh:mi:ss', #2014-10-14T17:07:15.618
            'yyyy-mm-dd Thh:mi:ss', #2014-10-14T17:07:15.618
            'yyyy.mm.dd AD at hh:mi:ss', #2014.10.20 AD at 04:27:12 EEST
            'dd/mon/yyyy:hh:mi:ss', #25/Oct/2014:03:31:13
            'dd mon yyyy hh:mi:ss EEST', #20 Oct 2014 01:35:36 EEST
            'dd.mm.yyyy:hh:mi:ss', #25.10.2014:18:30:10
            'longm dd, yyyy hh:mi:ss', #October 14, 2014 20:00:02
            'yyyymmdd hhmiss', #20141015_113010
            );


main();

sub usage
{
    print "$0 -i <input file> -m <map result file> -n <first n lines to search> -f -d\n
    \t -m: map file to store the result of time format of files. Default: $defaultMapfile\n
    \t -f: force to do the finding again, i.e. ignore and overwrite the mapping result in the -m <file>\n
    \t -n: only search the pattern for the first n lines. Default is 500.\n
    \t -d: debug mode\n";
    exit;
}

sub main
{
    my $origfile;
    my $mapfile;
    my $force_do_again = 0;
    GetOptions(
            "input|i=s" => \$origfile,
            "map|m=s" => \$mapfile,
            "maxline|n=i" => \$g_max_lines,
            "debug|d" => \$debug,
            "force|f" => \$force_do_again,
            );
    if (!$origfile) {
        usage();
    }
    if (!$mapfile) {
        $mapfile = $defaultMapfile;
        print "Result will be stored in: $mapfile\n";
    }
    if (! $force_do_again) {
        read_format_map($mapfile);
    }
    init_pattern_regex();
    process_files(get_valid_files($origfile));
    write_format_map($mapfile);
}

sub get_valid_files
{
    my $f = shift;
    my @flist;
    open (my $fh, "<", $f) or die ("cannot read $f\n");
    while (my $line = <$fh> ) {
        chomp($line);
        if (valid($line)) {
            push (@flist, $line);
        }
    }
    close($fh);
    return \@flist;
}

sub smu_log
{
    if ($debug) {
        print join(', ', @_), "\n";
    }
}

sub init_pattern_regex
{
    for my $pat (@g_patterns) {
        $g_time_regex{$pat} = convert_to_regex($pat);
    }
    for my $pat (@g_weak_patterns) {
        $g_time_regex{$pat} = convert_to_regex($pat);
    }
    debug_print_regex();
}

sub debug_print_regex
{
    for my $pat (keys %g_time_regex) {
        smu_log ("$pat - $g_time_regex{$pat}\n");
    }
}

sub find_format_for_line
{
    my $line = shift;
    my $refregexs = shift;
    smu_log ("finding format for line: $line");
    for (my $i = 0; $i < scalar @$refregexs; $i++) {
        smu_log ("\t regex: $i, $$refregexs[$i]");
        if ($line =~ /$$refregexs[$i]/) {
            smu_log ("\t matched: $i, $$refregexs[$i]");
            return $i;
        }
    }
    return -1;
}

sub convert_to_regex
{
    my $pattern = shift;
    my %pat2reg = (
            'yyyy', '2014',
            'wod', '(Mon|Tue|Wed|Thu|Fri|Sat|Sun)',
            'hh', '[012]?[0-9]',
            'mi', '[0-5][0-9]',
            'ss', '[0-5][0-9]',
            'mon', '(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)',
            'longm', '(January|February|March|April|May|June|July|August|September|October|November|December)',
            'mm', '[01]?[0-9]',
            'dd', '[0-3]?[0-9]',
            'mis', '[0-9]{1,3}',
            );

    for my $pat (keys %pat2reg) {
        $pattern =~ s/$pat/$pat2reg{$pat}/;
    }
    my %pat2reg_special = (
            'yy', '\d{2}',
            );
    for my $pat (keys %pat2reg_special) {
        $pattern =~ s/$pat/$pat2reg_special{$pat}/;
    }
    return $pattern;
}

sub process_files
{
    my $flist = shift;
    my $n = scalar @$flist;
    my $i = 1;
    for my $f (@$flist) {
        if (!$g_format_map{$f} || $g_format_map{$f}{status} eq $g_status_try) {
            try_to_update_format_map($f);
            print $i++,"/$n - file $f processed.\n";
        } else {
            print $i++,"/$n - file $f ignored.\n";
        }
    }
}

sub try_to_match_file
{
    my $file = shift;
    my $candidates = shift;
    my $refregexs = shift;
    my ($nmatches, $total, $pattern) = find_pattern_for_file($file, $candidates, $refregexs);
    my $status = $g_status_never_match;
    my $ratio = 0;
    if ($nmatches > 0 && $total > 0) {
        $ratio = sprintf("%.4f", $nmatches / $total);
        $status = $g_status_matched;
    } 
    return ($status, $pattern, $nmatches, $total, $ratio);
}

sub try_to_update_format_map
{
    my $file = shift;
    my $status = $g_status_never_match;
    my ($pattern, $nmatches, $total, $ratio);

    my $predefined = get_predefined_pattern($file);
    if (defined $predefined) {
        my @patterns = ($predefined);
        ($status, $pattern, $nmatches, $total, $ratio) = try_to_match_file($file, \@patterns, \%g_time_regex);
    }
    if ($status eq $g_status_never_match) {
        ($status, $pattern, $nmatches, $total, $ratio) = try_to_match_file($file, \@g_patterns, \%g_time_regex);
    }
    if ($status eq $g_status_never_match) {
        ($status, $pattern, $nmatches, $total, $ratio) = try_to_match_file($file, \@g_weak_patterns, \%g_time_regex);
        if ($status eq $g_status_matched && $ratio > $g_accept_ratio) {
            $status = $g_status_try;
        } 
    }
    smu_log ("update-map: , $status, $pattern, $file, $nmatches, $total, $ratio");
    update_map_entry($status, $pattern, $file, $nmatches, $total, $ratio);
}

sub read_format_map
{
    my $mapfile = shift;
    open(my $fh, '<', $mapfile) or return;
    smu_log("READING MAP...\n");
    while (my $line = <$fh>) {
        chomp($line);
        my ($status, $fmt, $fpath, $nmatches, $linetotal, $ratio) = split($myFS, $line);
        smu_log("$line");
        update_map_entry($status, $fmt, $fpath, $nmatches, $linetotal, $ratio);
    }
}

sub build_format_map_output
{
    my @txt;
    for my $f (keys %g_format_map) {
        my $line = $g_format_map{$f}{status};
        $line .= $myFS.$g_format_map{$f}{pattern};
        $line .= $myFS.$f;
        $line .= $myFS.$g_format_map{$f}{nmatches};
        $line .= $myFS.$g_format_map{$f}{linetotal};
        $line .= $myFS.$g_format_map{$f}{ratio};
        push(@txt, $line."\n");
    }
    @txt = sort @txt;
    return \@txt;
}
sub write_format_map
{
    my $mapfile = shift;
    my $txt = build_format_map_output();
    smu_log("MAP RESULT:\n @$txt");
    open (my $fh, '>', $mapfile) or die ("Cannot open file $mapfile\n");
    print $fh @$txt;
    close ($fh);
}

sub update_map_entry
{
    my ($status, $fmt, $f, $nmatches, $linetotal, $ratio) = @_;
    if (!$g_format_map{$f} ||
            $status ne $g_format_map{$f}{status}) {
        $g_format_map{$f}{status} = $status;
        $g_format_map{$f}{pattern} = $fmt;
        $g_format_map{$f}{nmatches} = $nmatches;
        $g_format_map{$f}{linetotal} = $linetotal;
        $g_format_map{$f}{ratio} = $ratio;
    }
}

sub find_pattern_for_file
{
    my $fname = shift;
    my $candidates = shift;
    my $refregexs = shift;
    my $n_line = 0;
    my $nmatches = 0;
    open (my $fh, '<', $fname) or return -1;
    my $matched_pat = undef;
    while (my $line = <$fh> ) {
        chomp($line);
        smu_log("Trying for line: $line");
        if (not defined $matched_pat) {
            for my $pat (@$candidates) {
                if ($line =~ /$$refregexs{$pat}/) {
                    $matched_pat = $pat;
                    $nmatches++;
                    smu_log("line matched: $line, $matched_pat");
                }
            }
        } else {
            if ($line =~ /$$refregexs{$matched_pat}/) {
                $nmatches++;
                smu_log("line matched: $line, $matched_pat");
            }
        }
        if (++$n_line >= $g_max_lines) {
            last;
        }
    }
    close($fh);
    if (not defined $matched_pat) {
        $matched_pat = "";
    }
    smu_log ("file match result: $fname, $matched_pat, $nmatches\n");
    return ($nmatches, $n_line, $matched_pat);
}

sub valid
{
    my $f = shift;
    if ($f =~ /.*\.lck/) {
        return 0;
    }
    if ( -f $f && -r $f && !-z $f) {
        return 1;
    } else {
        return 0;
    }
}

sub get_predefined_pattern
{
    my $file = shift;

    for my $key (keys %g_predefined_patterns) {
        if ($file =~ $key) {
            return $g_predefined_patterns{$key};
        }
    }
    return undef;
}
