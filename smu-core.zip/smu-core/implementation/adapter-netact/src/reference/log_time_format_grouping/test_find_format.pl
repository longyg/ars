#!/usr/bin/perl -w
use strict;

my $number = 1;
my $g_inputfile = "inputtest.list";
my $g_mapfile = "maptest";
my @g_output_lines = (
        'N %%  %% inputtest.4 %% 0 %% 3 %% 0',
        'T %% yyyy %% inputtest.1 %% 1 %% 2 %% 0.5000',
        'Y %% mon dd hh:mi:ss %% inputtest.2 %% 2 %% 3 %% 0.6667',
        'Y %% yyyy-mm-ddThh:mi:ss %% inputtest.3 %% 1 %% 3 %% 0.3333',
        );

main();

sub create_test_file
{
    my $txt = shift;
    my $file = "inputtest.".$number++;
    open (my $fh, '>', $file) or die ("cannot open $file.\n");
    print $fh $txt;
    close ($fh);
    qx ( echo $file >> $g_inputfile);
}

sub setup
{
    qx (rm $g_inputfile);
    create_test_file("line 1: 2014\n line2: text");
    create_test_file("line 1: Time: Sat Oct 25 02:54:41 2014 \n line2: text \n line 3: Time: Sat Oct 25 02:54:41 2014 \n");
    create_test_file("line 1: 00:21:21\n line2: text\n line3: 2014-10-25T00:12:12 text");
    create_test_file("line 1: test\n line2: text\n line3: 20-2 text");
}

sub teardown
{
    qx(rm inputtest.*);
}

sub test_case
{
    qx (./find_timeformat.pl -i inputtest.list -m $g_mapfile -f);
    open (my $fh, '<', $g_mapfile) or die ("cannot open $g_mapfile");
    my $i = 0;
    while (my $line = <$fh>) {
        chomp($line);
        my $expected = $g_output_lines[$i++];
        if ($line ne $expected) {
            print "FAIL: '$line' not equal to '$expected'\n";
            return;
        }
    }
    print "OK.\n";
}

sub main
{
    setup();
    test_case();
    teardown();
}
