#!/usr/bin/perl
#
use strict;
use Data::Dumper qw(Dumper);
use Getopt::Long;
use Text::Glob qw( match_glob glob_to_regex );
use LogConfItem;
use LmcPathMapper;

my $debug = 0;
my $dbUser = "smu";
my $dbPass = "smu";
my $table_name = "SMU_LOG_CONFIG";
my $myFS = ',';
my %g_result;
my %g_result_uniq;
my %logConfItems;

sub read_logs_from_file {
    my $file = shift;
    my @logs;
    open (my $fh, "<", $file) or die "cannot open file";
    while (my $line = <$fh>) {
        chomp $line;
        my @log = split("\t", $line);
        push @logs, \@log;
    }
    close($fh);
    return \@logs;
}

sub build_log_items_from_array {
    my $logs = shift;
    my $mapper = LmcPathMapper->new("lmc_map.cf");
    foreach (@$logs) {
        my ($path, $lmcPath, $component, $service, $timeFmt, $example) = @$_;
        if (not $lmcPath and $path) {
            $lmcPath = $mapper->getLmcPath($path);
        } elsif (not $path and $lmcPath) {
            $path = $mapper->getOriginalPath($lmcPath);
        } 
        if (not $path) {
            next;
        }
        if ($logConfItems{$path}) {
            $logConfItems{$path}->addTimeFormat($timeFmt, $example);
            $logConfItems{$path}->addNode($service);
            $logConfItems{$path}->addComponent($component);
        } else {
            $logConfItems{$path} = LogConfItem->new($lmcPath, $path, $component, $service, $timeFmt, $example);
        }
    }
#print Dumper \%logConfItems;
}

sub print_logs_as_csv {
    my $file = shift;
    open (my $fh, ">",  $file) or die "cannot open file $file";
    smu_log("writting output to $file\n");
    foreach my $path (sort keys %logConfItems) {
        my $item = $logConfItems{$path};
        my $rows = $item->toRows();
        my @lines; 
        foreach (@$rows) {
            push @lines, join("\t", @$_)."\n";
        }
        foreach (sort @lines) {
            print $fh $_;
        }
    }
    close($fh);
}

main();

sub usage()
{
    print "$0 -m <mapfile> -l <leftfile> -p <patternFile> -d\n";
    exit 1;
}

sub smu_log
{
    my @msg = shift;
    if ($debug) {
        for (@msg) {
            print $_;
        }
        print "\n";
    }
}

sub diff_input_and_output {
    my ($left, $right) = @_;
    my $diff = qx(diff $left $right);
    print "\ndiff $left $right\n", $diff;
    print "\n";
}

sub ask_to_overrite_pattern_file {
    my ($dest, $src) = @_;
    print "Overwrite the $dest with $src?\n";
    my $answer = <STDIN>;
    chomp $answer;
    if ($answer eq "y" or $answer eq "Y") {
        print "cp -f $src $dest...\n";
        qx(cp -f $src $dest);
        if ($? == 0) {
            print "done\n";
        } else {
            print "rc: ", $? >> 8, "\n";
        }
    }
}

sub main
{
    my $mapFile;
    my $left;
    my $patFile;
    GetOptions("map|m=s" => \$mapFile,
            "left|l=s" => \$left,
            "pattern|p=s" => \$patFile,
            "debug|d" => \$debug
            ) or usage();
    if (!$mapFile or !$patFile) {
        usage();
    }
    smu_log ("processing $mapFile\n");
    my $ifh;
    my $ofh;
    my $leftfh;
    build_log_items_from_array(read_logs_from_file($patFile));
    my $outputFile = "$patFile.tmp"; 
    
    open ($ifh, "<", "$mapFile") or die "cannot open file $mapFile";
    open ($leftfh, ">", "$left") or die "cannot open file $left";
    my $matched = 0;
    my $n = 0;
    print "start loop\n";
    while (my $line = <$ifh>)
    {
        chomp($line);
        $matched = 0;
        my ($status, $tfmt, $fpath) = split(" %% ", $line);
        if (not $fpath) {
            print "warning: not valid file path: $fpath\n";
            next;
        }
        $n++;
        if ($n % 1000 == 0) {
            print $n, "\n";
        }
        for my $item (values %logConfItems) {
            if ($item->acceptLmcPath($fpath, $tfmt)) {
                smu_log ("Line: $line");
                smu_log ("$fpath accepted by $item->{path}");
                $matched = 1;
                last;
            }
        }
        if (!$matched) {
            print $leftfh "$line\n";
        } 
    }
    close($ifh);
    close($leftfh);
    print_logs_as_csv($outputFile);
    diff_input_and_output($patFile, $outputFile);
    ask_to_overrite_pattern_file($patFile, $outputFile);
}



