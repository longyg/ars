#find all log files and put the name in the "input.txt"
find /var/opt/oss/logc/ -type f > input.txt

#find time format of files in "input.txt"
./find_timeformat.pl -i input.txt -m map

#group log files, after the time format mapping is stored in "map" file.
./group_logs.pl -f map -l gleft > gout

#extract out the mapping rule only from "gout"
grep -vE 'e.g.' gout  | grep -E '^[0-9]' | awk -F'%%'  '{print $2 " %% " $3 " %% " $4;}' | sort > final_config.cf

