/*
This class is copied from jboss-logging-3.1.3.GA.jar in order to hack the logging of hibernate
 */
package org.jboss.logging;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

final class SMUJDKLogger extends org.jboss.logging.Logger {

    private static final long serialVersionUID = 2563174097983721393L;
    private static String JBOSS_LOGGER_NAME =  "com.nokia.oss.smu.data.Hibernate";

    @SuppressWarnings({ "NonConstantLogger" })
    private transient final java.util.logging.Logger logger;


    public SMUJDKLogger(final String name) {
        super(name);
        logger = java.util.logging.Logger.getLogger(JBOSS_LOGGER_NAME);
    }

    protected void doLog(final Level level, final String loggerClassName, final Object message, final Object[] parameters, final Throwable thrown) {
        if (isEnabled(level)) try {
            final org.jboss.logging.JBossLogRecord rec = new org.jboss.logging.JBossLogRecord(translate(level), String.valueOf(message), loggerClassName);
            if (thrown != null) rec.setThrown(thrown);
            rec.setLoggerName(getName());
            rec.setParameters(parameters);
            rec.setResourceBundleName(logger.getResourceBundleName());
            rec.setResourceBundle(logger.getResourceBundle());
            logger.log(rec);
        } catch (Throwable ignored) {}
    }

    protected void doLogf(final Level level, final String loggerClassName, String format, final Object[] parameters, final Throwable thrown) {
        if (isEnabled(level)) try {
            final ResourceBundle resourceBundle = logger.getResourceBundle();
            if (resourceBundle != null) try {
                format = resourceBundle.getString(format);
            } catch (MissingResourceException e) {
                // ignore
            }
            final String msg = parameters == null ? String.format(format) : String.format(format, parameters);
            final org.jboss.logging.JBossLogRecord rec = new org.jboss.logging.JBossLogRecord(translate(level), msg, loggerClassName);
            if (thrown != null) rec.setThrown(thrown);
            rec.setLoggerName(getName());
            rec.setResourceBundleName(logger.getResourceBundleName());
            // we've done all the business
            rec.setResourceBundle(null);
            rec.setParameters(null);
            logger.log(rec);
        } catch (Throwable ignored) {}
    }

    private static java.util.logging.Level translate(final Level level) {
        /* The levels by hibernate is reduced! */
        if (level != null) switch (level) {
            case FATAL: return org.jboss.logging.JDKLevel.ERROR;
            case ERROR: return org.jboss.logging.JDKLevel.WARN;
            case WARN:  return org.jboss.logging.JDKLevel.DEBUG;
            case INFO:  return org.jboss.logging.JDKLevel.DEBUG;
            case DEBUG: return org.jboss.logging.JDKLevel.DEBUG;
            case TRACE: return org.jboss.logging.JDKLevel.TRACE;
        }
        return org.jboss.logging.JDKLevel.ALL;
    }

    public boolean isEnabled(final Level level) {
        return logger.isLoggable(translate(level));
    }
}
