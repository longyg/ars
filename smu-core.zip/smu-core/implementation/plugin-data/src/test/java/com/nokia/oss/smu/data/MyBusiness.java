package com.nokia.oss.smu.data;

import org.junit.Assert;
import org.springframework.stereotype.Component;

import com.nokia.oss.smu.data.sync.Synchronized;

@Component
public class MyBusiness {

	@Synchronized(lockName = "mybusiness.lock")
	public void doBuisinessWithLock() {
		this.doBuisinessWithoutLock();
	}
	
	public void doBuisinessWithoutLock() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException ex) {
			Assert.fail("UnitTest should not be interrupted");
		}
	}
}
