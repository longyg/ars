package com.nokia.oss.smu.data;

import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import com.nokia.oss.smu.data.sync.internal.SynchronizedLockHelper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SyncTest.SpringConfiguation.class)
public class SyncTest {

	@Resource
	MyBusiness myBusiness;
	
	@Resource
	private DelayedEntityManagerFactory emf;

	@Resource
	private SynchronizedLockHelper synchronizedLockHelper;

	@Before
	public void setUp() {
		this.emf.sendCommand("contextReady");
		synchronizedLockHelper.addLock("mybusiness.lock");
	}

	@Test
	public void lockShouldBeSerial() {
		long time = this.getExecutionTime(5, true);
		Assert.assertTrue(time > 5000);
	}
	
	@Test
	public void nonLockShouldBeParallel() {
		long time =  this.getExecutionTime(5, false);
		Assert.assertTrue(time < 1500);
	}
	
	private long getExecutionTime(int threadCount, final boolean withLock) {
		Thread[] threads = new Thread[threadCount];
		for (int i = threadCount - 1; i >= 0; i--) {
			threads[i] = new Thread(new Runnable() {
				@Override
				public void run() {
					if (withLock) {
						myBusiness.doBuisinessWithLock();
					} else {
						myBusiness.doBuisinessWithoutLock();
					}
				}
			});
		}
		long time = System.currentTimeMillis();
		for (Thread thread : threads) {
			thread.start();
		}
		for (Thread thread : threads) {
			try {
				thread.join();
			} catch (InterruptedException ex) {
				Assert.fail("Test thread should not be interrupted");
			}
		}
		return System.currentTimeMillis() - time;
	}
	
	@Configuration
	@ImportResource("classpath:plugin-data.spring.xml")
	@ComponentScan(basePackageClasses = MyBusiness.class)
	public static class SpringConfiguation {
		
		@Bean
		public DataSource dataSource() {
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
			dataSource.setUrl("jdbc:hsqldb:mem:testdb");
			dataSource.setUsername("sa");
			return dataSource;
		}
		
		@Bean
		public Properties jpaProperties() {
			Properties properties = new Properties();
			properties.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
			properties.put("hibernate.hbm2ddl.auto", "create-drop");
			return properties;
		}
	}
}
