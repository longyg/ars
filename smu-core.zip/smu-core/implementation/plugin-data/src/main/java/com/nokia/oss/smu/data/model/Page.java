package com.nokia.oss.smu.data.model;

import java.util.Collection;

public interface Page<T> {

	int getExpectedPageIndex();
	
	long getTotalRowCount();
	
	int getTotalPageCount();
	
	int getActualPageIndex();
	
	Collection<T> getItems();


}
