package com.nokia.oss.smu.data.model;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.persistence.TypedQuery;

public class Pages {

	private Pages() {
		
	}
	
	public static <T> Page<T> createPage(int pageIndex, int pageSize, long totalRowCount, TypedQuery<T> query) {
		if (pageSize < 1) {
			throw new IllegalArgumentException("pageSize must >= 1");
		}
		if (totalRowCount < 0) {
			throw new IllegalArgumentException("totalRowCount must < 1");
		}
		int totalPageCount = (int)((totalRowCount + pageSize - 1) / pageSize);
		int actualPageIndex = pageIndex;
		if (actualPageIndex >= totalPageCount) {
			actualPageIndex = totalPageCount - 1;
		}
		if (actualPageIndex < 0) {
			actualPageIndex = 0;
		}
		List<T> entities = query.setFirstResult(actualPageIndex * pageSize).setMaxResults(pageSize).getResultList(); 
		return new PageImpl<T>(pageIndex, totalRowCount, totalPageCount, actualPageIndex, entities);
	}
	
	private static class PageImpl<T> implements Page<T> {
		
		private int pageIndex;
				
		private long totalRowCount;
		
		private int totalPageCount;
		
		private int actualPageIndex;
		
		private Collection<T> items;

		public PageImpl(
				int pageIndex,
				long totalRowCount, 
				int totalPageCount, 
				int actualPageIndex, 
				Collection<T> items) {
			this.pageIndex = pageIndex;
			this.totalRowCount = totalRowCount;
			this.totalPageCount = totalPageCount;
			this.actualPageIndex = actualPageIndex;
			this.items = Collections.unmodifiableCollection(items);
		}

		@Override
		public int getExpectedPageIndex() {
			return this.pageIndex;
		}

		@Override
		public long getTotalRowCount() {
			return this.totalRowCount;
		}

		@Override
		public int getTotalPageCount() {
			return this.totalPageCount;
		}

		@Override
		public int getActualPageIndex() {
			return this.actualPageIndex;
		}

		@Override
		public Collection<T> getItems() {
			return this.items;
		}
		
	}
}
