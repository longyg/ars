package com.nokia.oss.smu.data.jpa;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Entities {

    private Entities() {

    }

    public static <E> List<E> distinct(List<E> c) {
        Set<E> set = new LinkedHashSet<E>((c.size() * 4 + 2) / 3);
        set.addAll(c);
        if (set.size() == c.size()) {
            return c;
        }
        c = new ArrayList<E>(set.size());
        for (E e : set) {
            c.add(e);
        }
        return c;
    }

    public static <E> List<E> distinct(List<E> c, boolean condition) {
        if (condition) {
            return distinct(c);
        }
        return c;
    }
}
