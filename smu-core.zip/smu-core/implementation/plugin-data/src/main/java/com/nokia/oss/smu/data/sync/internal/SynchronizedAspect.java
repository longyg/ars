package com.nokia.oss.smu.data.sync.internal;

import javax.annotation.Resource;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.nokia.oss.smu.data.sync.Synchronized;

@Aspect
@Component
@Order(1)
public class SynchronizedAspect {
	
	@Resource
	private SynchronizedLockHelper synchronizedLockHelper;

	// TODO: change to other way to deactivate AOP injection
	@Value("${lock.disabled}")
	private String lockDisabled;
	
	@Around(
			value = "execution(public * *(..)) && @annotation(synchronizedAnnotation)",
			argNames = "synchronizedAnnotation"
	)
	public Object process(final ProceedingJoinPoint pjp, Synchronized synchronizedAnnotation) throws Throwable {
		if ("true".equals(this.lockDisabled)) {
			return pjp.proceed();
		}
		
	    final Object[] outputValues = new Object[2]; //0: retval; 1: exception
		this.synchronizedLockHelper.execute(synchronizedAnnotation.lockName(), new Runnable() {
			@Override
			public void run() {
				try {
					outputValues[0] = pjp.proceed();
				} catch (Throwable ex) {
					outputValues[1] = ex;
				}
			}
	    }, synchronizedAnnotation.nowait());
		if (outputValues[1] != null) {
			throw (Throwable)outputValues[1];
		}
		return outputValues[0];
	}
}
