package com.nokia.oss.smu.data.sync.internal;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.annotation.Resource;
import javax.persistence.LockTimeoutException;
import javax.persistence.PessimisticLockException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * If class name is SynchronizedLockService,
 * foolish WAS will consider it as a JNDI resource.
 */
@Component
public class SynchronizedLockHelper {

    private static final Logger LOGGER = Logger.getLogger(SynchronizedLockHelper.class.getName());
    @Resource
    private SynchronizedLockRepository synchronizedLockRepository;
    @Resource
    private PlatformTransactionManager transactionManager;
    // TODO: change to other way to deactivate AOP injection
    @Value("${lock.disabled}")
    private String disabled;
    private ConcurrentMap<String, Object> fakeLockMap = new ConcurrentHashMap<>();

    @Transactional
    public void execute(String lockName, Runnable runnable, boolean nowait) {
        if ("true".equals(this.disabled)) {
            synchronized (this.fakeLockMap.putIfAbsent(lockName, new Object())) {
                runnable.run();
            }
        } else {
            try {
                LOGGER.fine("Try to get pessimistic lock for " + lockName + ", nowait=" + nowait);
                if (this.synchronizedLockRepository.pessimisticLock(lockName, nowait) == null) {
                    try {
                        this.addLock(lockName);
                    } catch (RuntimeException exception) {
                        LOGGER.fine("Error is ignored when adding lock ");
                    }
                    this.synchronizedLockRepository.pessimisticLock(lockName, nowait);
                }
                LOGGER.fine("after locked, execute task for " + lockName + " start");
                runnable.run();
                LOGGER.fine("after locked, execute task for " + lockName + " done");
            } catch (LockTimeoutException | PessimisticLockException e) {
                //FIXME: LockTimeoutException should be thrown to avoid rollback transaction.
                // But this version of hibernate throws PessimisticLockException.
                // Maybe newer version of hibernate can fix it.
                LOGGER.log(Level.FINEST, "Failed to get lock: " + lockName, e);
                throw e;
            }
        }
    }

    public void addLock(String lockName) {
        LOGGER.info("Adding lock " + lockName);

        /* This must be done in new transaction because it should be committed or rolled back
        * separately before acquiring the pessimistic lock. Otherwise inserting might throw exception
        * when committing the pessimistic lock in which case it's too late to ignore it. */
        TransactionStatus ts = this.transactionManager.getTransaction(
                new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW)
        );
        try {
            SynchronizedLockHelper.this.synchronizedLockRepository.addLock(lockName);
        } catch (RuntimeException ex) {
            this.transactionManager.rollback(ts);
            throw ex;
        }

        this.transactionManager.commit(ts);
        LOGGER.info("Lock is added " + lockName);
    }
}
