package com.nokia.oss.smu.data.internal;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;

import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * Configure object of this class in spring context
 * <pre>
 *     &lt;bean id="entityManagerFactory" class="com.nokia.oss.smu.data.internal.DelayedEntityManagerFactoryBean"&gt;
 *         ... inject properties ...
 *     &lt;/bean&gt;
 * </pre>
 *   
 * Then inject this object as
 * <pre>
 *     &#64;Resource
 *     private EntityManagerFactory emf;
 * </pre>
 *     
 * This is an unstable reference because it does not depend on the ready state of database.
 * <ul>
 *     <li>
 *         If the database isn't OK when any method of this injected object is invoked,
 *         an IllegalStateException will be raised with this message:
 *         "The environment is not ready, don't try to access database"
 *      </li>
 *      <li>
 *          You can also check whether the database is ready manully, like this
 *          <pre>
 *              if (UnstableReferences.isAvailable(this.emf)) {
 *                  Do some database operations
 *              } else {
 *                  Database is not OK, uses some workaround to tell the user the database environment is not ready.
 *              }
 *          </pre>
 *      </li>
 * </ul>
 * 
 * In order to allow it can become stable automatically, please do this when spring context is ready
 * <pre>
 *     ((ManageableReference)springContext.getBean(EntityManagerFactory.class)).sendCommand("contextReady");
 * </pre>
 */
public class DelayedEntityManagerFactoryBean extends LocalContainerEntityManagerFactoryBean {
    
    private ReadWriteLock rwl = new ReentrantReadWriteLock();
    
    private boolean contextReady;
    
    private Object realEntityManagerFactory;
    
    public DelayedEntityManagerFactoryBean() {
		this.setEntityManagerFactoryInterface(DelayedEntityManagerFactory.class);
	}

	@Override
    protected EntityManagerFactory createNativeEntityManagerFactory() throws PersistenceException {
        return (EntityManagerFactory)Proxy.newProxyInstance(
                DelayedEntityManagerFactoryBean.class.getClassLoader(), 
                new Class<?>[] { DelayedEntityManagerFactory.class }, 
                this.new InvocationHandlerImpl()
        );
    }
    
    private Object getOrCreateRealEntityManagerFactory() {
        Lock rl = this.rwl.readLock();
        Lock wl = this.rwl.writeLock();
        
        Object retval;
        
        rl.lock();
        try {
            retval = this.realEntityManagerFactory;
        } finally {
            rl.unlock();
        }
        
        if (retval == null) {
            wl.lock();
            try {
                retval = this.realEntityManagerFactory;
                if (retval == null && this.contextReady) {
                    retval = this.createRealEntityManagerFactory();
                    this.realEntityManagerFactory = retval;
                }
            } finally {
                wl.unlock();
            }
        }
        
        return retval;
    }
    
    private Object createRealEntityManagerFactory() throws PersistenceException {
    	
    	// Additional network checking because:
    	// If then next step "super.createNativeEntityManagerFactory" fail at first time,
    	// at the second time, the schema operation(validation, create or update)
    	// of JPA won't be executed(Is it a bug of Hibernate?).
        try (Connection con = this.getDataSource().getConnection()){
        } catch (SQLException ex) {
            throw new PersistenceException(
                    "Cannot create JPA Entity Manager Factory because data source is broken", 
                    ex
            );
        }
        
        // Note: This is super invocation, not this invocation!
        return super.createNativeEntityManagerFactory();
    }
    
    private Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    	// Implements "void ManageleReference.sendCommand(String command, Object ... args)"
    	if (method.getReturnType() == void.class &&
    			method.getName().equals("sendCommand") &&
    			method.getParameterTypes().length == 2) {
    		this.sendCommand((String)args[0], (Object[])args);
    		return null;
    	}
    	
    	Object realEMF = this.getOrCreateRealEntityManagerFactory();
        
        // Implements "boolean UnstableReference.isAvailable()"
        if (method.getReturnType() == boolean.class &&
                method.getName().equals("isAvailable") && 
                method.getParameterTypes().length == 0) {
            return realEMF != null;
        }
        
        // Implements all the methods of javax.persistence.EntityManagerFactory
        if (realEMF == null) {
            throw new IllegalStateException("The environment is not ready, don't try to access database");
        }

        return method.invoke(realEMF, args);
    }
    
    /*
     * Manually notify context ready,
     * don't use ApplicationListener<ContextRefreshEvent>
     * because that event cannot guarantee it's the last event of whole context
     */
    private void sendCommand(String command, Object[] args) {
    	Lock wl = this.rwl.writeLock();
    	
    	switch (command) {
    	case "contextReady":
    		wl.lock();
    		try {
    			this.contextReady = true;
    		} finally {
    			wl.unlock();
    		}
    		break;
    	default:
    		throw new IllegalArgumentException("Unexpected command: " + command);	
    	}
    }

    private class InvocationHandlerImpl implements InvocationHandler {
        
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            return DelayedEntityManagerFactoryBean.this.invoke(proxy, method, args);
        }
    }
}
