package com.nokia.oss.smu.data.aspect;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.nokia.oss.smu.core.util.LogUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import javax.persistence.LockTimeoutException;
import javax.persistence.PessimisticLockException;

@Component
@Aspect
public class DataAccessingAspect {
    
    private static Logger LOGGER = Logger.getLogger(DataAccessingAspect.class.getName());

    @AfterThrowing(
            pointcut = "execution(* *.*(..)) && within(@org.springframework.stereotype.Repository *)", 
            throwing = "ex"
    )
    public void handleDataAccessingException(JoinPoint joinPoint, RuntimeException ex) {
        if (!(ex instanceof LockTimeoutException || ex instanceof PessimisticLockException)) {
            LOGGER.severe("Data accessing error raised by " + joinPoint.getSignature() + ": " + LogUtils.getChainedCauses(ex));
            LOGGER.log(Level.FINE, "Data accessing error raised by \"" + joinPoint.getSignature() + '"', ex);
        }
    }
}
