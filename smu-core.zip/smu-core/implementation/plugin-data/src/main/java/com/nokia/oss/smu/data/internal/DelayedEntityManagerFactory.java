package com.nokia.oss.smu.data.internal;

import javax.persistence.EntityManagerFactory;

import com.nokia.oss.smu.core.spring.ManageableReference;
import com.nokia.oss.smu.core.spring.UnstableReference;

/*
 * For design aspect, it's unnecessary to combine these three super interfaces together
 * by this new derived interface.
 * 
 * But unfortunately, the EntityManagerFactoryBean of spring framework cannot accept
 * a list of interfaces type, it can only accept one interface type, it's why this
 * boring interface is created.
 */
public interface DelayedEntityManagerFactory 
extends EntityManagerFactory, UnstableReference, ManageableReference {
}
