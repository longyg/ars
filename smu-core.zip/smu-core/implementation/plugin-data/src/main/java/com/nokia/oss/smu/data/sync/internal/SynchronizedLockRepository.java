package com.nokia.oss.smu.data.sync.internal;

import com.nokia.oss.smu.data.sync.entities.SynchronizedLock;
import com.nokia.oss.smu.data.sync.entities.SynchronizedLock_;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class SynchronizedLockRepository {

    @PersistenceContext
    private EntityManager em;

    public void addLock(String lockName) {
        SynchronizedLock synchronizedLock = new SynchronizedLock();
        synchronizedLock.setName(lockName);
        this.em.merge(synchronizedLock);
    }

    public SynchronizedLock pessimisticLock(String lockName, boolean nowait) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaQuery<SynchronizedLock> cq = cb.createQuery(SynchronizedLock.class);
        Root<SynchronizedLock> synchronizedLock = cq.from(SynchronizedLock.class);
        cq.where(cb.equal(synchronizedLock.get(SynchronizedLock_.name), lockName));
        final TypedQuery<SynchronizedLock> typedQuery = this.em.createQuery(cq)
                .setLockMode(LockModeType.PESSIMISTIC_WRITE);
        if (nowait) {
            typedQuery.setHint("javax.persistence.lock.timeout", 0);
        }
        List<SynchronizedLock> locks = typedQuery.getResultList();
        return locks.isEmpty() ? null : locks.iterator().next();
    }
}
