package com.nokia.oss.smu.data.jpa;

import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.criteria.CollectionJoin;
import javax.persistence.criteria.Fetch;
import javax.persistence.criteria.FetchParent;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ListJoin;
import javax.persistence.criteria.MapJoin;
import javax.persistence.criteria.SetJoin;
import javax.persistence.metamodel.CollectionAttribute;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.MapAttribute;
import javax.persistence.metamodel.PluralAttribute;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;

import org.hibernate.jpa.criteria.path.AbstractJoinImpl;

/**
 * @author frank.1.chen@nsn.com
 */
public class JoinOptimizers {

    private static final Field JOIN_TYPE_FIELD;

    private static final String IDENTIFIER = "[A-Za-z][A-Za-z0-9]*";

    private static final Pattern INCLUDE_PATH_PATTERN = Pattern.compile(
            "\\.{1,2}?" + IDENTIFIER + "(" + "\\.{1,2}" + IDENTIFIER + ")*");

    private static final Pattern INCLUDE_PATH_SEPRATOR_PATTERN = Pattern.compile("\\.{1,2}");

    private JoinOptimizers() {

    }

    public static <X, Y> Join<X, Y> join(From<?, X> from, SingularAttribute<X, Y> attribute) {
        return join(from, attribute, JoinType.INNER);
    }

    public static <X, Y> CollectionJoin<X, Y> join(From<?, X> from, CollectionAttribute<X, Y> attribute) {
        return join(from, attribute, JoinType.INNER);
    }

    public static <X, Y> SetJoin<X, Y> join(From<?, X> from, SetAttribute<X, Y> attribute) {
        return join(from, attribute, JoinType.INNER);
    }

    public static <X, Y> ListJoin<X, Y> join(From<?, X> from, ListAttribute<X, Y> attribute) {
        return join(from, attribute, JoinType.INNER);
    }

    public static <X, K, V> MapJoin<X, K, V> join(From<?, X> from, MapAttribute<X, K, V> attribute) {
        return join(from, attribute, JoinType.INNER);
    }

    public static <X, Y> Join<X, Y> join(From<?, X> from, String attributeName) {
        return join(from, attributeName, JoinType.INNER);
    }

    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, SingularAttribute<X, Y> attribute) {
        return fetch(fetchParent, attribute, JoinType.INNER);
    }

    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, PluralAttribute<X, ?, Y> attribute) {
        return fetch(fetchParent, attribute, JoinType.INNER);
    }

    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, String attributeName) {
        return fetch(fetchParent, attributeName, JoinType.INNER);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> Join<X, Y> join(From<?, X> from, SingularAttribute<X, Y> attribute, JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute() == attribute) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (Join<X, Y>) join;
            }
        }
        return from.join(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> CollectionJoin<X, Y> join(From<?, X> from, CollectionAttribute<X, Y> attribute,
            JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute() == attribute) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (CollectionJoin<X, Y>) join;
            }
        }
        return from.join(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> SetJoin<X, Y> join(From<?, X> from, SetAttribute<X, Y> attribute, JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute() == attribute) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (SetJoin<X, Y>) join;
            }
        }
        return from.join(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> ListJoin<X, Y> join(From<?, X> from, ListAttribute<X, Y> attribute, JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute() == attribute) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (ListJoin<X, Y>) join;
            }
        }
        return from.join(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, K, V> MapJoin<X, K, V> join(From<?, X> from, MapAttribute<X, K, V> attribute, JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute() == attribute) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (MapJoin<X, K, V>) join;
            }
        }
        return from.join(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> Join<X, Y> join(From<?, X> from, String attributeName, JoinType joinType) {
        for (Join<X, ?> join : from.getJoins()) {
            if (join.getAttribute().getName().equals(attributeName)) {
                if (join.getJoinType() != joinType) {
                    useInnerJoin(join);
                }
                return (Join<X, Y>) join;
            }
        }
        return from.join(attributeName, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, SingularAttribute<X, Y> attribute,
            JoinType joinType) {
        for (Fetch<X, ?> fetch : fetchParent.getFetches()) {
            if (fetch.getAttribute() == attribute) {
                if (fetch.getJoinType() != joinType) {
                    useInnerJoin(fetch);
                }
                return (Fetch<X, Y>) fetch;
            }
        }
        return fetchParent.fetch(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, PluralAttribute<X, ?, Y> attribute,
            JoinType joinType) {
        for (Fetch<X, ?> fetch : fetchParent.getFetches()) {
            if (fetch.getAttribute() == attribute) {
                if (fetch.getJoinType() != joinType) {
                    useInnerJoin(fetch);
                }
                return (Fetch<X, Y>) fetch;
            }
        }
        return fetchParent.fetch(attribute, joinType);
    }

    @SuppressWarnings("unchecked")
    public static <X, Y> Fetch<X, Y> fetch(FetchParent<?, X> fetchParent, String attributeName, JoinType joinType) {
        for (Fetch<X, ?> fetch : fetchParent.getFetches()) {
            if (fetch.getAttribute().getName().equals(attributeName)) {
                if (fetch.getJoinType() != joinType) {
                    useInnerJoin(fetch);
                }
                return (Fetch<X, Y>) fetch;
            }
        }
        return fetchParent.fetch(attributeName, joinType);
    }

    /**
     * This method has the same functionality with the method
     * <a href="http://msdn.microsoft.com/zh-cn/library/bb738708(v=vs.110).aspx">
     * "System.Data.Objects.ObjectQuery&lt;T&gt;.Include(String)"
     * </a>
     * which is supported by Microsoft .NET framework.
     *
     * @param fetchParent The fetch parent of JPA criteria, it should be the your root queried object.
     * @param includePath <p>
     *                    A string that follows the pattern ""\.{1,2}?[A-Za-z](\.{1,2}[A-Za-z0-9])*",
     *                    for example:
     *                    <ul>
     *                    <li>employees.annualLeaves</li>
     *                    <li>.employees.annualLeaves</li>
     *                    <li>employees..annualLeaves</li>
     *                    <li>.employees..annualLeaves</li>
     *                    <li>..employees.annualLeaves</li>
     *                    <li>.employees..annualLeaves</li>
     *                    </ul>
     *                    The '.' means fetch the association by left join, often you should use it;
     *                    the '..' means fetch the association by inner join.
     *                    </p>
     *                    <p/>
     *                    If the include path does not start with "." or "..", for this default case.
     *                    you can consider it starts with ".".
     *                    <p/>
     *                    Please view the {@link #addIncludePaths(FetchParent, String...)} to see more real
     *                    demo programs
     */
    public static void addIncludePath(FetchParent<?, ?> fetchParent, String includePath) {
        if (includePath == null || includePath.isEmpty()) {
            return;
        }
        if (!INCLUDE_PATH_PATTERN.matcher(includePath).matches()) {
            throw new IllegalArgumentException(
                    "The inclue path \""
                            + includePath
                            + "\" is illegal, it must match the pattern \""
                            + INCLUDE_PATH_PATTERN.pattern()
                            + "\"");
        }
        JoinType joinType = JoinType.LEFT;
        int position = 0;
        Matcher matcher = INCLUDE_PATH_SEPRATOR_PATTERN.matcher(includePath);
        while (matcher.find()) {
            String nodeName = includePath.substring(position, matcher.start());
            if (!nodeName.isEmpty()) {
                fetchParent = fetch(fetchParent, nodeName, joinType);
            }
            joinType = matcher.group().equals("..") ? JoinType.INNER : JoinType.LEFT;
            position = matcher.end();
        }
        String nodeName = includePath.substring(position);
        fetch(fetchParent, nodeName, joinType);
    }

    /**
     * <p>
     * A shortcut too let you add several include paths to your fetch parent by on method invocation.
     * In the real project, you can uses this method to create the powerful business data query API.
     * </p>
     * <p>
     * Please see the demo
     * <pre><code>
     *  @PersistenceContext
     *  private EntityManager em;
     * <p/>
     *  public List<Department> getDepartmentsLikeName(String name, String ... includePaths) {
     *  	CriteriaBuilder cb = this.em.getCriteiraBuilder();
     *  	CriteriaQuery<Department> cq = cb.createQuery(Department.class);
     *  	Root<Department> department = cq.from(Department.class);
     *  	cq.where(
     *  		cb.like(
     *  			cb.toUpper(department.get(Department_.name)),
     *  			name.toUpperCase()
     * 			)
     * 		);
     *  	JoinOptimizers.addIncludePaths(department, includePaths);
     *  	return this.em.createQuery(cq).getResultList();
     *  }
     *  </code></pre>
     * In the topper layer, you can use call this data access API via these ways:
     * <ul>
     * <li>
     * <pre><code>
     *  			List<Department> departments = this.departmentRepository.getDepartmentsLikeName("%a%");
     *  		</code></pre>
     * This invocation you only want to queries the departments whose name contains 'a' insenstively
     * </li>
     * <li>
     * <pre><code>
     *  			List<Department> departments = this.departmentRepository.getDepartmentsLikeName(
     *  				"%a%", ".employees.annualLeaves");
     *  		</code></pre>
     * This invocation means
     * <ul>
     * <li>You to queries the departments whose name contains 'a' insenstively</li>
     * <li>You want to fetch the association "employees" of each department</li>
     * <li>You want to fetch the association "annualLeaves" of each employee</li>
     * </ul>
     * </li>
     * <li>
     * <pre><code>
     *  			List<Department> departments = this.departmentRepository.getDepartmentsLikeName(
     *  				"%a%",
     *  				".employees.annualLeaves",
     *  				".employees.supervisor.supervisor",
     *  				".department.investors");
     *  		</code></pre>
     * <p>
     * This invocation has several include paths to increase the fetch breadth,
     * and each include path is very long to increase the fetch depth.
     * </p>
     * <p>
     * The association "employees" appears in two include paths. but they will be
     * merged to one fetch join.
     * </p>
     * The actual fetch plan a tree like this
     * <pre><code>
     *  +-<root>(Department queries by you)
     *  |
     *  +----+-employees
     *  |    |
     *  |    +----+-annualLeaves
     *  |    |
     *  |    \----+-supervisor
     *  |         |
     *  |         \------supervisior
     *  |
     *  \----+-department
     *       |
     *       \------investors
     *  		</code></pre>
     * </li>
     * </li>
     * </p>
     *
     * @param fetchParent  The fetch parent of JPA criteria, it should be the your root queried object.
     * @param includePaths Unlimited include paths.
     */
    public static void addIncludePaths(FetchParent<?, ?> fetchParent, String... includePaths) {
        if (includePaths != null) {
            for (String includePath : includePaths) {
                addIncludePath(fetchParent, includePath);
            }
        }
    }

    private static void useInnerJoin(Object joinObject) {
        try {
            JOIN_TYPE_FIELD.set(joinObject, JoinType.INNER);
        } catch (IllegalAccessException ex) {
            throw new AssertionError(ex);
        }
    }

    static {
        Field field;
        try {
            field = AbstractJoinImpl.class.getDeclaredField("joinType");
        } catch (NoSuchFieldException ex) {
            throw new AssertionError(ex);
        }
        field.setAccessible(true);
        JOIN_TYPE_FIELD = field;
    }
}
