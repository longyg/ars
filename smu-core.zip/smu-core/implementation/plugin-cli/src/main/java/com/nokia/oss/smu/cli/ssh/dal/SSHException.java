package com.nokia.oss.smu.cli.ssh.dal;


public class SSHException extends RuntimeException {

	private static final long serialVersionUID = 7929831546870881922L;
	
	public static final String ERROR_AUTHENTICATE_FAILED = "Auth fail";

	public static final String ERROR_ROOT_SSH_DISABLED = "ssh.error.root.ssh.disabled";

	private String errorSymbol;

	public SSHException(String message, Throwable cause) {
		super(message, cause);
	}

	public SSHException(String message) {
		super(message);
	}

	public SSHException(Throwable cause) {
		super(cause);
	}
	
	public SSHException(String errorSymbol, String message) {
	    super(message);
	    this.errorSymbol = errorSymbol;
	}
	
	public SSHException(String errorSymbol, String message, Throwable cause) {
        super(message, cause);
        this.errorSymbol = errorSymbol;
    }

    public String getErrorSymbol() {
        return this.errorSymbol;
    }
}
