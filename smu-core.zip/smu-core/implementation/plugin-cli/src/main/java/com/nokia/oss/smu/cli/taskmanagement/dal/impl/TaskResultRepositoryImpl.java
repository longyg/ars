package com.nokia.oss.smu.cli.taskmanagement.dal.impl;

import com.nokia.oss.smu.cli.taskmanagement.dal.TaskResultRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskResult;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Component
public class TaskResultRepositoryImpl implements TaskResultRepository {

    @PersistenceContext
    private EntityManager em;

    public TaskResult getTaskResult(long taskId) {
        return this.em.find(TaskResult.class, taskId);
    }

    public void setTaskResult(TaskResult result) {
        this.em.merge(result);
    }
}
