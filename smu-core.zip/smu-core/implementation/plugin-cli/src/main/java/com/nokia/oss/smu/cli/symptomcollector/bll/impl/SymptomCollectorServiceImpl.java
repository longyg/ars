package com.nokia.oss.smu.cli.symptomcollector.bll.impl;

import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.symptomcollector.bll.SymptomCollectorService;
import com.nokia.oss.smu.cli.symptomcollector.bll.SymptomCollectorTaskArgument;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTaskPart;
import com.nokia.oss.smu.cli.symptomcollector.dal.SymptomCollectorOutputRepository;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskCreationException;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import com.nokia.oss.smu.data.sync.Synchronized;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.File;
import java.util.*;
import java.util.concurrent.Semaphore;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class SymptomCollectorServiceImpl implements SymptomCollectorService {
    private static final Logger LOG = Logger.getLogger(SymptomCollectorServiceImpl.class.getName());

    private static final String LIST_COMPONENTS_COMMAND = "/opt/oss/bin/symptomcollector --list-components";
    private static final String LIST_SCENARIOS_COMMAND = "/opt/oss/bin/symptomcollector --list-scenarios";
    private static final Pattern COMPONENTS_AND_SCENARIOS_PATTERN = Pattern.compile("^\\d+\\)\\s+.+");
    private static final String COMPONENTS_AND_SCENARIOS_TRIM = "^\\d+\\)\\s+";
    private static final int COLLECT_TASK_LIMIT = 1;
    private static final String PHC_LOCK_FILE = "/var/opt/nokia/oss/global/NSN-mhcf/lockfile";

    @Resource
    private SSHRepository sshRepository;

    @Resource
    private SFTPRepository sftpRepository;

    @Resource
    private TaskRepository taskRepository;

    @Resource
    private SymptomCollectorOutputRepository symptomCollectorOutputRepository;

    @Override
    public Collection<String> listComponents() {
        final Semaphore semaphore = new Semaphore(0);
        final Collection<String> components = new LinkedHashSet<>();
        final Throwable[] sshThrowableRef = new Throwable[1];
        final StringBuilder stdErrBuilder = new StringBuilder();

        LOG.info("Executing command to list components.");
        this.sshRepository.executeCommand(LIST_COMPONENTS_COMMAND, null, new SSHRepository.AsyncCallback() {
            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                LOG.finest("Got line from stdout: " + line);
                Matcher matcher = COMPONENTS_AND_SCENARIOS_PATTERN.matcher(line);
                if (matcher.matches()) {
                    components.add(line.replaceAll(COMPONENTS_AND_SCENARIOS_TRIM,""));
                }
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) {
                LOG.finest("Got line from stderr: " + line);
                if (stdErrBuilder.length() != 0) {
                    stdErrBuilder.append(System.getProperty("line.separator", "\n"));
                }
                stdErrBuilder.append(line);
            }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                LOG.fine("Task execution finished.");
                if (ex != null) {
                    sshThrowableRef[0] = ex;
                }
                semaphore.release();
            }
        });
        try {
            LOG.fine("Wait for command finish by waiting for semaphore.");
            semaphore.acquire();
        } catch (InterruptedException ex) {
            LOG.severe("Command execution was interrupted: " + ex.getMessage());
            throw new SSHException(ex.getMessage(), ex);
        }

        if (sshThrowableRef[0] != null) {
            LOG.severe("Exception caught when executing command:" + sshThrowableRef[0].getMessage());
            throw new SSHException(sshThrowableRef[0].getMessage(), sshThrowableRef[0]);
        }

        if (stdErrBuilder.length() != 0) {
            LOG.warning("Stderr has following ouput during executing: " + stdErrBuilder.toString());
        }

        return components;
    }

    @Override
    public Collection<String> listScenarios() {
        final Semaphore semaphore = new Semaphore(0);
        final Collection<String> scenarios = new LinkedHashSet<>();
        final Throwable[] sshThrowableRef = new Throwable[1];
        final StringBuilder stdErrBuilder = new StringBuilder();
        LOG.info("Executing command to list scenarios.");
        this.sshRepository.executeCommand(LIST_SCENARIOS_COMMAND, null, new SSHRepository.AsyncCallback() {
            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                LOG.finest(" Got line from stdout: " + line);
                Matcher matcher = COMPONENTS_AND_SCENARIOS_PATTERN.matcher(line);
                if (matcher.matches()) {
                    scenarios.add(line.replaceAll(COMPONENTS_AND_SCENARIOS_TRIM,""));
                }
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) {
                LOG.finest("Got line from stderr: " + line);
                if (stdErrBuilder.length() != 0) {
                    stdErrBuilder.append(System.getProperty("line.separator", "\n"));
                }
                stdErrBuilder.append(line);
            }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                LOG.fine("Task execution finished.");
                if (ex != null) {
                    sshThrowableRef[0] = ex;
                }
                semaphore.release();
            }
        });
        try {
            LOG.fine("Wait for command finish by waiting for semaphore.");
            semaphore.acquire();
        } catch (InterruptedException ex) {
            LOG.severe("Command execution was interrupted: " + ex.getMessage());
            throw new SSHException(ex.getMessage(), ex);
        }

        if (sshThrowableRef[0] != null) {
            LOG.severe("Exception caught when executing command:" + sshThrowableRef[0].getMessage());
            throw new SSHException(sshThrowableRef[0].getMessage(), sshThrowableRef[0]);
        }

        if (stdErrBuilder.length() != 0) {
            LOG.warning("Stderr has following ouput during executing: " + stdErrBuilder.toString());
        }

        return scenarios;
    }

    @Transactional
    @Override
    public SymptomCollectorTask createTask(final SymptomCollectorTaskArgument taskArgument) {
        LOG.info("Creation of collector task requested: " + taskArgument);
        long runningTaskCount = this.taskRepository.getRunningTaskCount(SymptomCollectorTask.class);
        if (runningTaskCount >= COLLECT_TASK_LIMIT || isPHCReallyRunning()) {
            throw new TaskCreationException(
                    "Another symptom collection is running, please wait and try again later.");
        }

        SymptomCollectorTask task = new SymptomCollectorTask();
        StringBuilder builder = new StringBuilder();

        if (taskArgument.getComponents() != null && !taskArgument.getComponents().isEmpty()) {
            for (String component : taskArgument.getComponents()) {
                if (!component.isEmpty()) {
                    builder.append(component).append(",");
                }
            }
            task.setComponent(builder.toString());
        }

        if (taskArgument.getScenarios() != null && !taskArgument.getScenarios().isEmpty()) {
            for (String scenario : taskArgument.getScenarios()) {
                if (!scenario.isEmpty()) {
                    builder.append(scenario).append(",");
                }
            }
            task.setScenario(builder.toString());
        }

        Date now = new Date();
        task.setCreationTime(now);
        task.setHeartBeatTime(now);
        task.setState(TaskState.PENDING);
        LOG.info("Collector task created: " + task);
        return (SymptomCollectorTask) this.taskRepository.mergeTask(task);
    }

    @Synchronized(lockName = "smu.task.lock")
    @Transactional
    @Override
    public void cancelTask(long taskId) {
        LOG.fine("Cancelling collector task ID=" + taskId);
        Task task = this.taskRepository.getTask(taskId);
        if (task != null) {
            if (task.getState() == TaskState.PENDING) {
                LOG.info("Collector task " + task + " is in state of pending, stop it directly");
                task.setState(TaskState.STOPPED);
            } else if (task.getState() == TaskState.RUNNING) {
                LOG.info("Collector Task " + task + " is stopping");
                task.setState(TaskState.STOPPING);
            }
            this.taskRepository.mergeTask(task);
        }
    }

    @Transactional
    @Override
    public void heartBeatTask(long id) {
        LOG.fine("Heart beat received for collector task ID=" + id);
        Task task = this.taskRepository.getTask(id);
        if (task != null) {
            Date now = new Date();
            task.setHeartBeatTime(now);
            LOG.fine("Heartbeat updated for collector task ID=" + id + " to " + now);
            this.taskRepository.mergeTask(task);
        }
    }

    @Transactional(readOnly = true)
    @Override
    public SymptomCollectorTaskPart getTaskPart(TaskPartRequest request) {
        long taskId = request.getTaskId();
        Task task = this.taskRepository.getTaskById(taskId);
        if (task == null) {
            return null;
        }

        SymptomCollectorTaskPart taskPart = new SymptomCollectorTaskPart(task);
        taskPart.setOutputLines(
                this.symptomCollectorOutputRepository.getTaskOutputs(taskId)
        );

        TaskPartRequest.ErrorRequest errorRequest = request.getErrorRequest();
        if (errorRequest != null) {
            LOG.fine("Get error outputs for task ID=" + taskId);
            taskPart.setErrors(this.symptomCollectorOutputRepository.getErrorOutputs(taskId));
        }
        return taskPart;
    }

    @Override
    public long getPackSize(long taskId)
    {
        String packagePath = this.symptomCollectorOutputRepository.getPackagePath(taskId);
        long size = this.sftpRepository.getFileSize(packagePath, "omc", "");
        LOG.info("Size of package file " + packagePath + ": " + size);
        return size;
    }

    @Override
    public void downloadPackage(long taskId, long offset, java.io.OutputStream response)
    {
        String packagePath = this.symptomCollectorOutputRepository.getPackagePath(taskId);
        LOG.info("download file content from file=" + packagePath + ", offset=" + offset);
        this.sftpRepository.downloadFile(packagePath, "omc", "", offset, response);
    }

    @Override
    public String getPackName(long taskId)
    {
        String packagePath = this.symptomCollectorOutputRepository.getPackagePath(taskId);
        if (packagePath != null ) {
            return new File(packagePath).getName();
        }
        return "";
    }

    private boolean isPHCReallyRunning() {
        final Semaphore waitLockCheck = new Semaphore(0);
        final boolean[] lockFileExist = new boolean[1];
        this.sshRepository.executeCommand("ls " + PHC_LOCK_FILE + " 2>/dev/null", null, new SSHRepository.AsyncCallback() {

            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                lockFileExist[0] = line.contains(PHC_LOCK_FILE);
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) { }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                waitLockCheck.release();
            }
        });

        try {
            waitLockCheck.acquire(1);
        } catch (InterruptedException e) {
            LOG.warning("Checking PHC lock file has been interrupted.");
        }

        return lockFileExist[0];
    }
}
