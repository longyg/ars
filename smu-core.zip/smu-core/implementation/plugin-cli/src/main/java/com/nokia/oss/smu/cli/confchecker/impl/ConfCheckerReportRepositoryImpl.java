package com.nokia.oss.smu.cli.confchecker.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.cli.confchecker.dal.ConfCheckerReportRepository;
import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport;
import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport_;
import com.nokia.oss.smu.data.jpa.JoinOptimizers;

@Repository
public class ConfCheckerReportRepositoryImpl implements ConfCheckerReportRepository {
    
    @PersistenceContext
    private EntityManager em;

    @Override
    public void persist(ConfCheckerReport task) {
        this.em.persist(task);
    }

    @Override
    public void deleteAll() {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaDelete<ConfCheckerReport> cd = cb.createCriteriaDelete(ConfCheckerReport.class);
        cd.from(ConfCheckerReport.class);
        this.em.createQuery(cd).executeUpdate();
    }

    @Override
    public ConfCheckerReport getNewest(String... includePaths) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        
        CriteriaQuery<ConfCheckerReport> cq = cb.createQuery(ConfCheckerReport.class);
        Root<ConfCheckerReport> task = cq.from(ConfCheckerReport.class);
        Subquery<Long> sq;
        {
            sq = cq.subquery(Long.class);
            Root<ConfCheckerReport> sTask = sq.from(ConfCheckerReport.class);
            sq.select(cb.max(sTask.get(ConfCheckerReport_.id)));
        }
        JoinOptimizers.addIncludePaths(task, includePaths);
        cq.where(cb.equal(task.get(ConfCheckerReport_.id), sq));
        List<ConfCheckerReport> tasks = this.em.createQuery(cq).getResultList();
        return tasks.isEmpty() ? null : tasks.get(0);
    }
}
