package com.nokia.oss.smu.cli.confchecker.dal;

import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport;

public interface ConfCheckerReportRepository {
    
    void persist(ConfCheckerReport task);
    
    void deleteAll();
    
    ConfCheckerReport getNewest(String ... includePaths);
}
