package com.nokia.oss.smu.cli.logbrowser.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "SMU_LB_KEYWORD")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="KTYPE", discriminatorType = DiscriminatorType.STRING, length= 32)
@SequenceGenerator(
        name = "keywordSequence",
        sequenceName = "SMU_LB_KEYWORD_ID_SEQ",
        initialValue = 1,
        allocationSize = 1
)
abstract public class Keyword {
    @Id
    @Column(name = "KEYWORD_ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "keywordSequence")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TASK_ID", nullable = false)
    @JsonIgnore
    private LogSearchTask task;

    @Column(name = "KEYWORD", length = 4000)
    private String value;

    public Keyword() {}

    public Keyword(LogSearchTask task, String value) {
        this.task = task;
        this.value = value;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LogSearchTask getTask() {
        return task;
    }

    public void setTask(LogSearchTask task) {
        this.task = task;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
