package com.nokia.oss.smu.cli.ssh.dal.impl;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.nokia.oss.credserv.credentiallibrary.CredentialReader;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class SSHConnectionFactory {
	
	private static final String CREDENTIAL_TYPE = "appserv";
	
	private static final String CREDENTIAL_INSTANCE = "appserv";
	
	private static final Logger LOGGER = Logger.getLogger(SSHConnectionFactory.class.getName());

    @Value("${smu.ssh.host}")
    private String defaultHost;

    @Value("${smu.ssh.user}")
    private String defaultUser;

    @Value("${smu.ssh.password}")
    private String defaultPassword;

    @Value("${smu.ssh.ciphers}")
    private String sshCiphers;

    @Value("${smu.ssh.kex}")
    private String sshKex;

    @Value("${smu.ssh.MAC}")
    private String sshMAC;

    public void setDefaultHost(String defaultHost) {
        this.defaultHost = defaultHost;
    }

    public void setDefaultUser(String defaultUser) {
        this.defaultUser = defaultUser;
    }

    public void setDefaultPassword(String defaultPassword) {
        this.defaultPassword = defaultPassword;
    }
    
    public Session createConnection() {
        return this.createConnection(this.defaultHost);
    }

    public Session createConnection(String host) {
        return this.createConnection(host, this.defaultUser, this.defaultPassword);
    }

    public Session createConnection(String host, String user, String password) {
        Session session = null;
        if (password == null || password.isEmpty()) {
            password = readPassword(user);
        }
        try {
            JSch jSch = new JSch();
            session = jSch.getSession(user, host, 22);
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setConfig("cipher.c2s", sshCiphers);
            session.setConfig("cipher.s2c", sshCiphers);
            session.setConfig("kex", sshKex);
            session.setConfig("mac.c2s", sshMAC);
            session.setConfig("mac.s2c", sshMAC);
            LOGGER.fine("Connecting " + host + " with user " + user + ", pass " + password);
            LOGGER.fine("connect with cipher: " + session.getConfig("cipher.c2s"));
            LOGGER.fine("connect with kex: " + session.getConfig("kex"));
            LOGGER.fine("connect with MAC: " + session.getConfig("mac.c2s"));
			session.connect();
		} catch (JSchException ex) {
			String message = "Cannot connect to the host \"" + readableHostName(host) + "\"";
			LOGGER.log(Level.SEVERE, message, ex);
			throw new SSHException(
                    ex.getMessage(),
			        message,
			        ex
			);
		}
		return session;
    }

    private static String readPassword(String user) {
        return new CredentialReader().getPassword(user, CREDENTIAL_TYPE, CREDENTIAL_INSTANCE);
    }
    
    private static String readableHostName(String hostName) {
        if ("localhost".equals(hostName) || "127.0.0.1".equals(hostName)) {
            try {
                return InetAddress.getLocalHost().getHostName();
            } catch (UnknownHostException ex) {
                LOGGER.warning("Can't get the real name of local host " + hostName);
            }
        }
        return hostName;
    }
}
