package com.nokia.oss.smu.cli.logbrowser.bll;

import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTask;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTaskPart;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;

import java.io.OutputStream;
import java.util.Collection;

public interface LogBrowserService {

    Collection<String> listScenarios();

    LogSearchTask createTask(LogSearchTaskArgument taskArgument);

    void cancelTask(long taskId);
    
    LogSearchTaskPart getTaskPart(TaskPartRequest request);

    FilePart readFilePart(String nodeName, String fileName, long offset, long maxLen);
	
	LogSearchTask createPackageTask(LogSearchTaskArgument taskArgument);

    boolean isDownloading();

    void verifyPassword(String password);

    void downloadPackage(long taskId, String password, OutputStream response);

    long getPackSizeOfTask(long taskId, String password);

    String getPackName(long taskId);
}
