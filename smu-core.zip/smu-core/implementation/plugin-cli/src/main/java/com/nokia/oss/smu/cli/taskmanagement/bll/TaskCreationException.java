package com.nokia.oss.smu.cli.taskmanagement.bll;

public class TaskCreationException extends RuntimeException {

    private static final long serialVersionUID = 1642519536723830397L;

    public TaskCreationException(String message) {
        super(message);
    }
}
