package com.nokia.oss.smu.cli.confchecker.impl;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReportItem;

public class ConfCheckerReportParser {
    private static final Logger LOGGER = Logger.getLogger(ConfCheckerReportParser.class.getName());

    public static Set<ConfCheckerReportItem> parseReport(Collection<String> rawOutput) {
        Set<ConfCheckerReportItem> reportItems = new LinkedHashSet<>();
        ConfCheckerReportItem report = new ConfCheckerReportItem();
        String emptyChangeLog = "No change history";
        for (String line : rawOutput) {
            LOGGER.log(Level.WARNING, "The line is :" + line);
            int comonIndex = line.indexOf(':');
            if (comonIndex == -1) {
                continue;
            }
            String name = line.substring(0, comonIndex);
            String value = line.substring(comonIndex + 1).trim();
            switch (name) {
            case "Host":
                report.setHostName(value);
                break;
            case "Service":
                report.setService(value);
                break;
            case "File":
                report.setFileName(value);
                break;
            case "Change history log":
                if (value.contains(emptyChangeLog)) {
                    report.setChangeLog("");
                } else {
                    report.setChangeLog(value);
                }
                reportItems.add(report);
                report = new ConfCheckerReportItem();
                break;
            }
        }
        return reportItems;
    }
}
