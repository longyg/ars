package com.nokia.oss.smu.cli.logbrowser.entities;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;

@Entity
@DiscriminatorValue("log-search")
public class LogSearchTask extends Task {

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private Collection<Keyword> keywords;

    @Column(name = "CASE_SENSITIVITY")
    private boolean caseSensitive;
    
    @Column(name = "PACK_FILES")
    private boolean packFiles;

    @Column(name = "REGULAR_EXPRESSION")
    private boolean regularExpression;

    @Column(name = "SCENARIO", length = 256)
    private String scenario;

    @Column(name = "LAST_MODIFY_START")
    private Date lastModificationStart;

    @Column(name = "LAST_MODIFY_END")
    private Date lastModificationEnd;

    @OneToMany(mappedBy = "task", cascade = CascadeType.REMOVE) //JPA cascade
    private Set<LogSearchOutput> outputs;

    public Set<LogSearchOutput> getOutputs() {
        return outputs;
    }

    public void setOutputs(Set<LogSearchOutput> outputs) {
        this.outputs = outputs;
    }

    public Collection<Keyword> getKeywords() {
        return keywords;
    }

    public void setKeywords(Collection<Keyword> keywords) {
        this.keywords = keywords;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    public void setCaseSensitive(boolean caseSensitive) {
        this.caseSensitive = caseSensitive;
    }
    
    public boolean isPackFiles() {
        return packFiles;
    }

    public void setPackFiles(boolean packFiles) {
        this.packFiles = packFiles;
    }

    public boolean isRegularExpression() {
        return regularExpression;
    }

    public void setRegularExpression(boolean regularExpression) {
        this.regularExpression = regularExpression;
    }

    public String getScenario() {
        return scenario;
    }

    public void setScenario(String scenario) {
        this.scenario = scenario;
    }

    public Date getLastModificationStart() {
        return lastModificationStart;
    }

    public void setLastModificationStart(Date lastModificationStart) {
        this.lastModificationStart = lastModificationStart;
    }

    public Date getLastModificationEnd() {
        return lastModificationEnd;
    }

    public void setLastModificationEnd(Date lastModificationEnd) {
        this.lastModificationEnd = lastModificationEnd;
    }

    public String toString() {
        ReflectionToStringBuilder builder = new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
        return builder.setExcludeFieldNames("outputs").toString();
    }
}
