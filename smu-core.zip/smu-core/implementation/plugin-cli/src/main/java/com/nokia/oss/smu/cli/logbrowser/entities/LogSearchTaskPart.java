package com.nokia.oss.smu.cli.logbrowser.entities;

import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchOutput;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.data.model.Page;

import java.util.List;

/**
 * Created by ricyang on 16-3-3.
 */
public class LogSearchTaskPart {

    private Task task;

    private Page<LogSearchOutput> outputPages;

    private List<LogSearchOutput> errors;
	
	private boolean downloading;

    public LogSearchTaskPart(Task task) {
        this.task = task;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public Page<LogSearchOutput> getOutputPages() {
        return outputPages;
    }

    public void setOutputPages(Page<LogSearchOutput> outputPages) {
        this.outputPages = outputPages;
    }

    public List<LogSearchOutput> getErrors() {
        return errors;
    }

    public void setErrors(List<LogSearchOutput> errors) {
        this.errors = errors;
    }
	
	public boolean isDownloading() {
        return downloading;
    }

    public void setDownloading(boolean downloading) {
        this.downloading = downloading;
    }

}
