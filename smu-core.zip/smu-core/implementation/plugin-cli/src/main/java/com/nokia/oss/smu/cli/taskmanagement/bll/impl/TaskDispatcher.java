package com.nokia.oss.smu.cli.taskmanagement.bll.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.hibernate.proxy.HibernateProxy;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository.AsyncTask;
import com.nokia.oss.smu.cli.taskmanagement.bll.AtomicHandler;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskExecutor;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskIdentifier;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import com.nokia.oss.smu.data.sync.Synchronized;

@Component
public class TaskDispatcher {

    private static final Logger LOGGER = Logger.getLogger(TaskDispatcher.class.getName());

    private static int MAX_RUNNING_TASK_COUNT = 4;

    private static long HEART_BEAT_TIMEOUT = 60 * 1000;

    @Resource
    private TaskRepository taskRepository;

    @Resource
    private PlatformTransactionManager transactionManager;
    
    @Resource
    private SSHRepository sshRepository;
    
    private Map<Class<? extends Task>, TaskExecutor<?>> taskExecutorMap = new ConcurrentHashMap<>();

    @Synchronized(lockName = "smu.task.lock", nowait = true)
    @Transactional
    public void dispatch() {
        LOGGER.fine("cli task dispatch start");
        this.removeHeartBeatLostTasks();
        this.stopCancellingOrRemovedTasks();
        this.startPendingTaskImpl();
        LOGGER.fine("cli task dispatch done");
    }
    
    public void registerExecutor(TaskExecutor<?> executor) {
        if (executor == null) {
            throw new IllegalArgumentException("executor cannot be null");
        }
        this.taskExecutorMap.put(executor.getTaskType(), executor);
    }
    
    private void removeHeartBeatLostTasks() {
        final TaskDispatcher that = TaskDispatcher.this;
        this.atomicExecute(new AtomicHandler() {
            @Override
            public void handle() {
                Date maxHeartBeatTime = new Date(System.currentTimeMillis() - HEART_BEAT_TIMEOUT);
                List<Task> timeoutTasks = that.taskRepository.getTasksByMaxHeartBeatTime(maxHeartBeatTime);
                
                if (timeoutTasks != null && !timeoutTasks.isEmpty()) {
                    
                    Set<AsyncTask> asyncTasks = that.sshRepository.getAsyncTasks(new SSHRepository.Predicate() {
                        @Override
                        public boolean match(AsyncTask asyncTask) {
                            return asyncTask.getIdentifier() instanceof TaskIdentifier;
                        }
                    });
                    Map<Long, AsyncTask> asyncTaskMap = new HashMap<>();
                    for (AsyncTask sshTask : asyncTasks) {
                        TaskIdentifier identifier = (TaskIdentifier)sshTask.getIdentifier();
                        asyncTaskMap.put(identifier.toLong(), sshTask);
                    }
                    
                    for (Task timeoutTask : timeoutTasks) {
                        String taskId = String.valueOf(timeoutTask.getId());
                        String cleanupCmd = String.format("sudo logbrowser --search-task-id %s --clean", taskId);
                        that.sshRepository.executeAndWait(cleanupCmd);
                        AsyncTask asyncTask = asyncTaskMap.get(timeoutTask.getId());
                        if (asyncTask != null) {
                            LOGGER.info("Terminate ssh execution for heartbeat timeout task:" + timeoutTask.getId() + " before removing from database");
                            asyncTask.close();
                        } else {
                            LOGGER.fine("Heart beat timeout for search task" + timeoutTask.getId() + ", and its ssh task has alreay been terminated");
                        }
                    }
                    
                    that.taskRepository.removeTasks(timeoutTasks);
                }
            }
        });
    }

    private void stopCancellingOrRemovedTasks() {
        
        Set<AsyncTask> asyncTasks = this.sshRepository.getAsyncTasks(new SSHRepository.Predicate() {
            @Override
            public boolean match(AsyncTask asyncTask) {
                return asyncTask.getIdentifier() instanceof TaskIdentifier;
            }
        });
        if (asyncTasks.isEmpty()) {
            return;
        }

        Map<Long, AsyncTask> runningTaskMap = new HashMap<>();
        for (AsyncTask asyncTask : asyncTasks) {
            long taskId = ((TaskIdentifier) asyncTask.getIdentifier()).toLong();
            runningTaskMap.put(taskId, asyncTask);
        }

        List<Task> aliveTasks = this.taskRepository.getExpectedAliveTasks(runningTaskMap.keySet());
        for (Task nonCancelledTask : aliveTasks) {
            runningTaskMap.remove(nonCancelledTask.getId());
        }

        for (AsyncTask asyncTask : runningTaskMap.values()) {
            LOGGER.info("The task " + ((TaskIdentifier) asyncTask.getIdentifier()).toLong()
                    + " is cancelled or removed, stop it");
            asyncTask.close();
        }
    }
    
    private void startPendingTaskImpl() {
        long runningTaskCount = this.taskRepository.getRunningTaskCount(Task.class);
        if (runningTaskCount > MAX_RUNNING_TASK_COUNT) {
            LOGGER.severe("Unable to start pending task because the number of running tasks exceeds the max.");
            return;
        }
        if (runningTaskCount == MAX_RUNNING_TASK_COUNT) {
            return;
        }
        // Only take one pending task so that every node has chance to execute
        // new task.
        Task pendingTask = this.taskRepository.getOldestPendingTask();
        if (pendingTask != null) {
            this.startTask(pendingTask);
        }
    }

    private void startTask(final Task task) {

        this.atomicExecute(new AtomicHandler() {
            @Override
            public void handle() {
                task.setStartTime(new Date());
                task.setState(TaskState.RUNNING);
                TaskDispatcher.this.taskRepository.mergeTask(task);
            }
        });

        this.executorOf(task).begin(task, new TaskExecutor.Context<Task>() {
            @Override
            public void atomic(AtomicHandler handler) {
                TaskDispatcher.this.atomicExecute(handler);
            }

            @Override
            public void finish(Task task, Throwable ex) {
                TaskDispatcher.this.finishTask(task, ex);
            }
        });
    }

    private void finishTask(final Task task, final Throwable ex) {
        LOGGER.info("Prepare to finish the task: " + task.getId());
        this.atomicExecute(new AtomicHandler() {
            @Override
            public void handle() {
                // refreshedTask may be null because of many reasons, such as: 1, heart beat timeout; 2, user change database directly
                Task refreshedTask = TaskDispatcher.this.taskRepository.getTask(task.getId());
                if (refreshedTask != null) {
                    refreshedTask.setEndTime(new Date());
                    if (refreshedTask.getState() == TaskState.STOPPING) {
                        refreshedTask.setState(TaskState.STOPPED);
                    }
                    else {
                        refreshedTask.setState(ex == null ? TaskState.FINISHED : TaskState.FAILED);
                    }
                    TaskDispatcher.this.executorOf(refreshedTask).end(refreshedTask, ex);
                    TaskDispatcher.this.taskRepository.mergeTask(refreshedTask);
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    private <T extends Task> TaskExecutor<T> executorOf(T task) {
        if (task instanceof HibernateProxy) {
            task = (T)((HibernateProxy)task).getHibernateLazyInitializer().getImplementation();
        }
        TaskExecutor<?> executor = this.taskExecutorMap.get(task.getClass());
        if (executor == null) {
            throw new IllegalStateException(
                    "Not executor for task whose type is \""
                    + task.getClass()
                    + "\""
            );
        }
        return (TaskExecutor<T>)executor;
    }
    
    private void atomicExecute(final AtomicHandler handler) {
        new TransactionTemplate(
                this.transactionManager, 
                new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW)
        ).execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(TransactionStatus status) {
                handler.handle();
                return null;
            }
        });
    }
}
