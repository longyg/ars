package com.nokia.oss.smu.cli.logbrowser.dal;

import java.util.List;

import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchOutput;
import com.nokia.oss.smu.data.model.Page;

public interface LogSearchOutputRepository {
	
	Page<LogSearchOutput> getTaskOutputs(long taskId, int pageIndex, int pageSize, String sortingField, String sortingMode);
	
	List<LogSearchOutput> getErrorOutputs(long taskId, long minExclusiveId);
	
	void persistOutput(LogSearchOutput taskOutput);
	
	void deleteErrorOutputs(long taskId);

	void deletePreviousDownloadResult(long taskId);

	String getPackageFilePath(long taskId);

}
