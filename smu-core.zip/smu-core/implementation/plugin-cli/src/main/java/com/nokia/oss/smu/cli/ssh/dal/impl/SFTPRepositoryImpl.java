package com.nokia.oss.smu.cli.ssh.dal.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

@Repository
public class SFTPRepositoryImpl implements SFTPRepository {

    private static final Logger LOGGER = Logger.getLogger(SFTPRepositoryImpl.class.getName());

    private static final Charset CHARSET = Charset.forName("utf-8");

    private static final int SFTP_RECEIVE_BUFFER_SIZE = 8 * 1024;

    private static final long READ_ONCE_TIMEOUT = 2 * 1000;

    private static final String CHANNEL_SFTP = "sftp";

    private static final int SFTP_CONNECT_TIMEOUT = 15000;

    @Value("${smu.ssh.host}")
    private String defaultHost;
    @Resource
    private SSHConnectionFactory connectionFactory;

    @Override
    public void verifyPassword(String password) {
        Session session = this.connectionFactory.createConnection(defaultHost, "root", password);
        session.disconnect();
    }

    @Override
    public long getFileSize(String filePath, String user, String password) {
        FileSizeGetter sizeGetter = new FileSizeGetter();
        try {
            this.manipulateFile(filePath, user, password, sizeGetter);
        } catch (SSHException ex) {
            LOGGER.log(Level.WARNING, "Failed to get package file size: " + filePath, ex);
        }
        return sizeGetter.getSize();
    }

    @Override
    public void downloadFile(String filePath, String user, String password, long offset, OutputStream outStream) {
        try {
            this.manipulateFile(filePath, user, password, new FileDownloader(offset, outStream));
        } catch (SSHException ex) {
            LOGGER.log(Level.WARNING, "Failed to download package file: " + filePath, ex);
            throw ex;
        }
    }

    @Override
    public FilePart readFilePart(String hostName, String fileName, long offset, long maxLen) {
        return this.readFilePart(hostName, fileName, offset, null, null, maxLen);
    }

    @Override
    public FilePart readFilePart(String hostName, String fileName, long offset, String user, String password,
            long maxLen) {
        FilePartReader filePartReader = new FilePartReader(offset, maxLen);
        try {
            this.manipulateFile(hostName, fileName, user, password, filePartReader);
            return filePartReader.getFilePart();
        } catch (SSHException ex) {
            LOGGER.log(Level.SEVERE, "Cannot read file " + fileName + "@" + hostName, ex);
            throw ex;
        }
    }

    private void manipulateFile(String hostname, String filePath, String user, String password,
            FtpFileManipulator manipulator) {
        Session con = null;
        ChannelSftp channel = null;
        try {
            if (user != null && password != null) {
                con = this.connectionFactory.createConnection(hostname, user, password);
            } else {
                con = this.connectionFactory.createConnection(hostname);
            }

            channel = (ChannelSftp) con.openChannel(CHANNEL_SFTP);
            channel.connect(SFTP_CONNECT_TIMEOUT);
            manipulator.invoke(channel, filePath);
        } catch (SftpException ex) {
            throw new SSHException(ex.getMessage(), ex.getMessage(), ex);
        } catch (IOException | JSchException ex) {
            throw new SSHException("Error occured when manipulating file: " + filePath, ex);
        } finally {
            if (channel != null) {
                channel.disconnect();
            }
            if (con != null) {
                con.disconnect();
            }
        }
    }

    private void manipulateFile(String filePath, String user, String password, FtpFileManipulator manipulator) {
        this.manipulateFile(defaultHost, filePath, user, password, manipulator);
    }

    private interface FtpFileManipulator {
        void invoke(ChannelSftp channel, String path) throws IOException, SftpException;
    }

    private static class LineCollector {
        private StringBuilder lineBuilder;
        private List<String> lines;
        private char[] cbuf;
        private int byteLen;

        public LineCollector() {
            this.lineBuilder = new StringBuilder();
            this.cbuf = new char[SFTP_RECEIVE_BUFFER_SIZE];
            this.lines = new ArrayList<String>();
        }

        public boolean collect(byte[] buf, int len) throws IOException {
            boolean lineCollected = false;
            if (len > 0) {
                this.byteLen += len;
                ByteArrayInputStream inputStream = new ByteArrayInputStream(buf, 0, len);
                try (Reader reader = new InputStreamReader(inputStream, CHARSET)) {
                    while (true) {
                        int clen = reader.read(this.cbuf);
                        if (clen == -1) {
                            break;
                        }
                        lineCollected |= this.collect(clen);
                    }
                }
            }
            return lineCollected;
        }

        private boolean collect(int clen) {
            boolean retval = false;
            char[] arr = this.cbuf;
            for (int i = 0; i < clen; i++) {
                if (arr[i] == '\n') {
                    this.lines.add(this.lineBuilder.toString());
                    this.lineBuilder = new StringBuilder();
                    retval = true;
                } else {
                    this.lineBuilder.append(arr[i]);
                }
            }
            return retval;
        }

        public List<String> getLines() {
            return lines;
        }

        public int getByteLength() {
            return this.byteLen - this.lineBuilder.toString().getBytes(CHARSET).length;
        }
    }

    private class FilePartReader implements FtpFileManipulator {

        private long offset;

        private long maxLen;

        private FilePart filePart = null;

        public FilePartReader(long offset, long maxLen) {
            this.offset = offset;
            this.maxLen = maxLen;
        }

        public FilePart getFilePart() {
            return this.filePart;
        }

        @Override
        public void invoke(ChannelSftp channel, String path) throws IOException, SftpException {
            if (offset < 0) {
                throw new IllegalArgumentException("\"offset must be greator than or equal to zero\"");
            }
            if (maxLen < 1) {
                throw new IllegalArgumentException("max length cannot be 0 or negative, given value:" + maxLen);
            }

            byte[] buf = new byte[SFTP_RECEIVE_BUFFER_SIZE];
            long readFrom = offset;
            LOGGER.info("read file " + path + " from " + offset);
            LineCollector lineCollector = new LineCollector();
            boolean collected = false;
            boolean end = false;

            long startTime = System.currentTimeMillis();

            try (InputStream in = channel.get(path)) {
                if (in.skip(readFrom) < readFrom) {
                    LOGGER.info("No more content to read.");
                    end = true;
                }
                while (!end) {
                    int len = -1;
                    try {
                        len = in.read(buf, 0, buf.length);
                    } catch (IOException ex) {
                        if (!collected) {
                            throw ex;
                        }
                        LOGGER.log(Level.WARNING, "Only partial data got due to read exception", ex);
                        break;
                    }
                    if (len == -1) {
                        end = true;
                        LOGGER.info("Read file " + path + " reaches the end.");
                        break;
                    }
                    LOGGER.finest("read " + len + " bytes from " + path);
                    if (lineCollector.collect(buf, len)) {
                        collected = true;
                    }
                    LOGGER.finest(lineCollector.getLines().size() + " lines, " + lineCollector.getByteLength()
                            + " bytes collected");
                    readFrom += len;
                    if (collected) {
                        if (len >= maxLen) {
                            LOGGER.finest("Read abort due to buffer size limit: " + maxLen + ", bytes read: " + len);
                            break;
                        }
                        long time = System.currentTimeMillis() - startTime;
                        if (time >= READ_ONCE_TIMEOUT) {
                            LOGGER.finest(
                                    "Read abort due to time limit(ms): " + READ_ONCE_TIMEOUT + ", time used(ms): " + time);
                            break;
                        }
                    }
                }
            } catch (SftpException e) {
                LOGGER.severe("Failed to open sftp file " + path + ": " + e.getMessage());
                throw e;
            }

            int byteLength = lineCollector.getByteLength();
            this.filePart = new FilePart(lineCollector.getLines(), end ? -1 : offset + byteLength);
            LOGGER.info(
                    "read file part collected lines: " + lineCollector.getLines().size() + ", bytes: " + lineCollector
                            .getByteLength());
        }
    }

    private class FileSizeGetter implements FtpFileManipulator {
        private long size;

        public long getSize() {
            return this.size;
        }

        @Override
        public void invoke(ChannelSftp channel, String path) throws IOException, SftpException {
            try {
                SftpATTRS attrs = channel.stat(path);
                this.size = attrs.getSize();
            } catch (SftpException e) {
                LOGGER.log(Level.SEVERE, "Cannot read file attributes of file " + path, e);
                throw e;
            }
        }
    }

    private class FileDownloader implements FtpFileManipulator {
        private long offset;
        private OutputStream outStream;

        public FileDownloader(long offset, OutputStream outStream) {
            this.offset = offset;
            this.outStream = outStream;
        }

        @Override
        public void invoke(ChannelSftp channel, String path) throws IOException, SftpException {
            try {
                channel.get(path, this.outStream);
            } catch (SftpException e) {
                LOGGER.log(Level.SEVERE, "Cannot download file " + path, e);
                throw e;
            }
        }
    }
}
