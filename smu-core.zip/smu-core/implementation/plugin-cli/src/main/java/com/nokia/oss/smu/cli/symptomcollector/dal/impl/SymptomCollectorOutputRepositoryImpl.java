package com.nokia.oss.smu.cli.symptomcollector.dal.impl;

import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorOutput;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorOutput_;
import com.nokia.oss.smu.cli.symptomcollector.dal.SymptomCollectorOutputRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task_;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.*;
import java.util.List;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

@Repository
public class SymptomCollectorOutputRepositoryImpl implements SymptomCollectorOutputRepository {
    private static final Logger LOG = getLogger(SymptomCollectorOutputRepositoryImpl.class.getName());

    @PersistenceContext
    private EntityManager em;

    @Override
    public String getPackagePath(long taskId) {
        String packagePath = "";
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");
        CriteriaQuery<SymptomCollectorOutput> cq = cb.createQuery(SymptomCollectorOutput.class);
        Root<SymptomCollectorOutput> symptomCollectorOutput = cq.from(SymptomCollectorOutput.class);

        cq.where(
                cb.equal(symptomCollectorOutput.get(SymptomCollectorOutput_.task).get(Task_.id), pTaskId),
                cb.isNotNull(symptomCollectorOutput.get(SymptomCollectorOutput_.packagePath))
        );

        List<SymptomCollectorOutput> outputs = this.em
                .createQuery(cq)
                .setMaxResults(1)
                .setParameter(pTaskId, taskId)
                .getResultList();

        if (outputs != null && !outputs.isEmpty()) {
            packagePath = outputs.get(0).getPackagePath();
        }
        return packagePath;
    }

    @Override
    public List<SymptomCollectorOutput> getTaskOutputs(long taskId) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");
        CriteriaQuery<SymptomCollectorOutput> cq = cb.createQuery(SymptomCollectorOutput.class);
        Root<SymptomCollectorOutput> symptomCollectorOutput = cq.from(SymptomCollectorOutput.class);

        cq.where(
                cb.equal(symptomCollectorOutput.get(SymptomCollectorOutput_.task).get(Task_.id), pTaskId),
                cb.isNotNull(symptomCollectorOutput.get(SymptomCollectorOutput_.unparsedLine))
        )
        .orderBy(cb.asc(symptomCollectorOutput.get(SymptomCollectorOutput_.id)));

        List<SymptomCollectorOutput> outputs = this.em
                .createQuery(cq)
                .setParameter(pTaskId, taskId)
                .getResultList();

        return outputs;
    }

    @Override
    public List<SymptomCollectorOutput> getErrorOutputs(long taskId) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");
        CriteriaQuery<SymptomCollectorOutput> cq = cb.createQuery(SymptomCollectorOutput.class);
        Root<SymptomCollectorOutput> symptomCollectorOutput = cq.from(SymptomCollectorOutput.class);
        cq
                .where(
                        cb.equal(symptomCollectorOutput.get(SymptomCollectorOutput_.task).get(Task_.id), pTaskId),
                        cb.isTrue(symptomCollectorOutput.get(SymptomCollectorOutput_.err))
                )
                .orderBy(cb.asc(symptomCollectorOutput.get(SymptomCollectorOutput_.id)));

        List<SymptomCollectorOutput> errorOutputs = this.em
                .createQuery(cq)
                .setParameter(pTaskId, taskId)
                .getResultList();

        LOG.fine("Fetched error outputs(size=" + errorOutputs.size() + " for task ID=" + taskId);
        return errorOutputs;
    }

    @Override
    public void persistOutput(SymptomCollectorOutput symptomCollectorOutput) {
        this.em.persist(symptomCollectorOutput);
        LOG.finest("Task output saved: " + symptomCollectorOutput);
    }
}
