package com.nokia.oss.smu.cli.taskmanagement.entities;

public final class TaskIdentifier {

    private long id;

    public TaskIdentifier(long id) {
        super();
        this.id = id;
    }

    public long toLong() {
        return this.id;
    }

    @Override
    public int hashCode() {
        return (int) (this.id ^ (this.id >>> 32));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TaskIdentifier)) {
            return false;
        }
        TaskIdentifier other = (TaskIdentifier) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "LogSearchTaskIdentifier(" + this.id + ")";
    }
}
