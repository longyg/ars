package com.nokia.oss.smu.cli.logbrowser.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("REGEXP")
public class RegularExpression extends Keyword {
    public RegularExpression() {
    }

    public RegularExpression(LogSearchTask task, String value) {
        super(task, value);
    }
}
