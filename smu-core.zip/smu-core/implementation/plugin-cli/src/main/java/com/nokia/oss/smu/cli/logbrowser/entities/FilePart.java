package com.nokia.oss.smu.cli.logbrowser.entities;

import java.util.List;

public class FilePart {

	private List<String> lines;
	private long nextOffset;

	public FilePart() {
	
	}

	public FilePart(List<String> lines, long nextOffset) {
        this.lines = lines;
        this.nextOffset = nextOffset;
    }
	
	public List<String> getLines() {
        return lines;
    }

    public void setLines(List<String> lines) {
        this.lines = lines;
    }

	public long getNextOffset() {
		return nextOffset;
	}

	public void setNextOffset(long nextOffset) {
		this.nextOffset = nextOffset;
	}
}
