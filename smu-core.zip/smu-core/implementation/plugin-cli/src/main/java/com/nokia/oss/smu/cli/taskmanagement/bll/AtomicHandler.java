package com.nokia.oss.smu.cli.taskmanagement.bll;

public interface AtomicHandler {

    void handle();
}
