package com.nokia.oss.smu.cli.taskmanagement.entities;

public enum TaskState {
	PENDING,
	RUNNING,
	STOPPING,
	STOPPED,
	FINISHED,
	FAILED
}
