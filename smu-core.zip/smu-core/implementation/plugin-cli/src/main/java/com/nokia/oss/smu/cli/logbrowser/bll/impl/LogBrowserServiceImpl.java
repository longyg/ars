package com.nokia.oss.smu.cli.logbrowser.bll.impl;

import static java.util.logging.Logger.getLogger;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.concurrent.Semaphore;
import java.util.logging.Logger;
import java.util.*;

import javax.annotation.Resource;

import com.nokia.oss.smu.cli.logbrowser.entities.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;

import com.nokia.oss.smu.cli.logbrowser.bll.LogBrowserService;
import com.nokia.oss.smu.cli.logbrowser.bll.LogSearchTaskArgument;
import com.nokia.oss.smu.cli.logbrowser.dal.LogSearchOutputRepository;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.logbrowser.entities.Keyword;
import com.nokia.oss.smu.cli.logbrowser.entities.RegularExpression;
import com.nokia.oss.smu.cli.logbrowser.entities.SimpleKeyword;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTaskPart;
import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository.AsyncTask;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskCreationException;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import com.nokia.oss.smu.data.sync.Synchronized;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

@Service
public class LogBrowserServiceImpl implements LogBrowserService {

    private static final Logger LOG = getLogger(LogBrowserServiceImpl.class.getName());

    private static final int SEARCH_TASK_LIMIT = 4;

    private static final String LIST_SCENARIO_COMMAND = "sudo /opt/oss/bin/logbrowser --list-scenario";

    private static final String USER_FOR_DOWNLOAD_PACKAGE = "root";

    @Resource
    private SSHRepository sshRepository;

    @Resource
    private SFTPRepository sftpRepository;

    @Resource
    private TaskRepository taskRepository;

    @Resource
    private LogSearchOutputRepository logSearchOutputRepository;

    @Resource
    private PlatformTransactionManager transactionManager;

    @Value("${smu.ssh.user}")
    private String user;

    @Override
    public Collection<String> listScenarios() {
        final Semaphore semaphore = new Semaphore(0);
        final Collection<String> scenarios = new LinkedHashSet<>();
        final Throwable[] sshThrowableRef = new Throwable[1];
        final StringBuilder stdErrBuilder = new StringBuilder();
        LOG.info("Executing command to list scenarios.");
        this.sshRepository.executeCommand(LIST_SCENARIO_COMMAND, null, new SSHRepository.AsyncCallback() {
            @Override
            public void stdout(AsyncTask asyncTask, String line) {
                LOG.finest("Got line from stdout: " + line);
                if (stdErrBuilder.length() == 0) {
                    scenarios.add(line);
                }
            }

            @Override
            public void stderr(AsyncTask asyncTask, String line) {
                LOG.finest("Got line from stderr: " + line);
                if (stdErrBuilder.length() != 0) {
                    stdErrBuilder.append(System.getProperty("line.separator", "\n"));
                }
                stdErrBuilder.append(line);
            }

            @Override
            public void finish(AsyncTask asyncTask, Throwable ex) {
                LOG.fine("Task execution finished.");
                semaphore.release();
                if (ex != null) {
                    sshThrowableRef[0] = ex;
                }
            }
        });

        try {
            LOG.fine("Wait for command finish by waiting for semaphore.");
            semaphore.acquire();
        } catch (InterruptedException ex) {
            LOG.severe("Command execution was interrupted: " + ex.getMessage());
            throw new SSHException(ex.getMessage(), ex);
        }

        if (sshThrowableRef[0] != null) {
            LOG.severe("Exception caught when executing command:" + sshThrowableRef[0].getMessage());
            throw new SSHException(sshThrowableRef[0].getMessage(), sshThrowableRef[0]);
        }

        if (stdErrBuilder.length() != 0) {
            LOG.warning("Stderr has following ouput during executing: " + stdErrBuilder.toString());
        }

        return scenarios;
    }

    @Transactional
    @Override
    public LogSearchTask createTask(final LogSearchTaskArgument taskArgument) {
        LOG.info("Creation of search task requested: " + taskArgument);
        long runningTaskCount = this.taskRepository.getRunningTaskCount(LogSearchTask.class);
        if (runningTaskCount >= SEARCH_TASK_LIMIT) {
            throw new TaskCreationException(
                    "There are too many searches running, please try again later.");
        }

        LogSearchTask task = new LogSearchTask();
        Date now = new Date();
        task.setCreationTime(now);
        task.setHeartBeatTime(now);
        task.setCaseSensitive(taskArgument.isCaseSensitive());
		task.setPackFiles(taskArgument.isPackFiles());

        String regExp = taskArgument.getRegExp();
        if (regExp != null && !regExp.isEmpty()) {
            task.setRegularExpression(true);
            task.setKeywords(Collections.<Keyword>singletonList(new RegularExpression(task, regExp)));
        } else {
            ArrayList<Keyword> keywords = new ArrayList<Keyword>();
            for (String keyword : taskArgument.getKeywords()) {
                if (!keyword.isEmpty()) {
                    keywords.add(new SimpleKeyword(task, keyword));
                }
            }
            task.setKeywords(keywords);
        }

        if (taskArgument.getScenario() != null) {
            task.setScenario(taskArgument.getScenario());
        }

        Date startTime = taskArgument.getModificationStart();
        if (startTime != null) {
            task.setLastModificationStart(startTime);
        }

        Date endTime = taskArgument.getModificationEnd();
        if (endTime != null) {
            task.setLastModificationEnd(endTime);
        }

        task.setState(TaskState.PENDING);
        LOG.info("Search task created: " + task);
        return (LogSearchTask)this.taskRepository.mergeTask(task);
    }
	
	@Transactional
    @Override
    public LogSearchTask createPackageTask(final LogSearchTaskArgument taskArgument) {
        LOG.info("Creation of package task requested: " + taskArgument);
        this.logSearchOutputRepository.deleteErrorOutputs(taskArgument.getTaskId());
        this.logSearchOutputRepository.deletePreviousDownloadResult(taskArgument.getTaskId());
        LogSearchTask task = (LogSearchTask)this.taskRepository.getTask(taskArgument.getTaskId());
        Date now = new Date();
        task.setCreationTime(now);
        task.setHeartBeatTime(now);
        task.setEndTime(null);
        task.setPackFiles(taskArgument.isPackFiles());
        task.setState(TaskState.PENDING);
        LOG.info("package task created: " + task);
        return (LogSearchTask)this.taskRepository.mergeTask(task);
    }

    @Synchronized(lockName = "smu.task.lock")
    @Transactional
    @Override
    public void cancelTask(long taskId) {
        LOG.fine("Cancelling task ID=" + taskId);
        Task task = this.taskRepository.getTask(taskId);
        if (task != null) {
            if (task.getState() == TaskState.PENDING) {
                LOG.info("Task " + task + " is in state of pending, stop it directly");
                task.setState(TaskState.STOPPED);
            } else if (task.getState() == TaskState.RUNNING) {
                LOG.info("Task " + task + " is stopping");
                task.setState(TaskState.STOPPING);
            }
            this.taskRepository.mergeTask(task);
        }
    }
    
    @Transactional
    public Task getTask(long id) {
        return this.taskRepository.getTask(id);
    }
    
    @Transactional(readOnly = true)
    public LogSearchTaskPart getTaskPart(TaskPartRequest request) {
        
        long taskId = request.getTaskId();
        Task task = this.taskRepository.getTaskById(taskId);
        if (task == null) {
            return null;
        }

        LogSearchTaskPart taskPart = new LogSearchTaskPart(task);
        TaskPartRequest.OutputRequest outputRequest = request.getOutputRequest();
        if (outputRequest != null) {
            LOG.fine("Get output for task ID=" + taskId
                    + ", pageIndex=" +  outputRequest.getResultPageIndex()
                    + ", pageSize=" + outputRequest.getResultPageSize()
                    + ", sortingField=" + outputRequest.getSortingField()
                    + ", sortingMode=" + outputRequest.getSortingMode()
            );
            taskPart.setOutputPages(
                    this.logSearchOutputRepository.getTaskOutputs(
                            taskId,
                            outputRequest.getResultPageIndex(),
                            outputRequest.getResultPageSize(),
                            outputRequest.getSortingField(),
                            outputRequest.getSortingMode()
                    )
            );
        }

        TaskPartRequest.ErrorRequest errorRequest = request.getErrorRequest();
        if (errorRequest != null) {
            LOG.fine("Get error outputs for task ID=" + taskId + ", from ID=" + errorRequest.getMinExclusiveId());
            taskPart.setErrors(this.logSearchOutputRepository.getErrorOutputs(taskId, errorRequest.getMinExclusiveId()));
        }

        return taskPart;
    }
    
    @Override
    public FilePart readFilePart(String hostName, String fileName, long offset, long maxLen) {
        LOG.fine("Get file content from " + hostName + ", file=" + fileName + ", offset=" + offset
                + "maxLen=" + maxLen);
        return this.sftpRepository.readFilePart(hostName, fileName, offset, maxLen);
    }
	
	@Transactional
    @Override
    public boolean isDownloading()
    {
        return this.taskRepository.isTaskPackaging();
    }

    @Override
    public void verifyPassword(String password)
    {
        LOG.info("verify password for download");
        this.sftpRepository.verifyPassword(password);
    }

    @Transactional(readOnly = true)
    @Override
    public long getPackSizeOfTask(long taskId, String password)
    {
        String packFilePath = this.logSearchOutputRepository.getPackageFilePath(taskId);
        if (packFilePath != null) {
            return this.sftpRepository.getFileSize(packFilePath, USER_FOR_DOWNLOAD_PACKAGE, password);
        }
        LOG.warning("Cannot find the package file path for task " + taskId);
        return 0;
    }

    @Override
    public void downloadPackage(final long taskId, String password, java.io.OutputStream outStream)
    {
        String packFilePath = new TransactionTemplate(
                this.transactionManager,
                new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW)
        ).execute(new TransactionCallback<String>() {
            @Override
            public String doInTransaction(TransactionStatus status) {
                return LogBrowserServiceImpl.this.logSearchOutputRepository.getPackageFilePath(taskId);
            }
        });

        if (packFilePath == null) {
            throw new SSHException("Failed to download file, cannot find the package file");
        }
        LOG.info("Start download file " + packFilePath);
        this.sftpRepository.downloadFile(packFilePath, USER_FOR_DOWNLOAD_PACKAGE, password, 0, outStream);
    }

    @Transactional(readOnly = true)
    @Override
    public String getPackName(long taskId)
    {
        String packFilePath = this.logSearchOutputRepository.getPackageFilePath(taskId);
        if (packFilePath != null) {
            return new File(packFilePath).getName();
        }
        return "";
    }
}
