package com.nokia.oss.smu.cli.ssh.dal.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.Session;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import org.springframework.stereotype.Repository;

@Repository
public class SSHRepositoryImpl implements SSHRepository {

    private static final Logger LOGGER = Logger.getLogger(SSHRepositoryImpl.class.getName());

    private static final String STDERR_PREFIX = "STDERR:";

    private static final Charset UTF8_CHARSET = Charset.forName("utf-8");

    private static final String COMMAND_PREFIX = "{ ";
    private static final String COMMAND_POSTFIX = ";} 2> >(sed 's/^/" + STDERR_PREFIX + "/' >&2)";

    private static final int SSH_CONNECT_TIMEOUT = 15000;

    @Resource
    private ExecutorService executorService;

    @Resource
    private SSHConnectionFactory connectionFactory;

    private Set<AsyncTask> asyncTaskSet = new HashSet<>();

    private ReadWriteLock asyncTaskSetLock = new ReentrantReadWriteLock();

    @Override
    public Set<AsyncTask> getAsyncTasks(Predicate predicate) {
        this.asyncTaskSetLock.readLock().lock();
        try {
            if (predicate == null) {
                return new HashSet<>(this.asyncTaskSet);
            }
            Set<AsyncTask> set = new HashSet<>();
            for (AsyncTask asyncTask : this.asyncTaskSet) {
                if (predicate.match(asyncTask)) {
                    set.add(asyncTask);
                }
            }
            return set;
        } finally {
            this.asyncTaskSetLock.readLock().unlock();
        }
    }

    @Override
    public AsyncTask executeCommand(String command, Object taskIdentifier, AsyncCallback asyncCallback) {
        final ExecutorService es = SSHRepositoryImpl.this.executorService;
        final TaskImpl taskImpl = this.new TaskImpl(command, taskIdentifier, asyncCallback);
        es.execute(new Runnable() {
            @Override
            public void run() {
                if (taskImpl.initialize()) {
                    es.execute(new OutputStreamReadingRunnable(taskImpl, new StdOutStreamHandler()));
                }
            }
        });
        return taskImpl;
    }

    void addAsyncTask(AsyncTask asyncTask) {
        this.asyncTaskSetLock.writeLock().lock();
        try {
            this.asyncTaskSet.add(asyncTask);
        } finally {
            this.asyncTaskSetLock.writeLock().unlock();
        }
    }

    void removeAsyncTask(AsyncTask asyncTask) {
        this.asyncTaskSetLock.writeLock().lock();
        try {
            this.asyncTaskSet.remove(asyncTask);
        } finally {
            this.asyncTaskSetLock.writeLock().unlock();
        }
    }

    @Override
    public int executeAndWait(String command) {
        final Semaphore semaphore = new Semaphore(0);
        final int[] rc = {-1};
        executeCommand(
                command,
                null,
                new SSHRepository.AsyncCallback() {
                    @Override
                    public void stdout(AsyncTask asyncTask, String line) {
                        LOGGER.fine("Read stdout: " + line);
                    }

                    @Override
                    public void stderr(AsyncTask asyncTask, String line) {
                        LOGGER.warning("Read stderr: " + line);
                    }

                    @Override
                    public void finish(AsyncTask asyncTask, Throwable ex) {
                        rc[0] = asyncTask.getReturnCode();
                        semaphore.release();
                    }
                });
        try {
            LOGGER.fine("Wait for command finish by waiting for semaphore.");
            semaphore.acquire();
        } catch (InterruptedException ex) {
            LOGGER.severe("Command execution was interrupted: " + ex.getMessage());
            throw new SSHException(ex.getMessage(), ex);
        }

        return rc[0];
    }

    private interface ClosingStep {
        void execute() throws Throwable;
    }

    private interface ChannelStreamHandler {
        void handleLine(TaskImpl task, String line);

        void readDone(TaskImpl task, Throwable ex);
    }

    private static class StdOutStreamHandler implements ChannelStreamHandler {

        @Override
        public void readDone(TaskImpl task, Throwable ex) {
            task.stdOutReadEnd(ex);
        }

        @Override
        public void handleLine(TaskImpl task, String line) {
            if (line.startsWith(STDERR_PREFIX)) {
                task.asyncCallback.stderr(task, line.substring(STDERR_PREFIX.length()));
                return;
            }

            task.asyncCallback.stdout(task, line);
        }
    }

    private static class OutputStreamReadingRunnable implements Runnable {

        private TaskImpl taskImpl;
        private ChannelStreamHandler streamHandler;

        OutputStreamReadingRunnable(TaskImpl taskImpl, ChannelStreamHandler streamHandler) {
            this.taskImpl = taskImpl;
            this.streamHandler = streamHandler;
        }

        @Override
        public void run() {
            try (InputStream in = taskImpl.channel.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, UTF8_CHARSET))) {
                taskImpl.channel.getErrStream().close();
                final ChannelExec channel = this.taskImpl.channel;
                boolean done = false;
                while (!done) {
                    if (channel.isClosed()) {
                        LOGGER.info("channel exit-status: " + channel.getExitStatus());
                        done = true;
                    }
                    if (in.available() > 0) {
                        String line = reader.readLine();
                        while (line != null) {
                            LOGGER.fine("line got: " + line);
                            this.streamHandler.handleLine(this.taskImpl, line);
                            line = reader.readLine();
                        }
                    }
                    if (!done) {
                        try {
                            LOGGER.fine("No output yet.");
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            LOGGER.severe("SSH execution has been interrupted");
                            channel.disconnect();
                            break;
                        }
                    }
                }
                LOGGER.info("channel closed.");
            } catch (IOException | RuntimeException ex) {
                LOGGER.log(Level.SEVERE,
                        "Failed on reading the output of task whose identifier is \"" + taskImpl.getIdentifier() + "\"",
                        ex);
                this.streamHandler.readDone(this.taskImpl, ex);
            }

            this.streamHandler.readDone(this.taskImpl, null);
        }
    }

    private class TaskImpl implements AsyncTask {

        private String command;

        private Object identifier;

        private AsyncCallback asyncCallback;

        private Session session;

        private ChannelExec channel;

        private Integer returnCode;

        private AtomicReference<Throwable> readThrowable = new AtomicReference<>();

        private AtomicBoolean closed = new AtomicBoolean();

        private Semaphore closingSemaphore = new Semaphore(0);

        private AtomicBoolean stdOutEnd = new AtomicBoolean();

        TaskImpl(String command, Object identifier, AsyncCallback asyncCallback) {
            this.command = command;
            this.identifier = identifier;
            this.asyncCallback = asyncCallback;
        }

        @Override
        public String getCommand() {
            return this.command;
        }

        @Override
        public Object getIdentifier() {
            return this.identifier;
        }

        @Override
        public boolean isClosed() {
            return this.closed.get();
        }

        @Override
        public void close() {
            this.close(null);
        }

        @Override
        public Integer getReturnCode() {
            return returnCode;
        }

        public void setReturnCode(Integer returnCode) {
            this.returnCode = returnCode;
        }

        boolean initialize() {
            try {
                this.createSSHWithoutErrorClosing(command);
                SSHRepositoryImpl.this.addAsyncTask(this);
            } catch (RuntimeException ex) {
                this.close(ex);
                LOGGER.log(Level.SEVERE, "Failed to initialize the task", ex);
                return false;
            }
            return true;
        }

        void stdOutReadEnd(Throwable ex) {
            this.stdOutEnd.set(true);
            LOGGER.fine("stdout read done");
            readEnd(ex);
        }

        void close(Throwable ex) {
            if (this.closed.compareAndSet(false, true)) {
                this.closingSemaphore.release();

                ex = this.closeImpl(ex);
                if (ex != null) {
                    LOGGER.log(Level.SEVERE, "Failed to close the async task", ex);
                }
            }
        }

        private Throwable closeImpl(final Throwable throwable) {
            final TaskImpl that = this;
            return this.executeClosingSteps(throwable, new ClosingStep() {
                @Override
                public void execute() throws Throwable {
                    SSHRepositoryImpl.this.removeAsyncTask(that);
                }
            }, new ClosingStep() {
                @Override
                public void execute() throws Throwable {
                    that.asyncCallback.finish(that, throwable);
                }
            }, new ClosingStep() {
                @Override
                public void execute() throws IOException {
                    LOGGER.log(Level.FINE, "disconnect ssh channel");
                    if (that.channel != null) {
                        that.channel.disconnect();
                        LOGGER.log(Level.FINE, "ssh channel disconnected");
                    }
                }
            }, new ClosingStep() {
                @Override
                public void execute() {
                    LOGGER.log(Level.FINE, "disconnect ssh session");
                    if (that.session != null) {
                        that.session.disconnect();
                        LOGGER.log(Level.FINE, "disconnect ssh session done");
                    }
                }
            });
        }

        private Throwable executeClosingSteps(Throwable throwable, ClosingStep... steps) {
            for (ClosingStep step : steps) {
                try {
                    step.execute();
                } catch (Throwable ex) {
                    if (throwable == null) {
                        throwable = ex;
                    }
                }
            }
            return throwable;
        }

        private void createSSHWithoutErrorClosing(String command) {
            SSHRepositoryImpl that = SSHRepositoryImpl.this;

            this.session = that.connectionFactory.createConnection();
            String cmd = COMMAND_PREFIX + command + COMMAND_POSTFIX;
            try {
                this.channel = (ChannelExec) this.session.openChannel("exec");

                // Set PTY so that when disconnect, sshd in server will signal SIGHUP to child processes.
                // http://stackoverflow.com/questions/5527405/where-is-sighup-from-sshd-forks-a-child-to-create-a-new-session-kill-this-chi
                this.channel.setPty(true);
                this.channel.setCommand(cmd);
                this.channel.setInputStream(null);
                channel.getErrStream().close();
                LOGGER.info("Executing command " + cmd + " via ssh channel now...");
                this.channel.connect(SSH_CONNECT_TIMEOUT);
            } catch (Exception ex) {
                String message = "Failed to execute \"" + cmd + "\" because of some io problems";
                LOGGER.log(Level.SEVERE, message, ex);
                throw new SSHException(message, ex);
            }
        }

        void readEnd(Throwable ex) {
            this.setReturnCode(this.channel.getExitStatus());
            this.readThrowable.compareAndSet(null, ex);
            this.close(this.readThrowable.get());
        }
    }
}
