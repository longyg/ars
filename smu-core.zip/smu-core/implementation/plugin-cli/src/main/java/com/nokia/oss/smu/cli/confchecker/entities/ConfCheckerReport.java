package com.nokia.oss.smu.cli.confchecker.entities;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "SMU_CC_REPORT")
@SequenceGenerator(
        name = "confCheckerReportSequence", 
        sequenceName = "SMU_CC_REPORT_ID_SEQ", 
        initialValue = 1, 
        allocationSize = 1
)
public class ConfCheckerReport {
    @Id
    @Column(name = "SMU_CC_REPORT_ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "confCheckerReportSequence")
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CHECK_TIME", nullable = false)
    private Date checkTime;

    @OneToMany(mappedBy = "owner", cascade = CascadeType.ALL) // JPA cascade
    @OnDelete(action = OnDeleteAction.CASCADE) // database cascade
    private Set<ConfCheckerReportItem> items;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    public Set<ConfCheckerReportItem> getItems() {
        return items;
    }

    public void setItems(Set<ConfCheckerReportItem> items) {
        this.items = items;
    }
}
