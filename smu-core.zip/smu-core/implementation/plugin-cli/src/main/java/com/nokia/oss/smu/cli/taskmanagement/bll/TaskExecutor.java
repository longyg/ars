package com.nokia.oss.smu.cli.taskmanagement.bll;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;

/*
 * The implementation class should not have generic parameters
 * but it must specify the generic parameter of this super interface.
 */
public interface TaskExecutor<T extends Task> {
    
    Class<T> getTaskType();

    void begin(T task, Context<T> ctx);
    
    /*
     * After upgrade to Java8, change this to be:
     * default void end(T task, Throwable ex) {}
     */
    void end(T task, Throwable ex);
    
    interface Context<T extends Task> {
        void atomic(AtomicHandler handler);
        void finish(T task, Throwable ex);
    }
}
