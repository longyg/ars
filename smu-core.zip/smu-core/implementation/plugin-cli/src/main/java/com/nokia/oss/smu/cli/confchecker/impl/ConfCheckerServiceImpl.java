package com.nokia.oss.smu.cli.confchecker.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nokia.oss.smu.cli.confchecker.bll.ConfCheckerService;
import com.nokia.oss.smu.cli.confchecker.dal.ConfCheckerReportRepository;
import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport;
import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReportItem;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository.AsyncTask;
import com.nokia.oss.smu.data.sync.Synchronized;

@Service
public class ConfCheckerServiceImpl implements ConfCheckerService {
    
    private static final Logger LOGGER = Logger.getLogger(ConfCheckerServiceImpl.class.getName());
    
    private static final String LINE_SEPARATOR = System.getProperty("line.separator", "\n");
    
    private static final String NO_CHANGE_HISTORY = "No change history";
    
    private static final String HOST = "Host";
    
    private static final String SERVICE = "Service";
    
    private static final String FILE = "File";
    
    private static final String LAST_BACKUP_VERSION = "Last backup version";
    
    private static final String CHANGE_HISTORY_LOG = "Change history log";

    private static final String ENABLE_ROOT_LOGIN = "Please enable root SSH login access first.";

    @Resource
    private SSHRepository sshRepository;
    
    @Resource
    private SFTPRepository sftpRepository;
    
    @Resource
    private ConfCheckerReportRepository confCheckerTaskRepository;

    @Synchronized(lockName = "conf.checker.task.lock")
    @Transactional
    @Override
    public ConfCheckerReport getReport(boolean refresh) {
        if (!refresh) {
            LOGGER.info("Try to get the existing report from database");
            ConfCheckerReport existingReport = this.confCheckerTaskRepository.getNewest(".items");
            if (existingReport != null) {
                LOGGER.info("Found the existing report from database, return directly");
                return existingReport;
            }
            LOGGER.info("No report found from database");
        }
        
        this.confCheckerTaskRepository.deleteAll();
        
        ConfCheckerReport newReport;
        LOGGER.info("Get newest report via configuration checker command");
        try {
            newReport = this.createReport();
        } catch (RuntimeException | Error ex) {
            LOGGER.log(Level.SEVERE, "Failed to get the newest report via configuration checker command", ex);
            throw ex;
        }
        
        LOGGER.info("Got the newest report via configuration checker command, then save it into database and return");
        
        this.confCheckerTaskRepository.persist(newReport);
        
        return newReport;
    }

    @Override
    public FilePart readFilePart(String hostName, String fileName, long offset, String user, String password,
                                 long maxLen) {
        return this.sftpRepository.readFilePart(hostName, fileName, offset, user, password, maxLen);
    }

    private ConfCheckerReport createReport() {
        
        String[] commands = {
                "sudo /opt/oss/bin/configurationchecker.pl --listConf",
                "sudo /opt/oss/bin/configurationchecker.pl --listChanges|tail -1|awk -F':[[:space:]]+' '{print $2}'|xargs cat"
        };
        final Collection<String>[] outs = this.callScripts(commands);
        if (LOGGER.isLoggable(Level.FINEST)) {
            for (int i = 0; i < commands.length; i++) {
                LOGGER.log(Level.FINEST, String.format("The out for command %s is:\n", commands[i]));
                for (String line : outs[i]) {
                    LOGGER.log(Level.FINEST, '\t' + line);
                }
            }
        }
        
        Collection<ConfCheckerReportItem> confItems = parseConf(outs[0]);
        List<ConfCheckerReportItem> changedItems = parseChange(outs[1]);
        
        Set<ConfCheckerReportItem> reportItems = mergeItems(confItems, changedItems);
        
        if (LOGGER.isLoggable(Level.FINEST)) {
            LOGGER.log(Level.FINEST, "The parsed data is :\n");
            LOGGER.log(Level.FINEST, reportItems.toString());
        }
        
        ConfCheckerReport report = new ConfCheckerReport();
        report.setCheckTime(new Date());
        report.setItems(reportItems); //Let JPA do the cascade persist.
        for (ConfCheckerReportItem output : reportItems) {
            output.setOwner(report); //Let each child object can change the foreign key.
        }
        return report;
    }
    
    @SuppressWarnings("unchecked")
    private Collection<String>[] callScripts(String ... commands) {
        if (commands == null || commands.length == 0) {
            return new Collection[0];
        }
        final Semaphore semaphore = new Semaphore(0);
        final Throwable[] throwables = new Throwable[commands.length];
        final Collection<String>[] outs = new Collection[commands.length];
        final Collection<String>[] errs = new Collection[commands.length];
        for (int i = outs.length - 1; i >= 0; i--) {
            outs[i] = new ArrayList<>();
            errs[i] = new ArrayList<>();
        }
        for (int i = 0; i < commands.length; i++) {
            final int commandIndex = i;
            this.sshRepository.executeCommand(
                    commands[commandIndex], 
                    null, 
                    new SSHRepository.AsyncCallback() {
                        @Override
                        public void stdout(AsyncTask asyncTask, String line) {
                            if (errs[commandIndex].isEmpty()) {
                                outs[commandIndex].add(line);
                            }
                        }
                        @Override
                        public void stderr(AsyncTask asyncTask, String line) {
                            errs[commandIndex].add(line);
                        }
                        @Override
                        public void finish(AsyncTask asyncTask, Throwable ex) {
                            semaphore.release();
                            if (ex != null) {
                                throwables[commandIndex] = ex;
                            }
                        }
                    });
        }
        
        try {
            semaphore.acquire(commands.length);
        } catch (InterruptedException ex) {
            LOGGER.severe("SSH command execution has been interrupted." + ex);
            throw new SSHException(ex.getMessage(), ex);
        }
        
        if (LOGGER.isLoggable(Level.SEVERE)) {
            for (int i = 0; i < throwables.length; i++) {
                if (throwables[i] != null) {
                    LOGGER.log(Level.SEVERE, "Failed to execute the command: " + commands[i] + " becasue of exception", throwables[i]);
                }
            }
        }
        
        SSHException sshException = null;
        for (int i = 0; i < throwables.length; i++) {
            if (throwables[i] != null) {
                if (sshException == null) {
                    sshException = new SSHException(throwables[i]);
                }
            }
        }
        if (sshException != null) {
            throw sshException;
        }
        
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < errs.length; i++) {
            if (!errs[i].isEmpty()){
                if(i > 0 && errs[i].equals(errs[i-1])){
                	continue;
                }
            	for (String line : errs[i]) {
                    builder.append('\t').append(line).append(LINE_SEPARATOR);
                }
            }
        }
        if (builder.length() != 0) {
            if (builder.indexOf(ENABLE_ROOT_LOGIN) != -1 ) {
                throw new SSHException(SSHException.ERROR_ROOT_SSH_DISABLED, "");
            } else {
                throw new SSHException(builder.toString());
            }
        }
        
        return outs;
    }
    
    private static List<ConfCheckerReportItem> parseConf(Collection<String> rawOutput) {
        List<ConfCheckerReportItem> items = new ArrayList<>();
        ConfCheckerReportItem item = new ConfCheckerReportItem();
        for (String line : rawOutput) {
            line = line.trim();
            int comonIndex = line.indexOf(':');
            if (comonIndex == -1) {
                continue;
            }
            String name = line.substring(0, comonIndex);
            String value = line.substring(comonIndex + 1).trim();
            if (name.equals(SERVICE)) {
                item.setService(value);
            } else if (name.equals(FILE)) {
                item.setFileName(value);
                items.add(item);
                item = new ConfCheckerReportItem();
            }
        }
        return items;
    }
    
    private static List<ConfCheckerReportItem> parseChange(Collection<String> rawOutput) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        List<ConfCheckerReportItem> items = new ArrayList<>();
        ConfCheckerReportItem item = new ConfCheckerReportItem();
        for (String line : rawOutput) {
            int comonIndex = line.indexOf(':');
            if (comonIndex == -1) {
                continue;
            }
            String name = line.substring(0, comonIndex);
            String value = line.substring(comonIndex + 1).trim();
            switch (name) {
            case HOST:
                item.setHostName(value);
                break;
            case SERVICE:
                item.setService(value);
                break;
            case FILE:
                item.setFileName(value);
                break;
            case LAST_BACKUP_VERSION:
                int lastDotIndex = value.lastIndexOf('.');
                if (lastDotIndex != -1) {
                    String time = value.substring(lastDotIndex + 1);
                    try {
                        item.setLastChangeTime(dateFormat.parse(time));
                    } catch (ParseException ex) {
                        LOGGER.warning(
                                "Illegal value \""
                                + value
                                + "\"of " 
                                + LAST_BACKUP_VERSION
                                + "its substring \""
                                + time
                                + "\" is not valid time format"
                        );
                    }
                }
                break;
            case CHANGE_HISTORY_LOG:
                if (!value.contains(NO_CHANGE_HISTORY)) {
                    item.setChangeLog(value);
                    items.add(item);
                }
                item = new ConfCheckerReportItem();
                break;
            }
        }

        return items;
    }
    
    private static Set<ConfCheckerReportItem> mergeItems(Collection<ConfCheckerReportItem> confItems, Collection<ConfCheckerReportItem> changedItems) {
        Set<ConfCheckerReportItem> set = new LinkedHashSet<>(
                ((confItems.size() + changedItems.size()) * 4 + 2) /3
        );
        Set<String> allUnmatchedChangedPaths =  null;
        allUnmatchedChangedPaths = new LinkedHashSet<>();
        for (ConfCheckerReportItem changedItem : changedItems) {
            allUnmatchedChangedPaths.add(distributedFileName(changedItem));
        }
        for (ConfCheckerReportItem confItem : confItems) {
            boolean add = true;
            Set<String> matchedChangedPaths = new LinkedHashSet<String>();
            for (ConfCheckerReportItem changedItem : changedItems) {
                if (patternMatch(confItem.getFileName(), changedItem.getFileName())) {
                    add = false;
                    matchedChangedPaths.add(distributedFileName(changedItem));
                    allUnmatchedChangedPaths.remove(distributedFileName(changedItem));
                }
            }
            if (add) {
                set.add(confItem);
            } else {
                LOGGER.info(
                        "The conf pattern \""
                        + confItem.getFileName()
                        + "\' is matched by files: "
                        + matchedChangedPaths
                );
            }
        }
        if (!allUnmatchedChangedPaths.isEmpty()) {
            LOGGER.severe("The changed files: " + allUnmatchedChangedPaths + " cannot be matched by any pattern");
        }
        set.addAll(changedItems);
        return set;
    }
    
    private static boolean patternMatch(String confPattern, String changedPath) {
        boolean wildcard = confPattern.indexOf('?') != -1 || confPattern.indexOf('*') != -1;
        if (!wildcard) {
            return confPattern.equals(changedPath);
        }
        String regex = confPattern
                .replace("\\", "\\\\")
                .replace("(", "\\(")
                .replace(")", "\\)")
                .replace("[", "\\[")
                .replace("]", "\\[")
                .replace("}", "\\}")
                .replace("}", "\\}")
                .replace(".", "\\.")
                .replace("+", "\\+");
        regex = regex     
                .replace("?", "[^/]")
                .replace("*", "[^/]*");
        return Pattern.matches(regex, changedPath);
    }
    
    private static String distributedFileName(ConfCheckerReportItem item) {
        return item.getHostName() + '@' + item.getFileName();
    }
}
