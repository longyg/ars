package com.nokia.oss.smu.cli.symptomcollector.entities;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import java.util.List;


public class SymptomCollectorTaskPart {

    private Task task;

    private List<SymptomCollectorOutput> outputLines;

    private List<SymptomCollectorOutput> errors;

    private boolean downloading;

    public SymptomCollectorTaskPart(Task task) {
        this.task = task;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public List<SymptomCollectorOutput> getOutputLines() {
        return outputLines;
    }

    public void setOutputLines(List<SymptomCollectorOutput> outputLines) {
        this.outputLines = outputLines;
    }

    public List<SymptomCollectorOutput> getErrors() {
        return errors;
    }

    public void setErrors(List<SymptomCollectorOutput> errors) {
        this.errors = errors;
    }

    public boolean isDownloading() {
        return downloading;
    }

    public void setDownloading(boolean downloading) {
        this.downloading = downloading;
    }
}
