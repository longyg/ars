package com.nokia.oss.smu.cli.ssh.dal;

import java.util.Set;

public interface SSHRepository {

	Set<AsyncTask> getAsyncTasks(Predicate preedicate);
	
	AsyncTask executeCommand(String command, Object taskIdentifier, AsyncCallback asyncCallback);
	
	interface Predicate {
		boolean match(AsyncTask asyncTask);
	}
	
	interface AsyncTask {
		String getCommand();
		Object getIdentifier();
		Integer getReturnCode();
		boolean isClosed();
		void close();
	}
	
	interface AsyncCallback {
		void stdout(AsyncTask asyncTask, String line);
		void stderr(AsyncTask asyncTask, String line);
		void finish(AsyncTask asyncTask, Throwable ex);
	}

	int executeAndWait(String command);
}
