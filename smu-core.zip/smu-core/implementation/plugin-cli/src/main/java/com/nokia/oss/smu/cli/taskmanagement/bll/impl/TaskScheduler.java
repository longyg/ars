package com.nokia.oss.smu.cli.taskmanagement.bll.impl;

import javax.annotation.Resource;
import javax.persistence.LockTimeoutException;
import javax.persistence.PessimisticLockException;

import com.nokia.oss.smu.core.util.LogUtils;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class TaskScheduler {

    @Resource
    private TaskDispatcher taskDispatcher;

    private static final Logger LOGGER = Logger.getLogger(TaskScheduler.class.getName());

    @Scheduled(fixedDelay = 2000, initialDelay = 5000)
    public void schedule() {
        final String taskName = "dispatching cli tasks";
        LOGGER.fine("Executing " + taskName);
        try {
            this.taskDispatcher.dispatch();
        } catch (LockTimeoutException | PessimisticLockException e) {
            LOGGER.log(Level.FINE, taskName + " skipped because timeout to get lock", LogUtils.getChainedCauses(e));
            LOGGER.log(Level.FINEST, "Exception details: ", e);
        } catch (RuntimeException | Error ex) {
            LOGGER.warning("Error in " + taskName + ": " + LogUtils.getChainedCauses(ex));
            LOGGER.log(Level.FINE, "Error in " + taskName + ": ", ex);
        }
    }
}
