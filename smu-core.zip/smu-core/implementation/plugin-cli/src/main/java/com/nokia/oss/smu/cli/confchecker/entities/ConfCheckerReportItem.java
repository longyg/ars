package com.nokia.oss.smu.cli.confchecker.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SMU_CC_REPORT_ITEM")
@SequenceGenerator(
        name = "confCheckerReportItemSequence",
        sequenceName = "SMU_CC_REPORT_ITEM_ID_SEQ",
        initialValue = 1,
        allocationSize = 1
)
public class ConfCheckerReportItem {
    @Id
    @Column(name = "SMU_CC_REPORT_ITEM_ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "confCheckerReportItemSequence")
    private Long id;

    @Column(name = "HOST_NAME", length = 256)
    private String hostName;

    @Column(name = "SERVICE", length = 256)
    private String service;

    @Column(name = "FILE_NAME", length = 4000)
    private String fileName;

    @Column(name = "CHANGE_LOG", length = 4000)
    private String changeLog;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "LAST_CHANGE_TIME")
    private Date lastChangeTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SMU_CC_REPORT_ID", nullable = false)
    @JsonIgnore
    private ConfCheckerReport owner;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getChangeLog() {
        return changeLog;
    }

    public void setChangeLog(String changeLog) {
        this.changeLog = changeLog;
    }

    public Date getLastChangeTime() {
        return lastChangeTime;
    }

    public void setLastChangeTime(Date lastChangeTime) {
        this.lastChangeTime = lastChangeTime;
    }

    public ConfCheckerReport getOwner() {
        return owner;
    }

    public void setOwner(ConfCheckerReport owner) {
        this.owner = owner;
    }
}
