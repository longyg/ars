package com.nokia.oss.smu.cli.logbrowser.entities;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "SMU_LOG_SEARCH_OUTPUT")
@SequenceGenerator(
		name = "logSearchOutputSequence",
		sequenceName = "SMU_LOG_SEARCH_OUTPUT_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class LogSearchOutput {

	@Id
	@Column(name = "LOG_SEARCH_OUTPUT_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "logSearchOutputSequence")
	private Long id;
	
	@Column(name = "UNPARSED_LINE", length = 4000)
	private String unparsedLine;
	
	@Column(name = "PASSED_NODE_NAME", length = 256)
	private String parsedNodeName;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PARSED_TIME")
	private Date parsedTime;
	
	@Column(name = "PARSED_FILE_PATH", length = 500)
	private String parsedFilePath;
	
	@Column(name = "ERR", nullable = false)
	private boolean err;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@OnDelete(action = OnDeleteAction.CASCADE) //database cascade
	@JoinColumn(name = "TASK_ID", nullable = false)
	private Task task;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUnparsedLine() {
		return unparsedLine;
	}

	public void setUnparsedLine(String unparsedLine) {
		this.unparsedLine = unparsedLine;
	}

	public String getParsedNodeName() {
		return parsedNodeName;
	}

	public void setParsedNodeName(String parsedNodeName) {
		this.parsedNodeName = parsedNodeName;
	}

	public Date getParsedTime() {
		return parsedTime;
	}

	public void setParsedTime(Date parsedTime) {
		this.parsedTime = parsedTime;
	}

	public String getParsedFilePath() {
		return parsedFilePath;
	}

	public void setParsedFilePath(String parsedFilePath) {
		this.parsedFilePath = parsedFilePath;
	}

	public boolean isErr() {
		return err;
	}

	public void setErr(boolean err) {
		this.err = err;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	@Override
	public String toString() {
		ReflectionToStringBuilder builder = new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
		return builder.setExcludeFieldNames("task").toString();
	}
}
