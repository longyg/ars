package com.nokia.oss.smu.cli.confchecker.bll;

import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;

public interface ConfCheckerService {
    
    ConfCheckerReport getReport(boolean refresh);
    
    FilePart readFilePart(String hostName, String fileName, long offset, String user, String password, long maxLen);
}
