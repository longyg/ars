package com.nokia.oss.smu.cli.symptomcollector.entities;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.util.List;

@Entity
@DiscriminatorValue("symptom-collector")
public class SymptomCollectorTask extends Task {

    @Column(name = "COMPONENT", length = 256)
    private String component;

    @Column(name = "SCENARIO", length = 256)
    private String scenario;

    @OneToMany(mappedBy = "task", cascade = CascadeType.REMOVE) //JPA cascade
    @OnDelete(action = OnDeleteAction.CASCADE) //database cascade
    private List<SymptomCollectorOutput> outputs;

    public List<SymptomCollectorOutput> getOutputs() {
        return outputs;
    }

    public void setOutputs(List<SymptomCollectorOutput> outputs) {
        this.outputs = outputs;
    }

    public String getScenario() {
        return scenario;
    }

    public void setScenario(String scenario) {
        this.scenario = scenario;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String toString() {
        ReflectionToStringBuilder builder = new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
        return builder.setExcludeFieldNames("outputs").toString();
    }
}
