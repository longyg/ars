package com.nokia.oss.smu.cli.index.bll.impl;

import com.nokia.oss.smu.cli.index.bll.IndexService;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.logging.Logger;

@Service
public class IndexServiceImpl implements IndexService{
    private static final Logger LOG = Logger.getLogger(IndexServiceImpl.class.getName());

    @Resource
    private TaskRepository taskRepository;

    @Transactional
    @Override
    public void heartBeatTask(String ids) {
        LOG.fine("Heart beat received for task ID=" + ids);

        String[] idArray = ids.split(",");
        for (String id: idArray) {
            long taskId = Long.parseLong(id);

            Task task = this.taskRepository.getTask(taskId);
            if (task != null) {
                Date now = new Date();
                task.setHeartBeatTime(now);
                LOG.fine("Heartbeat updated for task ID=" + taskId + " to " + now);
                this.taskRepository.mergeTask(task);
            }
        }
    }
}
