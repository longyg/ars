package com.nokia.oss.smu.cli.taskmanagement.entities;


import javax.persistence.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "SMU_TASK_RESULT")

public class TaskResult {

    @Id
    @Column(name = "TASK_RESULT_ID", nullable = false)
    private Long id;

    @Column(name = "RETURN_CODE")
    private Integer returnCode;

    @Column(name = "ERR", length = 1000)
    private String err;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action= OnDeleteAction.CASCADE)
    @JoinColumn(name = "TASK_ID", nullable = false)
    private Task task;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }

    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

}
