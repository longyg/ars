package com.nokia.oss.smu.cli.ssh.dal;

import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;

import java.io.OutputStream;

public interface SFTPRepository {

    FilePart readFilePart(String hostName, String fileName, long offset, long maxLen);

    FilePart readFilePart(String hostName, String fileName, long offset, String user, String password, long maxLen);

    long getFileSize(String packagePath, String user, String password);

    void downloadFile(String packagePath, String user, String password, long offset, OutputStream outStream);

    void verifyPassword(String password);

}
