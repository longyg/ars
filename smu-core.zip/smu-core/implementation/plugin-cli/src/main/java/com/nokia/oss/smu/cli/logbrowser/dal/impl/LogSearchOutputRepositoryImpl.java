package com.nokia.oss.smu.cli.logbrowser.dal.impl;

import static java.util.logging.Logger.getLogger;

import java.util.List;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nokia.oss.smu.cli.logbrowser.dal.LogSearchOutputRepository;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchOutput;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchOutput_;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task_;
import com.nokia.oss.smu.data.model.Page;
import com.nokia.oss.smu.data.model.Pages;

@Repository
public class LogSearchOutputRepositoryImpl implements LogSearchOutputRepository {

	private static final Logger LOG = getLogger(LogSearchOutputRepositoryImpl.class.getName());

	public static final String LOG_PACKAGER_RESULT_LINE_PREFIX = "Package successfully:";

	@PersistenceContext
	private EntityManager em;

	@Override
	public Page<LogSearchOutput> getTaskOutputs(long taskId, int pageIndex, int pageSize, String sortingField, String sortingMode) {
		long totalRowCount = this.createOutputQuery(Long.class, taskId, null, null).getSingleResult();
		LOG.finest("Found total row count: " + totalRowCount);
		Page<LogSearchOutput> page = Pages.createPage(
				pageIndex,
				pageSize,
				totalRowCount,
				this.createOutputQuery(LogSearchOutput.class, taskId, sortingField, sortingMode)
		);
		LOG.finest("Found data page: " + page);
		return page;
	}
	
	@Override
	public List<LogSearchOutput> getErrorOutputs(long taskId, long minExclusiveId) {
		LOG.fine("Retrieving error output for task ID=" + taskId);
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");
		ParameterExpression<Long> pMinExclusiveId = cb.parameter(Long.class, "minExclusiveId");
		
		CriteriaQuery<LogSearchOutput> cq = cb.createQuery(LogSearchOutput.class);
		Root<LogSearchOutput> logSearchOutput = cq.from(LogSearchOutput.class);
		
		cq
		.where(
				cb.equal(logSearchOutput.get(LogSearchOutput_.task).get(Task_.id), pTaskId),
				cb.gt(logSearchOutput.get(LogSearchOutput_.id), pMinExclusiveId),
				cb.isNull(logSearchOutput.get(LogSearchOutput_.parsedFilePath)),
				cb.notLike(logSearchOutput.get(LogSearchOutput_.unparsedLine), LOG_PACKAGER_RESULT_LINE_PREFIX + "%")
		)
		.orderBy(cb.asc(logSearchOutput.get(LogSearchOutput_.id)));

		List<LogSearchOutput> errorOutputs = this.em
				.createQuery(cq)
				.setParameter(pTaskId, taskId)
				.setParameter(pMinExclusiveId, minExclusiveId)
				.getResultList();
		LOG.fine("Fetched error outputs(size=" + errorOutputs.size() + " for task ID=" + taskId);
		return errorOutputs;
	}
	
	@Override
	public void deleteErrorOutputs(long taskId)
	{
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaDelete<LogSearchOutput> cd = cb.createCriteriaDelete(LogSearchOutput.class);
		Root<LogSearchOutput> logSearchOutput = cd.from(LogSearchOutput.class);
		cd.where(
				cb.equal(logSearchOutput.get(LogSearchOutput_.task).get(Task_.id), taskId),
				cb.equal(logSearchOutput.get(LogSearchOutput_.err), 1)
		);
		this.em.createQuery(cd).executeUpdate();
	}

	@Override
	public void deletePreviousDownloadResult(long taskId)
	{
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaDelete<LogSearchOutput> cd = cb.createCriteriaDelete(LogSearchOutput.class);
		Root<LogSearchOutput> logSearchOutput = cd.from(LogSearchOutput.class);
		cd.where(
				cb.equal(logSearchOutput.get(LogSearchOutput_.task).get(Task_.id), taskId),
				cb.like(logSearchOutput.get(LogSearchOutput_.unparsedLine), LOG_PACKAGER_RESULT_LINE_PREFIX + "%")
		);
		this.em.createQuery(cd).executeUpdate();
	}

	@Override
	public String getPackageFilePath(long taskId) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");

		CriteriaQuery<LogSearchOutput> cq = cb.createQuery(LogSearchOutput.class);
		Root<LogSearchOutput> logSearchOutput = cq.from(LogSearchOutput.class);

		cq.where(
						cb.equal(logSearchOutput.get(LogSearchOutput_.task).get(Task_.id), pTaskId),
						cb.like(logSearchOutput.get(LogSearchOutput_.unparsedLine), LOG_PACKAGER_RESULT_LINE_PREFIX + "%")
				)
				.orderBy(cb.asc(logSearchOutput.get(LogSearchOutput_.id)));

		List<LogSearchOutput> packageOutputs = this.em
				.createQuery(cq)
				.setParameter(pTaskId, taskId)
				.getResultList();
		if(packageOutputs != null && !packageOutputs.isEmpty()) {
			String line = packageOutputs.get(0).getUnparsedLine();
			return line.substring(LOG_PACKAGER_RESULT_LINE_PREFIX.length());
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private <T> TypedQuery<T> createOutputQuery(Class<T> resultType, long taskId,
												String sortingField, String sortingMode) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		ParameterExpression<Long> pTaskId = cb.parameter(Long.class, "taskId");
		
		CriteriaQuery<T> cq = cb.createQuery(resultType);
		Root<LogSearchOutput> logSearchOutput = cq.from(LogSearchOutput.class);
		cq.where(
				cb.equal(logSearchOutput.get(LogSearchOutput_.task).get(Task_.id), pTaskId),
				cb.isNotNull(logSearchOutput.get(LogSearchOutput_.parsedFilePath))
		);
		if (resultType == Long.class) {
			((CriteriaQuery<Long>)cq).select(cb.count(logSearchOutput));
		} else {
		    if (sortingField != null && !sortingField.isEmpty()) {
		        if ("desc".equals(sortingMode)) {
		            cq.orderBy(cb.desc(logSearchOutput.get(sortingField)));
		        } else {
		            cq.orderBy(cb.asc(logSearchOutput.get(sortingField)));
		        }
		    }
		}
		
		return this.em.createQuery(cq).setParameter(pTaskId, taskId);
	}

	@Override
	public void persistOutput(LogSearchOutput logSearchOutput) {
		this.em.persist(logSearchOutput);
		LOG.finest("Task output saved: " + logSearchOutput);
	}
}
