package com.nokia.oss.smu.cli.taskmanagement.dal;


import com.nokia.oss.smu.cli.taskmanagement.entities.TaskResult;

public interface TaskResultRepository {

    TaskResult getTaskResult(long taskId);

    void setTaskResult(TaskResult result);

}
