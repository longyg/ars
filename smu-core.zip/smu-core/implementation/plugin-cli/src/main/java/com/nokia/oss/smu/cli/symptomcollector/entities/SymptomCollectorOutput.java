package com.nokia.oss.smu.cli.symptomcollector.entities;


import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Entity
@Table(name = "SMU_SYMPTOM_OUTPUT")
@SequenceGenerator(
		name = "symptomOutputSequence",
		sequenceName = "SMU_SYMPTOM_OUTPUT_ID_SEQ",
		initialValue = 1,
		allocationSize = 1
)
public class SymptomCollectorOutput {

	@Id
	@Column(name = "SYMPTOM_OUTPUT_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "symptomOutputSequence")
	private Long id;
	
	@Column(name = "UNPARSED_LINE", length = 4000)
	private String unparsedLine;

	@Column(name = "PACKAGE_PATH", length = 256)
	private String packagePath;

	@Column(name = "ERR", nullable = false)
	private boolean err;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@OnDelete(action = OnDeleteAction.CASCADE) //database cascade
	@JoinColumn(name = "TASK_ID", nullable = false)
	private Task task;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUnparsedLine() {
		return unparsedLine;
	}

	public void setUnparsedLine(String unparsedLine) {
		this.unparsedLine = unparsedLine;
	}

	public String getPackagePath() {return packagePath;}

	public void setPackagePath(String packagePath) {this.packagePath = packagePath; }

	public boolean isErr() {
		return err;
	}

	public void setErr(boolean err) {
		this.err = err;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	@Override
	public String toString() {
		ReflectionToStringBuilder builder = new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
		return builder.setExcludeFieldNames("task").toString();
	}
}
