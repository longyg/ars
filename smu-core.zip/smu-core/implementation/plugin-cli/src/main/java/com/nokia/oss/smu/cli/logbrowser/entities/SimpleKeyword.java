package com.nokia.oss.smu.cli.logbrowser.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("SIMPLE")
public class SimpleKeyword extends Keyword {
    public SimpleKeyword() {
    }

    public SimpleKeyword(LogSearchTask task, String value) {
        super(task, value);
    }
}
