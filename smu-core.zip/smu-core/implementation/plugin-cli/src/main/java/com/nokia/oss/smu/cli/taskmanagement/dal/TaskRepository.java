package com.nokia.oss.smu.cli.taskmanagement.dal;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.nokia.oss.smu.cli.taskmanagement.entities.Task;

public interface TaskRepository {

	Task getTask(long taskId);
	
	List<Task> getTasks();

	List<Task> getExpectedAliveTasks(Iterable<Long> taskIds);
	
	Task getOldestPendingTask();
	
	long getRunningTaskCount(Class<? extends Task> cls);

	Task getTaskById(long id);
	
	List<Task> getTasksByMaxHeartBeatTime(Date maxHeartBeatTime);
	
	Task mergeTask(Task task);
	
	void removeTasks(Collection<Task> tasksToBeRemoved);
	
	boolean isTaskPackaging();
}
