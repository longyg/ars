package com.nokia.oss.smu.cli.logbrowser.bll.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.nokia.oss.smu.cli.logbrowser.dal.LogSearchOutputRepository;
import com.nokia.oss.smu.cli.logbrowser.entities.Keyword;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchOutput;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTask;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository.AsyncTask;
import com.nokia.oss.smu.cli.taskmanagement.bll.AtomicHandler;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskExecutor;
import com.nokia.oss.smu.cli.taskmanagement.bll.impl.TaskDispatcher;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskIdentifier;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;

@Component
public class LogSearchTaskExecutor implements TaskExecutor<LogSearchTask> {
    
    private static final Logger LOGGER = Logger.getLogger(LogSearchTask.class.getName());
    
    public static final String LOGBROWSER_LAST_MODIFICATION_FORMAT = "yyyyMMddHHmm";
    
    private static final Pattern TIME_AND_SPACE_PATTERN = 
            Pattern.compile("\\s+\\d\\d\\d\\d-\\d\\d-\\d\\dT\\d\\d:\\d\\d:\\d\\d\\s+");
    
    @Resource
    private LogSearchOutputRepository logSearchOutputRepository;
    
    @Resource
    private TaskDispatcher taskDispatcher;
    
    @Resource
    private SSHRepository sshRepository;
    
    @Override
    public Class<LogSearchTask> getTaskType() {
        return LogSearchTask.class;
    }
    
    @PostConstruct
    public void init() {
        this.taskDispatcher.registerExecutor(this);
    }

    @Override
    public void begin(final LogSearchTask task, final Context<LogSearchTask> ctx) {
        String command = generateShell(task);
        LOGGER.info("Prepare to start the task: " + task.getId() + " with shell command line: " + command);
        SSHRepository.AsyncCallback commandCallback = new SSHRepository.AsyncCallback() {
            
            @Override
            public void stdout(AsyncTask asyncTask, String line) {
                
                if (asyncTask.isClosed()) {
                    if (LOGGER.isLoggable(Level.FINE)) {
                        LOGGER.fine(
                                "Ignore the stdout response data of SSH because the task has beean closed, the ignored data is: " + 
                                line
                        );
                    }
                    return;
                }
                
                LogSearchOutput taskOutput = new LogSearchOutput();
                taskOutput.setTask(task);
                taskOutput.setErr(false);
                taskOutput.setUnparsedLine(line);
                Matcher matcher = TIME_AND_SPACE_PATTERN.matcher(line);
                LOGGER.fine("ssh received output : " + line);
                if (matcher.find() && matcher.start() != 0 && matcher.end() < line.length()) {
                    String nodeName = line.substring(0, matcher.start());
                    String time = line.substring(matcher.start(), matcher.end()).trim().replace('T', ' ');
                    String file = line.substring(matcher.end());
                    taskOutput.setParsedNodeName(nodeName);
                    try {
                        taskOutput.setParsedTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(time));
                    } catch (ParseException ex) {
                        throw new AssertionError("Impossible except internal bug", ex);
                    }
                    taskOutput.setParsedFilePath(file);
                }
                this.persistTaskOutput(taskOutput);
            }
            
            @Override
            public void stderr(AsyncTask asyncTask, String line) {
                
                if (asyncTask.isClosed()) {
                    if (LOGGER.isLoggable(Level.FINE)) {
                        LOGGER.fine(
                                "Ignore the stderr response data of SSH because the task has beean closed, the ignored data is: " + 
                                line
                        );
                    }
                    return;
                }
                
                LogSearchOutput taskOutput = new LogSearchOutput();
                taskOutput.setTask(task);
                taskOutput.setErr(true);
                taskOutput.setUnparsedLine(line);
                LOGGER.info("log search task stderr output:" + line);
                this.persistTaskOutput(taskOutput);
            }

            @Override
            public void finish(AsyncTask asyncTask, Throwable ex) {
                ctx.finish(task, ex);
            }
            
            private void persistTaskOutput(final LogSearchOutput logSearchOutput) {
                ctx.atomic(new AtomicHandler() {
                    @Override
                    public void handle() {
                        LogSearchTaskExecutor.this.logSearchOutputRepository.persistOutput(logSearchOutput);
                    }
                });
            }
        };
        try {
            this.sshRepository.executeCommand(command, new TaskIdentifier(task.getId()), commandCallback);
        } catch (RuntimeException | Error ex) {
            LOGGER.log(Level.SEVERE, "Can't start the SSH command: " + command, ex);
            ctx.finish(task, ex);
        }
    }

    @Override
    public void end(LogSearchTask task, Throwable ex) {
        if(task.isPackFiles()) {
            if (task.getState() == TaskState.STOPPED) {  // if the task state is STOPPED, return immediately
                return;
            } else if(this.logSearchOutputRepository.getPackageFilePath(task.getId()) == null ){ // when state is FINISHED or FAILED, but no package, always fail
                LOGGER.warning("Task:"+ task.getId() +", Package failed");
                task.setState(TaskState.FAILED);
            } else { // when state is FINISHED or FAILED state, set state to FINISHED
                LOGGER.info("Task:" + task.getId()+ ", Package success");
                task.setState(TaskState.FINISHED);
            }
        }
    }

    private String generateShell(LogSearchTask task) {
        StringBuilder builder = new StringBuilder("sudo /opt/oss/bin/logbrowser --file-only");

        if ( !task.isCaseSensitive()) {
            builder.append(" --case-insensitive");
        }
        
        if ( task.isPackFiles()) {
            builder.append(" --package -force");
        }

        if (task.isRegularExpression()) {
            builder.append(" --regexp ").append("\'");
            //TODO validate keywords must contain one keyword.
            Keyword keyword = task.getKeywords().iterator().next();
            builder.append(keyword.getValue());
            builder.append("\'");
        } else if (!task.getKeywords().isEmpty()) {
            for (Keyword keyword : task.getKeywords()) {
                builder.append(" --keyword ").append(quotedKeywordForBash(keyword.getValue()));
            }
        }

        if (task.getScenario() != null && !task.getScenario().isEmpty()) {
            builder.append(" --scenario ").append(task.getScenario());
        }

        if (task.getLastModificationStart() != null) {
            SimpleDateFormat format = new SimpleDateFormat(LOGBROWSER_LAST_MODIFICATION_FORMAT);
            builder.append(" --starttime ").append(format.format(task.getLastModificationStart()));
        }

        if (task.getLastModificationEnd() != null) {
            SimpleDateFormat format = new SimpleDateFormat(LOGBROWSER_LAST_MODIFICATION_FORMAT);
            builder.append(" --endtime ").append(format.format(task.getLastModificationEnd()));
        }
        
        builder.append(" --search-task-id ").append(task.getId());

        return builder.toString();
    }
    
    private String quotedKeywordForBash(String keyword) {
        return "\'" + keyword.replace("'", "'\"'\"'") + "\'";
    }
}
