package com.nokia.oss.smu.cli.symptomcollector.bll.impl;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import com.nokia.oss.smu.cli.symptomcollector.dal.SymptomCollectorOutputRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorOutput;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.taskmanagement.bll.AtomicHandler;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskExecutor;
import com.nokia.oss.smu.cli.taskmanagement.bll.impl.TaskDispatcher;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskIdentifier;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import org.springframework.stereotype.Component;

import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class SymptomCollectorTaskExecutor implements TaskExecutor<SymptomCollectorTask> {
    private static final Logger LOGGER = Logger.getLogger(SymptomCollectorTask.class.getName());
    private static final String PACK_OK_MESSAGE = "Package generated at : /var/opt/nokia/oss/global/NSN-mhcf/omc/symptomcollector";

    @Resource
    private SymptomCollectorOutputRepository symptomCollectorOutputRepository;

    @Resource
    private TaskDispatcher taskDispatcher;

    @Resource
    private SSHRepository sshRepository;

    @Override
    public Class<SymptomCollectorTask> getTaskType() {
        return SymptomCollectorTask.class;
    }

    @PostConstruct
    public void init() {
        this.taskDispatcher.registerExecutor(this);
    }

    @Override
    public void begin(final SymptomCollectorTask task, final Context<SymptomCollectorTask> ctx) {
        String command = generateShell(task);
        LOGGER.info("Prepare to start the task " + task.getId() + " with shell command line: " + command);
        SSHRepository.AsyncCallback commandCallback = new SSHRepository.AsyncCallback() {

            @Override
            public void stdout(SSHRepository.AsyncTask asyncTask, String line) {
                if (asyncTask.isClosed()) {
                    if (LOGGER.isLoggable(Level.FINE)) {
                        LOGGER.fine(
                                "Ignore the stdout response data of SSH because the task has beean closed, the ignored data is: " +
                                line
                        );
                    }
                    return;
                }

                LOGGER.fine("ssh received output : " + line);
                String line4db = line.replaceAll("\u001B\\[[\\d;]*[^\\d;]","");
                if (line4db.isEmpty())
                {
                    line4db = " ";
                }

                SymptomCollectorOutput taskOutput = new SymptomCollectorOutput();
                taskOutput.setTask(task);
                taskOutput.setErr(false);
                taskOutput.setUnparsedLine(line4db);
                if (line.contains(PACK_OK_MESSAGE)) {
                    LOGGER.info(line);
                    taskOutput.setPackagePath(line.substring(line.indexOf('/'), line.length()));
                }

                this.persistTaskOutput(taskOutput);
            }

            @Override
            public void stderr(SSHRepository.AsyncTask asyncTask, String line) {
                if (asyncTask.isClosed()) {
                    if (LOGGER.isLoggable(Level.FINE)) {
                        LOGGER.fine(
                                "Ignore the stderr response data of SSH because the task has beean closed, the ignored data is: " +
                                        line
                        );
                    }
                    return;
                }

                SymptomCollectorOutput taskOutput = new SymptomCollectorOutput();
                taskOutput.setTask(task);
                taskOutput.setErr(true);
                taskOutput.setUnparsedLine(line);
                LOGGER.info("symptom collector task stderr output: " + line);
                this.persistTaskOutput(taskOutput);
            }

            @Override
            public void finish(SSHRepository.AsyncTask asyncTask, Throwable ex) {
                ctx.finish(task, ex);
            }

            private void persistTaskOutput(final SymptomCollectorOutput symptomCollectorOutput) {
                ctx.atomic(new AtomicHandler() {
                    @Override
                    public void handle() {
                        SymptomCollectorTaskExecutor.this.symptomCollectorOutputRepository.persistOutput(symptomCollectorOutput);
                    }
                });
            }
        };
        try {
            this.sshRepository.executeCommand(command, new TaskIdentifier(task.getId()), commandCallback);
        } catch (RuntimeException | Error ex) {
            LOGGER.log(Level.SEVERE, "Can't start the SSH command: " + command, ex);
            ctx.finish(task, ex);
        }
    }

    @Override
    public void end(SymptomCollectorTask task, Throwable ex) {
        String packagePath = this.symptomCollectorOutputRepository.getPackagePath(task.getId());
        if ( packagePath != null && !packagePath.isEmpty()) {
            task.setState(TaskState.FINISHED);
        } else if(task.getState() != TaskState.STOPPED) {
            task.setState(TaskState.FAILED);
        }
    }

    private String generateShell(SymptomCollectorTask task) {
        String cmd = "/opt/oss/bin/symptomcollector";
        if (task.getComponent() != null && !task.getComponent().isEmpty()) {
            cmd = cmd + " --component " + task.getComponent() + " -p";
        }
        if (task.getScenario() != null && !task.getScenario().isEmpty()) {
            cmd = cmd + " --scenario " + task.getScenario() + " -p";
        }
        return cmd;
    }
}
