package com.nokia.oss.smu.cli.symptomcollector.dal;

import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorOutput;

import java.util.List;

public interface SymptomCollectorOutputRepository {

    List<SymptomCollectorOutput> getTaskOutputs(long taskId);

    List<SymptomCollectorOutput> getErrorOutputs(long taskId);

    void persistOutput(SymptomCollectorOutput taskOutput);

    String getPackagePath(long taskId);
}
