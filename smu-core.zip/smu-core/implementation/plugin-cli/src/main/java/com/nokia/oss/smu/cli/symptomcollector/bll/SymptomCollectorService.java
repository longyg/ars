package com.nokia.oss.smu.cli.symptomcollector.bll;

import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTaskPart;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import java.io.OutputStream;
import java.util.Collection;

public interface SymptomCollectorService {

    Collection<String> listComponents();

    Collection<String> listScenarios();

    SymptomCollectorTask createTask(SymptomCollectorTaskArgument taskArgument);

    void cancelTask(long taskId);
    
    void heartBeatTask(long id);
    
    SymptomCollectorTaskPart getTaskPart(TaskPartRequest request);

    void downloadPackage(long taskId, long offset, OutputStream response);

    long getPackSize(long taskId);

    String getPackName(long taskId);
}
