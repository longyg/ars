package com.nokia.oss.smu.cli.symptomcollector.bll;

public class LoadElementsException extends RuntimeException {

    private static final long serialVersionUID = -9120165898607924754L;

    public LoadElementsException(String message) {
        super(message);
    }
}
