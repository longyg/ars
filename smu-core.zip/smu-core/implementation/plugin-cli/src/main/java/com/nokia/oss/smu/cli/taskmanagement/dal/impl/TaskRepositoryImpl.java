package com.nokia.oss.smu.cli.taskmanagement.dal.impl;

import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTask;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTask_;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask_;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task_;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.*;
import javax.persistence.criteria.CriteriaBuilder.In;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;


@Repository
public class TaskRepositoryImpl implements TaskRepository {
	private static final Logger LOG = getLogger(TaskRepositoryImpl.class.getName());

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public Task getTask(long taskId) {
		LOG.fine("Retrieving task ID=" + taskId);
		return this.em.find(Task.class, taskId);
	}

	@Override
	public List<Task> getTasks() {
		LOG.fine("Retrieving all tasks");
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<Task> cq = cb.createQuery(Task.class);
		Root<Task> task = cq.from(Task.class);
		cq.orderBy(cb.desc(task.get(Task_.id)));
		return this.em.createQuery(cq).getResultList();
	}

	@Override
	public List<Task> getExpectedAliveTasks(Iterable<Long> runningTaskIds) {
		LOG.fine("Retrieving expected alive tasks" );
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<Task> cq = cb.createQuery(Task.class);
		Root<Task> task = cq.from(Task.class);
		In<Long> in = cb.in(task.get(Task_.id));
		for (Long taskId : runningTaskIds) {
			if (taskId != null) {
				in.value(taskId);
			}
		}
		cq.where(
				in, 
				cb.or(
						cb.equal(task.get(Task_.state), TaskState.PENDING),
						cb.equal(task.get(Task_.state), TaskState.RUNNING)
				)
		);
		return this.em.createQuery(cq).getResultList();
	}
	
	@Override
	public Task getOldestPendingTask() {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<Task> cq = cb.createQuery(Task.class);
		Root<Task> task = cq.from(Task.class);
		cq
		.where(cb.equal(task.get(Task_.state), TaskState.PENDING))
		.orderBy(cb.asc(task.get(Task_.id)));
		List<Task> tasks = 
				this
				.em
				.createQuery(cq)
				.setMaxResults(1)
				.getResultList();
		return tasks.isEmpty() ? null : tasks.get(0);
	}

	@Override
	public long getRunningTaskCount(Class<? extends Task> cls) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<Long> cq = cb.createQuery(Long.class);

        Root<? extends Task> task = cq.from(cls);
        cq
                .where(cb.equal(task.get(Task_.state), TaskState.RUNNING))
                .select(cb.count(task));

		return this.em.createQuery(cq).getSingleResult();
	}

	@Override
	public boolean isTaskPackaging()
	{
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaQuery<LogSearchTask> cq = cb.createQuery(LogSearchTask.class);
		Root<LogSearchTask> logSearchTask = cq.from(LogSearchTask.class);
		cq.where(
		        cb.equal(logSearchTask.get(LogSearchTask_.state), TaskState.RUNNING), 
		        cb.equal(logSearchTask.get(LogSearchTask_.packFiles), true)
		);
		List<LogSearchTask> tasks =
				        this
						.em
						.createQuery(cq)
						.setMaxResults(1)
						.getResultList();
		return !tasks.isEmpty();
	}

	@Override
	public Task getTaskById(long id) {
	    return this.em.find(Task.class, id);
	}
	
	@Override
    public List<Task> getTasksByMaxHeartBeatTime(Date maxHeartBeatTime) {
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        ParameterExpression<Date> pMaxHeartBeatTime = cb.parameter(Date.class, "maxHeartBeatTime");
        CriteriaQuery<Task> cd = cb.createQuery(Task.class);
        Root<Task> task = cd.from(Task.class);
        cd.where(cb.lessThan(task.get(Task_.heartBeatTime), pMaxHeartBeatTime));
        return
                this
                .em
                .createQuery(cd)
                .setParameter(pMaxHeartBeatTime, maxHeartBeatTime)
                .getResultList();
    }

    @Override
	public Task mergeTask(Task task) {
		return this.em.merge(task);
	}

	@Override
    public void removeTasks(Collection<Task> tasksToBeRemoved) {
        if (tasksToBeRemoved == null || tasksToBeRemoved.isEmpty()) {
            return;
        }
        if (tasksToBeRemoved.size() == 1) {
            this.em.remove(tasksToBeRemoved.iterator().next());
            return;
        }
        CriteriaBuilder cb = this.em.getCriteriaBuilder();
        CriteriaDelete<Task> cd = cb.createCriteriaDelete(Task.class);
        Root<Task> task = cd.from(Task.class);
        In<Long> idInList = cb.in(task.get(Task_.id));
        for (Task removedTask : tasksToBeRemoved) {
            idInList.value(removedTask.getId());
        }
        cd.where(idInList);
        this.em.createQuery(cd).executeUpdate();
    }
}
