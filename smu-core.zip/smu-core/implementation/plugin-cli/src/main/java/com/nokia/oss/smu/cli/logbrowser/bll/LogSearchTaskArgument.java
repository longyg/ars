package com.nokia.oss.smu.cli.logbrowser.bll;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;
import java.util.List;

public class LogSearchTaskArgument {

    private List<String> keywords;

    private String regExp;
	
	private Long taskId;

    private String scenario;

    private boolean caseSensitive;

    private Date modificationStart;

    private Date modificationEnd;
	
	private boolean packFiles;

    public Long getTaskId(){return taskId;}

    public void setTaskId(Long taskId) {this.taskId = taskId;}

    public String getRegExp() {
        return regExp;
    }

    public void setRegExp(String regExp) {
        this.regExp = regExp;
    }

    public List<String> getKeywords() {
        return keywords;
    }

    public void setKeywords(List<String> keywords) {
        this.keywords = keywords;
    }

    public String getScenario() {
        return scenario;
    }

    public void setScenario(String scenario) {
        this.scenario = scenario;
    }

    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    public void setCaseSensitive(boolean caseSensitive) {
        this.caseSensitive = caseSensitive;
    }

    public Date getModificationStart() {
        return modificationStart;
    }

    public void setModificationStart(Date modificationStart) {
        this.modificationStart = modificationStart;
    }

    public Date getModificationEnd() {
        return modificationEnd;
    }

    public void setModificationEnd(Date modificationEnd) {
        this.modificationEnd = modificationEnd;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
	
	public boolean isPackFiles() {
        return packFiles;
    }

    public void setPackFiles(boolean packFiles) {
        this.packFiles = packFiles;
    }
    
}
