package com.nokia.oss.smu.cli.taskmanagement.entities;

/**
 * Created by ricyang on 16-3-3.
 */
public class TaskPartRequest {

    private long taskId;

    private OutputRequest outputRequest;

    private ErrorRequest errorRequest;

    public OutputRequest getOutputRequest() {
        return outputRequest;
    }

    public void setOutputRequest(OutputRequest outputRequest) {
        this.outputRequest = outputRequest;
    }

    public ErrorRequest getErrorRequest() {
        return errorRequest;
    }

    public void setErrorRequest(ErrorRequest errorRequest) {
        this.errorRequest = errorRequest;
    }

    public long getTaskId() {
        return taskId;
    }

    public void setTaskId(long taskId) {
        this.taskId = taskId;
    }

    public static class HeartbeatRequest {
        private long taskId;

        public long getTaskId() {
            return taskId;
        }

        public void setTaskId(long taskId) {
            this.taskId = taskId;
        }
    }

    public static class OutputRequest {

        private int resultPageIndex;

        private int resultPageSize;

        private String sortingField;

        private String sortingMode;

        private long errorMinExclusiveId;

        public int getResultPageIndex() {
            return resultPageIndex;
        }

        public void setResultPageIndex(int resultPageIndex) {
            this.resultPageIndex = resultPageIndex;
        }

        public int getResultPageSize() {
            return resultPageSize;
        }

        public void setResultPageSize(int resultPageSize) {
            this.resultPageSize = resultPageSize;
        }

        public String getSortingField() {
            return sortingField;
        }

        public void setSortingField(String sortingField) {
            this.sortingField = sortingField;
        }

        public String getSortingMode() {
            return sortingMode;
        }

        public void setSortingMode(String sortingMode) {
            this.sortingMode = sortingMode;
        }

        public long getErrorMinExclusiveId() {
            return errorMinExclusiveId;
        }

        public void setErrorMinExclusiveId(long errorMinExclusiveId) {
            this.errorMinExclusiveId = errorMinExclusiveId;
        }

    }

    public static class ErrorRequest {

        private long minExclusiveId;

        public long getMinExclusiveId() {
            return minExclusiveId;
        }

        public void setMinExclusiveId(long minExclusiveId) {
            this.minExclusiveId = minExclusiveId;
        }
    }

}
