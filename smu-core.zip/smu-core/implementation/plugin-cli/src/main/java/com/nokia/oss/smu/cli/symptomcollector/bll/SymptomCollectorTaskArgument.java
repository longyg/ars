package com.nokia.oss.smu.cli.symptomcollector.bll;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import java.util.List;

public class SymptomCollectorTaskArgument {

    private List<String> components;
    private List<String> scenarios;

    private Long taskId;

    public Long getTaskId(){return taskId;}

    public void setTaskId(Long taskId) {this.taskId = taskId;}

    public List<String> getComponents() {
        return components;
    }

    public void setComponents(List<String> components) {
        this.components = components;
    }

    public List<String> getScenarios() {
        return scenarios;
    }

    public void setScenarios(List<String> scenarios) {
        this.scenarios = scenarios;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

}
