package com.nokia.oss.smu.cli.index.bll;

public interface IndexService {

    void heartBeatTask(String ids);

}
