package com.nokia.oss.smu.cli.symptomcollector.bll.impl;

import javax.annotation.Resource;

import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.symptomcollector.bll.SymptomCollectorTaskArgument;
import com.nokia.oss.smu.cli.symptomcollector.dal.SymptomCollectorOutputRepository;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorOutput;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTaskPart;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskCreationException;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskState;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import com.nokia.oss.smu.cli.ssh.dal.SFTPRepository;
import com.nokia.oss.smu.cli.ssh.dal.SSHRepository;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.OutputStream;
import java.util.*;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SymptomCollectorServiceImplTest.Config.class)
public class SymptomCollectorServiceImplTest {

    @Resource
    private FakeSSHRepository sshRepository;

    @Resource
    private FakeSFTPRepository sftpRepository;

    @Resource
    private FakeTaskRepository taskRepository;

    @Resource
    private FakeOutputRepository symptomCollectorOutputRepository;

    @Resource
    private SymptomCollectorServiceImpl symptomCollectorServiceImpl;

    private SymptomCollectorTaskArgument taskArgument;
    private Task task;

    private final List<String> components = new ArrayList<>();
    private final List<String> scenarios = new ArrayList<>();

    private final static long TASK_ID = 12345678L;
    private final static String LIST_COMPONENTS_CMD = "/opt/oss/bin/symptomcollector --list-components";
    private final static String LIST_SCENARIOS_CMD = "/opt/oss/bin/symptomcollector --list-scenarios";

    @Before
    public void setUp() {
        sshRepository.clear();

        components.add("1) TestComponents");
        scenarios.add("11) TestScenarios");

        taskArgument = new SymptomCollectorTaskArgument();
        taskArgument.setTaskId(TASK_ID);
        taskArgument.setComponents(components);
        taskArgument.setScenarios(scenarios);

        task = new SymptomCollectorTask();
        task.setId(TASK_ID);
    }

    @Test
    public void componentsShouldBeListed_IfListComponentsCommandIsStarted() throws Exception {
        Collection<String> components4SSH = new LinkedHashSet<>();
        components4SSH.add("1) Test-component1");
        components4SSH.add("2) Test-component2");
        components4SSH.add("3 Malformed component could not be listed");
        sshRepository.setListedComponents(components4SSH);
        sshRepository.setException4AsyncCallbackFinish(null);

        Collection<String> expectedComponets = new LinkedHashSet<>();
        expectedComponets.add("Test-component1");
        expectedComponets.add("Test-component2");
        assertEquals(expectedComponets, symptomCollectorServiceImpl.listComponents());
    }

    @Test(expected = SSHException.class)
    public void componentsCouldNotBeLoaded_IfThereIsException() {
        Throwable exception = new Exception("loading components failed");
        sshRepository.setException4AsyncCallbackFinish(exception);
        symptomCollectorServiceImpl.listComponents();
    }

    @Test
    public void scenariosShouldBeListed_IfListScenariosCommandIsStarted() throws Exception {
        Collection<String> scenarios4SSH = new LinkedHashSet<>();
        scenarios4SSH.add("1) Test-scenario1");
        scenarios4SSH.add("2 Malformed scenario could not be listed");
        scenarios4SSH.add("3) Test-scenario3");
        sshRepository.setListedScenarios(scenarios4SSH);
        sshRepository.setException4AsyncCallbackFinish(null);

        Collection<String> expectedScenarios = new LinkedHashSet<>();
        expectedScenarios.add("Test-scenario1");
        expectedScenarios.add("Test-scenario3");
        assertEquals(expectedScenarios, symptomCollectorServiceImpl.listScenarios());
    }

    @Test(expected = SSHException.class)
    public void scenariosCouldNotBeLoaded_IfThereIsException() {
        Throwable exception = new Exception("loading scenarios failed");
        sshRepository.setException4AsyncCallbackFinish(exception);
        symptomCollectorServiceImpl.listScenarios();
    }

    @Test
    public void taskShouldBeCreated_IfCollectionIsStartedAndThereIsNoOtherRunning() throws Exception {
        taskRepository.setRunningTaskCount(0);
        Task task = symptomCollectorServiceImpl.createTask(taskArgument);
        assertEquals(TaskState.PENDING, task.getState());
    }

    @Test(expected = TaskCreationException.class)
    public void taskShouldNotBeCreated_IfThereIsRunningTask() {
        taskRepository.setRunningTaskCount(1);
        symptomCollectorServiceImpl.createTask(taskArgument);
    }

    @Test
    public void taskStateShouldBecomeStopped_WhenTaskStateIsPendingAndTaskIsCancelled() throws Exception {
        task.setState(TaskState.PENDING);
        taskRepository.setTask(task);
        symptomCollectorServiceImpl.cancelTask(task.getId());
        assertEquals(TaskState.STOPPED, taskRepository.getTask(TASK_ID).getState());
    }

    @Test
    public void taskStateShouldBecomeStopping_WhenTaskStateIsRunningAndTaskIsCancelled() throws Exception {
        task.setState(TaskState.RUNNING);
        taskRepository.setTask(task);
        symptomCollectorServiceImpl.cancelTask(task.getId());
        assertEquals(TaskState.STOPPING, taskRepository.getTask(TASK_ID).getState());
    }

    @Test
    public void heartbeatTaskShouldBePerformed() throws Exception {
        final Date initialTime = new Date(1L);
        task.setHeartBeatTime(initialTime);
        taskRepository.setTask(task);
        symptomCollectorServiceImpl.heartBeatTask(task.getId());
        assertNotEquals(initialTime, taskRepository.getTask(TASK_ID).getHeartBeatTime());
    }

    @Test
    public void outputsShouldBeRetrieved() throws Exception {
        TaskPartRequest request = new TaskPartRequest();
        request.setTaskId(TASK_ID);
        taskRepository.setTask(task);
        SymptomCollectorTaskPart taskPart = symptomCollectorServiceImpl.getTaskPart(request);
        assertTrue(taskPart.getOutputLines().toString().contains("Test: Collecting symptoms..."));
    }

    @Configuration
    static class Config {
        @Bean
        public SymptomCollectorServiceImpl getServiceImpl() {
            return new SymptomCollectorServiceImpl();
        }

        @Bean(name = "sftpRepository")
        public FakeSFTPRepository getSFTPRepo() {
            return new FakeSFTPRepository();
        }

        @Bean(name = "sshRepository")
        public FakeSSHRepository getSSHRepo() {
            return new FakeSSHRepository();
        }

        @Bean(name = "taskRepository")
        public FakeTaskRepository getTaskRepo() {
            return new FakeTaskRepository();
        }

        @Bean(name = "outputRepository")
        public FakeOutputRepository getOutputRepo() {
            return new FakeOutputRepository();
        }
    }

    private static class FakeSSHRepository implements SSHRepository {
        private List<String> executedCommands = new ArrayList<>();
        private List<AsyncCallback> callbacks = new ArrayList<>();
        private Collection<String> components = new LinkedHashSet<>();
        private Collection<String> scenarios = new LinkedHashSet<>();
        private Throwable ex = null;

        @Override
        public Set<AsyncTask> getAsyncTasks(Predicate predicate) {
            return null;
        }

        @Override
        public AsyncTask executeCommand(String command, Object taskIdentifier, AsyncCallback callback) {
            executedCommands.add(command);
            callbacks.add(callback);
            if (command.equals(LIST_COMPONENTS_CMD)) {
                for (String component:components) {
                    callback.stdout(null, component);
                }

            } else if (command.equals(LIST_SCENARIOS_CMD)) {
                for (String scenario:scenarios) {
                    callback.stdout(null, scenario);
                }
            }
            callback.stderr(null, "");
            callback.finish(null, ex);
            return null;
        }

        @Override
        public int executeAndWait(String command) {
            return 0;
        }

        public void setException4AsyncCallbackFinish(Throwable ex) {
            this.ex = ex;
        }

        public void setListedComponents(Collection<String> components) {
            this.components = components;
        }

        public void setListedScenarios(Collection<String> scenarios) {
            this.scenarios = scenarios;
        }

        public void clear() {
            executedCommands.clear();
            callbacks.clear();
        }
    }

    private static class FakeSFTPRepository implements SFTPRepository {
        @Override
        public FilePart readFilePart(String hostName, String fileName, long offset, long maxLen) {
            return null;
        }

        @Override
        public FilePart readFilePart(String hostName, String fileName, long offset, String user, String password,
                                     long maxLen) {
            return null;
        }

        @Override
        public void verifyPassword(String password) {
        }

        @Override
        public long getFileSize(String packagePath, String user, String password) {
            return 0;
        }

        @Override
        public void downloadFile(String packageName, String user, String password, long offset, OutputStream outStream ) {
        }
    }

    private static class FakeTaskRepository implements TaskRepository {
        private long taskCount = 0L;
        private Task task;

        @Override
        public Task getTask(long taskId) {
            return this.task;
        }

        public void setTask(Task task) {
            this.task = task;
        }

        @Override
        public List<Task> getTasks() {
            return null;
        }

        @Override
        public List<Task> getExpectedAliveTasks(Iterable<Long> taskIds) {
            return null;
        }

        @Override
        public Task getOldestPendingTask() {
            return null;
        }

        @Override
        public long getRunningTaskCount(Class<? extends Task> cls) {
            return taskCount;
        }

        public void setRunningTaskCount(long taskCount) {
            this.taskCount = taskCount;
        }

        @Override
        public Task getTaskById(long id) {
            return getTask(id);
        }

        @Override
        public List<Task> getTasksByMaxHeartBeatTime(Date maxHeartBeatTime) {
            return null;
        }

        @Override
        public Task mergeTask(Task task) {
            return task;
        }

        @Override
        public void removeTasks(Collection<Task> tasksToBeRemoved) {

        }

        @Override
        public boolean isTaskPackaging() {
            return false;
        }
    }

    private static class FakeOutputRepository implements SymptomCollectorOutputRepository {
        @Override
        public List<SymptomCollectorOutput> getTaskOutputs(long taskId) {
            List<SymptomCollectorOutput> outputs = new ArrayList<>();
            SymptomCollectorOutput output = new SymptomCollectorOutput();
            output.setId(1L);
            output.setUnparsedLine("Test: Collecting symptoms...");
            outputs.add(output);
            return outputs;
        }

        @Override
        public List<SymptomCollectorOutput> getErrorOutputs(long taskId) {
            return null;
        }

        @Override
        public void persistOutput(SymptomCollectorOutput taskOutput) {
        }

        @Override
        public String getPackagePath(long taskId) {
            return null;
        }
    }
}
