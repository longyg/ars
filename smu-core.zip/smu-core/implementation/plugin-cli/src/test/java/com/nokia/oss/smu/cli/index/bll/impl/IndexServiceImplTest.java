package com.nokia.oss.smu.cli.index.bll.impl;

import javax.annotation.Resource;

import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTask;
import com.nokia.oss.smu.cli.taskmanagement.dal.TaskRepository;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = IndexServiceImplTest.Config.class)
public class IndexServiceImplTest {

    @Resource
    private FakeTaskRepository taskRepository;

    @Resource
    private IndexServiceImpl indexServiceImpl;

    private Task task1;
    private Task task2;
    private final static long TASK_ID_1 = 12345678L;
    private final static long TASK_ID_2 = 87654321L;

    @Before
    public void setUp() {
        task1 = new SymptomCollectorTask();
        task1.setId(TASK_ID_1);

        task2 = new SymptomCollectorTask();
        task2.setId(TASK_ID_2);
    }

    @Test
    public void hearbeatTaskShouldBePerformed() throws Exception {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        final Date heartBeatTime = dateFormat.parse("2000-01-01 00:00:00");

        task1.setHeartBeatTime(heartBeatTime);
        taskRepository.addTask(task1);
        task2.setHeartBeatTime(heartBeatTime);
        taskRepository.addTask(task2);

        String ids = task1.getId().toString() + "," + task2.getId().toString();
        indexServiceImpl.heartBeatTask(ids);
        assertNotEquals(heartBeatTime, taskRepository.getTasks().get(0).getHeartBeatTime());
        assertNotEquals(heartBeatTime, taskRepository.getTasks().get(1).getHeartBeatTime());
    }

    @Configuration
    static class Config {
        @Bean
        public IndexServiceImpl getServiceImpl() {
            return new IndexServiceImpl();
        }

        @Bean(name = "taskRepository")
        public FakeTaskRepository getTaskRepo() {
            return new FakeTaskRepository();
        }
    }

    private static class FakeTaskRepository implements TaskRepository {
        private long taskCount = 0L;
        private List<Task> taskList = null;

        public FakeTaskRepository() {
            taskList = new ArrayList<>();
        }

        @Override
        public Task getTask(long taskId) {
            for (Task task :taskList) {
                if (task.getId() == taskId) {
                    return  task;
                }
            }

            return null;
        }

        @Override
        public List<Task> getTasks() {
            return taskList;
        }

        public void addTask(Task task) {
            taskList.add(task);
        }

        @Override
        public List<Task> getExpectedAliveTasks(Iterable<Long> taskIds) {
            return null;
        }

        @Override
        public Task getOldestPendingTask() {
            return null;
        }

        @Override
        public long getRunningTaskCount(Class<? extends Task> cls) {
            return taskCount;
        }

        public void setRunningTaskCount(long taskCount) {
            this.taskCount = taskCount;
        }

        @Override
        public Task getTaskById(long id) {
            return getTask(id);
        }

        @Override
        public List<Task> getTasksByMaxHeartBeatTime(Date maxHeartBeatTime) {
            return null;
        }

        @Override
        public Task mergeTask(Task task) {
            return task;
        }

        @Override
        public void removeTasks(Collection<Task> tasksToBeRemoved) {

        }

        @Override

        public boolean isTaskPackaging() {
            return false;
        }
    }
}
