package com.nokia.oss.smu.web.session;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

public class PHCPostFilter implements Filter {
    private static final Logger LOG = getLogger(PHCPostFilter.class.getName());
    private String contextPath;

    public void destroy() {
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        if (request instanceof HttpServletRequest) {
            String requestURI = ((HttpServletRequest) request).getRequestURI();
            if (requestURI.startsWith(contextPath + "/rest/phc/update")) {
                LOG.fine("PHC post request arrived, skip session timeout filter to allow insecure access.");
                requestURI = requestURI.replaceAll(((HttpServletRequest) request).getContextPath(), "");
                request.getRequestDispatcher(requestURI).forward(request, response);
                return;
            }
        }

        chain.doFilter(request, response);
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        contextPath = filterConfig.getServletContext().getContextPath();
    }
}
