package com.nokia.oss.smu.web.helper;

public class URLHelper {

    private static URLHelper instance;
    private String root;

    private URLHelper() {

    }

    public static URLHelper getInstance() {
        if (instance == null) {
            instance = new URLHelper();
        }

        return instance;
    }

    public String getRoot() {
        return root;
    }

    public void setContextPath(String contextPath) {
        root = contextPath;
    }
}
