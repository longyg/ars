package com.nokia.oss.smu.web.session;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class PermissionAspect {
	
	private static final Logger LOGGER = Logger.getLogger(PermissionAspect.class.getName());
	
	@Resource
	private Authorization authorization;
	
	@Before(
			value =
					"execution(public * com.nokia.oss.smu.web.controller.*Controller.*(..)) && "
					+ "@annotation(permission)",
			argNames = "permission"
	)
	public void validateHttpRequest(JoinPoint jp, Permission permission) throws Throwable {
		if (!this.authorization.checkPermission(permission.value())) {
			String message = 
					"The method \"" + jp.getSignature()
					+ "\" requires the permission \"" + permission.value() + "\"";
			if (LOGGER.isLoggable(Level.SEVERE)) {
				LOGGER.log(Level.SEVERE, message);
			}
          throw new HttpUnauthorizedException(message);
        }
	}
}
