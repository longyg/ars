package com.nokia.oss.smu.web.helper;

import java.util.TimeZone;

public class ServerInfo {

    public static int utcOffset() {
        return  TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 1000;
    }
    
    private ServerInfo() {}
}
