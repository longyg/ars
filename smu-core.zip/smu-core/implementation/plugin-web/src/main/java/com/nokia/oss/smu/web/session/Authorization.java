package com.nokia.oss.smu.web.session;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.nokia.oss.interfaces.pem.PEMAuthorizationQuery;
import com.nokia.oss.interfaces.pem.PEMPermission;

@Component
public class Authorization {

	private static final Logger LOGGER = Logger.getLogger(Authorization.class.getName());

	@Resource(name = "pemAuthorizationQuery")
	private PEMAuthorizationQuery pemAuthorizationQuery;

	public String getRemoteUser() {
		return getRemoteUser(null);
	}
	
	public String getRemoteUser(HttpServletRequest request) {
		if (request == null) {
			request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		}
		return request.getRemoteUser();
	}
	
	public boolean checkPermission(String permission) {
		return this.checkPermission(permission, null);
	}

	public boolean checkPermission(String permission, HttpServletRequest request) {
		if (permission == null || permission.isEmpty()) {
			throw new IllegalArgumentException("\"permission\" cannot be null or empty");
		}
		if (permission.indexOf('=') == -1) {
			throw new IllegalArgumentException("\"permission\" must contain '-'");
		}
		
		String remoteUser = this.getRemoteUser(request);
	    
	    try {
	        String permissionObject = permission.substring(0, permission.indexOf("="));
	        String permissionOperation = permission.substring(permission.indexOf("=") + 1);
	        PEMPermission pemPermission = new PEMPermission(permissionObject, permissionOperation);
	        return this.pemAuthorizationQuery.checkPermission(remoteUser, pemPermission);
	    } catch (Exception ex) {
	        LOGGER.log(Level.SEVERE, "Check user permission failed", ex);
	        return false;
	    }
	}
}
