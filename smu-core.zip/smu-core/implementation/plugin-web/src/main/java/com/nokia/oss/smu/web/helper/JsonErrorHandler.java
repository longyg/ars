package com.nokia.oss.smu.web.helper;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ObjectNode;
import org.springframework.web.util.NestedServletException;

public class JsonErrorHandler extends HttpServlet {

    private static final long serialVersionUID = 8885611498107166338L;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException {
        Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
        if (throwable != null && response.getStatus() >= 500) {
            throwable = unwrapSpringServletException(throwable);
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode node = mapper.getNodeFactory().objectNode();
            node.put("error", throwable.getMessage());
            out.print(node.toString());
        }
    }

    public void doPost(HttpServletRequest request,
                       HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private static Throwable unwrapSpringServletException(Throwable throwable) {
        if (throwable instanceof NestedServletException) {
            if (throwable.getCause() != null) {
                throwable = throwable.getCause();
            }
        }
        return throwable;
    }
}