package com.nokia.oss.smu.web.controller;

import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.symptomcollector.bll.LoadElementsException;
import com.nokia.oss.smu.cli.symptomcollector.bll.SymptomCollectorService;
import com.nokia.oss.smu.cli.symptomcollector.bll.SymptomCollectorTaskArgument;
import com.nokia.oss.smu.cli.symptomcollector.entities.SymptomCollectorTaskPart;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskCreationException;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import com.nokia.oss.smu.web.helper.DownloadHelper;
import com.nokia.oss.smu.web.session.Permission;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequestMapping("/symptom-collector")
public class SymptomCollectorController {
    @Resource
    private SymptomCollectorService symptomCollecotrService;

    @RequestMapping(value = "/components")
    @Permission("SMU=Launch")
    @ResponseBody
    public Collection<String> components() {
        Collection<String> components = this.symptomCollecotrService.listComponents();
        if (components.isEmpty()) {
            throw new LoadElementsException("No components found");
        }
        return components;
    }

    @RequestMapping(value = "/scenarios")
    @Permission("SMU=Launch")
    @ResponseBody
    public Collection<String> scenarios() {
        Collection<String> scenarios = this.symptomCollecotrService.listScenarios();
        if (scenarios.isEmpty()) {
            throw new LoadElementsException("No scenarios found");
        }
        return scenarios;
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public Task createTask(@RequestBody SymptomCollectorTaskArgument taskArgument) {
        return this.symptomCollecotrService.createTask(taskArgument);
    }

    @RequestMapping(value = "/cancel-task", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public void cancelTask(@RequestParam("taskId") long taskId) {
        this.symptomCollecotrService.cancelTask(taskId);
    }

    @RequestMapping(value = "/heartbeat-task", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public void heartBeatTask(@RequestParam("taskId") long taskId) {
        this.symptomCollecotrService.heartBeatTask(taskId);
    }

    @RequestMapping(value = "/task-part", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public SymptomCollectorTaskPart getTaskPart(@RequestBody TaskPartRequest request) {
        long taskId = request.getTaskId();
        SymptomCollectorTaskPart taskPart = this.symptomCollecotrService.getTaskPart(request);
        if (taskPart == null) {
            throw new TaskNotFoundException("Task not found: " + taskId, taskId);
        }
        return taskPart;
    }

    @RequestMapping(value = "/download-task", method = {RequestMethod.POST, RequestMethod.GET})
    @Permission("SMU=Launch")
    public void download(@RequestParam("offset") long offset,
                         @RequestParam("taskId") long taskId,
                         HttpServletResponse response )
    {
        long size = this.symptomCollecotrService.getPackSize(taskId);
        DownloadHelper.setHeadersForDownload(response, size, this.symptomCollecotrService.getPackName(taskId));
        try{
            if(size > 0) {
                int start_point = 0;
                this.symptomCollecotrService.downloadPackage(taskId, start_point, response.getOutputStream());
                response.flushBuffer();
            }
        } catch (IOException | SSHException ex) {
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "download package failed!");
            } catch (IOException ioex) {
                throw new SSHException("Unknown error happened when download package");
            }
        }
    }

    @ExceptionHandler(TaskCreationException.class)
    @ResponseBody
    public Map<String, String> handleCreateFailure(HttpServletResponse response, TaskCreationException ex) {
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        Map<String, String> errorInfo = new LinkedHashMap<>();
        errorInfo.put("error", ex.getMessage());
        return errorInfo;
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public static class TaskNotFoundException extends RuntimeException {
        private static final long serialVersionUID = 821501769684180629L;

        private long taskId;

        public TaskNotFoundException(String message, long taskId) {
            super(message);
            this.taskId = taskId;
        }

        public long getTaskId() {
            return taskId;
        }
    }
}
