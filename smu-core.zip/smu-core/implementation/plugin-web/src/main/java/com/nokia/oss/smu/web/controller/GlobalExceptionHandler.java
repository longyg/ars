package com.nokia.oss.smu.web.controller;

import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.phc.ExecutionLimitException;
import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = Logger.getLogger(GlobalExceptionHandler.class.getName());

    @Resource
    private PasswordPolicy passwordPolicy;

    @ExceptionHandler({
            // Hibernate has a class named "TransactionException" too,
            // so write its full name here to avoid making some errors during refactor
            org.springframework.transaction.TransactionException.class,
            DataAccessException.class,
            PersistenceException.class,
            HibernateException.class,
            SQLException.class
    })
    @ResponseBody
    public Map<String, String> handleDatabaseException(HttpServletResponse response, Throwable ex) {

        LOGGER.log(Level.SEVERE, "Access data base failed", ex);

        Map<String, String> errorInfo = new LinkedHashMap<String, String>();
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        errorInfo.put("error", "Database error");
        errorInfo.put("errorCategory", "database");
        return errorInfo;
    }

    @ExceptionHandler(SSHException.class)
    @ResponseBody
    public Map<String, String> handleSSHException(
            HttpServletRequest request,
            HttpServletResponse response,
            SSHException ex) {
        Map<String, String> errorInfo = new LinkedHashMap<String, String>();
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        LOGGER.fine("ssh exception error symbol: '" + ex.getErrorSymbol() + "'");
        if (SSHException.ERROR_AUTHENTICATE_FAILED.equals(ex.getErrorSymbol())) {
            long retryLeft = passwordPolicy.calculateForNextAttempt(true);
            if (retryLeft > 0) {
                errorInfo.put("retryRemains", String.valueOf(retryLeft));
            }
            errorInfo.put("error", "Authenticate failed");
        } else if ("Permission denied".equals(ex.getErrorSymbol()))  {
            // this exception is thrown when attempt to open root read only file using non-root user
            long retryLeft = passwordPolicy.calculateForNextAttempt(false);
            if (retryLeft > 0) {
                errorInfo.put("retryRemains", String.valueOf(retryLeft));
            }
        } else if (SSHException.ERROR_ROOT_SSH_DISABLED.equals(ex.getErrorSymbol())) {
            errorInfo.put("errorCategory", "rootAccess");
        } else {
            errorInfo.put("error", ex.getMessage());
        }

        if (ex.getErrorSymbol() != null) {
            errorInfo.put("errorSymbol", ex.getErrorSymbol());
        }

        LOGGER.severe("SSH Exception caught, error object return: " + errorInfo);
        return errorInfo;
    }

    @ExceptionHandler(ExecutionLimitException.class)
    @ResponseBody
    public Map<String, String> handleExecutionLimitException(HttpServletResponse response, Throwable ex) {
        Map<String, String> info = new LinkedHashMap<>();
        response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
        info.put("error", ex.getMessage());
        info.put("errorCategory", "cli");
        return info;
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Map<String, String> handleError(HttpServletResponse response, Throwable ex) {
        Map<String, String> info = new LinkedHashMap<>();
        response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        info.put("error", ex.getMessage());
        info.put("errorCategory", "unknown");
        return info;
    }
}
