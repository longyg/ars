package com.nokia.oss.smu.web.controller;

import static java.util.logging.Logger.getLogger;

import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nokia.oss.smu.web.json.ProductInformation;
import com.nokia.oss.smu.web.services.SystemProperties;

@Controller
public class Monitoring {
    private static final Logger LOG = getLogger(Monitoring.class.getName());

    @RequestMapping(value = "/system/about", method = RequestMethod.GET)
    @ResponseBody
    public ProductInformation getProductInformation() {
        ProductInformation p = new ProductInformation();
        p.setProductName(SystemProperties.getProperty("product.name"));
        p.setVersion(SystemProperties.getProperty("product.version"));
        p.setBuildNumber(SystemProperties.getProperty("product.buildNumber"));

        LOG.fine("Product information fetched: " + p.getProductName() + " - " + p.getVersion() + " - " + p.getBuildNumber());
        return p;
    }
}
