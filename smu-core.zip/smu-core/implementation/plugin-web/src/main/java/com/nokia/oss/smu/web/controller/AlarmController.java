package com.nokia.oss.smu.web.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import com.nokia.oss.smu.netact.alarm.bll.internal.InternalAlarmSynchronizer;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.nokia.oss.interfaces.fmaccess.service.ManPageInfo;
import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.OperationException;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.ComponentVisitor;
import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.view.ComponentLayer;
import com.nokia.oss.smu.core.view.ComponentRef;
import com.nokia.oss.smu.netact.alarm.AlarmManualSpec;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmService;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm;
import com.nokia.oss.smu.netact.alarm.entities.InternalAlarm.AckState;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSpecification;
import com.nokia.oss.smu.netact.alarm.entities.model.LimitedResult;
import com.nokia.oss.smu.netact.alarm.entities.model.Order;
import com.nokia.oss.smu.netact.alarm.entities.model.Order.OrderMode;
import com.nokia.oss.smu.web.json.AlarmOperation;
import com.nokia.oss.smu.web.session.Authorization;
import com.nokia.oss.smu.web.session.Permission;

@Controller
public class AlarmController {

    private static final InternalAlarmSpecification ALL_CRITICAL;
    private static final InternalAlarmSpecification ALL_MAJOR;
    private static final InternalAlarmSpecification ALL_WARNING;
    private static final InternalAlarmSpecification ALL_MINOR;
    private static final InternalAlarmSpecification ALL_SERVERITY;

    @Resource
    private InternalAlarmService alarmService;

    @Resource
    private Authorization authorization;

    @Resource
    private InternalAlarmSynchronizer synchronizer;

    static {
        InternalAlarmSpecification critical = new InternalAlarmSpecification();
        critical.setSeverities(Arrays.asList(AlarmSeverity.CRITICAL));
        ALL_CRITICAL = critical;

        InternalAlarmSpecification major = new InternalAlarmSpecification();
        major.setSeverities(Arrays.asList(AlarmSeverity.MAJOR));
        ALL_MAJOR = major;

        InternalAlarmSpecification warning = new InternalAlarmSpecification();
        warning.setSeverities(Arrays.asList(AlarmSeverity.WARNING));
        ALL_WARNING = warning;

        InternalAlarmSpecification minor = new InternalAlarmSpecification();
        minor.setSeverities(Arrays.asList(AlarmSeverity.MINOR));
        ALL_MINOR = minor;

        InternalAlarmSpecification allser = new InternalAlarmSpecification();
        allser.setSeverities(Arrays.asList(AlarmSeverity.MINOR, AlarmSeverity.MAJOR, AlarmSeverity.WARNING, AlarmSeverity.CRITICAL));
        ALL_SERVERITY = allser;
    }

    @RequestMapping("/components/list")
    @ResponseBody
    public List<ComponentRef> componentView() {
        List<ComponentRef> componentRefs = null;
        MonitoredSystem monitoredSystem = MonitorPlatform.getPlatform().getFirstMonitoredSystem();
        List<ComponentLayer> layers = monitoredSystem.getComponentView().getLayers();
        if (layers != null && layers.size() >= 1) {
            componentRefs = new ArrayList<ComponentRef>();
            for (ComponentLayer layer : layers) {
                if (layer.getComponentRefs() != null && layer.getComponentRefs().size() >= 1) {
                    componentRefs.addAll(layer.getComponentRefs());
                }
            }
        }
        if (componentRefs != null){
            Collections.sort(componentRefs, new Comparator<ComponentRef>() {
                @Override
                public int compare(ComponentRef a, ComponentRef b) {
                    return a.getDisplayName().compareTo(b.getDisplayName());
                }
            });
        }
        return componentRefs;

    }

    @RequestMapping(value = "/alarms/statistics", method = RequestMethod.GET)
    @Permission("SMU=Launch")
    @ResponseBody
    public AlarmStatistics getAlarmStatistics() {

        AlarmStatistics statistics = new AlarmStatistics();
        statistics.setCriticalCount(alarmService.count(ALL_CRITICAL));
        statistics.setMajorCount(alarmService.count(ALL_MAJOR));
        statistics.setWarningCount(alarmService.count(ALL_WARNING));
        statistics.setMinorCount(alarmService.count(ALL_MINOR));
        statistics.setAlarmUpdating(synchronizer.isSynchronizing());
        statistics.setUnmappedCount(alarmService.countUnmapped());

        return statistics;
    }

    @RequestMapping(value = "/alarms/alarmCount", method = RequestMethod.GET)
    @Permission("SMU=Launch")
    @ResponseBody
    public String getAlarmCount() {
        Long Alarmcount = alarmService.count(ALL_SERVERITY);
        if (Alarmcount != null) {
            return Alarmcount.toString();
        } else {
            return "";
        }
    }


    @RequestMapping(value = "/alarms/query", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public LimitedResult<InternalAlarm> query(@RequestBody AlarmCriteria criteria) {

        InternalAlarmSpecification spec = new InternalAlarmSpecification();
        Set<AlarmSeverity> alarmSeverities = EnumSet.noneOf(AlarmSeverity.class);
        if (criteria.isCritical()) {
            alarmSeverities.add(AlarmSeverity.CRITICAL);
        }
        if (criteria.isMajor()) {
            alarmSeverities.add(AlarmSeverity.MAJOR);
        }
        if (criteria.isMinor()) {
            alarmSeverities.add(AlarmSeverity.MINOR);
        }
        if (criteria.isWarning()) {
            alarmSeverities.add(AlarmSeverity.WARNING);
        }
        spec.setSeverities(alarmSeverities);
        if (!criteria.isIncludeAcked()) {
            spec.setAckState(AckState.UNACKED);
        }

        if (criteria.getComponentId() != null && !criteria.getComponentId().isEmpty()) {
            if ("UNMAPPED".equalsIgnoreCase(criteria.getComponentId())) {
                spec.setUnmapped(true);
            }
            else {
                final Set<String> recursiveComponentIds = new HashSet<String>();
                MonitoredSystem monitoredSystem = MonitorPlatform.getPlatform().getFirstMonitoredSystem();
                for (ComponentLayer layer : monitoredSystem.getComponentView().getLayers()) {
                    for (ComponentRef ref : layer.getComponentRefs()) {
                        if (criteria.getComponentId().equals(ref.getComponent().getId())) {
                            ref.getComponent().accept(new ComponentVisitor() {
                                @Override
                                public void visit(Component component) {
                                    recursiveComponentIds.add(component.getId());
                                }
                            });
                            break;
                        }
                    }
                }

                spec.setMappedComponentIds(recursiveComponentIds);
            }
        }
        List<Order> orders = new ArrayList<Order>();
        orders.add(
                new Order(
                        criteria.getOrder().getField(),
                        "desc".equals(criteria.getOrder().getMode()) ? OrderMode.DESCENDING : OrderMode.ASCENDING
                )
        );
        spec.setOrders(orders);
        return this.alarmService.query(spec, 1000);
    }

    @RequestMapping(value = "/alarms/operation-allowed")
    @ResponseBody
    public boolean isOperationAllowed() {
        return this.authorization.checkPermission("FM_Alarm=AlarmOperation");
    }

    @RequestMapping(value = "/alarms/update", method = RequestMethod.POST)
    @Permission("FM_Alarm=AlarmOperation")
    @ResponseBody
    public String operateAlarms(@RequestBody AlarmOperation operation) throws OperationException {
        String user = this.authorization.getRemoteUser();
        if (operation.getOperation().equals("ack")) {
            alarmService.acknowledge(operation.getIds(), user);
        } else if (operation.getOperation().equals("unack")) {
            alarmService.unacknowledge(operation.getIds(), user);
        } else if (operation.getOperation().equals("cancel")) {
            alarmService.cancel(operation.getIds(), user);
        }

        return "OK";
    }

    @RequestMapping(value = "/alarms/man-page-info", method = RequestMethod.GET)
    @Permission("SMU=Launch")
    @ResponseBody
    public ManPageInfo magePageInfo(@RequestParam("alarmId") Integer alarmId) {
        return alarmService.getManPageInfo(alarmId);
    }


    public static class AlarmCriteria {

        private boolean critical;

        private boolean major;

        private boolean minor;

        private boolean warning;

        private boolean includeAcked;

        private String componentId;

        private Order order;

        public boolean isCritical() {
            return critical;
        }

        public void setCritical(boolean critical) {
            this.critical = critical;
        }

        public boolean isMajor() {
            return major;
        }

        public void setMajor(boolean major) {
            this.major = major;
        }

        public boolean isMinor() {
            return minor;
        }

        public void setMinor(boolean minor) {
            this.minor = minor;
        }

        public boolean isWarning() {
            return warning;
        }

        public void setWarning(boolean warning) {
            this.warning = warning;
        }

        public boolean isIncludeAcked() {
            return includeAcked;
        }

        public void setIncludeAcked(boolean includeAcked) {
            this.includeAcked = includeAcked;
        }

        public String getComponentId() {
            return componentId;
        }

        public void setComponentId(String componentId) {
            this.componentId = componentId;
        }

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        public static class Order {

            private String field;

            private String mode;

            public String getField() {
                return field;
            }

            public void setField(String field) {
                this.field = field;
            }

            public String getMode() {
                return mode;
            }

            public void setMode(String mode) {
                this.mode = mode;
            }
        }
    }


    public static class AlarmStatistics {
        private long criticalCount;
        private long majorCount;
        private long warningCount;
        private long minorCount;
        private long unmappedCount;
        private boolean alarmUpdating;

        public long getCriticalCount() {
            return criticalCount;
        }

        public void setCriticalCount(long criticalCount) {
            this.criticalCount = criticalCount;
        }

        public long getMajorCount() {
            return majorCount;
        }

        public void setMajorCount(long majorCount) {
            this.majorCount = majorCount;
        }

        public long getWarningCount() {
            return warningCount;
        }

        public void setWarningCount(long warningCount) {
            this.warningCount = warningCount;
        }

        public long getMinorCount() {
            return minorCount;
        }

        public void setMinorCount(long minorCount) {
            this.minorCount = minorCount;
        }

        public boolean isAlarmUpdating() {
            return alarmUpdating;
        }

        public void setAlarmUpdating(boolean alarmUpdating) {
            this.alarmUpdating = alarmUpdating;
        }

        public long getUnmappedCount() {
            return unmappedCount;
        }

        public void setUnmappedCount(long unmappedCount) {
            this.unmappedCount = unmappedCount;
        }
    }
}
