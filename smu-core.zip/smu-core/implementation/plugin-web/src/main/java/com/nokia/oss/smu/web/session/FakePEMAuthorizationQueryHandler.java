package com.nokia.oss.smu.web.session;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class FakePEMAuthorizationQueryHandler implements InvocationHandler {

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (method.getReturnType() == boolean.class && method.getName().equals("checkPermission")) {
			return true;
		}
		throw new UnsupportedOperationException();
	}
}
