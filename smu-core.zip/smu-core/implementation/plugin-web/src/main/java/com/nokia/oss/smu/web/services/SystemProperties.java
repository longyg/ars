package com.nokia.oss.smu.web.services;

import static java.util.logging.Logger.getLogger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.core.io.ClassPathResource;

import com.nokia.oss.mpflibs.javalibs.LdapAccess;

public class SystemProperties {
    
	private static final Logger LOG = getLogger(SystemProperties.class.getName());

	private static SystemProperties instance;
	
	private Properties productProperties;

	public static String getProperty(String key) {
		return getInstance().getProductProperties().getProperty(key);
	}

	public static String getApplicationTitle(String userName) {
		return getInstance().getTitle(userName, getProperty("product.name"));
	}

	private static String getLdapValue(String path, String attr) {
		String val = null;
		String[] parts = path.split("/");
		String node = null;
		String[] attr1 = { attr };

		for (int i = 0; i < parts.length; i++) {
			if (i == 0) {
				node = "cn=" + parts[parts.length - i - 1];
			} else {
				node += ",ou=" + parts[parts.length - i - 1];
			}
		}

		node += ",ou=config";

		String filter = "objectClass=*";
		DirContext context = null;
		LdapAccess ldapAccess = new LdapAccess();
		try {
			context = ldapAccess.getInitialDirContext();
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "ldap initialization failed.", e);
		}

		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		searchControls.setReturningAttributes(attr1);
		try {
			NamingEnumeration<SearchResult> answer = context.search(node, filter.toString(), searchControls);
			if (answer.hasMore()) {
				SearchResult result = answer.next();
				NamingEnumeration<? extends Attribute> attrs = result
						.getAttributes().getAll();
				if (attrs.hasMore()) {
					Attribute attr2 = attrs.next();
					LOG.log(Level.FINE, "ldap query result: " + attr2.getID() + "=" + attr2.get());
					val = (String) attr2.get();
				}
			}
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "ldap query failed.", e);
		}

		return val;
	}

	private static SystemProperties getInstance() {
		if (instance == null) {
			instance = new SystemProperties();
		}

		return instance;
	}

	private SystemProperties() {
	}

	private Properties getProductProperties() {
		if (productProperties == null) {
			ClassPathResource resource = new ClassPathResource(
					"product.properties");
			productProperties = new Properties();
			InputStream inputStream = null;
			try {
				inputStream = resource.getInputStream();
				productProperties.load(inputStream);
			} catch (IOException ex) {
				LOG.log(Level.SEVERE, ex.getMessage(), ex);
			} finally {
				if (inputStream != null) {
					try {
						inputStream.close();
					} catch (IOException ex) {
						LOG.log(Level.SEVERE, ex.getMessage(), ex);
					}
				}
			}
		}

		return productProperties;
	}

	private String getTitle(String username, String applicationName) {
		String titleTemplate = getTitleTemplate();
		return 
		        titleTemplate
		        .replace("{user}", username != null ? username : "")
				.replace("{clusterFQDN}", getClusterFQDN())
				.replace("{clusterId}", getClusterId())
				.replace("{clusterName}", getClusterName())
				.replace("{appName}", applicationName);
	}

	private String getTitleTemplate() {
		return "{appName} - {clusterName} - {user}";
	}

	private String getClusterFQDN() {
		try {
			return getLdapValue("services/mercury/Cell1", "ossMercuryClusterFQDN");
		}
		catch (Exception ex) {
			return "<cluster FQDN>";
		}
	}

	private String getClusterId() {
		try {
			return getLdapValue("cluster/cluster", "ossAttrID");
		} catch (Exception ex) {
			return "<cluster ID>";
		}
	}

	private String getClusterName() {
		try {
			return getLdapValue("cluster/cluster", "ossAttrName");
		} catch (Exception ex) {
			return "<cluster name>";
		}
	}
}
