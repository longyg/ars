package com.nokia.oss.smu.web.helper;

import javax.servlet.http.HttpServletResponse;

public class DownloadHelper {

    private DownloadHelper() {}

    public static void setHeadersForDownload(HttpServletResponse response, long size, String fileName) {
        response.setContentType("application/x-gzip");
        response.setContentType("application/force-download");
        response.setHeader("Pragma", "public");
        response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
        response.setHeader("Content-Transfer-Encoding", "binary");
        response.setHeader("Accept-Ranges", "none");
        if (size > 0) {
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
            response.setHeader("Content-Length", String.valueOf(size));
        } else {
            response.setHeader("Content-Disposition", "attachment; filename=\"" + "Download-Failed" + "\"");
            response.setHeader("Content-Length", "0");
        }
    }
}
