package com.nokia.oss.smu.web.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nokia.oss.smu.core.MonitoredSystem;
import com.nokia.oss.smu.core.platform.MonitorPlatform;
import com.nokia.oss.smu.core.view.ComponentView;
import com.nokia.oss.smu.netact.alarm.bll.InternalAlarmService;
import com.nokia.oss.smu.netact.alarm.entities.model.InternalAlarmSummary;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {
	
	@Resource
	private InternalAlarmService internalAlarmService;

    private static final String UNMAPPED_COMPONENT_ID = "unmapped";

	@RequestMapping("/component-view")
	@ResponseBody
	public ComponentView componentView() {
		MonitoredSystem monitoredSystem = MonitorPlatform.getPlatform().getFirstMonitoredSystem();
        return monitoredSystem.getComponentView();
	}

	@RequestMapping("/internal-alarm-summaries")
	@ResponseBody
	public Map<String, InternalAlarmSummary> getInternalAlarmSummaries() {
		Map<String, InternalAlarmSummary> summaryMap = this.internalAlarmService.getSummariesForComponents();
		nameUnmappedSummary(summaryMap);
		return summaryMap;
	}

	private void nameUnmappedSummary(Map<String, InternalAlarmSummary> summaryMap) {
		InternalAlarmSummary unmapped = summaryMap.get(null);
		if (unmapped != null) {
			summaryMap.remove(null);
			summaryMap.put(UNMAPPED_COMPONENT_ID, unmapped);
		}
	}
}
