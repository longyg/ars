package com.nokia.oss.smu.web.session;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

@WebFilter(value = "/*", dispatcherTypes = { DispatcherType.REQUEST, DispatcherType.FORWARD })
public class IframeResponseFilter implements Filter {
	
	@Override
	public void init(FilterConfig cfg) throws ServletException {}

	@Override
	public void doFilter(
			ServletRequest request, 
			ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
			HttpServletResponseWrapper responseWrapper = new HttpServletResponseWrapper((HttpServletResponse)response);
			chain.doFilter(request, responseWrapper);
	}

	@Override
	public void destroy() {
	
	}

}
