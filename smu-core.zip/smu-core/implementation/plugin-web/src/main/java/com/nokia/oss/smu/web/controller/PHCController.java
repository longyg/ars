package com.nokia.oss.smu.web.controller;

import com.nokia.oss.smu.phc.PHCResult;
import com.nokia.oss.smu.phc.PHCService;
import com.nokia.oss.smu.phc.RunningInfo;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Controller
@RequestMapping(value = "/phc")
public class PHCController {

    private static Logger LOGGER = Logger.getLogger(PHCController.class.getName());

    @Resource
    PHCService service;

    @RequestMapping(value = "/do-check", method = RequestMethod.POST)
    @ResponseBody
    public RunningInfo doCheck(@RequestBody CheckingArgument argument) {
        return service.performCheck(argument.getIds());
    }

    @RequestMapping(value = "/checking-status", method = RequestMethod.POST)
    @ResponseBody
    public RunningInfo getCheckingStatus() {
        return service.updateRunningState();
    }

    @RequestMapping(value = "/test-suites", method = RequestMethod.GET)
    @ResponseBody
    public Map<String, String> getTestSuites() {
        return service.getTestSuiteMap();
    }


    @RequestMapping(value = "/phc-history", method = RequestMethod.GET)
    @ResponseBody
    public Map<String, Object> getPHCResults(
            @RequestParam(value = "maxRows", required = false, defaultValue = "500") int maxRows) {
        if (maxRows < 1) {
            throw new IllegalArgumentException("maxRows must >= 1");
        }
        Map<String, Object> map = new HashMap<>();
        Collection<PHCResult> results = service.getPHCResults().values();
        map.put("count", results.size());
        if (results.size() > maxRows) {
            results = new ArrayList<>(results).subList(0, maxRows);
        }
        map.put("data", results);
        return map;
    }

    @RequestMapping(value = "/latest-result", method = RequestMethod.GET)
    @ResponseBody
    public PHCResult getLatestResult() {
        return this.service.getLatestResult();
    }

    @RequestMapping(value = "/report-content", method = RequestMethod.GET, produces = "text/html")
    public void getReport(HttpServletResponse response, @RequestParam("target") String target) {
        if (target != null) {
            target = target.trim();
        }
        if (target == null || target.isEmpty()) {
            throw new ReportNotAvailableException("report file path cannot be null.");
        }
        try {
            response.setContentType("text/html");
            try (InputStream inputStream = this.service.createReportStream(target)) {
                byte[] buf = new byte[4096];
                while (true) {
                    int len = inputStream.read(buf);
                    if (len == -1) {
                        break;
                    }
                    response.getOutputStream().write(buf, 0, len);
                }
            }
        } catch (Exception e) {
            String message = "cannot get report file : ";
            LOGGER.log(Level.SEVERE, message, e);
            throw new ReportNotAvailableException(message);
        }
    }

    @ExceptionHandler(ReportNotAvailableException.class)
    public ModelAndView handleNoReportException() {
        return new ModelAndView("/no-report.jsp");
    }


    public static class CheckingArgument {
        private String[] ids;

        public String[] getIds() {
            return ids;
        }

        public void setIds(String[] ids) {
            this.ids = ids;
        }
    }
}

@ResponseStatus(value = HttpStatus.NOT_FOUND)
class ReportNotAvailableException extends RuntimeException {

    private static final long serialVersionUID = 8702052559296049746L;

    public ReportNotAvailableException(String message) {
        super(message);
    }
}
