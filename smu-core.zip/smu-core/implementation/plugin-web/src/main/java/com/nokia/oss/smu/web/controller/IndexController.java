package com.nokia.oss.smu.web.controller;

import com.nokia.oss.smu.cli.index.bll.IndexService;

import javax.annotation.Resource;

import com.nokia.oss.smu.web.session.Permission;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/")
public class IndexController {

    @Resource
    private IndexService indexService;

    @RequestMapping(value = "/heartbeat-task", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public void heartBeatTask(@RequestParam("taskIds") String taskIds) {
        this.indexService.heartBeatTask(taskIds);
    }
}
