package com.nokia.oss.smu.web.helper;

public class DispatcherServletInitializationException extends RuntimeException {

	private static final long serialVersionUID = -5113851530729095213L;

	public DispatcherServletInitializationException() {
	}

	public DispatcherServletInitializationException(String message, Throwable cause) {
		super(message, cause);
	}

	public DispatcherServletInitializationException(String message) {
		super(message);
	}

	public DispatcherServletInitializationException(Throwable cause) {
		super(cause);
	}

}
