package com.nokia.oss.smu.web.session;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import com.nokia.oss.smu.web.helper.DispatcherServlet;

@WebFilter(value = "/index.jsp", dispatcherTypes = { DispatcherType.REQUEST, DispatcherType.FORWARD })
public class IndexFilter implements Filter {
	
	private static final Logger LOGGER = Logger.getLogger(IndexFilter.class.getName());

	private Authorization authorization;
	
	@Override
	public void init(FilterConfig cfg) throws ServletException {
		
	}

	@Override
	public void doFilter(
			ServletRequest request, 
			ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		Authorization authorization;
		try {
			authorization = this.getAuthorization();
		} catch (IllegalStateException ex) {
			LOGGER.log(Level.SEVERE, "Access the index filter before the initialization of DispatcherServlet", ex);
			request.getRequestDispatcher("/error-initialization.jsp").forward(request, response);
			return;
		}
		if (authorization != null && authorization.checkPermission("SMU=Launch", (HttpServletRequest)request)) {
			HttpServletResponseWrapper responseWrapper = new HttpServletResponseWrapper((HttpServletResponse)response);
			chain.doFilter(request, responseWrapper);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/no-permission.jsp");
			dispatcher.forward(request, response);
		}
		
	}

	@Override
	public void destroy() {
		
	}
	
	/**
	 * @category Can not initialize this.authorization in "init"(FilterConfig)" because 
	 *    the spring context has not been created during the that method.
	 */
	private Authorization getAuthorization() {
		if (this.authorization == null) {
			synchronized (this) {
				if (this.authorization == null) {
					this.authorization = 
							DispatcherServlet
							.getWebAppContext()
							.getBean(Authorization.class);
				}
			}
		}
		return this.authorization;
	}
}
