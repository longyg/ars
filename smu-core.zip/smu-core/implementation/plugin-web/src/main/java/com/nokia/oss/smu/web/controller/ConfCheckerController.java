package com.nokia.oss.smu.web.controller;

import javax.annotation.Resource;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.settings.PreferenceService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nokia.oss.smu.cli.confchecker.bll.ConfCheckerService;
import com.nokia.oss.smu.cli.confchecker.entities.ConfCheckerReport;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.web.session.Permission;

import java.util.Date;

@Controller
@RequestMapping("/conf-checker")
public class ConfCheckerController {
    @Resource
    private ConfCheckerService confCheckerService;

    @Resource
    private PreferenceService preferenceService;

    @Resource
    private PasswordPolicy passwordPolicy;

    @RequestMapping(value = "/report", method = RequestMethod.POST)
    @ResponseBody
    public ConfCheckerReport getReport(
            @RequestParam(value = "refresh", required = false, defaultValue = "false") boolean refresh) {
        return this.confCheckerService.getReport(refresh);
    }
    
    @RequestMapping(value = "/file-part", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public FilePart readPart(
            @RequestParam("hostName") String hostName, 
            @RequestParam("fileName") String fileName, 
            @RequestParam("offset") long offset,
            @RequestParam(value = "maxLen", required = false, defaultValue = "131072") long maxLen,
            @RequestParam("password") String password) {
        passwordPolicy.preventBruteForce();
        FilePart part = this.confCheckerService.readFilePart(hostName, fileName, offset, "root", password, maxLen);
        markAuthenticateSuccess();
        return part;
    }

    @Synchronized(lockName = "viewFile.updateFailedAttempts")
    private void markAuthenticateSuccess() {
        preferenceService.setVariable(PasswordPolicy.LAST_SUCCESS_PREF, String.valueOf(new Date().getTime()));
    }
}
