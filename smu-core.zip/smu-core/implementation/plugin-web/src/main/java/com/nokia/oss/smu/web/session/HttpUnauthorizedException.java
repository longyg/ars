package com.nokia.oss.smu.web.session;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.UNAUTHORIZED)
public class HttpUnauthorizedException extends RuntimeException {

	private static final long serialVersionUID = 7608033298170283444L;

	public HttpUnauthorizedException() {
		super();
	}

	public HttpUnauthorizedException(String message) {
		super(message);
	}

	public HttpUnauthorizedException(Throwable cause) {
		super(cause);
	}

	public HttpUnauthorizedException(String message, Throwable cause) {
		super(message, cause);
	}
}