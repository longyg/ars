package com.nokia.oss.smu.web.json;

public class AlarmOperation {
    private long[] ids;
    private String operation;

    public long[] getIds() {
        return ids.clone();
    }

    public void setIds(long[] ids) {
        this.ids = ids;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }
}
