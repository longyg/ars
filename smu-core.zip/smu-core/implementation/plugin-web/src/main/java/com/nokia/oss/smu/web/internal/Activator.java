package com.nokia.oss.smu.web.internal;

import com.nokia.oss.smu.core.platform.MonitorPlugin;
import com.nokia.oss.smu.web.helper.URLHelper;
import org.springframework.web.context.ServletContextAware;

import javax.servlet.ServletContext;

public class Activator implements MonitorPlugin, ServletContextAware {

    private ServletContext context;

    public void activate() {
        URLHelper.getInstance().setContextPath(context.getContextPath());
    }

    public void deactivate() {
    }

    @Override
    public void setServletContext(ServletContext servletContext) {
        context = servletContext;
    }
}
