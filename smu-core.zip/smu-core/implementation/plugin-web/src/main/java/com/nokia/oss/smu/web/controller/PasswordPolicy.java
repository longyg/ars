package com.nokia.oss.smu.web.controller;

import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.settings.PreferenceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;
import java.util.logging.Logger;

import static java.util.logging.Logger.getLogger;

@Service
public class PasswordPolicy {
    private static final Logger LOG = getLogger(PasswordPolicy.class.getName());

    private static final String FROMS_PREF = "viewFile.passwordRetry.from";
    private static final String RETRY_INTERVAL_PREF = "viewFile.passwordRetry.retryInterval";
    private static final String RETRY_COUNT_INTERVAL_PREF = "viewFile.passwordRetry.countInterval";
    private static final String RETRY_LIMIT_PREF = "viewFile.passwordRetry.firstTryLimit";

    static final String LAST_SUCCESS_PREF = "viewFile.authenticate.lastSuccess";

    @Resource
    PreferenceService preferenceService;

    void preventBruteForce() {
        if (calculateForNextAttempt(false) > 0) {
            throw new SSHException("Permission denied", "Too many attempts");
        }
    }

    @Synchronized(lockName = "viewFile.updateFailedAttempts")
    @Transactional
    long calculateForNextAttempt(boolean postFailure) {
        long nowMillis = System.currentTimeMillis();
        long countInterval = getLongValFromPreference(RETRY_COUNT_INTERVAL_PREF, 900000L);
        List<Date> keptPoints = new ArrayList<>();
        long limitInTimeFrame = getLongValFromPreference(RETRY_LIMIT_PREF, 3);
        Date lastSuccess = new Date(0L);
        try {
            lastSuccess = new Date(Long.valueOf(preferenceService.getVariable(LAST_SUCCESS_PREF)));
        } catch (NumberFormatException ignored) {
        }

        try {
            Collection<String> strings = preferenceService.getMultiVariable(FROMS_PREF);
            for (String string : strings) {
                Date from = new Date(Long.valueOf(string));
                if (nowMillis - from.getTime() <= countInterval && from.after(lastSuccess)) {
                    keptPoints.add(from);
                }
            }

            if (postFailure) {
                keptPoints.add(new Date(nowMillis));
            }

            List<String> list = new ArrayList<>();
            for (Date keptPoint : keptPoints) {
                list.add(String.valueOf(keptPoint.getTime()));
            }
            preferenceService.setMultiVariable(FROMS_PREF, list);
        } catch (NumberFormatException ignored) {
            LOG.severe("Cannot calculate password retries, it is an unexpected modification of database");
            return 0L;
        }

        if (keptPoints.size() < limitInTimeFrame) {
            return 0L;
        }

        Collections.sort(keptPoints);

        long afterInterval = getLongValFromPreference(RETRY_INTERVAL_PREF, 900000L);
        return afterInterval - (System.currentTimeMillis() - keptPoints.get(keptPoints.size() - 1).getTime());
    }

    private long getLongValFromPreference(String name, long defaultVal) {
        String val = preferenceService.getVariable(name);
        try {
            return Long.valueOf(val);
        } catch (NumberFormatException ex) {
            return defaultVal;
        }
    }
}