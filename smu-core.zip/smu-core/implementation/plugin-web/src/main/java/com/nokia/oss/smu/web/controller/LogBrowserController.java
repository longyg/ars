package com.nokia.oss.smu.web.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.nokia.oss.smu.data.sync.Synchronized;
import com.nokia.oss.smu.settings.PreferenceService;
import com.nokia.oss.smu.web.helper.DownloadHelper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.nokia.oss.smu.cli.logbrowser.bll.LogBrowserService;
import com.nokia.oss.smu.cli.logbrowser.bll.LogSearchTaskArgument;
import com.nokia.oss.smu.cli.logbrowser.entities.FilePart;
import com.nokia.oss.smu.cli.logbrowser.entities.LogSearchTaskPart;
import com.nokia.oss.smu.cli.ssh.dal.SSHException;
import com.nokia.oss.smu.cli.taskmanagement.bll.TaskCreationException;
import com.nokia.oss.smu.cli.taskmanagement.entities.Task;
import com.nokia.oss.smu.cli.taskmanagement.entities.TaskPartRequest;
import com.nokia.oss.smu.web.session.Permission;

@Controller
@RequestMapping("/log-browser")
public class LogBrowserController {

    @Resource
    private LogBrowserService logBrowserService;

    @Resource
    private PreferenceService preferenceService;

    @Resource
    private PasswordPolicy passwordPolicy;

    @RequestMapping(value = "/scenarios")
    @Permission("SMU=Launch")
    @ResponseBody
    public Collection<String> scenarios() {
        return this.logBrowserService.listScenarios();
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public Task createTask(@RequestBody LogSearchTaskArgument taskArgument) {
        return this.logBrowserService.createTask(taskArgument);
    }

    @RequestMapping(value = "/cancel-task", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public void cancelTask(@RequestParam("taskId") long taskId) {
        this.logBrowserService.cancelTask(taskId);
    }

    @RequestMapping(value = "/task-part", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public LogSearchTaskPart getTaskPart(@RequestBody TaskPartRequest request) {
        long taskId = request.getTaskId();
        LogSearchTaskPart taskPart = this.logBrowserService.getTaskPart(request);
        if (taskPart == null) {
            throw new TaskNotFoundException("Task not found: " + taskId);
        }
        taskPart.setDownloading(this.logBrowserService.isDownloading());
        return taskPart;
    }

    @RequestMapping(value = "/file-part", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public FilePart readFilePart(@RequestParam("hostName") String hostName,
                                 @RequestParam("fileName") String fileName,
                                 @RequestParam("offset") long offset,
                                 @RequestParam(value = "maxLen", required = false, defaultValue = "131072") long
                                         maxLen) {
        return this.logBrowserService.readFilePart(hostName, fileName, offset, maxLen);
    }

    @RequestMapping(value = "/verifyPassword", method = RequestMethod.POST)
    @Permission("SMU=Launch")
    @ResponseBody
    public String verifyPassword(@RequestParam("password") String password) {
        passwordPolicy.preventBruteForce();
        this.logBrowserService.verifyPassword(password);
        markAuthenticateSuccess();
        return "Authentication successfully";
    }

    @RequestMapping(value = "/download-task", method = {RequestMethod.POST, RequestMethod.GET})
    @Permission("SMU=Launch")
    public void download(@RequestParam("password") String password,
                         @RequestParam("taskId") long taskId,
                         HttpServletResponse response) {
        long size = this.logBrowserService.getPackSizeOfTask(taskId, password);
        DownloadHelper.setHeadersForDownload(response, size, this.logBrowserService.getPackName(taskId));
        try {
            if (size > 0) {
                this.logBrowserService.downloadPackage(taskId, password, response.getOutputStream());
                response.flushBuffer();
            }
        } catch (IOException | SSHException ex) {
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "download package failed!");
            } catch (IOException ioex) {
                throw new SSHException("Unknown error happened when download package");
            }
        }
    }

    @RequestMapping(value = "/package-task", method = {RequestMethod.POST, RequestMethod.GET})
    @Permission("SMU=Launch")
    @ResponseBody
    public Task packageTask(@RequestParam("password") String password,
                            @RequestParam("taskId") long taskId) {
        LogSearchTaskArgument taskArgument = new LogSearchTaskArgument();
        taskArgument.setPackFiles(true);
        taskArgument.setTaskId(taskId);
        return this.logBrowserService.createPackageTask(taskArgument);
    }

    @ExceptionHandler(TaskCreationException.class)
    @ResponseBody
    public Map<String, String> handleCreateFailure(HttpServletResponse response, TaskCreationException ex) {
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        Map<String, String> errorInfo = new LinkedHashMap<>();
        errorInfo.put("error", ex.getMessage());
        return errorInfo;
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    private static class TaskNotFoundException extends RuntimeException {

        private static final long serialVersionUID = 7227726346328848267L;

        TaskNotFoundException(String message) {
            super(message);
        }

    }

    @Synchronized(lockName = "viewFile.updateFailedAttempts")
    private void markAuthenticateSuccess() {
        preferenceService.setVariable(PasswordPolicy.LAST_SUCCESS_PREF, String.valueOf(new Date().getTime()));
    }
}
