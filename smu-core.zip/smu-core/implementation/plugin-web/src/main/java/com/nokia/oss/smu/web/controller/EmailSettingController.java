package com.nokia.oss.smu.web.controller;

import java.util.Collection;
import java.util.logging.Logger;

import javax.annotation.Resource;

import com.nokia.oss.smu.mail.internal.MailSenderImpl;
import com.nokia.oss.smu.settings.PreferenceUpgradeMigrator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nokia.oss.smu.settings.PreferenceService;

@Controller
public class EmailSettingController {
	
	private static Logger LOG = Logger.getLogger(EmailSettingController.class.getName());

	@Value("${internal.alarm.mail.resend.interval.default}")
	private long defaultResendInterval;

	@Resource
	private PreferenceService preferenceService;

    @Resource
    private PreferenceUpgradeMigrator preferenceUpgradeMigrator;

	@RequestMapping(value = "/email-setting", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public NotificationSetting getEmailSetting() {
		LOG.info("Reading email settings");
		NotificationSetting setting = new NotificationSetting();
		setting.setSmtpServer(preferenceService.getVariable(PreferenceService.SMTP_SERVER));
		setting.setSmtpServerPort(preferenceService.getVariable(PreferenceService.SMTP_SERVER_PORT));
		setting.setMailSender(preferenceService.getVariable(PreferenceService.MAIL_SENDER));
		setting.setTargetAddresses(preferenceService.getMultiVariable(PreferenceService.TARGET_ADDRESSES));
		setting.setEnabledForPHCChecker(preferenceService.isTrue(PreferenceService.ENABLED_FOR_PHC_CHECKER));

        preferenceUpgradeMigrator.migrateAlarmMailTriggers();

        AlarmMailSeverityRule esas = new AlarmMailSeverityRule();
        esas.setCriticalEnabled(preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED));
        esas.setMajorEnabled(preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED));
        esas.setMinorEnabled(preferenceService.isTrue(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED));
        setting.setAlarmRule(esas);
		String interval = preferenceService.getVariable(PreferenceService.CRITICAL_RESEND_INTERVAL);
		try {
			setting.resendInterval = Long.parseLong(interval) / 1000;
		}
		catch (NumberFormatException | NullPointerException ex) {
			setting.resendInterval = defaultResendInterval / 1000;
		}

		return setting;
	}
	
	@RequestMapping(value = "/email-setting",method = RequestMethod.POST)
	@ResponseBody
	public void setEmailSetting(@RequestBody NotificationSetting emailSetting) {
		if (emailSetting.getSmtpServer() != null && !emailSetting.getSmtpServer().isEmpty()) {
			preferenceService.setVariable(PreferenceService.SMTP_SERVER, emailSetting.getSmtpServer());
		}

		if (emailSetting.getSmtpServerPort() != null && !emailSetting.getSmtpServerPort().isEmpty()) {
			preferenceService.setVariable(PreferenceService.SMTP_SERVER_PORT, emailSetting.getSmtpServerPort());
		}

		String mailSender = emailSetting.getMailSender();
		if (mailSender == null || mailSender.isEmpty()) {
			mailSender = MailSenderImpl.DEFAULT_SENDER_ADDRESS;
		}

		preferenceService.setVariable(PreferenceService.MAIL_SENDER, mailSender);
		preferenceService.setMultiVariable(PreferenceService.TARGET_ADDRESSES, emailSetting.getTargetAddresses());

		AlarmMailSeverityRule esas = emailSetting.getAlarmRule();
		if (esas != null){
		    preferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_CRITICAL_ENABLED, esas.isCriticalEnabled() ? "true" : "false");
		    preferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_MAJOR_ENABLED, esas.isMajorEnabled() ? "true" : "false");
		    preferenceService.setVariable(PreferenceService.ENABLE_ALARM_SEVERITY_MINOR_ENABLED, esas.isMinorEnabled() ? "true" : "false");
		}

		if (emailSetting.resendInterval != null) {
			preferenceService.setVariable(PreferenceService.CRITICAL_RESEND_INTERVAL,
					String.valueOf(emailSetting.resendInterval * 1000));
		}

		preferenceService.setVariable(PreferenceService.ENABLED_FOR_PHC_CHECKER, emailSetting.isEnabledForPHCChecker() ? "true" : "false");

		LOG.info("Email settings saved.");
	}
	
	public static class NotificationSetting {
		private String smtpServer;
		private String smtpServerPort;
		private String mailSender;
		private Collection<String> targetAddresses;
		private boolean enabledForPHCChecker;
		private AlarmMailSeverityRule alarmRule;
		public Long resendInterval;
		
		@Override
		public String toString() {
		    StringBuilder value = new StringBuilder("{");
		    value.append("smtpServer: ").append(smtpServer).append(", ");
		    value.append("smtpServerPort: ").append(smtpServerPort).append(", ");
			value.append("mailSender: ").append(smtpServerPort).append(", ");
		    value.append("resendInterval: ").append(resendInterval).append(", ");
		    value.append("targetAddresses: [ ");
		    boolean started = false;
			for (String addr : targetAddresses) {
				if (started) {
				    value.append(", ");
				} else {
					started = true;
				}
				value.append(addr);
			}
			value.append(" ], ");
			if(alarmRule != null){
			    alarmRule.appendTo(value);
			}
			value.append("enabledForPHC: ").append(enabledForPHCChecker);
			value.append("}");
			return value.toString();
		}

		public AlarmMailSeverityRule getAlarmRule() {
            return alarmRule;
        }

        public void setAlarmRule(AlarmMailSeverityRule rule) {
            this.alarmRule = rule;
        }

        public String getSmtpServerPort() {
			return smtpServerPort;
		}

		public void setSmtpServerPort(String smtpServerPort) {
			this.smtpServerPort = smtpServerPort;
		}

		public String getSmtpServer() {
			return smtpServer;
		}

		public void setSmtpServer(String smtpServer) {
			this.smtpServer = smtpServer;
		}

		public String getMailSender() { return mailSender; }

		public void setMailSender(String mailSender) { this.mailSender = mailSender; }

		public Collection<String> getTargetAddresses() {
			return targetAddresses;
		}

		public void setTargetAddresses(Collection<String> targetAddresses) {
			this.targetAddresses = targetAddresses;
		}

		public boolean isEnabledForPHCChecker() {
			return enabledForPHCChecker;
		}

		public void setEnabledForPHCChecker(boolean enabledForPHCChecker) {
			this.enabledForPHCChecker = enabledForPHCChecker;
		}
	}
	
	public static class AlarmMailSeverityRule {
	    private boolean criticalEnabled;
	    private boolean majorEnabled;
	    private boolean minorEnabled;
        public boolean isCriticalEnabled() {
            return criticalEnabled;
        }
        public void setCriticalEnabled(boolean criticalEnabled) {
            this.criticalEnabled = criticalEnabled;
        }
        public boolean isMajorEnabled() {
            return majorEnabled;
        }
        public void setMajorEnabled(boolean majorEnabled) {
            this.majorEnabled = majorEnabled;
        }
        public boolean isMinorEnabled() {
            return minorEnabled;
        }
        public void setMinorEnabled(boolean minorEnabled) {
            this.minorEnabled = minorEnabled;
        }
        
        void appendTo(StringBuilder builder) {
            builder.append("alarm severities: [");
            builder.append("criticalEnabled:").append(this.isCriticalEnabled()).append(",");
            builder.append("majorEnabled:").append(this.isMajorEnabled()).append(",");
            builder.append("minorEnabled:").append(this.isMinorEnabled()).append(",");
            builder.append("],");
        }
	}
}
