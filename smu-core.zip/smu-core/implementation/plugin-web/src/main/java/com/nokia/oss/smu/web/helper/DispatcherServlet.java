package com.nokia.oss.smu.web.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.web.context.WebApplicationContext;

import com.nokia.oss.smu.data.internal.DelayedEntityManagerFactory;

public class DispatcherServlet extends org.springframework.web.servlet.DispatcherServlet {

	private static final long serialVersionUID = -5608724165868380043L;
	
	private static final Logger LOGGER = Logger.getLogger(DispatcherServlet.class.getName());
	
	private static final String SPRING_XML_POSTFIX = ".spring.xml"; 
	
	private static final String JAR_POSTFIX = ".jar";
	
	private static final Set<String> AUTO_SPRING_XMLS;
	
	private static WebApplicationContext webAppContext;
	
	public static WebApplicationContext getWebAppContext() {
		WebApplicationContext ctx = webAppContext;
		if (ctx == null) {
			throw new IllegalStateException("WebAppContext has not been initialized");
		}
		return ctx;
	}

	@Override
	protected WebApplicationContext initWebApplicationContext() {
	    WebApplicationContext ctx = super.initWebApplicationContext();
	    ctx.getBean(DelayedEntityManagerFactory.class).sendCommand("contextReady");
	    setWebContext(ctx);
		return ctx;
	}
	
	private synchronized static void setWebContext(WebApplicationContext ctx){
	    webAppContext = ctx;
	}

	@Override
	public void setContextConfigLocation(String configLocation) {
		String location = configLocation.trim();
		if (location.endsWith(",")) {
			location = location.substring(location.length());
		}
		
		StringBuilder xmlfiles = new StringBuilder(location);
		for (String autoSpringXML : AUTO_SPRING_XMLS) {
			if (!location.isEmpty()) {
			    xmlfiles.append(", ");
			}
			xmlfiles.append("classpath:");
			xmlfiles.append(autoSpringXML);
		}
		
		super.setContextConfigLocation(xmlfiles.toString());
	}
	
	private static Set<String> getAutoSpringXmls() {
		
		ClassLoader classLoader = DispatcherServlet.class.getClassLoader();
		Set<String> xmls = new LinkedHashSet<String>();
		
		if (classLoader instanceof URLClassLoader) { //Jetty
			for (URL url : ((URLClassLoader)classLoader).getURLs()) {
				if (url.toString().startsWith("file:")) {
					scanPath(
							false,
							File.separatorChar == '\\' ? 
								url.toString().substring("file:/".length()) : // windows, "file:/D:/abc", remove "file:/", result is "D:/abc"
								url.toString().substring("file:".length()), // linux, "file:/var/abc", remove "file:", result is "/var/abc"
							xmls);
				}
			}
		} else { //WAS
			for (String path : getPathsFromWASClassLoader(classLoader)) {
				scanPath(true, path, xmls);
			}
		}
		
		return xmls;
	}
	
	private static void scanPath(boolean was, String path, Set<String> xmls) {
		if (path.endsWith(JAR_POSTFIX)) {
			try {
				ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(path));
				try {
					while (true) {
						ZipEntry zipEntry = zipInputStream.getNextEntry();
						if (zipEntry == null) {
							break;
						}
						String zipEntryName = zipEntry.getName();
						if (zipEntryName.endsWith(SPRING_XML_POSTFIX)) {
							xmls.add(zipEntryName);
						}
					}
				} finally {
					zipInputStream.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace(System.err);
			}
		}
	}
	
	private static String[] getPathsFromWASClassLoader(ClassLoader classLoader) {
		/*
		 * com.ibm.ws.classloader.CompoundClassLoader 
		 * supports
		 * "public String[] getPaths()"
		 */
		Method method;
		try {
			method = classLoader.getClass().getMethod("getPaths");
		} catch (NoSuchMethodException ex) {
			throw new DispatcherServletInitializationException(
					"ClassLoader \""
					+ classLoader.getClass()
					+ "\"doesn't have public method \"getPaths()\"", 
					ex
			);
		}
		if (String[].class != method.getReturnType()) {
			throw new DispatcherServletInitializationException(
					"The method \"getPaths()\" of classLoader \""
					+ classLoader.getClass()
					+ "\"doesn't return String[]"
			);
		}
		try {
			return (String[])method.invoke(classLoader, new Object[0]);
		} catch (IllegalAccessException ex) {
			throw new AssertionError("Impossible, method is public method");
		} catch (InvocationTargetException ex) {
			throw new DispatcherServletInitializationException(
					"Cannot inovke the method \"getPaths()\" of classLoader \""
					+ classLoader.getClass()
					+ "\"",
					ex.getTargetException()
			);
		}
	}
	
	static {
		long time = System.currentTimeMillis();
		AUTO_SPRING_XMLS = getAutoSpringXmls();
		time = System.currentTimeMillis() - time;
		LOGGER.info("Cost " + time + "milli seconds to scan the *.spring.xml, the found results are: " + AUTO_SPRING_XMLS.toString());
	}
}
