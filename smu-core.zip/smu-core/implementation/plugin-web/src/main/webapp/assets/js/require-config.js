/**
 * Configuration file for RequireJS loader.
 * Created by mingghe on 2016/3/2.
 */
'use strict';

+function() {
    //Calculate the base URL according to the path of current page.
    var path = window.location.pathname;
    var baseUrl = 'wulfdist/js/dependencies';
    var index = path.lastIndexOf("components");
    baseUrl = index > 0 ? '../'.concat(baseUrl) : baseUrl;

    require.config({
        baseUrl: baseUrl,

        paths: {
            jquery: 'jquery.min',
            bootstrap: 'bootstrap.min',
            fuelux: 'fuelux',
            wulf: '../../../assets/js/wulf',
            'malihu-custom-scrollbar-plugin': 'jquery.mCustomScrollbar.concat.min',
            moment: 'moment-with-locales.min',
            //timezones: 'timezones.min', //TODO Jonathan: the timezones cannot be shimmed correctly.
            'twitter-bootstrap-wizard': 'jquery.bootstrap.wizard.min',
            'moment-timezone': 'moment-timezone-with-data.min',
            jqxcore: 'jqxcore',
            jqxdata: 'jqxdata',
            jqxbuttons: 'jqxbuttons',
            jqxscrollbar: 'jqxscrollbar',
            jqxmenu: 'jqxmenu',
            jqxcheckbox: 'jqxcheckbox',
            jqxlistbox: 'jqxlistbox',
            jqxdropdownlist: 'jqxdropdownlist',
            jqxgrid: 'jqxgrid',
            jqxpanel: 'jqxpanel',
            'jqxgrid.edit': 'jqxgrid.edit',
            'jqxgrid.columnsresize': 'jqxgrid.columnsresize',
            'jqxgrid.columnsreorder':'jqxgrid.columnsreorder',
            'jqxdata.export': 'jqxdata.export',
            'jqxgrid.export': 'jqxgrid.export',
            'jqxgrid.selection': 'jqxgrid.selection',
            'jqxgrid.filter': 'jqxgrid.filter',
            'jqxgrid.pager': 'jqxgrid.pager',
            'jqxgrid.sort': 'jqxgrid.sort',
            jqxcombobox: 'jqxcombobox'
        },

        shim: {
            bootstrap: {
                deps: ['jquery']
            },
            //timezones: {
            //    deps: ['jquery', 'moment-timezone'],
            //    exports: 'timezones'
            //},
            'twitter-bootstrap-wizard': {
                deps: ['jquery','bootstrap']
            },
            'malihu-custom-scrollbar-plugin': {
                deps: ['jquery']
            },
            jqxcore: {
                deps: ['jquery']
            },
            jqxdata: {
                deps: ['jqxcore']
            },
            jqxgrid: {
                deps: ['jqxcore', 'jqxdata','jqxbuttons', 'jqxscrollbar', 'jqxmenu', 'jqxlistbox', 'jqxdropdownlist']
            },
            'jqxgrid.selection': {
                deps: ['jqxgrid']
            },
            'jqxgrid.sort': {
                deps: ['jqxgrid']
            },
            'jqxgrid.pager': {
                deps: ['jqxgrid']
            },
            'jqxgrid.filter': {
                deps: ['jqxgrid']
            },
            'jqxgrid.columnsresize': {
                deps: ['jqxgrid']
            },
            'jqxgrid.columnsreorder': {
                deps: ['jqxgrid']
            },
            'jqxdata.export': {
                deps: ['jqxgrid']
            },
            'jqxgrid.export': {
                deps: ['jqxgrid']
            },
            'jqxgrid.edit': {
                deps: ['jqxgrid']
            },
            jqxpanel: {
                deps: ['jqxcore']
            },
            jqxdropdownlist: {
                deps: ['jqxcore','jqxbuttons','jqxscrollbar', 'jqxlistbox']
            },
            jqxlistbox: {
                deps: ['jqxcore','jqxbuttons', 'jqxscrollbar']
            },
            jqxcheckbox: {
                deps: ['jqxcore']
            },
            jqxmenu: {
                deps: ['jqxcore']
            },
            jqxscrollbar: {
                deps: ['jqxcore', 'jqxbuttons']
            },
            jqxbuttons: {
                deps: ['jqxcore']
            },
            jqxcombobox: {
                deps: ['jqxcore','jqxbuttons', 'jqxscrollbar', 'jqxlistbox']
            }
        }
    });
}();


