!function(a){"function"==typeof define&&define.amd?define(["jquery","bootstrap","./keyboard-support"],a):"object"==typeof module&&module.exports?module.exports=function(b,c){return void 0===c&&(c="undefined"!=typeof window?require("jquery"):require("jquery")(b)),a(c,require("bootstrap"),require("./keyboard-support")),c}:a(jQuery)}(function(a){"use strict";
    a(document).on("click.wf.balloon",function(b){
        a('[data-toggle^="popover"]').each(function(c,d){
            if(b.target!==d){
                var e=a(this).data("bs.popover");
                if(e == undefined){
                    return;
                }
                var f=e.tip();
                f.hasClass("in")&&a(this).triggerHandler("click.popover")
        }})}),
    a(".n-hover-popover")
            .on("mouseover.wf.balloon",function(){a(this).off("click"),a(this).data("bs.popover").show()})
            .on("mouseout.wf.balloon",function(){a(this).data("bs.popover").hide()}),
                                                    a('[data-toggle^="popover"]').one("shown.bs.popover",function(){
                                                            a(this).data("bs.popover").tip().on("click.wf.balloon",function(a){
                                                                    a.stopPropagation()})}),
                                                                            a(window).on("resize",function(){
                                                                                a('[data-toggle^="popover"]').each(function(){
                                                                                    var b=a(this).data("bs.popover");
                                                                                    if(b == undefined){
                                                                                        return;
                                                                                    }
                                                                                    var c=b.tip();
                                                                                    c.hasClass("in")&&b.show()})
                                                                             })});