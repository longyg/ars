/*
 * @author frchen.1.chen@nokia.com
 * 
 * Example:

// Code:
var logState = function(state) {
	console.log("____________________");
	console.log("tasks are dirty: " + state.isDirty("tasks"));
	console.log("selectedTask is dirty: " + state.isDirty("selectedTask"));
	console.log("selectedTaskOutput is dirty: " + state.isDirty("selectedTaskOutput"));
	console.log("selectedTaskOutputFileParts is dirty: " + state.isDirty("selectedTaskOutputFileParts"));
};
var state = com.nokia.oss.smu.createDependencyState([
	{
		name: "tasks",
		create: function() { return []; },
		equals: com.nokia.oss.smu.entityCollectionEqual("id")
	},
	{
		name: "selectedTask",
		dependency: "tasks",
		create: function() { return { id: 0 } },
		equals: com.nokia.oss.smu.entityObjectEqual("id"),
		refresh: com.nokia.oss.smu.findInCollectionByIdentifier("id")
	},
	{
		name: "selectedTaskOutput",
		dependency: "selectedTask",
		create: function() { return { id: 0 } },
		equals: com.nokia.oss.smu.entityObjectEqual("id")
	},
	{
		name: "selectedTaskOutputFileParts",
		dependency: "selectedTaskOutput",
		create: function() { return [] },
		equals: com.nokia.oss.smu.entityCollectionEqual("id")
	}
]);

state.setTasks([{ id: 1 }, { id: 2 }]);
state.setSelectedTask({id: 1});
state.setSelectedTaskOutput({id: 4});
state.setSelectedTaskOutputFileParts([{nextOffset: 1}, {nextOffset: 2}, {nextOffset: 3}]);
logState(state);

state.setTasks([{ id: 1}]);
logState(state);

state.setTasks([{ id: 2}]);
logState(state);

state.setTasks();
logState(state);

// Result:
____________________
tasks are dirty: true
selectedTask is dirty: true
selectedTaskOutput is dirty: true
selectedTaskOutputFileParts is dirty: true
____________________
tasks are dirty: true
selectedTask is dirty: true
selectedTaskOutput is dirty: true
selectedTaskOutputFileParts is dirty: true
____________________
tasks are dirty: true
selectedTask is dirty: false
selectedTaskOutput is dirty: false
selectedTaskOutputFileParts is dirty: false
____________________
tasks are dirty: false
selectedTask is dirty: false
selectedTaskOutput is dirty: false
selectedTaskOutputFileParts is dirty: false
 */
(function() {
	var pkg = (function(pacakgeName) {
		var names = pacakgeName.split(".");
		var pkg = window;
		for (var i = 0; i < names.length; i++) {
			var subPkg = pkg[names[i]];
			if (typeof(subPkg) == "undefined") {
				pkg[names[i]] = subPkg = {};
			}
			pkg = subPkg;
		}
		return pkg;
	})("com.nokia.oss.smu");
	pkg.createDependencyState = function(properties) {
		var propertyMap = {};
		properties = resolveProperties(properties, propertyMap);
		var state = {};
		for (var i = properties.length - 1; i >= 0; i--) {
			addProperty(state, properties[i]);
		}
		state.isDirty = function(propertyName) {
			var property = propertyMap[propertyName];
			if (!property) {
				throw new Error("Illegal propertyName: " + propertyName);
			}
			return !property.equals(this[propertyName], property.create());
		};
		state.isDirty = function(propertyName) {
			return this._dirty0(propertyName, 0, 0, 0);
		};
		state.containsDirty = function(propertyName, minDepth, maxDepth) {
			if (minDepth < 0) {
				throw new Error("minDepth must >= 0");
			}
			if (typeof(maxDepth) != "undefined" && maxDepth < minDepth) {
				throw new Error("maxDepth must >= minDepth if it's not undefined");
			}
			return this._dirty0(propertyName, 0, minDepth, maxDepth);
		};
		state._dirty0 = function(propertyName, level, minLevel, maxLevel) {
			var property = propertyMap[propertyName];
			if (!property) {
				throw new Error("Illegal property name \"" + propertyName + "\"");
			}
			return this._dirty1(property, level, minLevel, maxLevel);
		};
		state._dirty1 = function(property, level, minLevel, maxLevel) {
			if (level >= minLevel && !property.equals(this[property.name], property.create())) {
				return true;
			}
			if (typeof(maxLevel) == "undefined" || level < maxLevel) {
				for (var i = property.childProperties.length - 1; i >= 0; i--) {
					if (state._dirty(property.childProperties[i], level + 1, minLevel, maxLevel)) {
						return true;
					}
				}
			}
			return false;
		};
		return state;
	};
	pkg.entityObjectEqual = function() {
		if (arguments.length < 1) {
			throw new Error("At least one argument must be specified");
		}
		var args = arguments;
		return function(a, b) {
			if (!a) {
				return !b;
			}
			for (var i = args.length - 1; i >= 0; i--) {
				var fieldName = args[i];
				if (a[fieldName] != b[fieldName]) {
					return false;
				}
			}
			return true;
		};
	};
	pkg.entityCollectionEqual = function() {
		if (arguments.length < 1) {
			throw new Error("At least one argument must be specified");
		}
		var args = arguments;
		return function(a, b) {
			if (a == b) {
				return true;
			}
			if (!a) {
				return !b;
			}
			if (a.length != b.length) {
				return false;
			}
			for (var i = a.length - 1; i >= 0; i--) {
				if (!pkg.entityObjectEqual.apply(pkg, args)(a[i], b[i])) {
					return false;
				}
			}
			return true;
		};
	};
	pkg.findInCollectionByIdentifier = function(identifierName) {
		return function(oldValue, dependedValue) {
			for (var i = dependedValue.length - 1; i >= 0; i--) {
				if (pkg.entityObjectEqual(identifierName)(oldValue, dependedValue[i])) {
					return dependedValue[i];
				}
			}
		};
	};
	pkg.intersectWithCollectionByIdentifier = function(identifierName) {
		return function(oldValue, dependedValue) {
			var arr = [];
			for (var i = 0; i < oldValue.length; i++) {
				var element = pkg.findInCollectionByIdentifier(identifierName)(oldValue[i], dependedValue);
				if (element) {
					arr.push(element);
				}
			}
			return arr;
		};
	};
	var resolveProperties = function(properties, outputMap) {
		var clonedArr = [];
		for (var i = properties.length - 1; i >= 0; i--) {
			var property = properties[i];
			var upperName = property.name.substring(0, 1).toUpperCase() + property.name.substring(1);
			outputMap[property.name] = clonedArr[i] = { 
					name: property.name, 
					create: property.create, 
					equals: property.equals || function(a, b) { return a == b;},
					dependency: property.dependency,
					refresh: property.refresh,
					childProperties: [],
					setterName: "set" + upperName
			};
		}
		
		for (var i = clonedArr.length - 1; i >= 0; i--) {
			resolveDependency(clonedArr[i], outputMap, []);
		}
		return clonedArr;
	};
	var resolveDependency = function(property, map, resolvingQueue) {
		for (var i = 0; i < resolvingQueue.length; i++) {
			if (resolvingQueue[i].name === property.name) {
				throw new Error(
						"Find the dependency cycle :" +
						resolvingQueue.map(function(e) { return e.name; }).join("->") +
						"->" +
						property.name
				);
			}
		}
		if (typeof(property.dependency) != "string") {
			return;
		}
		var dependedProperty = map[property.dependency];
		if (!dependedProperty) {
			throw new Error("The dependency \"" + property.dependency + "\" of property \"" + property.name + "\" can't be resolved.");
		}
		property.dependency = dependedProperty;
		dependedProperty.childProperties.push(property);
		resolvingQueue.push(property);
		resolveDependency(dependedProperty, map, resolvingQueue);
	};
	var addProperty = function(state, property) {
		state[property.name] = property.create();
		state[property.setterName] = function(value) {
			if (typeof(value) == "undefined" || value == null) {
				value = property.create();
			}
			state[property.name] = value;
			if (property.equals(state[property.name], value)) {
				return;
			}
			for (var i = property.childProperties.length - 1; i >= 0; i--) {
				var childProperty = property.childProperties[i];
				var refreshedValue;
				if (typeof(childProperty.refresh) == "function") {
					refreshedValue = childProperty.refresh(state[childProperty.name], value);
				}
				this[childProperty.setterName](refreshedValue);
			}
		};
	};
})();