(function () {
    var ScheduledTask = function (timeout, handler) {
        this.timeout = timeout;
        this.handler = handler;
        this.isSuspended = false;
        this.timeoutId = 0;
    };

    ScheduledTask.prototype.suspend = function () {
        this.isSuspended = true;
    };

    ScheduledTask.prototype.resume = function () {
        this.isSuspended = false;
    };

    ScheduledTask.prototype.cancel = function () {
        clearTimeout(this.timeoutId);
        this.cancelled = true;
    };

    ScheduledTask.prototype.forceExecute = function () {
        if (!this.cancelled) {
            clearTimeout(this.timeoutId);
        }

        var that = this;
        var semaphore = this.handler();
        if (typeof(semaphore) == "undefined") {
            that.execute();
        } else {
            semaphore.ready(function () {
                that.execute();
            });
        }
    };

    ScheduledTask.prototype.execute = function () {
        var that = this;
        if (that.cancelled) {
            return;
        }
        this.timeoutId = setTimeout(
            function () {
                if (that.isSuspended) {
                    that.execute();
                } else {
                    var semaphore = that.handler();
                    if (!semaphore) {
                        that.execute();
                    } else {
                        semaphore.ready(function () {
                            that.execute();
                        });
                    }
                }
            },
            this.timeout
        );
    };

    var Semaphore = function (block) {
        this.block = block || 1;
        this.unblockHandlers = [];
    };

    Semaphore.prototype.release = function () {
        if (--this.block == 0) {
            var arr = this.unblockHandlers;
            var len = arr.length;
            for (var i = 0; i < len; i++) {
                arr[i]();
            }
            delete this.unblockHandlers;
        }
    };

    Semaphore.prototype.ready = function (handler) {
        if (this.block > 0) {
            this.unblockHandlers.push(handler);
        } else {
            handler();
        }
    };

    window.Scheduler = {
        semaphore: function (block) {
            return new Semaphore(block);
        },
        fixedDelay: function (timeout, handler) {
            var scheduledTask = new ScheduledTask(timeout, handler);
            var semaphore = handler();
            if (semaphore == null) {
            	scheduledTask.execute();
            } else {
            	semaphore.ready(function() {
            		scheduledTask.execute();
            	});
            }
            return scheduledTask;
        }
    };
})();