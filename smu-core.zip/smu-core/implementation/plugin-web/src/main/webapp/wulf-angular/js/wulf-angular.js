angular.idAllocator = {
		sequence: 0,
		alloc: function() {
			return "angular_id_" + this.sequence++;
		}
};

angular
	.module("nokia.wulf", [])
	.directive("wulfNavigator", function () {
		return {
			restrict: "E",
			replace: true,
			scope: {
				appName: "@",
				menuItems: "=menuItems",
				linkItems: "=linkItems",
				manageItems: "=manageItems"
			},
			templateUrl: "wulf-angular/templates/navigator.tpl.html",
			transclude: true,
			controller: function($scope, $http, $element) {
				$scope.currentUser = window.currentUser;
				$scope.showAbout = false;
				$scope.closeAboutDialog = function() {
					$scope.showAbout = false;
				};

				$scope.toggleAboutDialog = function () {
					$scope.showAbout = !$scope.showAbout;
					setTimeout(function() {
						$element.find('.about-dialog').focus();
					}, 0);
				};

				$scope.version = '';
				$http.get("rest/system/about")
					.then(function (response) {
						var data = response.data;
						$scope.productName = data.productName;
						$scope.version = data.version;
						$scope.buildNumber = data.buildNumber;
					});

				$scope.onAboutDialogKeyUp = function(e){
					if (e.keyCode == 27 || e.keyCode == 13) {
						$scope.closeAboutDialog();
					}
				};

				$scope.productVersion = function() {
					var segs = $scope.version.split('.');
					if (segs.length < 2) { return ''; }
					if (segs[1] == '0') { return segs[0]; }
					return segs[0] + '.' + segs[1];
				}
			}
		};
	})
.directive("wulfNotification",function() {
	return {
		restrict: "E",
		replace: true,
		templateUrl: "wulf-angular/templates/notification.tpl.html",
		controller: function($scope, $element) {
			$scope.isVisible = function() {
				return (
					$scope.messageMap &&
					$scope.messageMap[window.location.hash] &&
					$("input.notificiation-jquery-index:last")[0] === $element.find("input.notificiation-jquery-index")[0]
				);
			};
			$scope.getMessageType = function() {
				var message = null;
				if ($scope.messageMap) {
					message = $scope.messageMap[window.location.hash];
				}
				return message != null ? message.type : null;
			};
			$scope.getMessageText = function() {
				var message = null;
				if ($scope.messageMap) {
					message = $scope.messageMap[window.location.hash];
				}
				return message != null ? message.text : null;
			};
			$scope.close = function() {
				delete $scope.messageMap[window.location.hash];
			};
		},
		link: function($scope, $element) {
			var container = $element.closest('.smucontainer');
			var scroll = function() {
				var alertFace = $("div.alert-hover", $element);
				if (alertFace.length == 0) {
					return;
				}
				var st = container.scrollTop();
				alertFace.css("top", st).css("opacity", st < 10 ? "1" : "0.9");
			};
			container.bind('scroll', scroll);
			$scope.$on('$destroy', function() {
				container.unbind('scroll', scroll);
			});
		}
	};
})
.directive("wulfValidationIcon", function($timeout) {
	return {
		require: "ngModel",
		restrict: "A",
		link: function(scope, element, attrs, ngModelCtrl) {
			var icon = $("<span></span>");
			var okIconDisabled = attrs.okIconDisabled == "true";
			var updateIcon = function(value) {
				$timeout(
					function() {
						if (attrs.ngDisabled && scope.$eval(attrs.ngDisabled)) {
							icon.css('display', 'none');
							feedback.hide();
						} else if (attrs.required && ngModelCtrl.$isEmpty(value)) {
							icon.attr("class", "icon icon-mandatory");
							icon.css('display', '');
							feedback.show();
						} else if (ngModelCtrl.$valid) {
							icon.attr("class", "icon icon-ok");
							if (okIconDisabled || ngModelCtrl.$isEmpty(value)) {
								icon.css('display', 'none');
								feedback.hide();
							} else {
								icon.css('display', '');
								feedback.show();
							}
						} else {
							icon.attr("class", "icon icon-input-error");
							icon.css('display', '');
							feedback.show();
						}
					},
					0
				);
				return value;
			};
			scope.$watch(function() {
				return attrs.required;
			}, function() {
				updateIcon(ngModelCtrl.$viewValue);
			});
			var wrapper = element.wrap("<div></div>").parent();
			var messages = attrs.wulfValidationIcon ? scope.$eval(attrs.wulfValidationIcon) : null;
			var feedback = $();

			(typeof(require) != 'undefined') && require(['wulf/balloon'], function() {
				if (messages) {
					feedback = $("<span></span>")
						.addClass(element.is(".n-inputfield-small") ? "form-control-feedback form-control-feedback-small" : "form-control-feedback")
						.css("pointer-events", "auto")
						.attr("data-toggle", "popover")
						.attr("data-trigger", "manual")
						.append(icon);
					feedback.popover({
							placement: "top",
							html: true,
							content: function () {
								var errors = [];
								var dynamicErrorMessages = ngModelCtrl.$dynamicErrorMessages || {};
								for (var name in ngModelCtrl.$error) {
									var message = dynamicErrorMessages[name] || messages[name];
									if (typeof(message) == "string") {
										errors.push(message);
									}
								}
								if (errors.length == 0) {
									return undefined;
								}
								if (errors.length == 1) {
									return "<div class='smu-must-wrap' style='width:250px;'>" + errors[0] + "</div>";
								}
								var retval = "<ul class='smu-must-wrap' style='width:250px; padding-left: 20px;'>";
								for (var i = 0; i < errors.length; i++) {
									retval += "<li>" + errors[i] + "</li>";
								}
								retval += "</ul>";
								return retval;
							}
						})
						.on("mouseenter", function () {
							if (!icon.is(".icon-ok")) {
								$(this).popover("show");
							}
						})
						.on("mouseleave", function () {
							$(this).popover("hide");
						});
				}
				wrapper.addClass("has-feedback").css("display", "inline-block").append(feedback);
			});

                if (attrs.wrapperClass) {
                    wrapper.addClass(attrs.wrapperClass);
                }
                if (attrs.wrapperStyle) {
                    wrapper.attr("style", attrs.wrapperStyle);
                }

                ngModelCtrl.$parsers.push(updateIcon);
                ngModelCtrl.$formatters.push(updateIcon);
                updateIcon();
            }
        };
    })
    .directive("wulfPanel", function () {
        return {
            restrict: "E",
            replace: true,
            transclude: true,
            scope: {
                panelTitle: "@"
            },
            templateUrl: "wulf-angular/templates/panel.tpl.html"
        };
    })
    .directive("wulfGroup", function () {
        return {
            restrict: "E",
            replace: true,
            transclude: true,
            scope: {
                groupTitle: "@",
                collapsed: "="
            },
            templateUrl: "wulf-angular/templates/group.tpl.html"
        };
    })
    .directive("wulfDialog", function ($timeout) {
        return {
            restrict: "E",
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/dialog.tpl.html",
            scope: {
                type: "@",
                caption: "@",
                height: "@",
                buttons: "@",
                enterIndex: "@enterIndex",
                escIndex: "@",
                helpTip : "@",
                show: "=",
                disabledButtonGroups: "=disabledButtonGroups",
                init: "&",
                click: "&"
            },
            controller: function ($scope) {
                $scope.disableIndexs = [];
                $scope.close = function() {
                    $scope.show = false;
                    $scope.click({buttonIndex: -1});
                };
            },
            link: function (scope, element, attrs) {
                var arr = scope.buttons.split(/\s*\,\s*/);
                for (var i = arr.length - 1; i >= 0; i--) {
                	var value = arr[i];
                	var index = value.lastIndexOf(':');
                	if (index == -1) {
                		arr[i] = { text: value };
                	} else {
                		arr[i] = {
                			text: value.substring(0, index),
                			group: value.substring(index + 1)
                		};
                	}
                }
                scope.buttonArr = arr;
                if (typeof(scope.enterIndex) == "undefined") {
                    scope.enterIndex = 0;
                } else {
                    scope.enterIndex = parseInt(scope.enterIndex);
                }
                if (typeof(scope.escIndex) == "undefined") {
                    scope.escIndex = scope.buttons.split(/\s*\,\s*/).length - 1;
                } else {
                    scope.escIndex = parseInt(scope.escIndex);
                }
            }
        };
    })
    .directive('wulfMultiInput', ["$timeout", function ($timeout) {
        return {
            scope: {
                items: '=',
                options: '=inputOptions',
                additionalClasses: '@',
                btnAdditionalClasses: '@',
                validationOptions: '=',
                valuesChanged: '&'
            },
            templateUrl: 'wulf-angular/templates/wulf-multi-input.tpl.html',
            link: function (scope, ele, attrs) {
                var ulNode = ele.find('ul')[0];
                scope.valueChange = function(index) {
                    if (scope.valuesChanged) {
                        scope.valuesChanged();
                    }
                    if (scope.isPlaceholder(index) && scope.allItems[index] && scope.allItems[index].value) {
                        addItem(index);
					}
				};
                scope.removeClicked = function (index) {
                    removeItem(index);
                    if (scope.valuesChanged) {
                        scope.valuesChanged(); 
                    }
                    forceFocusItem(index);
                };
                scope.forwardTabPressed = false;
                scope.itemBlured = function (event, index) {
                    if (!scope.isPlaceholder(index) && (!scope.allItems[index].value || scope.allItems[index].value.length === 0)) {
                        removeItem(index);
                        if (scope.forwardTabPressed) {
                            forceFocusItem(index);
                            scope.forwardTabPressed = false;
                        }
                    }
                };
                scope.isPlaceholder = function (index) {
                    return index === scope.allItems.length - 1;
                };
                scope.itemKeydown = function (event, index) {
                    scope.forwardTabPressed = (event.keyCode == 9 && !event.shiftKey);
                };
                scope.$watchCollection('items', function(){
                    scope.allItems = scope.items.concat(getPlaceholder());
                });

                function getPlaceholder () {
                    return angular.copy({value: ''});
                }
                function addItem(index) {
                    scope.items.push(scope.allItems[index]);
                    scope.allItems.push(getPlaceholder());
                }
                function removeItem (index) {
                    scope.items.splice(index, 1);
                    scope.allItems.splice(index, 1);
                }
                function findTabableInNode(node) {
                    var selector = 'input, select, button, textarea, a';
                    if ($(node).is(selector)) {
                        return node;
                    }
                    var list = $(node).find(selector);
                    for (var i = 0; i < list.length; i++) {
                        if (!list[i].getAttribute('disabled')) {
                            return list[i];
                        }
                    }
                }
                function nextCandidate(node) {
                    while (node) {
                        if (node.nextSibling) {
                            return node.nextSibling;
                        }
                        node = node.parentNode;
                    }
                }
                function findTabableAfter(startNode) {
                    for (var node = nextCandidate(startNode); node; node = nextCandidate(node)) {
                        var found = findTabableInNode(node);
                        if (found) {
                            return found;
                        }
                    }
                }
                function forceFocusAfter(node) {
                    var nodeToFocus = findTabableAfter(node);
                    if (nodeToFocus) {
                        nodeToFocus.focus();
                    } else {
                        window.focus();
                    }
                }
                function forceFocusItem(index) {
                    //timeout to wait for disable status of Save button changes.
                    $timeout(function () {
                        if (scope.isPlaceholder(index)) {
                            forceFocusAfter(ulNode);
                        } else {
                            var node = ulNode.getElementsByTagName('INPUT')[index];
                            node && node.focus();
                        }
                    }, 0);
                }
            }
        }
    }])
    .directive("wulfMultiSelect", function ($timeout) {
	    return {
	        restrict: 'E',
	        replace: true,
	        templateUrl: "wulf-angular/templates/multi-select.tpl.html",
	        require: "^ngModel",
	        scope: {
	            items: "=",
	            valueField: "@valueField",
	            textField: "@textField",
	            placeholder: "@",
	            preCheck: "&preCheck"
	        },
	        link: function(scope, element, attrs, ngModelCtrl) {
	        	scope.isPlaceholderVisible = function() {
	        		if (typeof(scope.editingText) == "string" && scope.editingText.length) {
	        			return false;
	        		}
	        		var is = scope.items, len = is.length;
	        		for (var i = is.length - 1; i >= 0; --i) {
	        			if (is[i].checked) {
	        				return false;
	        			}
	        		}
	        		return true;
	        	};
	        	scope.itemValue = function(item) {
	        		var field = scope.valueField;
	        		if (field) {
	        			return item[field];
	        		}
	        		return item;
	        	};
	        	scope.itemText = function(item) {
	        		var field = scope.textField;
	        		if (field) {
	        			return item[field];
	        		}
	        		return item;
	        	};
	        	scope.itemOfValue = function(value) {
	        		var items = scope.items;
					for (var i = items.length - 1; i >= 0; --i) {
						if (scope.itemValue(items[i]) == value) {
							return items[i];
						}
					}
					return null;
	        	};
	        	scope.filteredItems = function() {
	        		var filter = scope.editingText;
	        		if (typeof(filter) != "string" || filter.length == 0) {
	        			return scope.items;
	        		}
	        		var items = scope.items, len = items.length, arr = [];
	        		for (var i = 0; i < len; i++) {
	        			var item = items[i];
	        			if (scope.itemText(item).indexOf(filter) == 0) {
	        				arr.push(item);
	        			}
	        		}
	        		return arr;
	        	};
	        	scope.selectedItems = function() {
	        		var arr = [];
	        		var values = ngModelCtrl.$viewValue;
	        		if (values) {
		        		var items = scope.items;
		        		for (var i = 0; i < values.length; i++) {
		        			for (var ii = items.length - 1; ii >= 0; ii--) {
		        				if (scope.itemValue(items[ii]) == values[i]) {
		        					arr.push(items[ii]);
		        					break;
		        				}
		        			}
		        		}
	        		}
	        		return arr;
	        	};
	        	scope.headerClick = function(e) {
	        		if (element.attr("disabled")) {
	        			return;
	        		}
	        		$("input:first", element)[0].focus();
	        		if (!scope.expanding) {
	        			expand();
	        		}
	        	};
	        	scope.toggleItem = function(item, focus) {
	        		if (element.attr("disabled")) {
	        			return;
	        		}
	        		if (focus) {
	        			$("input:first", element)[0].focus();
	        		}
	        		if (!item.checked && angular.isFunction(scope.preCheck)) {
	        			if (scope.preCheck() === false) {
	        				return;
	        			}
	        		}
	        		item.checked = !item.checked;
	        		checkChanged(item);
	        	};
	        	scope.uncheckItem = function(item) {
	        		if (element.attr("disabled")) {
	        			return;
	        		}
	        		item.checked = false;
	        		checkChanged(item);
	        	};
	        	scope.keydown = function(e) {
	        		if (element.attr("disabled")) {
	        			return;
	        		}
	        		if (scope.expanding && (e.keyCode == 9 || e.keyCode == 13)) {
	        			e.stopPropagation();
	        			e.preventDefault();
	        		}
	        		var input = $(e.target);
	        		var oldVal = input.val();
	        		$timeout(function() {
	        			input.css("width", input.val().length > 8 ? "100px" : "50px");
	        			if (oldVal.length == 0 && input.val().length == 0) {
	        				var values = ngModelCtrl.$viewValue || [];
	    	        		switch (e.keyCode) {
	    	        		case 8: // Backspace
	    	        			if (values.length) {
	    	        				var index = scope.chipCaretIndex;
	    	        				if (typeof(index) != "number" || index < 0 || index >= values.length) {
	    	        					index = values.length - 1;
	    		        			}
	    	        				scope.uncheckItem(scope.itemOfValue(values[index]));
	    	        			}
	    	        			break;
	    	        		case 37: // Left
	    	        			if (scope.chipCaretIndex == -1) {
	    	        				scope.chipCaretIndex = values.length - 1;
	    	        			} else if (scope.chipCaretIndex > 0 && scope.chipCaretIndex < values.length) {
	    	        				scope.chipCaretIndex--;
	    	        			}
	    	        			scope.expanding = false;
	    	        			break;
	    	        		case 39: // Right
	    	        			if (scope.chipCaretIndex >= 0 && scope.chipCaretIndex < values.length - 1) {
	    	        				scope.chipCaretIndex++;
	    	        			}
	    	        			scope.expanding = false;
	    	        			break;
	    	        		}
	            		} else if (!scope.expanding) {
	            			expand();
	            		}
	        			var divItems = $("div.dropdown-panel>div", element);
	        			if (typeof(scope.itemCaretIndex) != "number" || scope.itemCaretIndex < 0 || scope.itemCaretIndex >= divItems.length) {
	        				scope.itemCaretIndex = 0;
	        			}
	        			switch (e.keyCode) {
	        			case 38: // Up
	        				if (scope.itemCaretIndex > 0) {
	        					scope.itemCaretIndex--;
	        				} else {
	        					scope.expanding = false;
	        				}
	        				break;
	        			case 40: // Down
	        				if (!scope.expanding) {
	        					expand();
	        				} else {
	        					if (scope.itemCaretIndex < divItems.length - 1) {
	        						scope.itemCaretIndex++;
	        					}
	        				}
	        				break;
	        			case 13: // Enter
	        				if (scope.expanding && scope.itemCaretIndex >= 0 && scope.itemCaretIndex < divItems.length) {
	        					var value = $(divItems[scope.itemCaretIndex]).data("value");
	        					var item = scope.itemOfValue(value);
	        					scope.toggleItem(item);
	        				}
	        				break;
	        			case 27: // Esc
	        				scope.expanding = false;
	        				break;
	        			}
	        			if (scope.itemCaretIndex >= 0 && scope.itemCaretIndex < divItems.length) {
	        				var divItem = divItems[scope.itemCaretIndex];
	        				var divList = divItem.parentNode;
	        				$timeout(function() {
		        				if (divList.scrollTop > divItem.offsetTop) {
		        					divItem.scrollIntoView(true);
		        				} else if (divList.scrollTop + divList.offsetHeight < divItem.offsetTop + divItem.offsetHeight) {
		        					divItem.scrollIntoView(false);
		        				}
	        				}, 0);
	        			}
	        		}, 0);
	        	};
	        	var checkChanged = function(item) {
	        		if (element.attr("disabled")) {
	        			return;
	        		}
	        		var arr = ngModelCtrl.$viewValue || [];
	        		var value = scope.itemValue(item);
	        		if (item.checked) {
	        			arr.push(value);
	        		} else {
	        			for (var i = 0; i < arr.length; i++) {
	        				if (arr[i] == value) {
	        					arr.splice(i, 1);
	        					break;
	        				}
	        			}
	        		}
	        		ngModelCtrl.$setViewValue(arr);
	        		scope.chipCaretIndex = -1;
	        	};
	        	var expand = function() {
	        		scope.expanding = true;
					scope.itemCaretIndex = 0;
					$timeout(function() {
						var SCROLL_BAR = 20;
						var dropdownPanel = $("div.dropdown-panel", element);
						var header = $("div.header");
						var expectedWidth = (dropdownPanel.get(0).scrollWidth || 0) + SCROLL_BAR;
						if (expectedWidth < header.outerWidth()) {
							dropdownPanel.width(header.outerWidth());
						} else {
							dropdownPanel.width(expectedWidth);
						}
					}, 0);
	        	};
	        	var collapse = function(e) {
	        		var multiSelect = $(e.target).closest("div.multi-select");
	        		if (multiSelect.length == 0 || multiSelect[0] != element[0]) {
		        		scope.$apply(function() {
		        			scope.expanding = false;
		        		});
	        		}
	        	};
	        	scope.$on("$destroy", function() {
	        		$(document).unbind("click", collapse);
	        	});
	        	$(document).bind("click", collapse);
	        }
	    }
	})
    .directive("wulfCheckbox", function ($timeout) {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/checkbox.tpl.html",
            scope: {
                name: "@",
                checkChanged: "&",
                checkModel: "=",
                wrapDisabled: '='
            },
            link: function (scope, element, attrs) {
                function assignIdForInput() {
                    var input = element.find("input:first");
                    var label = element.find("label:first");
                    var id = angular.idAllocator.alloc();
                    input.attr("id", id);
                    label.attr("for", id);
                }

                assignIdForInput();
                scope.onChanged = function() {
                    if (angular.isFunction(scope.checkChanged)) {
                        $timeout(function () {
                            scope.checkChanged();
                        }, 0);
                    }
                }
            }
        };
    })
    .directive("wulfToggle", function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: "wulf-angular/templates/toggle.tpl.html",
            require: "ngModel",
            scope: {
                name: "@",
                change: "&"
            },
            link: function (scope, element, attrs, ngModelCtrl) {
                var input = element.find("input:first");
                var label = element.find("label:first");
                if (scope.name) {
                    input.attr("name", scope.name);
                }
                var id = angular.idAllocator.alloc();
                input.attr("id", id);
                label.attr("for", id);
                if (ngModelCtrl) {
                    ngModelCtrl.$render = function () {
                        input.attr("checked", ngModelCtrl.$viewValue);
                    };
                }
                input.on("change", function () {
                    if (ngModelCtrl) {
                        ngModelCtrl.$setViewValue(input.is(":checked"));
                    }
                    scope.$apply(function () {
                        scope.change();
                    });
                });
            }
        }
    })
    .directive("wulfSelect", function ($timeout) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: "wulf-angular/templates/select.tpl.html",
            require: "^ngModel",
            scope: {
                name: "@",
                valueField: "@valueField",
                textField: "@textField",
                items: "@",
                change: "&",
                labelClass: "@labelClass"
            },
            controller: function ($scope) {
                var cascadeGet = function (item, fieldChain) {
                    if (typeof(item) != "undefined") {
                        var fields = fieldChain.split(/\s*\.\s*/);
                        for (var i = 0; i < fields.length && typeof(item) != "undefined"; i++) {
                            item = item[fields[i]];
                        }
                    }
                    return item;
                };
                $scope.itemValue = function (item) {
                    return $scope.valueField ? cascadeGet(item, $scope.valueField) : item;
                };
                $scope.itemText = function (item) {
                    return $scope.textField ? cascadeGet(item, $scope.textField) : item;
                };
                $scope.getItems = function () {
                    return $scope.$parent.$eval($scope.items);
                };
            },
            link: function (scope, element, attrs, ngModelCtrl) {
                ngModelCtrl.$render = function () {
                    $("span.selected-label", element).text("");
                    var newValue = ngModelCtrl.$viewValue;
                    var items = scope.getItems();
                    for (var i = items.length - 1; i >= 0; i--) {
                        var item = items[i];
                        if (scope.itemValue(item) == newValue) {
                            $("span.selected-label", element).text(scope.itemText(item));
                            item.selected = true;
							scope.selectLabelText = scope.itemText(item);
                        } else {
                        	item.selected = false;
                        }
                    }
                };
                scope.$watchCollection(
                    function () {
                        return scope.getItems();
                    },
                    function () {
                        ngModelCtrl.$render();
                    }
                );
                $timeout(function () {
                    element.find("ul:last").click(function (e) {
                        for (var target = e.target; target && target != this; target = target.parentNode) {
                            if (target.nodeName === "LI") {
                                ngModelCtrl.$setViewValue($("span", target).attr("value"));
                                ngModelCtrl.$render();
                                scope.$apply(function () {
                                    scope.change();
                                });
                            }
                        }
                    });
                    $(element).on('show.bs.dropdown', function(e){
                        $(this).find('.dropdown-menu').first().stop(true, true).slideDown(200);
                    });
	                $(element).on('hide.bs.dropdown', function(e){
	                    $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
	                });
                }, 0);
            }
        };
    })
    .directive("editableInput", function () {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/editableInput.tpl.html",
            scope: {
                content: "@",
                click: "&"
            },
            controller: function ($scope) {
                $scope.fireClick = function () {
                    $scope.click();
                    // $scope.editOrclose();
                };
            },
            link: function (scope, element, attrs) {
                scope.editOrclose = function () {
                    var inputer = element.find("div").find("div:first");
                    if (!inputer.hasClass('open')) {
                        inputer.addClass('open');
                    } else {
                        inputer.removeClass('open');
                    }
                };
            }
        };

    })
    .directive("singleTree", function () {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/singletree.tpl.html",
            scope: {
                name: "@",
                isHidden: "@",
                type: "@"
            },
            link: function (scope, element, attrs) {
                scope.changeView = function () {
                    var node = element.find("div:first");
                    var icon = element.find('a:first>span:first');
                    if (node.hasClass('hidden')) {
                        node.removeClass('hidden');
                        icon.removeClass("icon-next").addClass("icon-arrow");
                    } else {
                        node.addClass('hidden');
                        icon.removeClass("icon-arrow").addClass("icon-next");
                    }
                };
            }
        };

    })
    .directive("tabset", function () {
        return {
            restrict: 'E',
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/tabset.tpl.html",
            controller: function ($scope, $element) {
                var ctrl = this;
                $scope.currentTabIndex = -1;
                ctrl.addTab = function (tabheader, isactive, tabcontent) {
                    $scope.currentTabIndex += 1;
                    var tabview = angular
                        .element("<div tab-id='" + $scope.currentTabIndex + "'></div>")
                        .addClass("tab-pane")
                        .append(tabcontent);
                    if (isactive) {
                        disActiveAll();
                        tabview.addClass('active');
                    }
                    $element.find("div:first").append(tabview);
                    return $scope.currentTabIndex;
                };

                ctrl.switchAble = function (element) {
                    if (($(element).hasClass('active'))) {
                        return false;
                    }
                    return true;
                };
                ctrl.switchTab = function (tabindex, element) {
                    var tabcontent = findTabContent(tabindex);
                    if (tabcontent != null) {
                        disActiveAll();
                        $(tabcontent).addClass('active');
                        $(element).addClass('active');
                    }
                };

                ctrl.deleteTab = function (tabindex, element) {
                    var tabcontent = findTabContent(tabindex);
                    if (tabcontent != null) {
                        $(tabcontent).remove();
                        if (($(element).hasClass('active'))) {
                            backToFirstActiveBeforeDelete();
                        }
                        $(element).remove();
                    }
                };

                function backToFirstActiveBeforeDelete(element) {
                    $element.find("div").find('div:first').addClass("active");
                    $element.find("li:first").addClass("active");
                }

                function disActiveAll() {
                    $element.find("div").find('div').removeClass("active");
                    $element.find("li").removeClass("active");
                }

                function findTabContent(tabindex) {
                    var tabcontent = null;
                    var tabcontents = $element.find("div:first").children();
                    for (var i = 0; i < tabcontents.length; i++) {
                        if (tabindex == $(tabcontents[i]).attr('tab-id')) {
                            tabcontent = tabcontents[i];
                            break;
                        }
                    }
                    return tabcontent;
                }

            }
        };
    })
    .directive("tab", function () {
        return {
            require: '^tabset',
            restrict: 'E',
            replace: true,
            transclude: true,
            templateUrl: "wulf-angular/templates/tab.tpl.html",
            scope: {
                header: '@',
                disabled: '@',
                active: '@',
                onload: '&',
                onclose: '&'
            },
            link: function (scope, element, attrs, tabsetCtrl, transclude) {
                // initalize the tab
                scope.tabindex = tabsetCtrl.addTab(scope.header, scope.active, transclude(
                    function (clone) {
                        return clone;
                    })
                );
                // regist tab event
                scope.onTabClick = function (tabindex) {
                    if (tabsetCtrl.switchAble(element)) {
                        //invoke before process callback
                        scope.onload({tabHeader: scope.header});
                        //switch tab
                        tabsetCtrl.switchTab(tabindex, element);
                    }
                };

                scope.onTabClose = function (tabindex, event) {
                    tabsetCtrl.deleteTab(tabindex, element);
                    event.preventDefault();
                    event.stopPropagation();
                    scope.onclose({tabHeader: scope.header});
                };
            }
        };
    });
