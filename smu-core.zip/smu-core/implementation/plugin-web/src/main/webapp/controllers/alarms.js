smuApp.directive("smuAlarmTable", ['$interval', '$timeout', function() {
    return {
        restrict: "E",
        replace: true,
        templateUrl: "templates/alarm-table.tpl.html",
        controller: function( $scope, $http, $interval, $timeout, createNotification) {
        	$scope.notification = createNotification();
        	$scope.allChecked = false;
            $scope.maxExceeded = false;
            $scope.checkAll = function(check) {
                for(var i = 0; i < $scope.alarms.length; i++) {
                    $scope.alarms[i]['checked'] = check;
                }
            };
            $scope.toggleCheckAll = function () {
                $scope.checkAll($scope.allChecked);
            };

            $scope.onAlarmCheck = function() {
                $scope.allChecked = $scope.isAlarmAllChecked();
            };

            $scope.loadAlarms = function(loadOption) {
                $scope.alarmCheckedForBackup = $scope.getCheckedAlarmIds();
            	$scope.alarmLoading = true;
            	$http.post("rest/alarms/query", JSON.stringify($scope.specification))
            	 .then(function (response) {
            		 	var limitedResult = response.data;
                        $scope.maxExceeded = limitedResult.overflow;
                        if( limitedResult.entities){
                        	$scope.alarms = limitedResult.entities;
                        }else{
                        	$scope.alarms = [];
                        }
                        $scope.totalAlarmNumber =   limitedResult.totalAlarmNumber;
                        $scope.matchedAlarmNumber =   limitedResult.matchedAlarmNumber;
                        $scope.$emit('alarmsLoaded', loadOption);
                        $scope.notification.hide("tag-load-alarms");
                        $scope.alarmLoading = false;
                    }, function(response){
                        var reason = 'unknown reason';
                    	if (response.data && response.data.errorCategory === "database") {
                            reason = "database error";
                    	} else if (response.data && response.data.error) {
                    	    reason = response.data.error;
                        }
                    	else if (response.statusText) {
                    		reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                    	}
                    	else if (response.status === -1) {
                    	    reason = 'network unavailable';
                        }

                        $scope.notification.error("Unable to load alarms due to " + reason + ".", "tag-load-alarms");
                        $scope.alarmLoading = false;
                    });
            };

            $scope.loadAlarms();

            $scope.selectAlarm = function(alarm) {
                if (!alarm) {
                    $scope.selectedAlarm = null;
                    return;
                }

                var old = $scope.selectedAlarm;

                $scope.selectedAlarm = alarm;
                $scope.$emit('alarmSelectionChanged', old, alarm);
            };

            $scope.keydown = function(e) {
            	if ($scope.selectedAlarm == null) {
            		return;
            	}
            	var up = e.keyCode == 38;
            	var down = e.keyCode == 40;
            	if (!up && !down) {
            		return;
            	}
            	for (var i = $scope.alarms.length - 1; i >= 0; i--) {
            		if ($scope.alarms[i] == $scope.selectedAlarm) {
            			if (up && i > 0) {
            				$scope.selectAlarm($scope.alarms[i - 1]);
            			} else if (down && i < $scope.alarms.length - 1) {
            				$scope.selectAlarm($scope.alarms[i + 1]);
            			}
            			break;
            		}
            	}
            };

            var alarmUpdateInterval = $interval(function () {
            	if($scope.dataAutoRefresh){
                	$scope.loadAlarms();
                }
            }, 15000);

            $scope.$on("$destroy", function() {
                $interval.cancel(alarmUpdateInterval);
            });
        }
    };
}]);

smuApp.controller("alarmController", function( $scope, $http, $timeout, $location, $document, $element, $window, createNotification, $sce) {
	$scope.notification = createNotification();
	$scope.dataAutoRefresh = true;
	$scope.componentRefs = [ { displayName: "All", component: { id: "" } } ];
	$scope.alarms = [];
	$scope.alarmCheckedForBackup = [];
	$scope.alarmCount = 0;
	$scope.alarmLoading = false;
    $scope.alarmsLimit = 1000;
    $scope.specification = {
    		critical: false,
    		major: false,
    		minor: false,
    		includeAcked: true,
    		componentId: "",
    		order: {
    			field: "alarmTime",
        		mode: "desc"
    		}
    };
    $scope.manPageInfo = {};

    function updateTableHeight() {
        var rowsWrapper = $element.find('.alarms-table .table-area');
        if (!rowsWrapper.length) {
            return;
        }

        var vh = $window.innerHeight;
        var offsetTop = $scope.notification.visible() ? 506 : 440;
        var rowsHeight = vh - offsetTop;
        rowsWrapper.css('max-height', rowsHeight + 'px');
        $scope.rowsHeightUpdated = true;
    }

    $scope.filtered = function() {
        var spec = $scope.specification;
        return spec.componentId !== "" || !(spec.critical && spec.major && spec.minor) || !spec.includeAcked
    };

    $scope.$watch('notification.visible()', updateTableHeight);
    $window.addEventListener('resize', updateTableHeight);

    $http.get('rest/components/list').then(function (response) {
        var data = response.data;
    	if (data) {
            data.forEach(function (componentRef) {
                $scope.componentRefs.push(componentRef);
            });

            // Add unmapped component.
            $scope.componentRefs.push({
                "component": {"id": "unmapped", "displayName": "Unmapped", "children": []},
                "displayName": "Unmapped"
            });
        }
    },function(){});

    $http.get('rest/alarms/operation-allowed').then(function(response) {
    	$scope.operationAllowed = response.data;
    },function(){});

    function updateSpecificationByFilters(){
    	if($location.search().all){
    		$scope.specification = {
	    		critical: true,
	    		major: true,
	    		minor: true,
	    		includeAcked: true,
	    		componentId: "",
	    		order: {
	    			field: "alarmTime",
	        		mode: "desc"
	    		}
    	    };
    	}else{
    		if($location.search().critical){
    			$scope.specification.critical=true;
    		}
    		if($location.search().major){
    			$scope.specification.major=true;
    		}
    		if($location.search().minor){
    			$scope.specification.minor=true;
    		}
    		if($location.search().includeAcked){
    			$scope.specification.includeAcked=true;
    		}
    		if($location.search().componentId){
    			$scope.specification.componentId = $location.search().componentId;
    		}
    		if($location.search().orderfield){
    			$scope.specification.order.field = $location.search().orderby;
    		}
    		if($location.search().asc){
    			$scope.specification.order.mode = "asc";
    		}
    	}
    }
    updateSpecificationByFilters();


    function stopRefresh(){
    	$scope.dataAutoRefresh = false;
    }

    $scope.getCheckedAlarmIds = function(ackStatus) {
        var ids = [];
        if (!$scope.alarms){
        	return ids;
        }
        for (var i = 0; i < $scope.alarms.length; i++) {
            if ($scope.alarms[i].checked) {
                if (ackStatus) {
                    if ($scope.alarms[i].ackState == ackStatus) {
                        ids.push($scope.alarms[i].id);
                    }
                    continue;
                }
                ids.push($scope.alarms[i].id);
            }
        }

        return ids;
    };
    $scope.sortIconClass = function(field) {
    	if (field == $scope.specification.order.field) {
    		return $scope.specification.order.mode == "asc" ? "icon-arrow-up" : "icon-arrow";
    	}
    	return "";
    };
    
    $scope.orderBy = function(field) {
    	if (field == $scope.specification.order.field) {
    		$scope.specification.order.mode = $scope.specification.order.mode == "asc" ? "desc" : "asc";
    	} else {
    		$scope.specification.order.field = field;
    	}
    	$scope.loadAlarms({resetSelection: true});
    };
    $scope.operateAlarms = function(action, success, error) {
        var ids = $scope.getCheckedAlarmIds();
        $http.post('rest/alarms/update', {operation: action, ids: ids}).then(success,error);
    };

    $scope.showOperationStatusDialog = function(msg) {
        $scope.operationMessage = msg;
        $scope.showOperationDialog = true;
    };

    $scope.showErrorMessageDialog = function(msg) {
        $scope.errorMessage = msg;
        $scope.showErrorDialog = true;
    };

    function onOperateErr(operation) {
        return function(response) {
            var reason = 'unknown reason';
            if (response.data && response.data.errorCategory === "database") {
                reason = "database error";
            } else if (response.data && response.data.error) {
                reason = response.data.error;
            }
            else if (response.statusText) {
                reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
            }
            else if (response.status === -1) {
                reason = 'network unavailable';
            }
            $scope.operationError = 'Failed to send ' + operation + ' due to ' + reason + ".";
            $scope.notification.error($scope.operationError, "tag-load-alarms");
        }
    }

    $scope.doAcknowledge = function(e) {
        $scope.operateAlarms('ack', function(response) {
            $scope.notification.ok('Acknowledgement request sent.', 3000);
        }, onOperateErr('acknowledgement'));
    };

    $scope.doUnacknowledge = function(e) {
        $scope.operateAlarms('unack', function(response) {
            $scope.notification.ok('Unacknowledgement request sent.', 3000);
        }, onOperateErr('unacknowledgement'));
    };

    $scope.doCancel = function (e) {
        $scope.operateAlarms('cancel', function(response) {
            $scope.notification.ok('Cancellation request sent.', 3000);
        }, onOperateErr('cancellation'));
    };

    $scope.closeOperationDialog=function(buttonIndex){
    	$scope.showOperationDialog = false;
    };

    $scope.closeErrorDialog=function(buttonIndex){
    	$scope.showErrorDialog = false;
    };

    function restoreAlarmsCheckStatus(newAlarms, selectedAlarmIDs){
    	if ( newAlarms && newAlarms.length != 0 && selectedAlarmIDs && selectedAlarmIDs.length != 0 ) {
    		for (var i=0 ; i < newAlarms.length ; i++){
    			for (var j=0; j< selectedAlarmIDs.length; j++){
    				if( $scope.alarms[i].id == selectedAlarmIDs[j] ){
    					$scope.alarms[i]['checked'] = true;
    				}
    			}
    		}
    	}
    }

    $scope.isAlarmAllChecked = function() {
        if (!$scope.alarms.length)
            return false;

        for (var i = 0, len = $scope.alarms.length; i < len; i++) {
            if (! $scope.alarms[i]['checked']) {
                return false;
            }
        }

        return true;
      };

    $scope.$on('alarmsLoaded', function(event, loadOption) {
        var toBeSelected = null;

        var oldSelectedAlarm = $scope.selectedAlarm;
        if ($scope.alarms && oldSelectedAlarm && !(loadOption && loadOption.resetSelection)) {
            for (var i = $scope.alarms.length - 1; i >= 0; i--) {
                var alarm = $scope.alarms[i];
                if (alarm.id == oldSelectedAlarm.id) {
                    toBeSelected = alarm;
                    break;
                }
            }
        }

        if ( !toBeSelected && $scope.alarms &&  $scope.alarms.length > 0) {
            toBeSelected = $scope.alarms[0];
        }

        $scope.selectAlarm(toBeSelected);


        if ($scope.alarms && $scope.alarms.length) {
            restoreAlarmsCheckStatus($scope.alarms, $scope.alarmCheckedForBackup);
        }

        $scope.allChecked = $scope.isAlarmAllChecked();

        if (!$scope.rowsHeightUpdated) {
            updateTableHeight();
        }
    });

    $scope.$on('alarmSelectionChanged', function(event, old, alarm) {
        if (alarm) {
            if (!old || old.id != alarm.id) {
                updateManPageInfo();
            }
        }
    });

    $scope.operationMessage = "";
    $scope.showOperationDialog = false;
    $scope.errorMessage = "";
    $scope.showErrorDialog = false;

    var updateManPageInfo = function() {
    	$scope.manPageLoading = true;
        $scope.manPageInfo = null;
        $http.get("rest/alarms/man-page-info?&alarmId=" + $scope.selectedAlarm.id)
            .then(function (response) {
                var manPageInfo = response.data;
                if (manPageInfo == undefined || manPageInfo === "") {
                    manPageInfo = {};
                }
                $scope.manPageInfo = manPageInfo;
                if ($scope.manPageInfo.userComments) {
                    $scope.manPageInfo.userComments = $sce.trustAsHtml($scope.manPageInfo.userComments);
                }
                $scope.manPageLoading = false;
            }, function () {
                $scope.manPageLoading = false;
            });
    };

    $document.find('body').css('min-width', '1409px');
    $scope.$on("$destroy", function () {
        $document.find('body').css('min-width', '');
    });
});
