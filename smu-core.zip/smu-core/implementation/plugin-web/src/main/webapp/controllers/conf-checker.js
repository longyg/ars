smuApp.service("hostCompare",function(){
    function Extractor(s) {
        var pattern = /\d+|[^\d]+/g;
        this.str = s || "";
        this.results = this.str.match(pattern);
        this.index = 0;
    }
    Extractor.prototype.next = function() {
    	if (!this.results || !this.results.length) {
    		return null;
		}

        var result = this.results[this.index++];
        if (result) {
            return {
                value: result,
                type: result.match(/^\d/) ? 'digit' : 'string'
            }
        } else {
            return null;
        }
    };

    function comparePart(a, b) {
        if (!a && !b) return null;
        if (!a) return -1;
        if (!b) return 1;

        if (a.type === 'digit' && b.type === 'digit') {
            return parseInt(a.value) - parseInt(b.value);
        } else {
            if (a.value === b.value) {
                return 0;
            } else {
                return a.value < b.value ? -1 : 1;
            }
        }
    }

    return function hostCompare(a, b) {
        var ea = new Extractor(a);
        var eb = new Extractor(b);
        while (true) {
            var result = comparePart(ea.next(), eb.next());
            if (result === null) {
                break;
            } else if (result !== 0) {
                return result;
            }
        }
        return 0;
    }
});

smuApp.filter('orderByHostName', function(hostCompare){
    return function (arr) {
        return arr.sort(function(a, b) {
            return hostCompare(a.value, b.value);
        });
    }
})
.controller("confCheckerController", function($scope, $http, $element, $timeout, createNotification, hostCompare) {
	$scope.notification = createNotification();
	$scope.fields = [
	    {
	    	name: "hostName",
	    	text: "Host name",
	    	filterType: "default",
	    	width: "10%"
	    },
	    {
	    	name: "service",
	    	text: "Service",
	    	filterType: "default",
	    	width: "8%"
	    },
	    {
	    	name: "fileName",
	    	text: "Configuration file",
	    	filterType: "regexp"
	    },
	    {
	    	name: "lastChangeTime",
	    	text: "Last change time",
	    	filterType: "select-days",
	    	filterData: [
	    	    { value: null, text: "All" },
	    	    { value: 1, text: "Past 1 day" },
	    	    { value: 2, text: "Past 2 days" },
	    	    { value: 3, text: "Past 3 days" },
	    	    { value: 4, text: "Past 4 days" },
	    	    { value: 7, text: "Past 1 week" },
	    	    { value: 14, text: "Past 2 weeks" }
	    	],
	    	width: "12%"
	    },
	    {
	    	name: "changeLog",
	    	text: "Operations",
	    	disableSorting: true,
	    	width: "13%"
	    }
	];

	$scope.showChangedDataOnly = true;

	// "encodeURIComponent" can't be invoked by angular expressions "{{ ... }}" in the html templates,
	// so support this boring wrapper function "encodedFilePath" to do it.
	$scope.encodedFilePath = function(filePath) {
		return encodeURIComponent(filePath);
	};
	$scope.loadReport = function(refresh) {
		var url = "rest/conf-checker/report";
		if (refresh) {
			url += "?refresh=true";
		}
		$scope.loading = true;
		$http
		.post(url)
		.then(function(response) {
			var report = response.data;
			$scope.report = report;
			$scope.sortingFieldName = $scope.fields[0].name;
			$scope.determineViewableItems();
			$scope.notification.hide("tag-load-report");
		}, function(response, status) {
            var reason = 'unknown reason';
            if (response.data && response.data.errorCategory === "database") {
                reason = "database error";
            }
			else if (response.data && response.data.errorCategory == "rootAccess") {
                reason = "root SSH login is disabled, please enable root SSH login first. Check <a target='_blank' style='color:#00a1cc;' href='/Infocenter/index.jsp?topic=%2Fconfiguration_checker%2Fconcepts%2Fintroduction.html'>product documentation</a> for enabling root SSH login.";
            }
            else if (response.data && response.data.error) {
                reason = response.data.error;
            }
            else if (response.status === 404) {
            	reason = 'report does not exist';
			}
            else if (response.statusText) {
                reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
            }
            else if (response.status === -1) {
                reason = 'network unavailable';
            }

            $scope.notification.error("Unable to fetch configuration change due to " + reason + ".", "tag-load-report");
		})["finally"](function() {
			$scope.loading = false;
		});
	};

	$scope.loadReport(false);

	require(['jquery','wulf/balloon'], function () {
		$('[data-toggle="popover"]').popover();
		$('[data-toggle="popover"]').popover();
	});


	$scope.filterActivated = function() {
		if (!$scope.fields) { return false; }

        for (var i = 0; i < $scope.fields.length; i++) {
			var f = $scope.fields[i];
            var fm = $scope.filterMap[f.name];
			if (fm && fm.dirty && fm.dirty()) {
				return true;
			}
		}
		return false;
	};

	$scope.determineViewableItems = function() {

		var allItems = $scope.report.items;
		if ($scope.showChangedDataOnly) {
			var arr = [];
			for (var i = 0; i < allItems.length; i++) {
				if (allItems[i].changeLog) {
					arr.push(allItems[i]);
				}
			}
			$scope.viewableItems = arr;
		} else {
			$scope.viewableItems = allItems;
		}

		var changedFileCount = 0;
		for (var i = allItems.length - 1; i >= 0; i--) {
			if (allItems[i].changeLog) {
				changedFileCount++;
			}
		}
		$scope.changedFileCount = changedFileCount;

		var filterMap = {};
		for (var i = $scope.fields.length - 1; i >= 0; i--) {
			var field = $scope.fields[i];
			if (!field.filterType) {
				continue;
			}
			var filter = { field: field, type: field.filterType, state: {} };
			if (filter.type == "select-days") {
				filter.match = function(value) {
					if (!this.state.value) {
						return true;
					}
					var now = new Date().getTime();
					var days = parseInt(this.state.value);
					return value >= now - days * 24 * 60 * 60 * 1000;
				};
				filter.dirty = function() {
					return this.state.value;
				};
				filter.selectedText = function() {
					var arr = this.field.filterData;
					if (arr && arr.length) {
						for (var i = arr.length - 1; i > 0; i--) {
							if (arr[i].value == this.state.value) {
								return arr[i].text;
								break;
							}
						}
						return arr[0].text;
					}
					return null;
				};
			} else if (filter.type == "regexp") {
				filter.match = function(value) {
					if (!this.state.value) {
						return true;
					}
					return new RegExp(this.state.value, "i").test(value);
				};
				filter.dirty = function() {
					return this.state.value;
				};
			} else if (filter.type == "default") {
				filter.match = function(value) {
					return this.state[value];
				};
				filter.dirty = function() {
					for (var key in this.state) {
						if (!this.state[key]) {
							return true;
						}
					}
					return false;
				};
				filter.selectedText = function() {
					if (this.allSelected) {
						return "All";
					}
					var arr = this.items;
					var texts = [];
					for (var i = arr.length - 1; i >= 0; i--) {
						var item = arr[i];
						if (this.state[item.value]) {
							texts.push(item.value);
						}
					}
					if (texts.length == 0) {
						return "None";
					}
					texts.sort(function(a, b) {
						if (a < b) {
							return -1;
						}
						if (a > b) {
							return +1;
						}
						return 0;
					});
					return texts.join(", ");
				};
				filter.allSelected = true;
				var filterItems = [];
				var distinctMap = {};
				for (var ii = 0; ii < $scope.viewableItems.length; ii++) {
					var value = $scope.viewableItems[ii][field.name];
					if (!distinctMap[value]) {
						distinctMap[value] = true;
						filterItems.push({"value": value});
					}
				}
				for (var key in distinctMap) {
					filter.state[key] = true;
				}
				filter.items = filterItems;
			}

			filterMap[field.name] = filter;
		}
		$scope.filterMap = filterMap;

		$scope.selectedReportItemCache = null;
	};

	$scope.toggleFilter = function(fieldName, e) {
		if ($scope.droppingDownFilterFieldName === fieldName) {
			$scope.droppingDownFilterFieldName = null;
		} else {
			$scope.droppingDownFilterFieldName = fieldName;
			$timeout(function() {
				var input = $(e.target).closest("th").find("div.dropdown-content").find(" input:first, button:first, select:first");
				if (input.length) {
					input[0].focus();
				}
			}, 0);
		}
	};
	$scope.filterContentKeyup = function(filter, e) {
		if (e.keyCode === 27) {
			$scope.droppingDownFilterFieldName = null;
		}
		if (filter.field.name == "lastChangeTime" && $scope.droppingDownFilterFieldName == filter.field.name) {
			var arr = filter.field.filterData;
			if (e.keyCode == 40) {
				for (var i = arr.length - 1; i >= 0; i--) {
					if (filter.state.value == arr[i].value && i < arr.length - 1) {
						filter.state.value = arr[i + 1].value;
						$scope.selectedReportItemCache = null;
						break;
					}
				}
			} else if (e.keyCode == 38) {
				for (var i = arr.length - 1; i >= 0; i--) {
					if (filter.state.value == arr[i].value && i > 0) {
						filter.state.value = arr[i - 1].value;
						$scope.selectedReportItemCache = null;
						break;
					}
				}
			}
		}
	};

	$scope.toggleSorting = function(field, e) {
		if (!field.disableSorting) {
			// The clicked element is neither filter nor dropdown content.
			if ($(e.target).closest("div[role='filter']").length == 0 && $(e.target).closest("div.dropdown-content").length == 0) {
				if ($scope.sortingFieldName == field.name) {
					$scope.descending = !$scope.descending;
				} else {
					$scope.descending = false;
					$scope.sortingFieldName = field.name;
				}
				$scope.selectedReportItemCache = null;
			}
		}
	};

	$scope.toggleSelectAll = function(fieldName) {
		var filter = $scope.filterMap[fieldName];
		var allSelected = filter.allSelected;
		var filterItems = filter.items;
		for (var i = filterItems.length - 1; i >= 0; i--) {
			filter.state[filterItems[i].value] = allSelected;
		}
		$scope.selectedReportItemCache = null;
	};

	$scope.toggleSelect = function(fieldName, filterItem) {
		var filter = $scope.filterMap[fieldName];
		if (!filter.state[filterItem.value]) {
			filter.allSelected = false;
		} else {
			var allSelected = true;
			var filterItems = filter.items;
			for (var i = filterItems.length - 1; i >= 0; i--) {
				if (!filter.state[filterItems[i].value]) {
					allSelected = false;
					break;
				}
			}
			filter.allSelected = allSelected;
		}

		$scope.selectedReportItemCache = null;
	};

	$scope.daysChanged = function(value) {
		$scope.filterMap['lastChangeTime'].state.value = value;
		$scope.selectedReportItemCache = null;
		$scope.droppingDownFilterFieldName = null;
	};

	$scope.regexpChanged = function() {
		$scope.selectedReportItemCache = null;
	};

	$scope.selectedReportItems = function() {
		var result = $scope.selectedReportItemCache;
		if (result) {
			return result;
		}
		result = [];
		var items = $scope.report ? $scope.report.items : [];
		for (var i = 0; i < items.length; i++) {
			var item = items[i];
			var unmatched = false;
			for (var fieldName in $scope.filterMap) {
				var value = item[fieldName];
				var filter = $scope.filterMap[fieldName];
				if (!filter.match(value)) {
					unmatched = true;
					break;
				}
			}
			if (!unmatched) {
				result.push(item);
			}
		}

		if ($scope.sortingFieldName == "hostName") {
			sortResult(result, [ "hostName", "service" ]);
		} else if ($scope.sortingFieldName == "service") {
			sortResult(result, [ "service", "hostName" ]);
		} else {
			sortResult(result, [ $scope.sortingFieldName, "service", "hostName" ]);
		}
		$scope.selectedReportItemCache = result; // Very important for performance!!!.
		return result;
	};
    
    $scope.isRemovedFile = function(changeLog) {
		if( changeLog.length == 0 ) {
            return false
        }
        if (changeLog.indexOf('File is deleted from current system') != -1) {
            return true
        } else {
            false
        }
	};

    var sortResult = function(result, fields) {
        result.sort(function(a, b) {
            for (var i = 0; i < fields.length; i++) {
                var v1 = a[fields[i]];
                var v2 = b[fields[i]];
                var cmp = 0;
                if (v1 === v2) {
                    cmp = 0;
               } else if (!v1) {
                    cmp = -1;
               } else if (!v2) {
                    cmp = +1;
               } else {
                    if (fields[i] === 'hostName') {
                        cmp = hostCompare(v1, v2);
                    } else {
                        cmp = strCompareIgnoreCase(v1, v2);
                    }
               }

                if (cmp != 0) {
                    return $scope.descending ? -cmp : cmp;
                }
            }
            return 0;
        });
    };

    var strCompareIgnoreCase = function(v1, v2) {
        var cmp = 0;
        if (typeof(v1) == "string") {
            v1 = v1.toUpperCase();
        }
        if (typeof(v2) == "string") {
            v2 = v2.toUpperCase();
        }
        if (v1 < v2) {
            cmp = -1;
        } else if (v1 > v2) {
            cmp = +1;
        }
        return cmp;
    };

	$scope.selectConfItem = function(index) {
		$scope.selectedIndex = index;
	}

	$scope.tableKeyDown = function(e) {
		if (e.keyCode == 38 && $scope.selectedIndex > 0) {//up
			$scope.selectedIndex--;
		} else if (e.keyCode === 40 && $scope.selectedIndex < $scope.selectedReportItems().length - 1) {//down
			$scope.selectedIndex++;
		}
	}

	var handler = function(e) {
		if ($(e.target).closest("button.dropdown-toggle").length == 0 && $(e.target).closest("div.dropdown-content").length == 0) {
			$scope.$apply(function() {
				$scope.droppingDownFilterFieldName = null;
			});
		}
	};
	$(document.body).bind("click", handler);
	
	var clipboard = new Clipboard("div.copy-log-path>a", {
		text: function(trigger) {
			return $(trigger).closest("td").attr("data-log-path");
		}
	});
	clipboard.on('success', function(e) {
		var itemScope = angular.element(e.trigger).scope();
		itemScope.$apply(function() {
			itemScope.reportItem.copied = true;
		});
	});
	
	$scope.$on('$destroy', function() {
		var popovers = $('[data-toggle="popover"]');
		popovers.popover && popovers.popover('hide');
		$(document.body).unbind("click", handler);
		
		clipboard.destroy();
    });
});
