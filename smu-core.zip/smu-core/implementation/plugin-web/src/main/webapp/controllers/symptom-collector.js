smuApp
.controller('symptomCollectorController', function($scope, $element, $timeout, $http, $element, $filter, $document,$window, createNotification, smuCacheService) {
	var TASK_REFRESH_TIME = 1000; //5000;
    var A_DAY = 1000 * 60 * 60 * 24;

    $scope.notification = createNotification();

	$scope.loadSymScenarios = function() {
        $http
            .get("rest/symptom-collector/scenarios")
            .then(function (response) {
            	var data = response.data;
                data.forEach(function (scenario, index) {
                    $scope.cache.symScenarios.push({
                        displayName: scenario,
                        scenario: scenario
                    });
                });	
            },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                    reason = reason.replace(/symptom-collector:?/, '');
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.cache.symScenarioLoadError = "Cannot list scenarios due to " + reason;
            })['finally'](function() {
            $scope.cache.symScenarioLoading = false;
        });
        $scope.cache.symScenarioLoading = true;
    };

	$scope.loadSymComponents = function() {
        $http
            .get("rest/symptom-collector/components")
            .then(function (response) {
            	var data = response.data;
                data.forEach(function (scenario, index) {
                    $scope.cache.symComponents.push({
                        displayName: scenario,
                        component: scenario
                    });
                });
            },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                    reason = reason.replace(/symptom-collector:?/, '');
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.cache.symComponentsLoadError = "Cannot list components due to " + reason;
            })['finally'](function() {
            $scope.cache.symComponentsLoading = false;
        });
        $scope.cache.symComponentsLoading = true;
    };


	$scope.initialize = function () {
		var cacheDataRef = smuCacheService.getData(CACHE_KEY_SYMPTOM_COLLECTOR);
		if (cacheDataRef) {
			$scope.cache = cacheDataRef;
		}
		else {
			smuCacheService.setData(CACHE_KEY_SYMPTOM_COLLECTOR, {
				sympTaskArgument: {
					scenarios: [],
					components: []
				},
				currentTask: {},
				collectStatus: "",
				packFiling: false,
				taskType: "Collect",
				symScenarioLoadError: false,
				symScenarioLoading: false,
				symComponentsLoadError: false,
				symComponentsLoading: false,
				showSymScenarioLoadingErrorNotice: false,
				showSymComponentsLoadingErrorNotice: false,
				symComponents: [],
				symScenarios: [],
				isMaxLimiation: false,
				collectingOngoing: false,
				collectOnce: false,
				onGoingDialogVisible: false,
				collectCreationError: null,
				isCreatingCollect: true,
				downloading: false,
				isResultUpdating: false
			});
			$scope.cache = smuCacheService.getData(CACHE_KEY_SYMPTOM_COLLECTOR);

			$scope.loadSymScenarios();
			$scope.loadSymComponents();
		}
	}
	$scope.initialize();

	$scope.tryStartCollect = function() {
        $scope.cache.collectCreationError = null;
        if ($scope.cache.currentTask.state == 'PENDING' || $scope.cache.currentTask.state == 'RUNNING') {
            $scope.cache.onGoingDialogVisible = true;
            setTimeout(function() { $element.find('.btn.close-dlg')[0].focus();}, 50);
        } else {
            $scope.startCollect();
			$scope.cache.taskType = "Collect";
			
        }
    };
    $scope.startCollect = function() {
        var collectRequest = angular.extend({}, $scope.cache.sympTaskArgument);
        
        $http.post("rest/symptom-collector/create", JSON.stringify(collectRequest))
            .then(function(response) {
            	var task = response.data;
                $scope.cache.collectingOngoing = true;
                $scope.cache.currentTask = task;
                $scope.cache.packFiling=true;
                $scope.cache.collectOnce = true;
                $scope.cache.collectStatus="";
            },function (response) {
            	var responseData = response.data;
				if (responseData.error.indexOf("symptom collection is running") != -1) {
					$scope.cache.onGoingDialogVisible = true;
				} else {
                    var reason = 'unknown reason';
                    if (response.data && response.data.errorCategory === "database") {
                        reason = "database error";
                    } else if (response.data && response.data.error) {
                        reason = response.data.error;
                    }
                    else if (response.statusText) {
                        reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                    }
                    else if (response.status === -1) {
                        reason = 'network unavailable';
                    }

                    $scope.cache.collectCreationError = "Unable to collect symptom due to " + reason + "."
                    $scope.notification.error($scope.cache.collectCreationError, "tag-create-task");
				}
            })['finally'](function() {
                $scope.cache.isCreatingCollect = false;
            });
        $scope.cache.isCreatingCollect = true;
    };
	
	$scope.cancelCollect = function() {
		$scope.cache.collectingOngoing = false;
        $http.post("rest/symptom-collector/cancel-task?taskId=" + $scope.cache.currentTask.id)
        .then(function() {
        	$scope.notification.hide("tag-cancel-task");
        },function (response) {
            var reason = 'unknown reason';
            if (response.data && response.data.errorCategory === "database") {
                reason = "database error";
            } else if (response.data && response.data.error) {
                reason = response.data.error;
            }
            else if (response.statusText) {
                reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
            }
            else if (response.status === -1) {
                reason = 'network unavailable';
            }

            $scope.notification.error("Unable to collect symptom due to " + reason + ".", "tag-cancel-task");
        });
        
	};
    
    $scope.formatChipText = function(str) {
        var maxChipTextLen = 32;
        if ( str.length > maxChipTextLen ) {
            var retStr = str;
            return retStr.slice(0, maxChipTextLen-3) + '...';
        } else {
            return str;
        }
    };

    function updateStatusArea() {
        var outputText =  document.getElementById('ta-readonly');
		if (outputText) {
			var s_height = outputText.scrollHeight + 2;
			outputText.setAttribute('style','height:'+s_height+'px');
		}
    }

    function parseOutput(outputList) {
       $scope.cache.collectStatus="";
       var recOutput = [];
       var i = 0;
       for(i=0; i<outputList.length; i++)
       {
         if(outputList[i].unparsedLine.indexOf("Progress") == -1)
         {
           //recOutput.push("\r\n");
           recOutput.push(outputList[i].unparsedLine);
         }
         else
         {
			if(i == 0)
			{				
				recOutput.push(outputList[i].unparsedLine);
			}
			else
			{
				if(outputList[i-1].unparsedLine.indexOf("Progress") == -1)
				{
					recOutput.push(outputList[i].unparsedLine);
				}else
				{
				   recOutput[recOutput.length-1]=outputList[i].unparsedLine;
				}
			}
         }
       }
       $scope.cache.collectStatus = recOutput.join("\r\n");
       updateStatusArea();
    }
    function requestTaskPart(request, semaphore) {
        if (request.taskId == null) {
            semaphore && semaphore.release();
            return semaphore;
        }
		if($scope.cache.taskType == "Collect"){
			$http.post("rest/symptom-collector/task-part?taskId=" + request.taskId, request)
				.then(function(response) {
					if (request.taskId != $scope.cache.currentTask.id) {
						/* This happens when the response of 'create' finished before this response comes,
						* in which case the currentTask.id has been changed to the new id. So just abandon this response */
						return;
					}
					$scope.cache.currentTask = response.data.task || {};
                    parseOutput(response.data.outputLines);

                    
                    
					$scope.cache.downloading = response.data.downloading;
					if (request.errorRequest && response.data.errors) {
						$scope.updateTaskErrors(response.data.errors);
					}
                    $scope.notification.hide("tag-task-part");
				}, function(response) {
					loadingError = response.data.error || 'Failed to update collect result due to: ' + (response.statusText ? response.statusText.charAt(0).toLowerCase() + response.statusText.slice(1) : 'unknown reason');
					if (response.status == 404) {
						loadingError = 'Collect result not found, it maybe has been cleaned up.';
						if ($scope.cache.currentTask.state == 'RUNNING' || $scope.cache.currentTask.state == 'PENDING') {
							$scope.cache.currentTask.state = 'FAILED';
						} else if ($scope.cache.currentTask.state == 'STOPPING' ){
							$scope.cache.currentTask.state = 'STOPPED';
						}
						$scope.cache.currentTask.removedByServer = true;
					}
					$scope.cache.downloading = false;
                    $scope.notification.error("Unable to collect symptom because " + loadingError.toLowerCase(), "tag-task-part");
				})["finally"](function () {
                    updateStatusArea();
					$scope.cache.isResultUpdating = false;
					semaphore && semaphore.release();
				});
				if ($scope.cache.currentTask.state == 'FAILED' || $scope.cache.currentTask.state == 'STOPPED' || $scope.cache.currentTask.state == 'FINISHED') {
					$scope.cache.collectingOngoing = false;
				}
		}
        return semaphore;
    }

    var taskRefresher = Scheduler.fixedDelay(TASK_REFRESH_TIME, function () {
		var semaphore = Scheduler.semaphore();
        var request = {taskId: $scope.cache.currentTask.id};
		var keywordUrlParams = 'offset=0';
		if($scope.cache.currentTask.state == 'FINISHED' && $scope.cache.packFiling)  // && $scope.packName != "NONE")
		{    
			$scope.cache.packFiling = false;
			$window.open(
			"rest/symptom-collector/download-task?" +
			"taskId=" + $scope.cache.currentTask.id +
			"&password="+$scope.passwd +
			"&" + keywordUrlParams, 
			'_top');
			
		}
		else if($scope.cache.currentTask.state == 'FAILED' || $scope.cache.currentTask.state == 'STOPPED'){
			$scope.cache.packFiling = false;
		}
        
        var semaphore = Scheduler.semaphore();
        var request = {taskId: $scope.cache.currentTask.id};

        return requestTaskPart(request, semaphore);
    });
    
    $scope.convertedTaskStatus =  function(){
		if ($scope.cache.taskType == "Collect" && $scope.cache.currentTask.state == "FINISHED") {
			return "Symptom collection finished and package downloaded";
		} else {
			var message = $scope.cache.taskType+'ion';
			if ($scope.cache.currentTask.state) {
				message += ' ';
				message += $scope.cache.currentTask.state.toLowerCase();
			}
			return message;
		}
	};
	
	$scope.multiSelectPreCheck = function(field) {
		if ($scope.cache.sympTaskArgument[field].length >= 5) {
			$scope.cache.isMaxLimiation = true;
			$timeout(function() {
				var buttons = $("button[ng-click^='handleMaxSelectionDialogOk']", $element);
				if (buttons.length != 0) {
					buttons[0].focus();
				}
			}, 0);
			return false;
		}
	};
	
	$scope.handleMaxSelectionDialogOk = function(){
		$scope.cache.isMaxLimiation = false;
	};
	
	$scope.isEmpty = function(c) {
		return !c || !c.length;
	};
    
    $scope.switchToLogSearch = function() {
        angular.element("div.lb-tasks-view ul li a[href=#log-browser]").trigger("click");
    };
});
