smuApp
.directive('regexpFormat', function($timeout) {
	return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModelCtrl) {
			var validate = function(value) {
				var valid = false;
				try {
					new RegExp(value);
					valid = true;
				} catch (e) {
					var dynamicErrorMessages = ngModelCtrl.$dynamicErrorMessages;
					if (!dynamicErrorMessages) {
						ngModelCtrl.$dynamicErrorMessages = dynamicErrorMessages = {};
					}
					dynamicErrorMessages['regexpformat'] = e.message;
				}
				ngModelCtrl.$setValidity('regexpformat', valid);
				return valid ? value : undefined;
			};
			ngModelCtrl.$parsers.push(validate);
			ngModelCtrl.$formatters.push(validate);
		}
	};
})
.directive('dateFormat', function() {
	return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModelCtrl) {
			var validate = function(value) {
				var valid = true;
				if (scope.$eval(attrs.dateFormat) && value && value.length != 0) {
					var v2 = value.trim().replace(/-/g, '/');
					valid = v2 == moment(new Date(Date.parse(v2))).format("YYYY/MM/DD HH:mm");
				}
				ngModelCtrl.$setValidity('dateformat', valid);
				return valid ? value : undefined;
			};
			ngModelCtrl.$parsers.push(validate);
			ngModelCtrl.$formatters.push(validate);
			scope.$watch(attrs.dateFormat, function() {
				var oldViewValue = ngModelCtrl.$viewValue;
				ngModelCtrl.$setViewValue("");
				ngModelCtrl.$setViewValue(oldViewValue);
			})
		}
	};
})
.directive('dateLe', function() {
	return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModelCtrl) {
			var expression = attrs.dateLe.trim();
			var validate = function(value) {
				var target = scope.$eval(expression);
		    	var cur = value;
		    	var valid = true;
		    	if (target && cur) {
		    		target = Date.parse(target.replace(/-/g, '/'));
			        var parsed = Date.parse(cur.replace(/-/g, '/'));
                    var formatOk = cur == moment(new Date(parsed)).format("YYYY-MM-DD HH:mm");
			        valid = isNaN(parsed) || isNaN(target) || !formatOk || parsed <= target;
		    	}
		        ngModelCtrl.$setValidity('datele', valid);
		        return value; //compare validation error cannot break model value, so don't return undefined
			};
			
			ngModelCtrl.$parsers.push(validate);
			ngModelCtrl.$formatters.push(validate);
			scope.$watch(expression, function() {
				var oldViewValue = ngModelCtrl.$viewValue;
				ngModelCtrl.$setViewValue("");
				ngModelCtrl.$setViewValue(oldViewValue);
			});
		}
	};
})
.directive('dateGe', function() {
	return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModelCtrl) {
			var expression = attrs.dateGe.trim();
			var validate = function(value) {
				var target = scope.$eval(expression);
		    	var cur = value;
		    	var valid = true;
		    	if (target && cur) {
		    		target = Date.parse(target.replace(/-/g, '/'));
			        var parsed = Date.parse(cur.replace(/-/g, '/'));
                    var formatOk = cur == moment(new Date(parsed)).format("YYYY-MM-DD HH:mm");
			        valid = isNaN(parsed) || isNaN(target) || !formatOk || parsed >= target;
		    	}
		        ngModelCtrl.$setValidity('datege', valid);
		        return value; //compare validation error cannot break model value, so don't return undefined
			};
			
			ngModelCtrl.$parsers.push(validate);
			ngModelCtrl.$formatters.push(validate);
			scope.$watch(expression, function() {
				var oldViewValue = ngModelCtrl.$viewValue;
				ngModelCtrl.$setViewValue("");
				ngModelCtrl.$setViewValue(oldViewValue);
			});
		}
	};
})
.controller('logBrowserController', function($scope, $timeout, $http, $element, $filter, $interval,
		$document,$window, $httpParamSerializerJQLike, createNotification, serverInfo, smuCacheService) {
	
	var TASK_HEARTBEAT_TIME = 3000;
	var TASK_REFRESH_TIME = 5000;
    var A_DAY = 1000 * 60 * 60 * 24;

    $scope.loadScenarios = function() {
        $http
            .get("rest/log-browser/scenarios")
            .then(function (response) {
                var data = response.data;
            	data.forEach(function (scenario, index) {
                    $scope.cache.scenarios.push({
                        displayName: scenario,
                        scenario: scenario
                    });
                });
            },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                    reason = reason.replace(/logbrowser:?/, '');
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.cache.scenarioLoadError = "Cannot list scenarios: " + reason;
            })['finally'](function() {
            $scope.cache.scenarioLoading = false;
        });
        $scope.scenarioLoading = true;
    };

    $scope.cleanResults = function() {
        $scope.cache.currentTask = {}; // TODO: consider merge the two variables
        $scope.cache.downloading = false;
        $scope.cache.taskResult = [];
        $scope.cache.errorOutputs = [];
        $scope.cache.taskPagination = {
            pageSize: 500,
            currentPage: 0,
            totalPageCount: 0,
            totalRowCount: 0
        };
    };

    $scope.initialize = function () {
        var cachedDataRef = smuCacheService.getData(CACHE_KEY_LOG_BROWSER);
        if (cachedDataRef) {
            $scope.cache = cachedDataRef;
        }
        else {
            smuCacheService.setData(CACHE_KEY_LOG_BROWSER, {
                timeRange: {start: false, end: false},
                usingRegExp: false,
                taskType: "Search",
                needsPassword: false,
                passwd: "",
                waitAuth: false,
                packFilesError: false,
                packName: "NONE",
                packFiling: false,
                downloading: false,
                downloadLog: false,
                scenarioLoadError: false,
                scenarioLoading: false,
                showScenarioLoadingErrorNotice: false,
                downloadBtnBalloonVisible: false,
                downloadBtnHintMessage: false,
                scenarios: [{displayName: "--None--", scenario: ""}],
                passwordPanel: { type: "root", result : null},
                retryRemain: 0,
                isCreatingSearch: false,
                currentTask: {},
                taskResult: [],
                errorOutputs: [],
                taskPagination: {
                    pageSize: 500,
                    currentPage: 0,
                    totalPageCount: 0,
                    totalRowCount: 0
                },
                onGoingDialogVisible: false,
                appVer: 'unknown',
                searchCreationError: null,
                errorMessage: '',
                outputSortingField: null,
                outputSortingMode: '',
                errorview: false,
                taskArgument: {
                    keywords: [],
                    regExp: null,
                    scenario: "",
                    packFiles: false,
                    caseSensitive: false,
                    modificationStart: $filter('serverDate')(Date.now() - A_DAY, 'yyyy-MM-dd HH:mm'),
                    modificationEnd: $filter('serverDate')(Date.now(), 'yyyy-MM-dd HH:mm')
                }
            });

            $scope.cache = smuCacheService.getData(CACHE_KEY_LOG_BROWSER);
            $scope.loadScenarios();
            $http.get("rest/system/about").then(function (response) {
                $scope.cache.appVer = response.data.version;
            },function(){});
        }
    };
    
    $scope.initialize();

    $scope.notification = createNotification();
    $scope.tryStartSearch = function() {
        $scope.cache.searchCreationError = null;
        if ($scope.cache.currentTask.state == 'PENDING' || $scope.cache.currentTask.state == 'RUNNING') {
            $scope.cache.onGoingDialogVisible = true;
            setTimeout(function() { $element.find('.btn.close-dlg')[0].focus();}, 50);
        } else {
            $scope.startSearch();
			$scope.cache.taskType = "Search";
			//$scope.downloadLog = true;
        }
    };

	$scope.tryDownload = function(){
        $scope.cache.needsPassword = true;
		$scope.cache.passwordPanel.result = "";
        $timeout(function() {
            $element.find("input[type='password']").focus();
        }, 50);
    };
		
	$scope.cancelAuth = function() {
		$scope.cache.passwordPanel.type = "root";
		$scope.cache.needsPassword = false;
		$scope.cache.passwordPanel.result = "";
	};

	$scope.verifyPassword = function(){
		$scope.cache.passwordPanel.type = "auth";
		$scope.cache.waitAuth = true;

        var payload = {
            password: $scope.cache.passwordPanel.result
        };
        $http.post("rest/log-browser/verifyPassword", $httpParamSerializerJQLike(payload), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
	    .then( function (response) {
		    $scope.cache.errorOutputs = [];
		    $scope.cache.needsPassword = false;
		    $scope.cache.passwordPanel.type = "root";
		    $scope.cache.packFiling = true;
		    $scope.cache.passwd = $scope.cache.passwordPanel.result;
		    $scope.downloadWithPassword();
		},function(response) {
			var errorResponse = response.data;
			$scope.cache.needsPassword = true;
			$scope.cache.packFiling = false;
			$scope.cache.passwordPanel.result = "";
			$scope.cache.errorMessage = errorResponse.error ? ('Read file error: '+errorResponse.error) :'Network connection lost';
            if (errorResponse.errorSymbol == "Auth fail") {
				$scope.cache.passwordPanel.type = "error";
			}
			else if (errorResponse.errorSymbol == "Permission denied") {
				$scope.cache.passwordPanel.type = "root";
			}
			else {
                $scope.cache.passwordPanel.type = "db";
            }
            updateRetryLimit(errorResponse.retryRemains);
		})['finally'](function() {
		    $scope.cache.waitAuth = false;
		});
	};


    $scope.downloadWithPassword = function(){
		var keywordUrlParams = 'offset=0';
        var task = $scope.cache.currentTask;
        $scope.cache.taskType = "Download";
		$scope.cache.passwordPanel.type = "root";
		$scope.cache.currentTask.state = 'PENDING';
		$scope.cache.packFiling = true;
		$scope.cache.downloadLog = false;
		$scope.cache.downloading = true;
        var payload = {
          password: $scope.cache.passwd
        };
        var url = "rest/log-browser/package-task?taskId="+task.id;
        $http.post(url, $httpParamSerializerJQLike(payload), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
        .then( function (response) {
			$scope.cache.needsPassword = false;
			$scope.cache.currentTask = response.data;
            },function(errorResponse) {
            	var response = errorResponse.data;
				//$scope.needsPassword = true;
				$scope.cache.packFiling = false;
				$scope.cache.errorMessage = response.error ? ('Read file error: '+response.error) :'Network connection lost';
					if (response.errorSymbol == "Auth fail") {
						$scope.cache.passwordPanel.type = "error";
					}
					else if (response.errorSymbol == "Permission denied") {
						$scope.cache.passwordPanel.type = "root";
					}
			})['finally'](function() {
			});
	};
	
    $scope.forceStartSearch = function() {
        $scope.cache.onGoingDialogVisible = false;
        $http.post("rest/log-browser/cancel-task?taskId=" + $scope.cache.currentTask.id)
            .then(function (response) {
            	$scope.notification.hide("tag-cancel-task");
                $scope.startSearch();
            },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Failed to cancel running search due to " + reason + ".", "tag-cancel-task");
            });
    };

    $scope.isCriteriaOK = function () {
        if ($scope.cache.timeRange.start && $scope.search_form.last_modify_start.$invalid) {
            return false;
        }

        if ($scope.cache.timeRange.end && $scope.search_form.last_modify_end.$invalid) {
            return false;
        }

        if (!$scope.cache.usingRegExp) {
        	var keywords = $scope.cache.taskArgument.keywords;
        	if (keywords) {
        		for (var i = keywords.length - 1; i >= 0; i--) {
        			if (keywords[i].value) {
        				return true;
        			}
        		}
        	}
        }
        return (
        	$scope.cache.usingRegExp && $scope.cache.taskArgument.regExp
            || $scope.cache.taskArgument.scenario
            || $scope.cache.timeRange.start
            || $scope.cache.timeRange.end
        );
    };

    $scope.startSearch = function() {
        var searchRequest = angular.extend({}, $scope.cache.taskArgument);
        if ($scope.cache.timeRange.start) {
            searchRequest.modificationStart = serverInfo.parseNoZoneDate(
            		$scope.cache.taskArgument.modificationStart,
            		'yyyy-MM-dd HH:mm'
            );
        } else{
            searchRequest.modificationStart = null;
        }
        if ($scope.cache.timeRange.end) {
            searchRequest.modificationEnd = serverInfo.parseNoZoneDate(
            		$scope.cache.taskArgument.modificationEnd,
            		'yyyy-MM-dd HH:mm'
            );
        } else{
            searchRequest.modificationEnd = null;
        }

        if ($scope.cache.usingRegExp) {
            searchRequest.keywords = [];
            searchRequest.regExp = $scope.cache.taskArgument.regExp;
        } else {
            searchRequest.regExp = null;
            searchRequest.keywords = searchRequest.keywords.map(function (v) {
                return v.value;
            });
        }

        $http.post("rest/log-browser/create", JSON.stringify(searchRequest))
            .then(function(response) {
            	var task = response.data;
                $scope.cleanResults();
                $scope.cache.currentTask = task;
            },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.cache.searchCreationError = "Failed to start search due to " + reason + ".";
            })['finally'](function() {
            	$scope.cache.isCreatingSearch = false;
			});
        $scope.cache.isCreatingSearch = true;
    };

    $scope.isTrySearchDisabled = function () {
        return !$scope.isCriteriaOK() || $scope.cache.isCreatingSearch || ($scope.cache.packFiling);
    };

	$scope.isDownloadDisabled = function () {
        return $scope.cache.currentTask.packFiles;
    };
	
    $scope.isSearchOngoing = function() {
        return (
            $scope.cache.currentTask.id != null &&
            !$scope.cache.currentTask.removedByServer &&
            $scope.cache.currentTask.state != 'FINISHED' &&
            $scope.cache.currentTask.state != 'FAILED' &&
            $scope.cache.currentTask.state != 'STOPPED'
        );
    };

    function updateRetryLimit(remains) {
        if (remains >= 1000) {
            $scope.cache.retryRemain = remains;
            $scope.cache.retryCounter = $interval(function () {
                $scope.cache.retryRemain -= 1000;
                if ($scope.cache.retryRemain < 1000) {
                    $interval.cancel($scope.cache.retryCounter);
                }
            }, 1000);
        }
    }


    function buildOutputRequest() {
        return {
            resultPageIndex : $scope.cache.taskPagination.currentPage > 0 ? ($scope.cache.taskPagination.currentPage - 1) : 0,
            resultPageSize : $scope.cache.taskPagination.pageSize,
            sortingField : $scope.cache.outputSortingField,
            sortingMode : $scope.cache.outputSortingMode
        };
    }

    function buildErrorRequest() {
        var nextId = 0;
        if ($scope.cache.errorOutputs.length) {
            nextId = $scope.cache.errorOutputs[$scope.cache.errorOutputs.length - 1].id;
        }

        return {
            minExclusiveId: nextId
        };
    }

    function requestTaskPart(request, semaphore) {
        if (request.taskId == null) {
            semaphore && semaphore.release();
            return semaphore;
        }
        $http.post("rest/log-browser/task-part?taskId=" + request.taskId, request)
            .then(function(response) {
                if (request.taskId != $scope.cache.currentTask.id) {
                    /* This happens when the response of 'create' finished before this response comes,
                    * in which case the currentTask.id has been changed to the new id. So just abandon this response */
                    return;
                }
                $scope.cache.currentTask = response.data.task || {};
                $scope.cache.downloading = response.data.downloading;
                if (request.outputRequest && response.data.outputPages) {
                    updateResultTable(response.data.outputPages);
                }
                if (request.errorRequest && response.data.errors) {
                    $scope.updateTaskErrors(response.data.errors);
                }
                $scope.notification.hide("tag-task-part");
            }, function(response) {
                var loadingError = response.data && response.data.error ?
                    response.data.error : 'Failed to update search result due to: ' + (response.statusText ? response.statusText.charAt(0).toLowerCase() + response.statusText.slice(1) : 'unknown reason');
                if (response.status == 404) {
                    loadingError = 'Search result not found, it maybe has been cleaned up.';
                    if ($scope.cache.currentTask.state == 'RUNNING' || $scope.cache.currentTask.state == 'PENDING') {
                        $scope.cache.currentTask.state = 'FAILED';
                    } else if ($scope.cache.currentTask.state == 'STOPPING' ){
                        $scope.cache.currentTask.state = 'STOPPED';
                    }
                    $scope.cache.currentTask.removedByServer = true;
                }
				$scope.cache.downloading = false;
                $scope.notification.error(loadingError, "tag-task-part");
            })["finally"](function () {
            	$scope.cache.isResultUpdating = false;
                semaphore && semaphore.release();
            });
        return semaphore;
    }

    function requestOutputForCurrentPage () {
        if ($scope.cache.currentTask.id == null) {
            return;
        }
        $scope.cache.isResultUpdating = true;
        var request = {
            taskId: $scope.cache.currentTask.id,
            outputRequest : buildOutputRequest()
        };

        requestTaskPart(request);
    }
    
	$scope.convertedTaskStatus =  function(){
		if ($scope.cache.taskType == "Download" && $scope.cache.currentTask.state == "FINISHED") {
			return "Package is ready, download is started";
		} else {
			var message = $scope.cache.taskType;
			if ($scope.cache.currentTask.state) {
				message += ' ';
				message += $scope.cache.currentTask.state.toLowerCase();
			}
			return message;
		}
	};

    var taskRefresher = Scheduler.fixedDelay(TASK_REFRESH_TIME, function () {
		var semaphore = Scheduler.semaphore();
        var request = {taskId: $scope.cache.currentTask.id};
		var keywordUrlParams = 'offset=0';
        if (!$scope.isSearchOngoing()) {
			if(!$scope.cache.downloadLog){
				    $scope.cache.downloadLog = true;
				    if($scope.cache.currentTask.state == 'FINISHED')  // && $scope.packName != "NONE")
					{   
				        $scope.cache.packFiling = false;
						$window.open(
						"rest/log-browser/download-task?" +
						"taskId=" + $scope.cache.currentTask.id +
						"&password="+$scope.cache.passwd +
						//"&fileName=" + encodeURIComponent($scope.packName) +
						"&" + keywordUrlParams, 
						'_top');
						$scope.cache.passwordPanel.result = "";
					}
					else if($scope.cache.currentTask.state == 'FAILED' || $scope.cache.currentTask.state == 'STOPPED'){
						$scope.cache.packFiling = false;
					}
			}
            return requestTaskPart(request, semaphore);
        }
        
        var semaphore = Scheduler.semaphore();
        var request = {taskId: $scope.cache.currentTask.id};
        if ($scope.isSearchOngoing()) {
            $scope.cache.isResultUpdating = true;
            request.outputRequest = buildOutputRequest();
            request.errorRequest = buildErrorRequest();
        }

        return requestTaskPart(request, semaphore);
    });

	$scope.cancelSearch = function() {
        $http.post("rest/log-browser/cancel-task?taskId=" + $scope.cache.currentTask.id)
        .then(function() {
        	$scope.notification.hide("tag-cancel-task");
        },function (response) {
            var reason = 'unknown reason';
            if (response.data && response.data.errorCategory === "database") {
                reason = "database error";
            } else if (response.data && response.data.error) {
                reason = response.data.error;
            }
            else if (response.statusText) {
                reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
            }
            else if (response.status === -1) {
                reason = 'network unavailable';
            }

            $scope.notification.error("Failed to cancel search due to " + reason + ".", "tag-cancel-task");
        });
	};

	$scope.gotoPage= function(targetPageIndex){
	    var targetPageNumber = new Number(targetPageIndex);
		if( /^\d+$/.test(targetPageNumber) ) { // check if the input is digits
            if (targetPageNumber < 1){ // if input number < 1, go to page 1
                $scope.cache.taskPagination.currentPage = 1;
            } else if (targetPageNumber > $scope.cache.taskPagination.totalPageCount) { // if input number > the max number, go to the last page
                $scope.cache.taskPagination.currentPage = $scope.cache.taskPagination.totalPageCount;
            } else {
                $scope.cache.taskPagination.currentPage = targetPageNumber;
            }
		}else{ // if input is not digits, go to page 1
		    $scope.cache.taskPagination.currentPage = 1;
		}
        requestOutputForCurrentPage();
	};

    function updateResultTable(page) {
        if (page) {
            $scope.cache.taskResult = [];
            var files = page.items;
            for (var i = 0; i < files.length; i++) {
                if (!com.nokia.oss.smu.findInCollectionByIdentifier("id")(files[i], $scope.cache.taskResult)) {
                    $scope.cache.taskResult.push(files[i]);
                }
            }

            $scope.cache.taskPagination.currentPage = page.actualPageIndex + 1;
            $scope.cache.taskPagination.totalPageCount = page.totalPageCount;
            $scope.cache.taskPagination.totalRowCount = page.totalRowCount;
        }
    }

    $scope.updateTaskErrors = function (outputs) {
        for (var i = 0; i < outputs.length; i++) {
            $scope.cache.errorOutputs.push(outputs[i]);
        }
    };

	$scope.openLog = function(item) {
		var keywordUrlParams = '';
        var task = $scope.cache.currentTask;

        if (task.regularExpression) {
            keywordUrlParams += "regexp=" + encodeURIComponent($scope.cache.currentTask.keywords[0].value) + "&";
        } else {
            for(var i = 0; i < task.keywords.length; i++) {
                keywordUrlParams += "keyword=" + encodeURIComponent(task.keywords[i].value) + "&";
            }
        }
        if (!task.caseSensitive) {
            keywordUrlParams += "insensitive=";
        }

        $window.open(
            "logcontent.jsp?" +
            "taskId=" + task.id +
            "&host=" + item.parsedNodeName +
            "&fileName=" + encodeURIComponent(item.parsedFilePath) +
            "&" + keywordUrlParams,
            '_blank');
	};

    $scope.showErrorsDialog = function(){
        $scope.cache.errorview = true;
        setTimeout(function() { 
            $element.find('.dialog-button')[0].focus();
            require(['wulf/balloon'], function() {
                $('[data-toggle="popover"]').popover();
            });
        }, 0);
    }
    $scope.closeErrorsDialog = function(buttonIndex){
        $scope.cache.errorview = false;
    }
    
	$scope.getOutputSortingText = function(outputField) {
		if ($scope.cache.outputSortingField != outputField) {
			return "";
		}
		return $scope.cache.outputSortingMode == "asc" ? "\u25B2" : "\u25BC"
	};

	$scope.sortOutput = function(outputField) {
		if ($scope.cache.outputSortingField != outputField) {
			$scope.cache.outputSortingField = outputField;
			$scope.cache.outputSortingMode = "asc";
		} else {
			var mode = $scope.cache.outputSortingMode;
			if (mode == "asc") {
				$scope.cache.outputSortingMode = "desc";
			} else if (mode == "desc") {
				delete $scope.cache.outputSortingField;
				delete $scope.cache.outputSortingMode;
			}
		}
        requestOutputForCurrentPage();
	};
	
	require(['wulf/balloon'], function() {
	    $('[data-toggle="popover"]').popover();
	});

	$scope.$on("$destroy", function() {
        var popovers = $('[data-toggle="popover"]');
        popovers.popover && popovers.popover('hide');

        taskRefresher.cancel();
	});
	
	$scope.handleBalloon = function($event) {
		var btnContainer = $("#btnContainer");
		
		if ($('#downloadBtn').prop("disabled") != true) {
			$scope.cache.downloadBtnHintMessage = "Download";
		} else {
			$scope.cache.downloadBtnHintMessage = "One download operation is already ongoing";
		}		

		switch ($event.type) {
			case "mouseenter":
			    $scope.cache.downloadBtnBalloonVisible = true;
				break;
			case "mouseleave":
			    $scope.cache.downloadBtnBalloonVisible = false;
				break;
			default:
			    break;
		}        
	};
    
    $scope.handleKeyPress = function(event, targetPage) {
        if(13 != event.which) {
            return;
        }

        $scope.gotoPage(targetPage);
    };
    
    $scope.switchToSymptomCollector = function() {
        angular.element("div.lb-tasks-view ul li a[href=#symptom-collector]").trigger("click");
    };
    
});
