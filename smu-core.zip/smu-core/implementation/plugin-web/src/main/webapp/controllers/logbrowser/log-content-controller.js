var lbApp = angular.module("logbrowserApp", ["nokia.wulf","ngRoute"]);

lbApp.config(function($locationProvider,$httpProvider) {
	$locationProvider.html5Mode({
		enabled: true,
		requireBase: false
	});
});

lbApp.filter('smuDuration', function () {
	return function (miliseconds) {
		miliseconds = miliseconds || 0;
		var seconds = Math.ceil(miliseconds / 1000);
		var hoursDiff = Math.floor(seconds / 3600);
		var minutesDiff = Math.floor((seconds / 60) % 60);
		var secondsDiff = seconds % 60;
		var segments = [];
		if (hoursDiff) {
			segments.push(hoursDiff + ((hoursDiff > 1) ? " hours" : " hour"));
		}
		if (minutesDiff) {
			segments.push(minutesDiff + ((minutesDiff > 1) ? " minutes" : " minute"));
		}
		if (secondsDiff) {
			segments.push(secondsDiff + ((secondsDiff > 1) ? " seconds" : " second"));
		}

		if (!segments.length) {
			return '0 second'
		}

		return segments.join(" ");
	};
});


var LinkedList = function () {
    this._cursor = this;
    this._size = 0;
    // @see java.util.LinkedHashMap.init()
    this._before = this._after = this;
    this.clear();
};
LinkedList.prototype.add = function (e) {
    // @see java.util.LinkedHahsMap.addBefore(Entry<K, V>)
    e._after = this;
    e._before = this._before;
    e._before._after = e;
    e._after._before = e;
    this._size++;
};
LinkedList.prototype.clear = function () {
    this._cursor = this;
    this._before = this._after = this; // @see java.util.LinkedHashMap.init()
};
LinkedList.prototype.current = function () {
    return this._cursor == this ? null : this._cursor;
};
LinkedList.prototype.next = function () {
    this._cursor = this._cursor._after;
    if (this._cursor === this) {
        this._cursor = this._cursor._after;
    }
    return this.current();
};
LinkedList.prototype.prev = function () {
    this._cursor = this._cursor._before;
    if (this._cursor === this) {
        this._cursor = this._cursor._before;
    }
    return this.current();
};
LinkedList.prototype.size = function () {
    return this._size;
};

lbApp.service("lbMatcher",function(){
	var matcher={
		matchLine: function(line){
			return false;
		}
	};
	return {
		 defaultMatcher:function(){
			 return matcher;
		 },
		 setMatcherWithKeywordsOrRegExp : function(enableRegExp, ignoreCase, regExpOrKeywords){
			 var regExpTester = null; 
			 if (enableRegExp && regExpOrKeywords) {
				 regExpTester = new RegExp(regExpOrKeywords, ignoreCase ? "i" : "");
			 }
			 matcher.matchLine = function(line){
				 if (enableRegExp){
					 return regExpTester.test(line);
				 }
				 if (ignoreCase) {
					 line = line.toUpperCase();
				 }
				 for (var i = 0 ; i< regExpOrKeywords.length; i++) {
					 var keyword = regExpOrKeywords[i];
					 if (ignoreCase) {
						 keyword = keyword.toUpperCase();
					 }
					 if (line.indexOf(keyword) != -1) {
						 return true;
					 }
				 }
				 return false;
			 };
			 return matcher;
		 }
	};
});

lbApp.controller("logContentController", function ($rootScope, $scope, $location, $http, $document, $interval, $timeout, $window,
												   $httpParamSerializerJQLike, lbMatcher) {
	var LOGCONTENT_REFRESH_TIME = 1000;
	var LOGCONTENT_MAX_LENGTH = 1024 * 1024 * 10;
	$scope.appVer = function() {
		return $window.appVersion || 'unknown';
	};

	$scope.appVer = 'unknown';
	$http.get("rest/system/about")
		.then(function (response) { 
				$scope.appVer = response.data.version; 
		},function(){});
    $scope.container = null;
	$scope.retryRemain = 0;
    var lineNumber = 0;
    $scope.matchedNodes = new LinkedList();
    $scope.clearLines = function () {
		$scope.matchedNodes.clear();
		if ($scope.container) {
			while ($scope.container.firstChild) {
				$scope.container.removeChild($scope.container.firstChild);
			}
		}
    };

    $scope.addLine = function (line, matched) {
		if ($scope.container) {
			var lineNumberUI =
				angular.element("<div></div>")
					.attr("class", "line-number text-right")
					.append(
						$document[0].createTextNode(++lineNumber + ".")
					);
			var lineClass = "";
			if (matched) {
				lineClass = "active";
				lineNumberUI.attr("id", lineClass + lineNumber);
				lineNumberUI.attr("tabindex", "-1");
				$scope.matchedNodes.add(lineNumberUI);
				lineNumberUI.attr("lineNumber", $scope.matchedNodes.size());
			}
			var le = $("<div></div>")
				.attr("class", "lb-data")
				.append(lineNumberUI)
				.append(
					angular.element("<div></div>")
						.attr("class", "lb-line " + lineClass)
						.append($document[0].createTextNode(line))
				);
			$scope.container.appendChild(le[0]);
		}
    };

    var jumpMatchedNode = function (oldNode, newNode) {
        if (oldNode) {
            oldNode.removeClass("line-selected");
        }
        if (newNode) {
            newNode.addClass("line-selected");
            $location.hash(newNode.attr("id"));
            newNode.focus();
            $scope.jumpedLine = newNode.attr("lineNumber");
        }
    };
    $scope.jumpBack = function () {
        jumpMatchedNode($scope.matchedNodes.current(), $scope.matchedNodes.prev());
    };
    $scope.jumpNext = function () {
        jumpMatchedNode($scope.matchedNodes.current(), $scope.matchedNodes.next());
    };

	$scope.cct = $location.search().role == "cct";
	
	var reinitialize = function(passwordPanelType) {
		uninitialize();

		if ($scope.cct && !passwordPanelType) {
			passwordPanelType = "root";
		}

		if(initializeStatus(passwordPanelType)) {
			if ($scope.cct || passwordPanelType) {
				$scope.passwordPanel.show = true;
				$timeout(function() {
					$document.find("input[type='password']").focus();
				}, 50);
			} else {
				initializeScheduler();
			}
		}
	};
	
	var initializeStatus = function(passwordPanelType) {
		
		$scope.passwordPanel = { type: passwordPanelType, show: false, result: null };
		
		$scope.criteria={
			host:"",
			fileName:"",
			nextOffset:0,
			keywords:[],
			regExp:'',
			enableRegExp:false
		};
		
		$scope.getKeywordsSummary = function() {
			return (
					$scope
					.criteria
					.keywords
					.map(function(keyword) { 
						return "'" + keyword + "'"; 
					})
					.join(", ")
			);
		};
		
		var parameters = $location.search();
		if(parameters && parameters.host && parameters.fileName){
			$scope.criteria.host = parameters.host;
			$scope.criteria.fileName = parameters.fileName;
			
			var keywords = parameters.keyword;
			var regExp = parameters.regexp;
			var ignoreCase = (parameters.insensitive != null) ? true:false;

			if(keywords) {
				// keywords first
				if(!Array.isArray(keywords)) {
					keywords = [keywords];
				}
				$scope.criteria.keywords = keywords;
				$scope.criteria.enableRegExp = false;
				$scope.lineMatcher = lbMatcher.setMatcherWithKeywordsOrRegExp(false, ignoreCase,keywords);
			}
			else if (regExp) {
				//second regular expression
				$scope.criteria.enableRegExp = true;
				$scope.criteria.regExp =  regExp;
				$scope.lineMatcher = lbMatcher.setMatcherWithKeywordsOrRegExp(true, ignoreCase,regExp);

			}
			return true;
		} else {
			$scope.errorMessage = "Read file error: host or fileName not available.";
			return false;
		}
	};

	$scope.updateRetryLimit = function(remains) {
		if (remains >= 1000) {
			$scope.retryRemain = remains;
			$scope.retryCounter = $interval(function () {
				$scope.retryRemain -= 1000;
				if ($scope.retryRemain < 1000) {
					$interval.cancel($scope.retryCounter);
				}
			}, 1000);
		}
	};

	var initializeScheduler = function(rootPasswordForCCT) {
		$scope.newScheduler = true;
		if ($scope.clearLines) {
			$scope.clearLines();
		}

		$scope.logContentDataUpdater = Scheduler.fixedDelay(LOGCONTENT_REFRESH_TIME, function() {
			var semaphore = Scheduler.semaphore();
			var data = {
					hostName: $scope.criteria.host,
					fileName: $scope.criteria.fileName,
					offset: $scope.criteria.nextOffset,
					password: $scope.passwordPanel.result
			};
			var url;
			// FIXME: There is an ugly design, for root readonly logs, it's handled by conf checker controller.
			if (typeof(rootPasswordForCCT) == "string") {
				url = "rest/conf-checker/file-part";
			} else {
				url = "rest/log-browser/file-part";
			}
			$http
			.post(url, $httpParamSerializerJQLike(data), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
			.then(function(response) {
				var filePart = response.data;
				if($scope.criteria.nextOffset != filePart.nextOffset && filePart.lines && filePart.lines.length >= 1) {
					if(filePart.nextOffset >= LOGCONTENT_MAX_LENGTH && !$scope.userConfirmContinueLoad) {
						$scope.logContentDataUpdater.suspend();
						return;
					}
					$scope.criteria.nextOffset = filePart.nextOffset;
					filePart.lines.forEach(function(line){
						var matched = $scope.lineMatcher.matchLine(line);
						if(matched){
							$scope.matchNumber += 1;
						}
						$scope.fileParts.push(
							{
								text:line,
								matched:matched,
								nextOffset:filePart.nextOffset
							}
						);
						$scope.addLine(line,matched);
					});
					if ($scope.errorMessage){
						$scope.errorMessage = null;
					}
				}
				if(filePart.nextOffset == -1) {
			        $scope.searchFinished = true;
			        $scope.logContentDataUpdater.cancel();
			        return;
			    }
				$scope.progressVisiable = true;
			},function(response) {
				var data = response.data;
				$scope.errorMessage = data.error ? ('Read file error: '+data.error) :'Network connection lost';
				$scope.progressVisiable = false;
				if ($scope.newScheduler) {
					if (data.errorSymbol == "Auth fail") {
						if ($scope.cct || $scope.passwordPanel.type) {
							$scope.updateRetryLimit(data.retryRemains);
							reinitialize("error");
						}
					} else if (data.errorSymbol == "Permission denied") {
						$scope.updateRetryLimit(data.retryRemains);
						reinitialize("root");
					}
				}
			})["finally"](function() {
				semaphore.release();
				$scope.newScheduler = false;
			});
			
			return semaphore;
		});
	};
	
	var uninitialize = function() {
		if ($scope.logContentDataUpdater) {
			$scope.logContentDataUpdater.cancel();
			$scope.logContentDataUpdater = undefined;
		}
		$scope.userConfirmContinueLoad=false;
		$scope.searchFinished=false;
		$scope.errorMessage=null;
		$scope.fileParts=[];
		$scope.fileCurrentLength = 0;
		$scope.lineMatcher = lbMatcher.defaultMatcher();
		$scope.matchNumber = 0;
		$scope.progressVisiable = true;
	};
	
	$scope.confirmPassword = function() {
		$scope.passwordPanel.show = false;
		uninitialize();
		initializeScheduler($scope.passwordPanel.result);
	};
	
	$scope.confirmContinueLoad=function(){
		$scope.userConfirmContinueLoad=true;
		$scope.logContentDataUpdater.resume();
	};

	$scope.$on("$destroy", function() {
		uninitialize();
	});

	$scope.containerInitialized = function(c) {
		$scope.container = c;
		reinitialize();
	};

	var frame = $document.find('.logcontent-body')[0];
	$(frame).load(function () {
		$scope.containerInitialized(frame.contentDocument.getElementById('log-content'));
	});
});
