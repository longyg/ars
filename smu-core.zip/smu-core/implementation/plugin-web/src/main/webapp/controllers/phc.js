smuApp.config(['$httpProvider', function($httpProvider) {
    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};    
    }    
    $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Sat, 29 Oct 1994 19:43:31 GMT';
    $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
}]);
smuApp.controller("phcController", function ($scope, $element, $http, $interval, $timeout, createNotification) {
    var CHECKING_UPDATE_INTERVAL = 5000;

    $scope.notification = createNotification();
    $scope.loading = false;
    $scope.reportsLimit = 500;
    $scope.reportUrl = null;
    $scope.checkingStatus = {};
    $scope.checkOngoing = true; // assume checking is ongoing at beginning.
    $scope.onGoingDialogVisible = false;
    
    $scope.results = [];
    
    $scope.getReports = function() {
        $scope.loading = true;
        $http.get("rest/phc/phc-history?maxRows=" + $scope.reportsLimit)
        	.then(function (response) {
        		var result = response.data;
        		$scope.results = result.data;
	            $scope.resultCount = result.count;
	            $scope.loading = false;
	        },function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to load reports list due to " + reason + ".");
	        })['finally'](function () {
	            $scope.loading = false;
	        });
    };
    $scope.getReports();
    
    // Open dialog to choose testsuite
    $scope.noTestSuiteSelected = function() {
        var arr = $scope.testSuites;
        if (arr) {
            for (var i = arr.length - 1; i >= 0; i--) {
                if (arr[i].selected) {
                    return false;
                }
            }
        }
        return true;
    };
    
    $scope.selectedSuiteDialog = function(buttonIndex) {
        $scope.selectSuiteDialogVisible = false;
        if (buttonIndex != 0) {
        	$scope.testSuites = $scope.testSuiteSnapshot;
        	$scope.testSuiteSnapshot = null;
            return;
        }
        
        $scope.testSuiteSnapshot = null;
        $scope.checkOngoing = true;
        $scope.notification.hide();
        
        var ids = [];
        for (var i = $scope.testSuites.length - 1; i >= 0; i--) {
          var suite = $scope.testSuites[i];
          if (suite.selected) {
              ids.push(suite.id);
          }
        }
        $http.post('rest/phc/do-check', { ids: ids }).then(
            function(resp) {
                $scope.checkingStatus = resp.data;
                $scope.startUpdateStatus();
            },
            function(resp) {
                if (resp.status == 429) {
                    $scope.notification.error("There is already one PHC instance running, please try again later.");
                    return;
                }

                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to start the check due to " + reason + ".");
            }
        );
    };
    
    $scope.toggleSelectAllSuites = function() {
    	var arr = $scope.testSuites;
    	var value = arr.allSelected;
    	for (var i = arr.length - 1; i >= 0; i--) {
    		arr[i].selected = value;
    	}
    };
    
    $scope.toggleSelectSuite = function(suite) {
    	var arr = $scope.testSuites;
    	arr.allSelected = true;
    	for (var i = arr.length - 1; i >= 0; i--) {
    		if (!arr[i].selected) {
    			arr.allSelected = false;
    			break;
    		}
    	}
    };
    
    $scope.doCheck = function() {
        $scope.selectSuiteDialogVisible = true;
        var initializeDialog = function () {
            var buttons = $("div.modal:visible button.btn:last", $element);
            if (buttons.length) {
                buttons[0].focus();
            }
            if ($scope.testSuites) {
                $scope.testSuiteSnapshot = angular.copy($scope.testSuites);
                $scope.testSuiteSnapshot.allSelected = $scope.testSuites.allSelected;
            }
        };
        
        $timeout(initializeDialog, 0);
        if (!$scope.testSuites && !$scope.loadingTestSuites) {
            $scope.loadTestSuitesFailed = false;
            $scope.loadingTestSuites = true;
            $http.get("rest/phc/test-suites")
                .then(function (resp) {
                    var data = resp.data;
                    var arr = [];
                    for (var k in data) {
                        arr.push({id: k, name: data[k], selected: true});
                    }
                    arr.allSelected = true;
                    $scope.testSuites = arr;
                    $timeout(initializeDialog, 0);
                }, function () {
                    $scope.loadTestSuitesFailed = true;
                }) ['finally'](function () {
                $scope.loadingTestSuites = false;
            });
        }
    };
    
    $scope.checkStatus = function (initializing) {
        $http.post('rest/phc/checking-status').then(
            function (resp) {
            	$scope.notification.hide("tag-check-status");
                $scope.checkingStatus = resp.data;
                if (initializing) {
                	if ($scope.checkingStatus.state == 'Starting' || $scope.checkingStatus.state == 'Running') {
	                    $scope.startUpdateStatus();
	                    return;
                	}
                	$scope.checkOngoing = false;
                } else if ($scope.checkOngoing &&  $scope.checkingStatus.state == 'Completed') {
                    $scope.checkOngoing = false;
                    $scope.stopUpdateStatus();
                    $scope.getReports();
                } else if ($scope.checkOngoing && $scope.checkingStatus.state == 'Failed' && --$scope.statusFailTolerance <= 0) {
                    $scope.checkOngoing = false;
                    $scope.stopUpdateStatus();
                    $scope.notification.error("Failed to create report, check logs for more details.", "tag-check-status");
                }
            },
            function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to update execution status due to " + reason + ".", "tag-check-status");
            });
    };

    $scope.checkStatusOnly = true;
    $scope.checkStatus(true);
    $scope.checker = null;
    $scope.startUpdateStatus = function() {
        $scope.statusFailTolerance = 5;
        $scope.checker = $interval(function() { 
        	$scope.checkStatus(false);
        	}, 
        	CHECKING_UPDATE_INTERVAL
        );
    };

    $scope.stopUpdateStatus = function() {
        $scope.checker && $interval.cancel($scope.checker) && ($scope.checker = null);
    };

    $scope.selectReport = function(index) {
        $scope.selectedIndex = index;
    };

    $scope.keydown = function(e) {
        if (e.keyCode == 38 && $scope.selectedIndex > 0) { //up
            $scope.selectedIndex--;
        } else if (e.keyCode === 40 && $scope.selectedIndex < $scope.results.length - 1) { // down
            $scope.selectedIndex++;
        }
    };

    $scope.$on("$destroy", function() {
        $scope.stopUpdateStatus();
    });

});
