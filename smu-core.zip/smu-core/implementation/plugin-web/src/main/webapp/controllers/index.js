smuApp.controller('navigationTabsController', function($scope, $rootScope, $route) {
    $scope.$route = $route;
});

smuApp.factory('createNotification', function($rootScope, $timeout, $sce) {

	var Message = function(type, text, tag, timeoutId) {
		this.type = type;
		this.text = $sce.trustAsHtml(text);
		this.tag = tag;
		this.timeoutId = timeoutId;
	};
	Message.prototype.close = function() {
		if (this.timeoutId) {
			$timeout.cancel(this.timeoutId);
			this.timeoutId = null;
		}
	};
	
	$rootScope.messageMap = {};
	
	var Notification = function(hash) {
		this._hash = hash;
	};
	
	var parseSecondaryArgs = function(args) {
		var result = {};
		for (var i = 1; i < args.length; i++) {
			var v = args[i];
			if (typeof(v) == "number") {
				result.timeout = v;
			} else if (typeof(v) == "string") {
				result.tag = v;
			}
		}
		return result;
	};
	Notification.prototype.show = function(type, text, tag, timeout) {
		var map = $rootScope.messageMap;
		var oldMessage = map[this._hash];
		if (oldMessage) {
			oldMessage.close();
		}
		var timeoutId = null;
		if (timeout) {
			var that = this;
			timeoutId = $timeout(function() {
				delete map[that._hash];
			}, timeout);
		}
		map[this._hash] = new Message(type || 'info', text, tag, timeoutId);
	};
	Notification.prototype.hide = function(tag) {
		var map = $rootScope.messageMap;
		var oldMessage = map[this._hash];
		if (oldMessage && (!tag || oldMessage.tag == tag)) {
			oldMessage.close();
			delete map[this._hash];
		}
	};
	Notification.prototype.visible = function (tag) {
		var oldMessage = $rootScope.messageMap[this._hash];
		return (oldMessage && (!tag || oldMessage.tag == tag))
	};
	Notification.prototype.ok = function(text) {
		var options = parseSecondaryArgs(arguments);
		this.show('ok', text, options.tag, options.timeout || 3000);
	};
	Notification.prototype.info = function(text) {
		var options = parseSecondaryArgs(arguments);
		this.show('info', text, options.tag, options.timeout || 3000);
	};
	Notification.prototype.error = function(text) {
		var options = parseSecondaryArgs(arguments);
		this.show('error', text, options.tag, options.timeout);
	};
	
	return function() {
		return new Notification(window.location.hash);
	};
});

smuApp.controller("indexController", function ($rootScope, $location, $routeParams, $anchorScroll, $scope, $timeout, $http, createNotification, smuCacheService) {
	var TASK_HEARTBEAT_TIME = 3000;

	$scope.notification = createNotification();
	$scope.menuItems = [
        {
            text: "Dashboard",
            href: "#dashboard",
            tabName: 'dashboard'
        },
        {
            text: "Internal Alarms",
            href: "#alarms?all",
            tabName: 'alarms'
        },
        {
            text: "PHC Report",
            href: "#phc",
            tabName: 'phc'
        },
        {
        	text: "Troubleshooting",
        	href: "#log-browser",
        	tabName: "troubleshooting"
        },
        {
        	text: "Configuration Changes",
        	href: "#conf-checker",
        	tabName: "confchecker"
        },
        {
        	text: "Mail Notification",
        	href: "#settings/email-notification",
        	tabName: 'settings'
        }
    ];

    $rootScope.preventRoute = false;
    $rootScope.$on('$locationChangeStart', function($event) {
        if ($rootScope.preventRoute ) {
            $event.preventDefault();
        }
    });

    $rootScope.currentUser = window.currentUser ? window.currentUser : '';
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        var is_firefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
        if (is_firefox) {
            var favicon = document.getElementById("favicon");
            if (favicon) {
                var parent = favicon.parentNode;
                parent.removeChild(favicon);
                parent.appendChild(favicon);
            }
        }
    });

	var taskHeartBeater = Scheduler.fixedDelay(TASK_HEARTBEAT_TIME, function () {
		var currentTaskIds = [];

		var logBrowserCache = smuCacheService.getData(CACHE_KEY_LOG_BROWSER);
		if (logBrowserCache && logBrowserCache.currentTask && logBrowserCache.currentTask.id) {
			currentTaskIds.push(logBrowserCache.currentTask.id);
		}

		var symptomCollectCache = smuCacheService.getData(CACHE_KEY_SYMPTOM_COLLECTOR);
		if (symptomCollectCache && symptomCollectCache.currentTask && symptomCollectCache.currentTask.id) {
			currentTaskIds.push(symptomCollectCache.currentTask.id);
		}

		if (currentTaskIds.length == 0) {
			return;
		}

		var semaphore = Scheduler.semaphore();
		return sendHeartBeat(currentTaskIds, semaphore);
	});

	function sendHeartBeat(taskIds, semaphore) {
		if (taskIds == null) {
			return null;
		}
        $http.post("rest/heartbeat-task?taskIds=" + taskIds)
            .then(function () {
            })["finally"](function () {
            semaphore && semaphore.release();
        });

		return semaphore;
	}

});