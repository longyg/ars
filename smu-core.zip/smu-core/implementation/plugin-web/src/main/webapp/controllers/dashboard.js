smuApp.controller("dashboardController", function ($scope, $http, $interval, createNotification) {
    var phcStatusUpdateInterval = 5000;
    var alarmUpdateInterval = 5000;
    var summaryUpdateInterval = 5000;
    
    $scope.notification = createNotification();
    $scope.componentsLoaded = false;
    $scope.alarmStatistics = {criticalCount: 0, majorCount: 0, minorCount: 0};

    $scope.latestResult = {totalTests: 0, failedTests: 0, updateTime: new Date(), valid: false};

    $scope.DataUpdater={
    	phcInterval:null,
    	alarmInterval:null
    };

    var layerOthers = {
        displayName: 'Others',
        componentRefs: [
            {
                displayName: 'Unmapped',
                component: {
                    id: 'unmapped',
                    children: []
                }
            }
        ]
    };

    var addUnmappedComponentView = function() {
        $scope.componentView.layers.push(layerOthers);
    };

    var refreshAlarmSummaries = function () {
        $http.get("rest/dashboard/internal-alarm-summaries")
            .then(function (response) {
                $scope.notification.hide("tag-alarm-summaries");
                $scope.internalAlarmSummaries = response.data;
            }, function (response) {
                if (response.status == 0) {
                    return;
                }

                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to fetch alarm due to " + reason + ".", "tag-alarm-summaries");
            });
    };

    $scope.totalAlarms = function (componentId) {
        if ($scope.internalAlarmSummaries && $scope.internalAlarmSummaries[componentId]) {
            return $scope.internalAlarmSummaries[componentId].criticalCount +
                $scope.internalAlarmSummaries[componentId].majorCount +
                $scope.internalAlarmSummaries[componentId].minorCount;
        } else {
            return 0;
        }
    };

    $scope.loadDashboard = function () {
        $http.get("rest/dashboard/component-view")
            .then(function (response) {
                $scope.componentsLoaded = true;
                $scope.notification.hide("tag-component-view");
                $scope.componentView = response.data;
                addUnmappedComponentView();
                refreshAlarmSummaries();
            }, function (response) {
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to load components due to " + reason + ".", "tag-component-view");
                $scope.componentsLoaded = true;
            });
    };
    

    $scope.getInternalAlarmCount = function (componentId, severity) {
        if ($scope.internalAlarmSummaries) {
            var summary = $scope.internalAlarmSummaries[componentId];
            if (summary) {
                var count = summary[severity + "Count"];
                if (count) {
                    return count;
                }
            }
        }
        return 0;
    };

    $scope.updatePHCStatistics = function () {
        $http.get('rest/phc/latest-result').then(function (response) {
            $scope.latestResult = response.data;
            $scope.latestResult['valid'] = true;
        }, function() {});
    };

    $scope.showFMAccessNotice = false;
    $scope.updateAlarmStatistics = function () {
        $http.get('rest/alarms/statistics')
        	.then(function (response) {
        		$scope.alarmStatistics = response.data;
        	},function(){});
    };

    $scope.DataUpdater.phcInterval = $interval($scope.updatePHCStatistics, phcStatusUpdateInterval);
    $scope.DataUpdater.alarmInterval = $interval($scope.updateAlarmStatistics, alarmUpdateInterval);
    $scope.DataUpdater.summaryInterval = $interval(refreshAlarmSummaries, summaryUpdateInterval);

    $scope.loadDashboard();

    $scope.$on('$destroy', function() {
    	$interval.cancel($scope.DataUpdater.phcInterval);
    	$interval.cancel($scope.DataUpdater.alarmInterval);
    	$interval.cancel($scope.DataUpdater.summaryInterval);
    });
});
