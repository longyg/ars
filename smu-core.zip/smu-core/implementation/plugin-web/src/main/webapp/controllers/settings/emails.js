smuApp.controller("emailSettingsController", function ($q, $http, $rootScope, $scope, $location, $timeout, $element, createNotification) {
	$scope.notification = createNotification();
	$scope.emailSetting = {};
	$scope.emails = [];
	$scope.emailSetting.smtpServerPort = 25;
	$scope.showUnsavedChangeDialog = false;
	$scope.resendIntervalSelector = null;

	$scope.resendInitiator = $q(function (resolve, reject) {
		if($scope.resendIntervalSelector == null) {
			require(['jquery', 'wulf/dropdowns'], function ($) {
				$scope.resendIntervalSelector = $('.resend-interval-select');
				$scope.resendIntervalSelector.adaptiveSelectlist();
				$scope.resendIntervalSelector.on('changed.fu.selectlist', function () {
					var item = $scope.resendIntervalSelector.selectlist('selectedItem');
					$scope.emailSetting.resendInterval = item.value;
					$scope.formChange();
					$scope.$apply();
				});

				resolve($scope.resendIntervalSelector);
			});
			return;
		}

		resolve($scope.resendIntervalSelector);
	});

	$scope.readSettings = function() {
		$http
			.get("rest/email-setting")
			.then(function (response) {
				$scope.emailSetting = response.data;
				if (!$scope.emailSetting.smtpServerPort) {
					$scope.emailSetting.smtpServerPort = 25;
				}
				$scope.emails = ($scope.emailSetting.targetAddresses || []).map(function (targetAddress) {
					return {value: targetAddress};
					$scope.$apply();
				});
				$scope.resendInitiator.then(function (selector) {
					selector.selectlist('selectByValue', $scope.emailSetting.resendInterval);
				});
			}, function (response) {
				if (response.status === 0) {
					return;
				}
                var reason = 'unknown reason';
                if (response.data && response.data.errorCategory === "database") {
                    reason = "database error";
                } else if (response.data && response.data.error) {
                    reason = response.data.error;
                }
                else if (response.statusText) {
                    reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                }
                else if (response.status === -1) {
                    reason = 'network unavailable';
                }

                $scope.notification.error("Unable to fetch email notification configuration due to " + reason + ".");
			});
	};
	$scope.readSettings();

    $scope.keyup = function(e) {
    	if (e.keyCode == 13) {
    		$scope.save();
    	}
    };
    $scope.save = function () {
    	if ($scope.emailSettingForm.$pristine || $scope.emailSettingForm.$invalid) {
    		return;
    	}
    	
        $scope.emailSetting.targetAddresses = $scope.emails.map(function (email) {
            return email.value;
        });

        $http
            .post("rest/email-setting", $scope.emailSetting)
            .then(function (response) {
                    $scope.notification.ok('The modifications have been saved.');
                    $scope.formClean();
                }, function (response) {
                    var reason = 'unknown reason';
                    if (response.data && response.data.errorCategory === "database") {
                        reason = "database error";
                    } else if (response.data && response.data.error) {
                        reason = response.data.error;
                    }
                    else if (response.statusText) {
                        reason = 'HTTP error: ' + response.status + ' ' + response.statusText;
                    }
                    else if (response.status === -1) {
                        reason = 'network unavailable';
                    }

                    $scope.notification.error("Unable to save email notification configuration due to " + reason);
                }
            );
    };

    $scope.confirmIfUncheck = function() {
        if(!$scope.emailSetting.alarmRule.criticalEnabled){
            $scope.warningNotificationVisible = true;
            $scope.emailSetting.alarmRule.criticalEnabled = true;
            setTimeout(function() { $element.find('.dialog-button')[0].focus();}, 50);
        }else{
			$scope.formChange();
        }
    };

    $scope.closeWarningNotificationDialog = function(buttonIndex){
		if (buttonIndex === 1) {
        	$scope.emailSetting.alarmRule.criticalEnabled = false;
			$scope.formChange();
		}
        $scope.warningNotificationVisible = false;
    };

    $scope.formChange = function () {
        $scope.emailSettingForm.$pristine = false;
        $scope.emailSettingForm.$dirty = true;
    };

    $scope.formClean = function () {
        $scope.emailSettingForm.$pristine = true;
        $scope.emailSettingForm.$dirty = false;
    };
    
    $scope.allNotificationsDisabled = function () {
    	return (!$scope.emailSetting.alarmRule ||
				!$scope.emailSetting.alarmRule.criticalEnabled &&
				!$scope.emailSetting.alarmRule.majorEnabled &&
				!$scope.emailSetting.alarmRule.minorEnabled) &&
				!$scope.emailSetting.enabledForPHCChecker;
    };
    
    window.onbeforeunload = function () {
        if (!$scope.emailSettingForm.$pristine) {
        	return "You have unsaved configurations.";
        }
    };

	$scope.leaveConfirmed = false;
	$scope.whereToGo = '';
    $scope.leaveTip = "You have unsaved configurations. \n Are you sure you want to leave this page?";
    var routeListener = $rootScope.$on('$routeChangeStart', function (event, next, current) {
    	if (current.templateUrl
            && current.templateUrl.toString() == "pages/email-settings.tpl.html"
            && next.templateUrl != current.templateUrl
            && $scope.emailSetting != null) {

            if (!$scope.emailSettingForm.$pristine) {
				if ($scope.leaveConfirmed) {
					return;
				}

				$scope.whereToGo = next.$$route.originalPath;
				var params = '';
				for (var p in next.params) {
					params += p;
					var value = next[p];
					params += (typeof(value) == 'undefined') ? '' : ('=' + value);
					params += '&';
				}
				if (params) {
					$scope.whereToGo += '?' + params.substring(0, params.length - 1);
				}

				$scope.showUnsavedChangeDialog  = true;
                setTimeout(function() { $element.find('.btn-confirm-stay')[0].focus();}, 50);
				event.preventDefault();
            }
        }
    });

	$scope.stayOnPage = function() {
		$scope.showUnsavedChangeDialog = false;
		$scope.leaveConfirmed = false;
	};

	$scope.leavePage = function() {
		$scope.showUnsavedChangeDialog = false;
		$scope.leaveConfirmed = true;
		$location.url($scope.whereToGo);
	};
    $scope.$on('$destroy', routeListener);
    
    $("div.resend-interval-select").find("button").keyup(function(e) {
    	if (e.keyCode == 13) {
    		e.stopPropagation();
    	}
    });
});
