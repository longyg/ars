var smuApp = angular.module("smuApp", ["ngRoute", "nokia.wulf", "angularMoment", "ngAnimate", "CacheService"]);

smuApp.config(function ($routeProvider,$locationProvider,$httpProvider) {
	$locationProvider.hashPrefix('');
    $routeProvider
        .when("/dashboard", {
            templateUrl: "pages/dashboard.tpl.html",
            tab: 'dashboard',
            helperUri:"Dashboard"
        })
        .when("/settings/email-notification", {
            templateUrl: "pages/email-settings.tpl.html",
            tab: 'settings',
            helperUri:"Mail_Notification"
        })
        .when("/phc", {
            templateUrl: "pages/phc.tpl.html",
            tab: 'phc',
            helperUri:"PHC_Report"
        })
        .when("/alarms", {
            templateUrl: "pages/alarms.tpl.html",
            tab: 'alarms',
            helperUri:"Internal_Alarm"
        })
        .when("/log-browser", {
        	templateUrl: "pages/log-browser.tpl.html",
        	tab: 'troubleshooting',
        	helperUri:"Search_Logs"
        })
        .when("/conf-file", {
        	templateUrl: "pages/conf-file.tpl.html",
        	tab: 'confchecker'
        })
        .when("/conf-checker", {
        	templateUrl: "pages/conf-checker.tpl.html",
        	tab: 'confchecker',
        	helperUri:"Configuration_Changes"
        })
		.when("/symptom-collector", {
			templateUrl: "pages/symption-collector.tpl.html",
			tab: 'troubleshooting',
            helperUri:"Symptom_Collection"
		})
        .otherwise({
            redirectTo: "/dashboard",
            tab: 'dashboard',
            helperUri:"System_Monitoring_Overview"
        });
});



(function() {
	
	var momentFormat = function(format) {
		if (!format) {
			return 'YYYY-MM-DD HH:mm:ss';
		}
		return format.replace(/y/g, 'Y').replace(/d/g, 'D');
	};
	
	smuApp.factory("serverInfo", function() {
		return {
			parseNoZoneDate: function(text, format) {
				format = momentFormat(format);
                // Simple check to avoid the bug of Moment.js which create a bad zone moment object without exception
				if (text.length != format.length) {
					throw new Error(text + " is not valid value of format " + format);
				}
                return moment(text).utcOffset(window.serverUtcOffset / 60).toDate();
			}
		};
	});

    smuApp.factory('smuCacheService', function(CacheService) {
        return {
            getData: function(key) {
                var data = CacheService.get(key);
                if (data) {
                    return data;
                }
                return null;
            },
            setData: function(key, value) {
                CacheService.put(key, value);
            }
        };
    });
	
	smuApp.filter('serverDate', function() {
		return function(date, format) {
			format = momentFormat(format);
			return moment(date).utcOffset(window.serverUtcOffset / 60).format(format);
		};
	});
})();

smuApp.filter('capitalize', function() {
    return function(input) {
        return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    };
});

smuApp.filter('limitTo99', function () {
    return function(num) {
        if (typeof(num) == 'undefined') {
            return 0;
        }
        return num > 99 ? '99+' : "" + num;
    };
});

smuApp.filter('smuTime', function($filter) {
    return function (timestamp) {
        return $filter('amDateFormat')(timestamp, "YYYY-MM-DD HH:mm:ss");
    }
});

smuApp.filter('smuDuration',function(){
	return function (miliseconds) {
        miliseconds = miliseconds || 0;
        var seconds = Math.ceil(miliseconds / 1000);
        var hoursDiff = Math.floor(seconds / 3600);
        var minutesDiff = Math.floor((seconds / 60) % 60);
        var secondsDiff = seconds % 60;
        var segments = [];
        if (hoursDiff) {
            segments.push(hoursDiff + ((hoursDiff > 1) ? " hours" : " hour"));
        }
        if (minutesDiff) {
            segments.push(minutesDiff + ((minutesDiff > 1) ? " minutes" : " minute"));
        }
        if (secondsDiff) {
            segments.push(secondsDiff + ((secondsDiff > 1) ? " seconds" : " second"));
        }

        if (!segments.length) {
            return '0 second'
        }

        return segments.join(" ");
	};
});

smuApp.directive('handleEnter', function(){
    return function(scope, element, attrs) {
        element.bind("keydown keypress", function(event){
            if(event.which == 13 || event.which == 32) {
                scope.$eval(attrs.handleEnter);
                event.preventDefault();
            }
        });
    }
});
