angular.module('CacheService', ['ng'])
       .factory('CacheService', function ($cacheFactory) {
           return $cacheFactory('smuCache');
       })

var CACHE_KEY_LOG_BROWSER = "LOG_BROWSER";
var CACHE_KEY_SYMPTOM_COLLECTOR = "SYMPTOM_COLLECTOR";