package com.nokia.oss.smu.alarm.internal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.nokia.oss.smu.alarm.AlarmMapping;
import com.nokia.oss.smu.alarm.base.FakeAlarm;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.base.BaseComponent;
import com.nokia.oss.smu.core.component.XmlComponent;

public class AlarmMappingConfigParserTest {

    private List<Component> components;
    private AlarmMappingConfigParser parser;
    private BaseComponent niceComponent;
    private XmlComponent compositeComponent;
    private XmlComponent subc1;
    private XmlComponent subc2;

    @Before
    public void setUp() {
        parser = new AlarmMappingConfigParser();
        components = new ArrayList<Component>();

        niceComponent = new BaseComponent() {
        };
        niceComponent.setId("nice-component");
        components.add(niceComponent);

        subc1 = new XmlComponent("name1");
        subc1.setId("subc1");
        subc2 = new XmlComponent("name2");
        subc2.setId("subc2");
        XmlComponent[] children = { subc1, subc2 };
        compositeComponent = new XmlComponent("name3", children);
        compositeComponent.setId("root-c");
        components.add(compositeComponent);
    }

    @After
    public void tearDown() {
        AlarmMappingConfigParserAspect.handler = null;
    }

    @Test
    public void rangeMappingShouldBeParsedIfRangeIsConfigured() throws XmlParseException {
        String str = "    <mapping>\n" +
                "        <range>[9000,9499]</range>\n" +
                "        <component id=\"nice-component\"></component>\n" +
                "    </mapping>\n";

        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);

        assertEquals(1, mappings.size());

        AlarmMapping mapping = mappings.get(0);
        assertTrue(AlarmMapping.RangeMapping.class.isInstance(mapping));

        FakeAlarm alarm = new FakeAlarm();
        alarm.setNumber(9000);
        assertEquals(niceComponent, mapping.mapComponent(alarm));
    }

    @Test
    public void whenGivenDnMappingDnMappingShouldReturned() throws XmlParseException {
        String str = "    <mapping>\n" +
                "        <dn>PLMN-PLMN/NETACT-1/NICE-1</dn>\n" +
                "        <component id=\"nice-component\"></component>\n" +
                "    </mapping>\n";

        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);

        assertEquals(1, mappings.size());

        AlarmMapping mapping = mappings.get(0);

        assertTrue(AlarmMapping.DnMapping.class.isInstance(mapping));
        FakeAlarm alarm = new FakeAlarm();
        alarm.setDistinguishName("PLMN-PLMN/NETACT-1/NICE-1");
        assertEquals(niceComponent, mapping.mapComponent(alarm));
    }

    @Test
    public void whenGivenTextMathMappingTextMappingShouldBeReturned() throws XmlParseException {
        String str = "<mapping>\n" +
                "<text-match>HELLO $1, NICE TO MEET YOU</text-match>" +
                "<component id=\"nice-component\" />" +
                "</mapping>";
        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);

        Assert.assertEquals(1, mappings.size());
        AlarmMapping mapping = mappings.get(0);
        assertTrue(AlarmMapping.TextMapping.class.isInstance(mapping));
        assertEquals("HELLO $1, NICE TO MEET YOU", mapping.getValue());
    }

    @Test
    public void validExpressionMappingShouldBeParsedCorrectly() throws XmlParseException {
        String str = "<mapping>\n" +
                "<text-match>SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK $2!</text-match>\n" +
                "<component>\n" +
                "<match expression=\"$1=NICE\" component-id=\"nice-component\"/>\n" +
                "<match expression=\"$1=SUB1\" component-id=\"subc1\"/>\n" +
                "</component>\n" +
                "</mapping>";
        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);

        Assert.assertEquals(1, mappings.size());
        AlarmMapping mapping = mappings.get(0);
        assertTrue(AlarmMapping.TextMapping.class.isInstance(mapping));

        FakeAlarm alarm = new FakeAlarm();

        alarm.setTitle("SERVICE NICE IS NOT AVAILABLE, YOU MAY CHECK logs!");
        assertEquals(niceComponent, mapping.mapComponent(alarm));

        alarm.setTitle("SERVICE SUB1 IS NOT AVAILABLE, YOU MAY CHECK anything!");
        assertEquals(subc1, mapping.mapComponent(alarm));
    }

    @Test(expected = XmlParseException.class)
    public void parseExceptionShouldBeThrownWhenBothIdAndMatchListAreMissing() throws XmlParseException {
        String str = "<mapping>\n" +
                "<text-match>dumb text</text-match>\n" +
                "<component/>" +
                "</mapping>";
        InputStream is = wrapMappingsAsInputStream(str);
        parser.loadAlarmMappingRules(components, is);
    }

    @Test
    public void givenRedundantComponentIdBeforeMatchList_returnsValidTextMapping() throws XmlParseException {
        String str = "<mapping>\n" +
                "<text-match>SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK $2!</text-match>\n" +
                "<component id=\"nice-component\">\n" +
                "<match expression=\"$1=NICE\" component-id=\"nice-component\"/>\n" +
                "</component>\n" +
                "</mapping>";
        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);

        assertEquals(mappings.size(), 1);
        AlarmMapping mapping = mappings.get(0);
        assertTrue(AlarmMapping.TextMapping.class.isInstance(mapping));
        FakeAlarm alarm = new FakeAlarm();
        alarm.setTitle("SERVICE NICE IS NOT AVAILABLE, YOU MAY CHECK logs!");
        assertEquals(niceComponent, mapping.mapComponent(alarm));
    }

    @Test
    public void mappingOfCompositeComponentShouldBeParsedCorrectly() throws XmlParseException {
        FakeAlarm alarm = new FakeAlarm();
        String str = "    <mapping>\n" +
                "        <range>[9000,9499]</range>\n" +
                "        <component id=\"subc1\"></component>\n" +
                "    </mapping>\n" +
                "    <mapping>\n" +
                "        <range>[9500,9999]</range>\n" +
                "        <component id=\"subc2\"></component>\n" +
                "    </mapping>\n";

        InputStream is = wrapMappingsAsInputStream(str);
        List<AlarmMapping> mappings = parser.loadAlarmMappingRules(components, is);
        assertEquals(2, mappings.size());

        AlarmMapping mapping = mappings.get(0);
        assertTrue(AlarmMapping.RangeMapping.class.isInstance(mapping));
        alarm.setNumber(9000);
        assertEquals(subc1, mapping.mapComponent(alarm));

        mapping = mappings.get(1);
        assertTrue(AlarmMapping.RangeMapping.class.isInstance(mapping));
        alarm.setNumber(9500);
        assertEquals(subc2, mapping.mapComponent(alarm));
    }

    @Test(expected = XmlParseException.class)
    public void whenGivenComponentListHasNoComponentReferredInMappingExceptionShouldBeThrown()
            throws XmlParseException {
        String mapping = "    <mapping>\n" +
                "        <range>[9000,9499]</range>\n" +
                "        <component id=\"not-exist\"></component>\n" +
                "    </mapping>\n";

        InputStream is = wrapMappingsAsInputStream(mapping);
        parser.loadAlarmMappingRules(components, is);
    }

    @Test(expected = XmlParseException.class)
    public void whenGivenEmptyInputTemplateParseExceptionShouldBeThrown() throws XmlParseException {
        String emptyString = "";
        InputStream is = new ByteArrayInputStream(emptyString.getBytes());
        parser.loadAlarmMappingRules(components, is);
    }

    @Test(expected = XmlParseException.class)
    public void recoverableErrorWhenTagNotDefinedInSchema() throws XmlParseException {
        String str = "<mapping>\n" +
                "<not-valid-tag>not such tag</not-valid-tag>" +
                "<component id=\"nice-component\" />" +
                "</mapping>";
        InputStream is = wrapMappingsAsInputStream(str);
        parser.loadAlarmMappingRules(components, is);
    }

    @Test(expected = XmlParseException.class)
    public void recoverableErrorWhenTNSIsWrong() throws XmlParseException {
        String str = "    <mapping>\n" +
                "        <dn>NOINST/HASINST-123/214</dn>\n" +
                "        <component id=\"nice-component\"></component>\n" +
                "    </mapping>\n";

        String text = "<alarm-mappings xmlns=\"http://www.unknown.com/smu/alarm-mappings\">\n" +
                str +
                "</alarm-mappings>";
        InputStream is = new ByteArrayInputStream(text.getBytes());
        parser.loadAlarmMappingRules(components, is);
    }

    protected InputStream wrapMappingsAsInputStream(String mapping) {
        String text = "<alarm-mappings xmlns=\"http://www.nsn.com/smu/alarm-mappings\">\n" +
                mapping +
                "</alarm-mappings>";
        return new ByteArrayInputStream(text.getBytes());
    }
}
