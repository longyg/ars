package com.nokia.oss.smu.alarm.base;

import java.util.Calendar;
import java.util.Map;

import com.nokia.oss.smu.alarm.AlarmSeverity;
import com.nokia.oss.smu.alarm.Alarmable;

public class FakeAlarm implements Alarmable {
	
	private Long id;

    private long number;
    
    private String title;

    private String distinguishName;

    private Calendar alarmTime;

    private AlarmSeverity severity;
    
    private String notificationId;
    
    private String ventType;
    
    private Map<String, String> additionalAttributes;
    
    private String acknowledgedBy;
    
    private Calendar ackTime;
    
    private String clearedBy;
    
    private Calendar clearTime;
    
    private String eventType;
    
    public FakeAlarm() {
    	this.alarmTime = Calendar.getInstance();
    }

	public FakeAlarm(long number, String title, AlarmSeverity severity, String distinguishName) {
		this();
		this.number = number;
		this.title = title;
		this.severity = severity;
		this.distinguishName = distinguishName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDistinguishName() {
		return distinguishName;
	}

	public void setDistinguishName(String distinguishName) {
		this.distinguishName = distinguishName;
	}

	public Calendar getAlarmTime() {
		return alarmTime;
	}

	public void setAlarmTime(Calendar alarmTime) {
		this.alarmTime = alarmTime;
	}

	public AlarmSeverity getSeverity() {
		return severity;
	}

	public void setSeverity(AlarmSeverity severity) {
		this.severity = severity;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getVentType() {
		return ventType;
	}

	public void setVentType(String ventType) {
		this.ventType = ventType;
	}

	public Map<String, String> getAdditionalAttributes() {
		return additionalAttributes;
	}

	public void setAdditionalAttributes(Map<String, String> additionalAttributes) {
		this.additionalAttributes = additionalAttributes;
	}

	public String getAcknowledgedBy() {
		return acknowledgedBy;
	}

	public void setAcknowledgedBy(String acknowledgedBy) {
		this.acknowledgedBy = acknowledgedBy;
	}

	public Calendar getAckTime() {
		return ackTime;
	}

	public void setAckTime(Calendar ackTime) {
		this.ackTime = ackTime;
	}

	public String getClearedBy() {
		return clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	public Calendar getClearTime() {
		return clearTime;
	}

	public void setClearTime(Calendar clearTime) {
		this.clearTime = clearTime;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
}