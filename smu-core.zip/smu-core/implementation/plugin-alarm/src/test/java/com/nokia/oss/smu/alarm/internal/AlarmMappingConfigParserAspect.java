package com.nokia.oss.smu.alarm.internal;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import java.util.logging.Logger;

@Aspect
public class AlarmMappingConfigParserAspect {

    public static volatile Handler handler;

    public interface Handler {
        void warning(Logger that, String message);
    }

    @Around(value = "call(void java.util.logging.Logger.warning(java.lang.String)) && "
            + "target(that) && "
            + "args(message) && "
            + "("
            + "    within(com.nokia.oss.smu.alarm.internal.AlarmMappingConfigParser) ||"
            + "    within(com.nokia.oss.smu.alarm.internal.AlarmMappingConfigParser.*)"
            + ")",
            argNames = "that, message")
    public void loggerWarning(ProceedingJoinPoint pjp, Logger that, String message) throws Throwable {
        Handler h = handler;
        if (h != null) {
            h.warning(that, message);
        } else {
            pjp.proceed();
        }
    }
}
