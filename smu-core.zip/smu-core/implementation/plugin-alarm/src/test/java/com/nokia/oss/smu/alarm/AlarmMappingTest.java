package com.nokia.oss.smu.alarm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.nokia.oss.smu.alarm.AlarmMapping;
import com.nokia.oss.smu.alarm.base.FakeAlarm;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.base.BaseComponent;

public class AlarmMappingTest {

    private BaseComponent component;
    private AlarmMapping.RangeMapping rangeMapping;
    private AlarmMapping.DnMapping dnMapping;
    private AlarmMapping.TextMapping textMapping;
    private FakeAlarm alarm;

    @Before
    public void setUp() {
        component = new BaseComponent() {
        };
        component.setId("nice-component");
        alarm = new FakeAlarm();
        rangeMapping = new AlarmMapping.RangeMapping();
        rangeMapping.addComponent(component);
        dnMapping = new AlarmMapping.DnMapping();
        dnMapping.addComponent(component);
        textMapping = new AlarmMapping.TextMapping();
        textMapping.addComponent(component);
    }

    @Test
    public void whenGivenRangeMappingCoverComponentsIdComponentShouldReturn() {
        Set<String> rangeSetCoversNumber = new HashSet<String>();
        alarm.setNumber(100);
        rangeSetCoversNumber.add("100");
        rangeSetCoversNumber.add("100, 101");
        rangeSetCoversNumber.add("[100, 100]");
        rangeSetCoversNumber.add("[100, 101], [1, 99]");

        for (String range : rangeSetCoversNumber) {
            rangeMapping.setValue(range);
            assertEquals(component, rangeMapping.mapComponent(alarm));
        }
    }

    @Test
    public void whenGivenRangeNotCoverComponentIdsNullShouldBeReturned() {
        Set<String> rangeSetNotCoversNumber = new HashSet<String>();
        alarm.setNumber(100);
        rangeSetNotCoversNumber.add("99");
        rangeSetNotCoversNumber.add("99, 101");
        rangeSetNotCoversNumber.add("[1, 99]");
        rangeSetNotCoversNumber.add("[101, 102]");

        for (String range : rangeSetNotCoversNumber) {
            rangeMapping.setValue(range);
            assertNull(rangeMapping.mapComponent(alarm));
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void whenNonNumberGivenToRangeMappingExceptionShouldBeThrown() {
        rangeMapping.setValue("[abc, 123]");
        rangeMapping.mapComponent(alarm);
    }

    @Test
    public void whenGivenCompleteStringExactMatchComponentShouldGiven() {
        dnMapping.setValue("PLMN-PLMN/NETACT-1234/EXACT-INSTANCE-1234");
        alarm.setDistinguishName("PLMN-PLMN/NETACT-1234/EXACT-INSTANCE-1234");

        assertEquals(component, dnMapping.mapComponent(alarm));
    }

    @Test
    public void whenGivenStringHasNoWildcadButNotEqualShouldGetNull() {
        dnMapping.setValue("HI");
        alarm.setDistinguishName("IAMDIFF");

        assertNotEquals(component, dnMapping.mapComponent(alarm));
    }

    @Test
    public void whenGivenRegularExpressionStringMatchedComponentShouldBeReturn() {
        dnMapping.setValue("HELLO.*");
        alarm.setDistinguishName("HELLO-WORLD");
        assertEquals(component, dnMapping.mapComponent(alarm));
    }

    @Test
    public void givenTextPatternWithPlaceholder_alarmWithMatchingTitleShouldBeMapped() {
        textMapping.setValue("SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK");
        Map<String, Component> matches = new HashMap<String, Component>();
        BaseComponent otherComponent1 = new BaseComponent() {
        };
        BaseComponent otherComponent2 = new BaseComponent() {
        };

        matches.put("$1=DISK", otherComponent1);
        matches.put("$1=NETWORK", otherComponent2);

        textMapping.setMatchList(matches);

        alarm.setTitle("SERVICE DISK IS NOT AVAILABLE, YOU MAY CHECK");
        assertEquals(otherComponent1, textMapping.mapComponent(alarm));

        alarm.setTitle("SERVICE NETWORK IS NOT AVAILABLE, YOU MAY CHECK");
        assertEquals(otherComponent2, textMapping.mapComponent(alarm));
    }

    @Test
    public void givenTextPatternWithAndGroup_alarmWithMatchingTitleShouldBeMapped() {
        textMapping.setValue("SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK $2!");
        Map<String, Component> matches = new HashMap<String, Component>();
        BaseComponent oracle = new BaseComponent() {
        };
        matches.put("$1=DATABASE&&$2=oracle", oracle);
        textMapping.setMatchList(matches);

        alarm.setTitle("SERVICE DATABASE IS NOT AVAILABLE, YOU MAY CHECK oracle!");
        assertEquals(oracle, textMapping.mapComponent(alarm));
    }

    @Test
    public void givenTextPatternWithOrGroup_alarmWithMatchingTitleShouldBeMapped() {
        textMapping.setValue("SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK $2!");
        Map<String, Component> matches = new HashMap<String, Component>();
        BaseComponent oracle = new BaseComponent() {
        };
        matches.put("$1=DATABASE||$2=oracle", oracle);
        textMapping.setMatchList(matches);

        alarm.setTitle("SERVICE DB IS NOT AVAILABLE, YOU MAY CHECK oracle!");
        assertEquals(oracle, textMapping.mapComponent(alarm));

        alarm.setTitle("SERVICE DATABASE IS NOT AVAILABLE, YOU MAY CHECK mysql!");
        assertEquals(oracle, textMapping.mapComponent(alarm));
    }

    @Test
    public void whenNoMathPairSpecifiedComponentBoundToMappingShouldBeReturned() {
        textMapping.setValue("SERVICE $1 IS NOT AVAILABLE, YOU MAY CHECK $2!");
        alarm.setTitle("SERVICE DATABASE IS NOT AVAILABLE, YOU MAY CHECK DATABASE LOG!");

        assertEquals(component, textMapping.mapComponent(alarm));
    }
}
