package com.nokia.oss.smu.alarm;

import java.util.Calendar;
import java.util.Map;

public interface Alarmable {
	
	Object getId();

    long getNumber();

    String getTitle();

    String getDistinguishName();

    Calendar getAlarmTime();

    AlarmSeverity getSeverity();
    
    String getNotificationId();
    
    String getEventType();
    
    Map<String, String> getAdditionalAttributes();
    
    String getAcknowledgedBy();
    
    Calendar getAckTime();
    
    String getClearedBy();
    
    Calendar getClearTime();
}
