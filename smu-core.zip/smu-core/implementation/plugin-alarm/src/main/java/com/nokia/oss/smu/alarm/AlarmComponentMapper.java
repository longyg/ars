package com.nokia.oss.smu.alarm;

import com.nokia.oss.smu.core.Component;

public interface AlarmComponentMapper {
    Component mapComponent(Alarmable alarmable);
}
