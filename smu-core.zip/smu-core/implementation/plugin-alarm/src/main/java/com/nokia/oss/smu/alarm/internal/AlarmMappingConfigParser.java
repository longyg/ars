package com.nokia.oss.smu.alarm.internal;

import com.nokia.oss.smu.alarm.AlarmMapping;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.CompositeComponent;
import com.nokia.oss.smu.core.XmlParseException;
import com.nokia.oss.smu.core.component.XmlObjectParser;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import java.io.InputStream;
import java.util.*;
import java.util.logging.Logger;

public class AlarmMappingConfigParser extends XmlObjectParser {
    private static final Logger LOGGER = Logger.getLogger(AlarmMappingConfigParser.class.getName());

    public List<AlarmMapping> loadAlarmMappingRules(Collection<? extends Component> components, InputStream xmlStream)
            throws XmlParseException {
        InputStream xsdIS = AlarmMapping.class.getClassLoader().getResourceAsStream("alarm-mapping.xsd");
        AlarmMappingXmlHandler handler = new AlarmMappingXmlHandler(components);
        parse(xsdIS, handler, xmlStream);
        return handler.getMappings();
    }

    private class AlarmMappingXmlHandler extends DefaultHandler {
        private final Map<String, Component> id2Components;
        private List<AlarmMapping> mappings;
        private AlarmMapping currentMapping;
        private Component currentComponent;
        private HashMap<String, Component> matches;
        private StringBuilder content;

        public AlarmMappingXmlHandler(Collection<? extends Component> components) {
            id2Components = new HashMap<>();
            buildId2ComponentMap(components);
            mappings = new ArrayList<>();
        }

        private void buildId2ComponentMap(Collection<? extends Component> components) {
            for (Component c : components) {
                id2Components.put(c.getId(), c);
                if (c instanceof CompositeComponent) {
                    buildId2ComponentMap(((CompositeComponent) c).getChildren());
                }
            }
        }

        public List<AlarmMapping> getMappings() {
            return mappings;
        }

        @Override
        public void error(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void fatalError(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void startElement(String uri, String name, String qName, Attributes attributes) throws SAXException {
            if ("alarm-mappings".equals(name)) {
                // Its OK to found root element, and we do not have anything want from it.
                return;
            }

            // It is very important to clear content when meet a start element.
            this.content = null;

            if ("mapping".equals(name)) {
                currentMapping = null;
                currentComponent = null;
            } else if ("range".equals(name)) {
                currentMapping = new AlarmMapping.RangeMapping();
            } else if ("dn".equals(name)) {
                currentMapping = new AlarmMapping.DnMapping();
            } else if ("text-match".equals(name)) {
                AlarmMapping.TextMapping textMapping = new AlarmMapping.TextMapping();
                matches = new HashMap<String, Component>();
                textMapping.setMatchList(matches);
                currentMapping = textMapping;
            } else if ("component".equals(name)) {
                String id = attributes.getValue(XMLConstants.NULL_NS_URI, "id");
                // TODO: consider supporting multiple ids, e.g. 'nwi3-sbi,snmp-sbi'
                if (id != null) {
                    //If Id is not specified it means the match list will be defined later.
                    //The checking for case of both missing is in endElement of "component".
                    Component component = id2Components.get(id);
                    if (component == null) {
                        LOGGER.severe("Component id specified for mapping, but it cannot be found in component list");
                        throw new SAXException("Component id cannot be found in component list: " + id);
                    }
                    currentComponent = component;
                }
            } else if ("match".equals(name)) {
                String expression = attributes.getValue(XMLConstants.NULL_NS_URI, "expression");
                String componentId = attributes.getValue(XMLConstants.NULL_NS_URI, "component-id");
                if (expression != null && componentId != null) {
                    Component component = id2Components.get(componentId);
                    if (component != null) {
                        matches.put(expression, component);
                    }
                }
            }
        }

        @Override
        public void endElement(String uri, String name, String qName) throws SAXException {
            if ("mapping".equals(name)) {
                mappings.add(currentMapping);
            } else if ("range".equals(name) || "number".equals(name) || "dn".equals(name) || "text-match"
                    .equals(name)) {
                if (this.content != null) {
                    currentMapping.setValue(this.content.toString());
                }
            } else if ("component".equals(name)) {
                if (validMatchList()) {
                    if (validCurrentComponent()) {
                        LOGGER.warning("Redundant component id will be ignored when there is match list");
                    }
                } else if (validCurrentComponent()) {
                    currentMapping.addComponent(currentComponent);
                } else {
                    LOGGER.severe(
                            "Incomplete mapping rule: either of component id or match list should be specified for mapping");
                    throw new SAXException(
                            "Incomplete mapping rule: either of component id or match list should be specified for mapping");
                }
            }
        }

        public void characters(char ch[], int start, int length)
                throws SAXException {
            if (this.content == null) {
                this.content = new StringBuilder();
            }
            this.content.append(ch, start, length);
        }

        private boolean validMatchList() {
            return (matches != null && !matches.isEmpty());
        }

        private boolean validCurrentComponent() {
            return (currentComponent != null);
        }
    }
}
