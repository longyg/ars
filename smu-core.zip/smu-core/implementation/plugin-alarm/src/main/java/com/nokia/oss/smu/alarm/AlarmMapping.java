package com.nokia.oss.smu.alarm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.nokia.oss.smu.core.Component;

public abstract class AlarmMapping {

    protected String value;
    
    protected List<Component> components = new ArrayList<Component>();

    abstract public Component mapComponent(Alarmable alarmable);

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void addComponent(Component component) {
        components.add(component);
    }

    protected Component getOnlyComponent() {
        if (components.size() != 1) {
            throw new IllegalStateException(
                    "Mapping need to provide only one component, but there is no one, or many inside.");
        }

        return components.get(0);
    }

    class Range {
        private long min;
        private long max;

        public Range(long min, long max) {
            this.min = min;
            this.max = max;
        }

        public void setMin(long min) {
            this.min = min;
        }

        public long getMin() {
            return this.min;
        }

        public void setMax(long max) {
            this.max = max;
        }

        public long getMax() {
            return this.max;
        }

        private boolean covers(long number) {
            return (number == min) || (number == max) || number > min && number < max;
        }
    }

    public static class RangeMapping extends AlarmMapping {
        private List<Range> ranges = new ArrayList<Range>();
        private Set<Long> numbers = new HashSet<Long>();

        @Override
        public void setValue(String value) {
            parse(value.trim());
            super.setValue(value);
        }

        @Override
        public Component mapComponent(Alarmable alarmable) {
            final long number = alarmable.getNumber();
            if (isInRanges(number) || isInNumbers(number)) {
                return getOnlyComponent();
            }
            return null;
        }

        private boolean isInRanges(long number) {
            for (Range range : ranges) {
                if (range.covers(number)) {
                    return true;
                }
            }
            return false;
        }

        private boolean isInNumbers(long number) {
            return numbers.contains(number);
        }

        private void parse(String rangeString) {
            if (rangeString.length() < 1) {
                throw new IllegalArgumentException("Range string given is not in required format: " + rangeString);
            }
            String delim = ",";
            StringTokenizer tokenizer = new StringTokenizer(rangeString, delim);

            long min = 0, max = 0;
            ParseState state = ParseState.INITIAL;
            while (tokenizer.hasMoreTokens()) {
                String token = tokenizer.nextToken().trim();
                state = state.nextState(token);
                switch (state) {
                case INITIAL:
                    //do nothing
                    break;
                case RANGE_MIN:
                    min = parseRangeMin(token);
                    break;
                case RANGE_MAX:
                    max = parseRangeMax(token);
                    ranges.add(new Range(min, max));
                    break;
                case SINGLE_NUMBER:
                    numbers.add(parseLongInt(token));
                    break;
                case ERROR:
                    throw new IllegalArgumentException("Wrong token: " + token);
                default:
                    break;
                }
            }
        }

        private long parseRangeMin(String token) {
            return parseLongInt(token.substring(1));
        }

        private long parseRangeMax(String token) {
            String t = token.substring(0, token.length() - 1);
            return parseLongInt(t);
        }

        private long parseLongInt(String token) {
            try {
                return Long.valueOf(token);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Long integer is expected while the token is: " + token);
            }
        }

        enum ParseState {
            INITIAL {
                @Override
                public ParseState nextState(String token) {
                    return nextSection(token);
                }
            },
            RANGE_MIN {
                @Override
                public ParseState nextState(String token) {
                    if (matchesRangeEnd(token)) {
                        return RANGE_MAX;
                    } else {
                        return ERROR;
                    }
                }
            },
            RANGE_MAX {
                @Override
                public ParseState nextState(String token) {
                    return nextSection(token);
                }
            },
            SINGLE_NUMBER {
                @Override
                public ParseState nextState(String token) {
                    return nextSection(token);
                }
            },
            ERROR {
                @Override
                public ParseState nextState(String token) {
                    return ERROR;
                }
            };

            public abstract ParseState nextState(String token);

            protected ParseState nextSection(String token) {
                if (matchesRangeStart(token)) {
                    return RANGE_MIN;
                } else if (matchesNumber(token)) {
                    return SINGLE_NUMBER;
                } else {
                    return ERROR;
                }
            }

            protected boolean matchesRangeStart(String token) {
                return token.startsWith("[");
            }

            protected boolean matchesRangeEnd(String token) {
                return token.endsWith("]");
            }

            protected boolean matchesNumber(String token) {
                return Character.isDigit(token.charAt(0));
            }
        }
    }

    public static class DnMapping extends AlarmMapping {

        private Pattern dnPattern;

        public void setValue(String value) {
            super.setValue(value);
            dnPattern = Pattern.compile(value.trim());
        }

        @Override
        public Component mapComponent(Alarmable alarmable) {
            if (value == null || alarmable.getDistinguishName() == null) {
                return null;
            }

            if (value.equals(alarmable.getDistinguishName())) {
                return getOnlyComponent();
            }

            Matcher m = dnPattern.matcher(alarmable.getDistinguishName());
            if (m.matches()) {
                return getOnlyComponent();
            }

            return null;
        }
    }

    public static class TextMapping extends AlarmMapping {
        private Pattern pattern;
        private Map<String, Component> matchList;

        @Override
        public void setValue(String value) {
            super.setValue(value);
            int i = 1;
            while (value.contains("$" + i)) {
                value = value.replace("$" + i, "(.*)");
                i++;
            }

            pattern = Pattern.compile(value.trim());
        }

        @Override
        public Component mapComponent(Alarmable alarmable) {
            String title = alarmable.getTitle();
            if (title == null || title.isEmpty()) {
                return null;
            }

            Matcher matcher = pattern.matcher(title);
            if (matcher.matches()) {
                if (matchList == null || matchList.isEmpty()) {
                    return getOnlyComponent();
                }

                String[] capturedGroupStrings = new String[matcher.groupCount()];
                for (int i = 0; i < capturedGroupStrings.length; i++) {
                    capturedGroupStrings[i] = matcher.group(i + 1);
                }

                return matchGroups(capturedGroupStrings);
            }

            return null;
        }

        private Component matchGroups(String[] capturedGroupStrings) {
            for (Map.Entry<String, Component> pair : matchList.entrySet()) {
                String expression = pair.getKey();
                for (int i = 0; i < capturedGroupStrings.length; i++) {
                    String placeHolder = "\\$" + (i + 1);
                    expression = expression.replaceAll(placeHolder, capturedGroupStrings[i]);
                }

                if (evaluateAST(expression)) {
                    return pair.getValue();
                }
            }

            return null;
        }

        private boolean evaluateAST(String expression) {
            String[] orGroups = expression.split("\\|\\|");
            if (orGroups.length > 1) {
                for (String orGroup : orGroups) {
                    if (evaluateAST(orGroup)) {
                        return true;
                    }
                }
            }

            String[] andGroups = expression.split("\\&\\&");
            if (andGroups.length > 1) {
                boolean assumeTrue = true;
                for (String andGroup : andGroups) {
                    if (!evaluateAST(andGroup)) {
                        assumeTrue = false;
                        break;
                    }
                }

                if (andGroups.length > 0 && assumeTrue) {
                    return true;
                }
            }

            String[] equalPair = expression.split("=");
            if (equalPair.length == 2) {
                if (equalPair[0] == null || equalPair[1] == null) {
                    return false;
                }

                return equalPair[0].equals(equalPair[1]);
            }

            if (equalPair.length > 2) {
                throw new IllegalStateException("Wrong equal sign number: " + expression);
            }

            return false;
        }

        public void setMatchList(Map<String, Component> matches) {
            matchList = matches;
        }
    }
}
