package com.nokia.oss.smu.alarm.internal;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.nokia.oss.smu.alarm.AlarmComponentMapper;
import com.nokia.oss.smu.alarm.AlarmMapping;
import com.nokia.oss.smu.alarm.Alarmable;
import com.nokia.oss.smu.core.Component;
import com.nokia.oss.smu.core.XmlParseException;

public class RulesBasedAlarmComponentMapper implements AlarmComponentMapper {

    private static final Logger LOG = Logger.getLogger(RulesBasedAlarmComponentMapper.class.getName());

    private List<AlarmMapping> alarmMappings;

    private AlarmMappingConfigParser parser;

    public RulesBasedAlarmComponentMapper() {
        parser = new AlarmMappingConfigParser();
        alarmMappings = new ArrayList<AlarmMapping>();
    }

    @Override
    public Component mapComponent(Alarmable alarmable) {
        for (AlarmMapping alarmMapping : alarmMappings) {
            Component component = alarmMapping.mapComponent(alarmable);
            if (component != null) {
                return component;
            }
        }

        return null;
    }

    public void initializeMappings(Component rootComponent, InputStream mappingXml) {
        List<Component> oneComponentList = new ArrayList<Component>(1);
        oneComponentList.add(rootComponent);
        try {
            alarmMappings = parser.loadAlarmMappingRules(oneComponentList, mappingXml);
        } catch (XmlParseException ex) {
            LOG.log(Level.SEVERE, "Cannot load alarm mapping from template", ex);
        }
    }

}
