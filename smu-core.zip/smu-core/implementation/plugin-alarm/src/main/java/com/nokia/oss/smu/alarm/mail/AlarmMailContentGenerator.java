package com.nokia.oss.smu.alarm.mail;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.nokia.oss.smu.alarm.Alarmable;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

@Component
public class AlarmMailContentGenerator {

	private Configuration cfg;
	
	private static final String templateFile = "alarm-mail-content.ftl";
	
	@SuppressWarnings("deprecation")
    public AlarmMailContentGenerator() {
		cfg = new Configuration();
		cfg.setClassForTemplateLoading(this.getClass(), "/");
		cfg.setDefaultEncoding("UTF-8");
	}

	public String generateContent(
	        int maxCount,
	        List<? extends Alarmable> alarms) {
	    
	    int fullCount = alarms.size();
	    Collections.sort(alarms, new Comparator<Alarmable>() {
            @Override
            public int compare(Alarmable a, Alarmable b) {
               int cmp = b.getSeverity().ordinal() - a.getSeverity().ordinal();
               if (cmp != 0) {
                   return cmp;
               }
               return b.getAlarmTime().compareTo(a.getAlarmTime());
            }
	    });

		if (fullCount > maxCount) {
			alarms = alarms.subList(0, maxCount);
		}
	    
	    Map<String, Object> ftlValueMap = new HashMap<>();
	    ftlValueMap.put("maxCount", maxCount);
	    ftlValueMap.put("fullCount", fullCount);
	    ftlValueMap.put("currentTime", new Date());
	    ftlValueMap.put("alarms", alarms);
	    
		try {
			Template temp = cfg.getTemplate(templateFile);
			Writer strWriter = new StringWriter();
			temp.process(ftlValueMap, strWriter);
			return strWriter.toString();
		} catch (IOException | TemplateException e) {
			throw new AlarmMailException(e);
		}
	}
}
