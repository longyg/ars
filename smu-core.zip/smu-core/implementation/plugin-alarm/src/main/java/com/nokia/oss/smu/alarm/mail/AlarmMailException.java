package com.nokia.oss.smu.alarm.mail;

public class AlarmMailException extends RuntimeException {

	private static final long serialVersionUID = 3556712954123135364L;

	public AlarmMailException() {
        super();
    }

    public AlarmMailException(Throwable cause) {
        super(cause);
    }

    public AlarmMailException(String message) {
        super(message);
    }

    public AlarmMailException(String message, Throwable cause) {
        super(message, cause);
    }
}
