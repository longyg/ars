package com.nokia.oss.smu.alarm;

public class OperationException extends Exception {

	private static final long serialVersionUID = -3012835007164460584L;

	public OperationException(String message) {
        super(message);
    }

    public OperationException(String message, Throwable cause) {
        super(message, cause);
    }
}
