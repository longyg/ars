package com.nokia.oss.smu.alarm;

/*
 * Note: 
 * The order of the members should not be changed
 * because JPA use generate SQL which compares the ordinal of these members.
 */
public enum AlarmSeverity {
    
    INDETERMINATE,
    WARNING,
    MINOR,
    MAJOR,
    CRITICAL,
}
